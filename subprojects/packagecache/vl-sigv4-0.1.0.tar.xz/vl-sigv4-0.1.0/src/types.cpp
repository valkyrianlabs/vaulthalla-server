// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Valkyrian Labs LLC

#include "vl/sigv4/types.hpp"

#include "vl/sigv4/canonical.hpp"

namespace vl::sigv4 {

std::string CredentialScope::str() const { return credentialScope(date, region, service); }

std::string_view errorCodeName(const ErrorCode code) noexcept {
    switch (code) {
        case ErrorCode::None: return "None";
        case ErrorCode::MissingAuthorization: return "MissingAuthorization";
        case ErrorCode::AmbiguousAuthorization: return "AmbiguousAuthorization";
        case ErrorCode::UnsupportedAlgorithm: return "UnsupportedAlgorithm";
        case ErrorCode::MalformedAuthorization: return "MalformedAuthorization";
        case ErrorCode::InvalidCredentialScope: return "InvalidCredentialScope";
        case ErrorCode::UnsupportedService: return "UnsupportedService";
        case ErrorCode::RegionMismatch: return "RegionMismatch";
        case ErrorCode::InvalidExpires: return "InvalidExpires";
        case ErrorCode::ExpiresTooLarge: return "ExpiresTooLarge";
        case ErrorCode::MissingDate: return "MissingDate";
        case ErrorCode::InvalidDate: return "InvalidDate";
        case ErrorCode::ScopeDateMismatch: return "ScopeDateMismatch";
        case ErrorCode::RequestTimeTooSkewed: return "RequestTimeTooSkewed";
        case ErrorCode::PresignExpired: return "PresignExpired";
        case ErrorCode::MissingSignedHeaders: return "MissingSignedHeaders";
        case ErrorCode::HostNotSigned: return "HostNotSigned";
        case ErrorCode::MissingSignature: return "MissingSignature";
        case ErrorCode::SignedHeaderMissing: return "SignedHeaderMissing";
        case ErrorCode::SessionTokenNotSupported: return "SessionTokenNotSupported";
        case ErrorCode::UnsupportedPayloadHash: return "UnsupportedPayloadHash";
        case ErrorCode::PayloadHashMismatch: return "PayloadHashMismatch";
        case ErrorCode::UnknownAccessKey: return "UnknownAccessKey";
        case ErrorCode::SignatureMismatch: return "SignatureMismatch";
    }
    return "Unknown";
}

std::string_view awsErrorCode(const ErrorCode code, const bool presigned) noexcept {
    const std::string_view malformed = presigned ? "AuthorizationQueryParametersError" : "AuthorizationHeaderMalformed";
    switch (code) {
        case ErrorCode::None: return "";
        case ErrorCode::MissingAuthorization: return "AccessDenied";
        case ErrorCode::AmbiguousAuthorization: return "InvalidArgument";
        case ErrorCode::UnsupportedAlgorithm:
        case ErrorCode::MalformedAuthorization:
        case ErrorCode::InvalidCredentialScope:
        case ErrorCode::UnsupportedService:
        case ErrorCode::RegionMismatch:
        case ErrorCode::ScopeDateMismatch:
        case ErrorCode::MissingSignedHeaders:
        case ErrorCode::HostNotSigned:
        case ErrorCode::MissingSignature: return malformed;
        case ErrorCode::InvalidExpires:
        case ErrorCode::ExpiresTooLarge: return "AuthorizationQueryParametersError";
        case ErrorCode::MissingDate:
        case ErrorCode::InvalidDate: return "AccessDenied";
        case ErrorCode::RequestTimeTooSkewed: return "RequestTimeTooSkewed";
        case ErrorCode::PresignExpired: return "AccessDenied";
        case ErrorCode::SignedHeaderMissing: return "SignatureDoesNotMatch";
        case ErrorCode::SessionTokenNotSupported: return "InvalidToken";
        case ErrorCode::UnsupportedPayloadHash: return "NotImplemented";
        case ErrorCode::PayloadHashMismatch: return "XAmzContentSHA256Mismatch";
        case ErrorCode::UnknownAccessKey: return "InvalidAccessKeyId";
        case ErrorCode::SignatureMismatch: return "SignatureDoesNotMatch";
    }
    return "AccessDenied";
}

}
