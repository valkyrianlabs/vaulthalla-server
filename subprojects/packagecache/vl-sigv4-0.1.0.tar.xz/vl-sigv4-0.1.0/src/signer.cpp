// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Valkyrian Labs LLC

#include "vl/sigv4/signer.hpp"

#include "vl/sigv4/canonical.hpp"
#include "vl/sigv4/crypto.hpp"

#include <string>
#include <utility>

namespace vl::sigv4 {

namespace {

std::string withQuery(const std::string& path, const std::string& query) {
    return query.empty() ? path : path + "?" + query;
}

}

std::string Signed::target() const { return withQuery(encoded_path, query_string); }

std::string Presigned::target() const { return withQuery(encoded_path, query_string); }

std::string Presigned::url(const std::string_view scheme) const {
    std::string out(scheme);
    out += "://";
    out += host;
    out += target();
    return out;
}

Signed sign(const Request& request, const Credentials& credentials, const std::string_view region,
            const std::string_view service, const TimePoint now) {
    Signed out;
    const bool s3 = singleEncodesPath(service);
    const auto date = amzDate(now);
    const auto day = date.substr(0, 8);
    const std::string payloadHash = request.payload_hash.empty() ? std::string(kEmptyPayloadSha256)
                                                                 : request.payload_hash;

    auto headers = normalizeHeaders(request.headers);
    headers["host"] = request.host;
    headers["x-amz-date"] = date;
    if (s3) headers["x-amz-content-sha256"] = payloadHash;
    if (!credentials.session_token.empty()) headers["x-amz-security-token"] = credentials.session_token;

    out.encoded_path = encodePath(request.path);
    const auto uri = s3 ? out.encoded_path : uriEncode(out.encoded_path, false);
    out.query_string = canonicalQuery(request.query);

    const auto canonical = canonicalHeaders(headers);
    out.canonical_request = canonicalRequest(request.method, uri, out.query_string, canonical.canonical,
                                             canonical.signed_headers, payloadHash);

    const auto scope = credentialScope(day, region, service);
    out.string_to_sign = stringToSign(date, scope, out.canonical_request);
    out.signature = signatureHex(deriveSigningKey(credentials.secret_key, day, region, service), out.string_to_sign);
    out.authorization = authorizationHeader(credentials.access_key, scope, canonical.signed_headers, out.signature);

    out.headers = std::move(headers);
    out.headers["authorization"] = out.authorization;
    return out;
}

std::expected<Presigned, Error> presign(const Request& request, const Credentials& credentials,
                                        const std::string_view region, const std::string_view service,
                                        const TimePoint now, const std::chrono::seconds expires) {
    if (expires < std::chrono::seconds{1})
        return std::unexpected(Error{.code = ErrorCode::InvalidExpires, .message = "Invalid X-Amz-Expires"});
    if (expires > kMaxPresignExpiry)
        return std::unexpected(Error{.code = ErrorCode::ExpiresTooLarge,
                                     .message = "X-Amz-Expires exceeds maximum allowed value"});

    Presigned out;
    const bool s3 = singleEncodesPath(service);
    const auto date = amzDate(now);
    const auto day = date.substr(0, 8);
    const auto scope = credentialScope(day, region, service);

    auto headers = normalizeHeaders(request.headers);
    headers["host"] = request.host;
    const auto canonical = canonicalHeaders(headers);

    auto query = request.query;
    query.emplace_back("X-Amz-Algorithm", std::string(kAlgorithm));
    query.emplace_back("X-Amz-Credential", credentials.access_key + "/" + scope);
    query.emplace_back("X-Amz-Date", date);
    query.emplace_back("X-Amz-Expires", std::to_string(expires.count()));
    query.emplace_back("X-Amz-SignedHeaders", canonical.signed_headers);
    if (!credentials.session_token.empty()) query.emplace_back("X-Amz-Security-Token", credentials.session_token);
    const auto canonicalQueryString = canonicalQuery(query);

    std::string payloadHash;
    if (s3) payloadHash = kUnsignedPayload;
    else payloadHash = request.payload_hash.empty() ? std::string(kEmptyPayloadSha256) : request.payload_hash;

    out.host = request.host;
    out.encoded_path = encodePath(request.path);
    const auto uri = s3 ? out.encoded_path : uriEncode(out.encoded_path, false);
    out.canonical_request = canonicalRequest(request.method, uri, canonicalQueryString, canonical.canonical,
                                             canonical.signed_headers, payloadHash);
    out.string_to_sign = stringToSign(date, scope, out.canonical_request);
    out.signature = signatureHex(deriveSigningKey(credentials.secret_key, day, region, service), out.string_to_sign);
    out.query_string = canonicalQueryString + "&X-Amz-Signature=" + out.signature;
    return out;
}

}
