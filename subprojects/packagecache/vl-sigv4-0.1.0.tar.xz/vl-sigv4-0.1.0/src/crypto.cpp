// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Valkyrian Labs LLC

#include "vl/sigv4/crypto.hpp"

#include <openssl/crypto.h>
#include <openssl/evp.h>
#include <openssl/hmac.h>
#include <openssl/sha.h>

#include <array>
#include <stdexcept>

namespace vl::sigv4 {

namespace {

// OpenSSL may reject a null pointer even with a zero length; empty views can carry one.
const unsigned char* bytes(const std::string_view value) noexcept {
    static constexpr unsigned char kEmpty[1] = {0};
    return value.empty() ? kEmpty : reinterpret_cast<const unsigned char*>(value.data());
}

}

std::string hexEncode(const std::string_view data) {
    static constexpr char kDigits[] = "0123456789abcdef";
    std::string out;
    out.reserve(data.size() * 2);
    for (const char ch : data) {
        const auto c = static_cast<unsigned char>(ch);
        out.push_back(kDigits[c >> 4]);
        out.push_back(kDigits[c & 0x0f]);
    }
    return out;
}

std::string sha256(const std::string_view data) {
    std::array<unsigned char, SHA256_DIGEST_LENGTH> digest{};
    if (SHA256(bytes(data), data.size(), digest.data()) == nullptr)
        throw std::runtime_error("vl::sigv4: SHA-256 failed");
    return {reinterpret_cast<const char*>(digest.data()), digest.size()};
}

std::string sha256Hex(const std::string_view data) { return hexEncode(sha256(data)); }

std::string hmacSha256(const std::string_view key, const std::string_view data) {
    std::array<unsigned char, EVP_MAX_MD_SIZE> digest{};
    unsigned int length = 0;
    if (HMAC(EVP_sha256(), bytes(key), static_cast<int>(key.size()), bytes(data), data.size(), digest.data(),
             &length) == nullptr)
        throw std::runtime_error("vl::sigv4: HMAC-SHA-256 failed");
    return {reinterpret_cast<const char*>(digest.data()), length};
}

std::string hmacSha256Hex(const std::string_view key, const std::string_view data) {
    return hexEncode(hmacSha256(key, data));
}

std::string deriveSigningKey(const std::string_view secretKey, const std::string_view date,
                             const std::string_view region, const std::string_view service) {
    std::string seed = "AWS4";
    seed += secretKey;
    const auto kDate = hmacSha256(seed, date);
    OPENSSL_cleanse(seed.data(), seed.size());
    const auto kRegion = hmacSha256(kDate, region);
    const auto kService = hmacSha256(kRegion, service);
    return hmacSha256(kService, "aws4_request");
}

std::string signatureHex(const std::string_view signingKey, const std::string_view stringToSign) {
    return hmacSha256Hex(signingKey, stringToSign);
}

bool constantTimeEqual(const std::string_view a, const std::string_view b) noexcept {
    if (a.size() != b.size()) return false;
    if (a.empty()) return true;
    return CRYPTO_memcmp(a.data(), b.data(), a.size()) == 0;
}

}
