// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Valkyrian Labs LLC

#include "vl/sigv4/canonical.hpp"

#include "vl/sigv4/crypto.hpp"

#include <algorithm>
#include <chrono>

namespace vl::sigv4 {

namespace {

constexpr bool isAlnum(const unsigned char c) noexcept {
    return (c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z') || (c >= '0' && c <= '9');
}

constexpr bool isUnreserved(const unsigned char c) noexcept {
    return isAlnum(c) || c == '-' || c == '_' || c == '.' || c == '~';
}

constexpr bool isSpace(const unsigned char c) noexcept {
    return c == ' ' || c == '\t' || c == '\n' || c == '\v' || c == '\f' || c == '\r';
}

constexpr int hexValue(const unsigned char c) noexcept {
    if (c >= '0' && c <= '9') return c - '0';
    if (c >= 'a' && c <= 'f') return c - 'a' + 10;
    if (c >= 'A' && c <= 'F') return c - 'A' + 10;
    return -1;
}

// Splits on sep, keeping empty pieces.
template <class F>
void forEachPiece(const std::string_view value, const char sep, F&& f) {
    std::size_t start = 0;
    while (true) {
        const auto end = value.find(sep, start);
        if (end == std::string_view::npos) {
            f(value.substr(start));
            return;
        }
        f(value.substr(start, end - start));
        start = end + 1;
    }
}

std::string joinPairs(std::vector<std::pair<std::string, std::string>>& pairs) {
    std::ranges::sort(pairs);
    std::string out;
    for (const auto& [name, value] : pairs) {
        if (!out.empty()) out.push_back('&');
        out += name;
        out.push_back('=');
        out += value;
    }
    return out;
}

void appendNumber(std::string& out, const long long value, const int width) {
    char digits[24];
    int n = 0;
    auto v = value < 0 ? 0 : value;
    do {
        digits[n++] = static_cast<char>('0' + v % 10);
        v /= 10;
    } while (v != 0 && n < 20);
    for (int i = n; i < width; ++i) out.push_back('0');
    while (n > 0) out.push_back(digits[--n]);
}

}

// --- encoding ----------------------------------------------------------------------------------------------------

std::string uriEncode(const std::string_view value, const bool encodeSlash) {
    static constexpr char kHex[] = "0123456789ABCDEF";
    std::string out;
    out.reserve(value.size() * 3);
    for (const char ch : value) {
        const auto c = static_cast<unsigned char>(ch);
        if (isUnreserved(c) || (c == '/' && !encodeSlash)) {
            out.push_back(ch);
        } else {
            out.push_back('%');
            out.push_back(kHex[c >> 4]);
            out.push_back(kHex[c & 0x0f]);
        }
    }
    return out;
}

std::string uriDecode(const std::string_view value) {
    std::string out;
    out.reserve(value.size());
    for (std::size_t i = 0; i < value.size(); ++i) {
        if (value[i] == '%' && i + 2 < value.size()) {
            const auto hi = hexValue(static_cast<unsigned char>(value[i + 1]));
            const auto lo = hexValue(static_cast<unsigned char>(value[i + 2]));
            if (hi >= 0 && lo >= 0) {
                out.push_back(static_cast<char>((hi << 4) | lo));
                i += 2;
                continue;
            }
        }
        out.push_back(value[i]);
    }
    return out;
}

bool singleEncodesPath(const std::string_view service) noexcept { return service == "s3"; }

// --- canonical URI -----------------------------------------------------------------------------------------------

std::string encodePath(const std::string_view rawPath) { return uriEncode(rawPath.empty() ? "/" : rawPath, false); }

std::string canonicalUri(const std::string_view rawPath, const std::string_view service) {
    auto encoded = encodePath(rawPath);
    return singleEncodesPath(service) ? encoded : uriEncode(encoded, false);
}

std::string canonicalUriFromWire(const std::string_view wirePath, const std::string_view service) {
    const auto path = wirePath.empty() ? std::string_view("/") : wirePath;
    // S3: the wire path itself, normalized so that equivalent encodings agree. Others: the wire path encoded once
    // more, exactly as sent (the client signed what it put on the wire).
    auto encoded = singleEncodesPath(service) ? uriEncode(uriDecode(path), false) : uriEncode(path, false);
    if (encoded.empty() || encoded.front() != '/') encoded.insert(encoded.begin(), '/');
    return encoded;
}

// --- canonical query ---------------------------------------------------------------------------------------------

std::string canonicalQuery(const QueryParams& rawParams) {
    std::vector<std::pair<std::string, std::string>> encoded;
    encoded.reserve(rawParams.size());
    for (const auto& [name, value] : rawParams) encoded.emplace_back(uriEncode(name, true), uriEncode(value, true));
    return joinPairs(encoded);
}

QueryParams parseQuery(const std::string_view wireQuery) {
    QueryParams out;
    if (wireQuery.empty()) return out;
    forEachPiece(wireQuery, '&', [&](const std::string_view part) {
        if (part.empty()) return;
        const auto eq = part.find('=');
        if (eq == std::string_view::npos) out.emplace_back(uriDecode(part), std::string{});
        else out.emplace_back(uriDecode(part.substr(0, eq)), uriDecode(part.substr(eq + 1)));
    });
    return out;
}

std::string canonicalQueryFromWire(const std::string_view wireQuery, const bool omitSignature) {
    std::vector<std::pair<std::string, std::string>> encoded;
    for (const auto& [name, value] : parseQuery(wireQuery)) {
        if (omitSignature && name == "X-Amz-Signature") continue;
        encoded.emplace_back(uriEncode(name, true), uriEncode(value, true));
    }
    return joinPairs(encoded);
}

std::string sortEncodedQuery(const std::string_view encodedQuery) {
    std::vector<std::pair<std::string, std::string>> pairs;
    if (encodedQuery.empty()) return {};
    forEachPiece(encodedQuery, '&', [&](const std::string_view part) {
        if (part.empty()) return;
        const auto eq = part.find('=');
        if (eq == std::string_view::npos) pairs.emplace_back(std::string(part), std::string{});
        else pairs.emplace_back(std::string(part.substr(0, eq)), std::string(part.substr(eq + 1)));
    });
    return joinPairs(pairs);
}

// --- canonical headers -------------------------------------------------------------------------------------------

std::string canonicalHeaderValue(const std::string_view value) {
    std::string out;
    out.reserve(value.size());
    bool pendingSpace = false;
    for (const char ch : value) {
        if (isSpace(static_cast<unsigned char>(ch))) {
            pendingSpace = true;
            continue;
        }
        if (pendingSpace && !out.empty()) out.push_back(' ');
        pendingSpace = false;
        out.push_back(ch);
    }
    return out;
}

std::string toLower(const std::string_view value) {
    std::string out(value);
    for (auto& ch : out)
        if (ch >= 'A' && ch <= 'Z') ch = static_cast<char>(ch - 'A' + 'a');
    return out;
}

std::map<std::string, std::string> normalizeHeaders(const HeaderList& headers) {
    std::map<std::string, std::string> out;
    for (const auto& [name, value] : headers) {
        auto canonical = canonicalHeaderValue(value);
        auto [it, inserted] = out.try_emplace(toLower(name), canonical);
        if (!inserted) {
            it->second.push_back(',');
            it->second += canonical;
        }
    }
    return out;
}

CanonicalHeaders canonicalHeaders(const std::map<std::string, std::string>& normalized) {
    CanonicalHeaders out;
    for (const auto& [name, value] : normalized) {
        out.canonical += name;
        out.canonical.push_back(':');
        out.canonical += value;
        out.canonical.push_back('\n');
        if (!out.signed_headers.empty()) out.signed_headers.push_back(';');
        out.signed_headers += name;
    }
    return out;
}

std::string canonicalHeadersFor(const std::map<std::string, std::string>& normalized,
                                const std::string_view signedHeaders) {
    std::string out;
    if (signedHeaders.empty()) return out;
    forEachPiece(signedHeaders, ';', [&](const std::string_view rawName) {
        const auto name = toLower(rawName);
        const auto it = normalized.find(name);
        if (name.empty() || it == normalized.end()) return;
        out += name;
        out.push_back(':');
        out += it->second;
        out.push_back('\n');
    });
    return out;
}

// --- request, scope, string to sign ------------------------------------------------------------------------------

std::string canonicalRequest(const std::string_view method, const std::string_view canonicalUri,
                             const std::string_view canonicalQuery, const std::string_view canonicalHeaders,
                             const std::string_view signedHeaders, const std::string_view payloadHash) {
    std::string out;
    out.reserve(method.size() + canonicalUri.size() + canonicalQuery.size() + canonicalHeaders.size() +
                signedHeaders.size() + payloadHash.size() + 5);
    out += method;
    out.push_back('\n');
    out += canonicalUri;
    out.push_back('\n');
    out += canonicalQuery;
    out.push_back('\n');
    out += canonicalHeaders;
    out.push_back('\n');
    out += signedHeaders;
    out.push_back('\n');
    out += payloadHash;
    return out;
}

std::string credentialScope(const std::string_view date, const std::string_view region,
                            const std::string_view service) {
    std::string out(date);
    out.push_back('/');
    out += region;
    out.push_back('/');
    out += service;
    out += "/aws4_request";
    return out;
}

std::string stringToSign(const std::string_view amzDate, const std::string_view scope,
                         const std::string_view canonicalRequest) {
    std::string out(kAlgorithm);
    out.push_back('\n');
    out += amzDate;
    out.push_back('\n');
    out += scope;
    out.push_back('\n');
    out += sha256Hex(canonicalRequest);
    return out;
}

std::string authorizationHeader(const std::string_view accessKey, const std::string_view scope,
                                std::string_view signedHeaders, const std::string_view signature) {
    std::string out(kAlgorithm);
    out += " Credential=";
    out += accessKey;
    out.push_back('/');
    out += scope;
    out += ", SignedHeaders=";
    out += signedHeaders;
    out += ", Signature=";
    out += signature;
    return out;
}

// --- dates -------------------------------------------------------------------------------------------------------

std::string amzDate(const TimePoint t) {
    const auto seconds = std::chrono::floor<std::chrono::seconds>(t);
    const auto days = std::chrono::floor<std::chrono::days>(seconds);
    const std::chrono::year_month_day ymd{days};
    const std::chrono::hh_mm_ss hms{seconds - days};
    std::string out;
    out.reserve(16);
    appendNumber(out, static_cast<int>(ymd.year()), 4);
    appendNumber(out, static_cast<unsigned>(ymd.month()), 2);
    appendNumber(out, static_cast<unsigned>(ymd.day()), 2);
    out.push_back('T');
    appendNumber(out, hms.hours().count(), 2);
    appendNumber(out, hms.minutes().count(), 2);
    appendNumber(out, hms.seconds().count(), 2);
    out.push_back('Z');
    return out;
}

std::string dateStamp(const TimePoint t) { return amzDate(t).substr(0, 8); }

std::optional<TimePoint> parseAmzDate(const std::string_view value) {
    if (value.size() != 16 || value[8] != 'T' || value[15] != 'Z') return std::nullopt;
    const auto number = [&](const std::size_t pos, const std::size_t len) -> int {
        int n = 0;
        for (std::size_t i = pos; i < pos + len; ++i) {
            const auto c = static_cast<unsigned char>(value[i]);
            if (c < '0' || c > '9') return -1;
            n = n * 10 + (c - '0');
        }
        return n;
    };
    const auto year = number(0, 4), month = number(4, 2), day = number(6, 2);
    const auto hour = number(9, 2), minute = number(11, 2), second = number(13, 2);
    if (year < 0 || month < 0 || day < 0 || hour < 0 || minute < 0 || second < 0) return std::nullopt;
    if (hour > 23 || minute > 59 || second > 59) return std::nullopt;
    const std::chrono::year_month_day ymd{std::chrono::year{year}, std::chrono::month{static_cast<unsigned>(month)},
                                          std::chrono::day{static_cast<unsigned>(day)}};
    if (!ymd.ok()) return std::nullopt;
    const auto at = std::chrono::sys_days{ymd} + std::chrono::hours{hour} + std::chrono::minutes{minute} +
                    std::chrono::seconds{second};
    return std::chrono::time_point_cast<Clock::duration>(at);
}

}
