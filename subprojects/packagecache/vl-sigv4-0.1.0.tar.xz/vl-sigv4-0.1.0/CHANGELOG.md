# Changelog

All notable changes to vl-sigv4 are recorded here. The format follows [Keep a Changelog](https://keepachangelog.com/),
and versions follow [Semantic Versioning](https://semver.org/) (before 1.0, a minor version may break the API).

## [Unreleased]

## [0.1.0] - 2026-11-02

First release: AWS Signature Version 4 consolidated from Vaulthalla's four implementations (relicensed MIT by
Valkyrian Labs LLC, the copyright owner).

### Added

- `sign()`: Authorization-header signing for S3 (single-encoded path, `x-amz-content-sha256`) and every other
  service (double-encoded path), session tokens, `UNSIGNED-PAYLOAD`.
- `presign()`: presigned URLs, `X-Amz-Expires` 1 s to 604800 s, session tokens.
- `parseAuthorization()` and three `verify()` overloads (secret, secret lookup, already parsed): header and presigned
  authentication, ±15 min skew, presign window, signed-header presence, payload hash (`UNSIGNED-PAYLOAD`,
  `STREAMING-UNSIGNED-PAYLOAD-TRAILER`), constant-time comparison, `ErrorCode` results with S3 error code mapping.
- Canonicalization and crypto primitives (`canonical.hpp`, `crypto.hpp`).
- Tests: AWS SigV4 suite vectors, AWS S3 documentation examples, botocore-checked presigns, Vaulthalla's signer and
  verifier goldens (233-record characterization fixture), round trips, verifier negatives, randomized robustness.
- meson build (static library, `vl_sigv4_dep`, `meson.override_dependency('vl-sigv4')`), pkg-config file, CI in
  `ci/run-ci` on the vps-ci pool with ASan/UBSan and a no-warnings gate.
