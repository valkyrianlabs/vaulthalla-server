// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Valkyrian Labs LLC
#pragma once

#include "vl/sigv4/sigv4.hpp"

#include <ctime>
#include <string>

namespace vl::sigv4::test {

inline TimePoint at(const std::time_t t) { return Clock::from_time_t(t); }

inline constexpr std::time_t k20150830T123600Z = 1440938160;   // AWS SigV4 test suite
inline constexpr std::time_t k20130524T000000Z = 1369353600;   // AWS S3 SigV4 documentation examples
inline constexpr std::time_t k20261102T000000Z = 1793577600;   // Vaulthalla goldens, botocore presigns

inline const Credentials kSuite{.access_key = "AKIDEXAMPLE",
                                .secret_key = "wJalrXUtnFEMI/K7MDENG+bPxRfiCYEXAMPLEKEY",
                                .session_token = {}};
inline const Credentials kS3Docs{.access_key = "AKIAIOSFODNN7EXAMPLE",
                                 .secret_key = "wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY",
                                 .session_token = {}};
inline const Credentials kS3DocsWithToken{.access_key = "AKIAIOSFODNN7EXAMPLE",
                                          .secret_key = "wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY",
                                          .session_token = "FwoGZXIvYXdzEXAMPLE//////////wEaDEXAMPLETOKEN+/="};

inline Request makeRequest(std::string method, std::string host, std::string path, QueryParams query = {},
                           HeaderList headers = {}, const std::string& body = {}) {
    return {.method = std::move(method),
            .host = std::move(host),
            .path = std::move(path),
            .query = std::move(query),
            .headers = std::move(headers),
            .payload_hash = sha256Hex(body)};
}

inline std::string param(const std::string& query, const std::string& name) {
    const auto key = name + "=";
    std::size_t pos = 0;
    while (pos <= query.size()) {
        const auto end = std::min(query.find('&', pos), query.size());
        const auto part = query.substr(pos, end - pos);
        if (part.starts_with(key)) return part.substr(key.size());
        pos = end + 1;
    }
    return {};
}

}
