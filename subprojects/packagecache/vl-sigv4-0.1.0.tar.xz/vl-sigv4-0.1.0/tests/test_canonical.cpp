// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Valkyrian Labs LLC
//
// Encoding, canonicalization and date helpers. The verifier-side expectations are goldens from Vaulthalla's gateway
// (core/src/protocols/s3/SigV4.cpp at 608aac48) and its tests (test_s3_gateway.cpp, test_s3_canonical_query.cpp);
// where this library deliberately differs (strict percent-decoding) the test says so.

#include "support.hpp"

#include <gtest/gtest.h>

namespace sv = vl::sigv4;

TEST(Encoding, UriEncodeRules) {
    EXPECT_EQ(sv::uriEncode("a b/c~d", false), "a%20b/c~d");
    EXPECT_EQ(sv::uriEncode("a b/c~d", true), "a%20b%2Fc~d");
    EXPECT_EQ(sv::uriEncode("\xc3\xa9", true), "%C3%A9");
    EXPECT_EQ(sv::uriEncode("a+b=c&d", true), "a%2Bb%3Dc%26d");
    EXPECT_EQ(sv::uriEncode("-_.~AZaz09", true), "-_.~AZaz09");
    EXPECT_EQ(sv::uriEncode(std::string_view("\0\x7f\xff", 3), true), "%00%7F%FF");
    EXPECT_EQ(sv::uriEncode("", true), "");
}

TEST(Encoding, UriDecodeIsStrict) {
    EXPECT_EQ(sv::uriDecode("a%20b%2fc%2F"), "a b/c/");
    EXPECT_EQ(sv::uriDecode("a+b"), "a+b");   // '+' is not a space
    EXPECT_EQ(sv::uriDecode("%zz%2%"), "%zz%2%");
    EXPECT_EQ(sv::uriDecode("%"), "%");
    EXPECT_EQ(sv::uriDecode("%4"), "%4");
    EXPECT_EQ(sv::uriDecode("%41"), "A");
    // Vaulthalla's verifier decoded these through strtoul ("%+1" -> 0x01, "%-1" -> 0xFF); they are not escapes.
    EXPECT_EQ(sv::uriDecode("%+1"), "%+1");
    EXPECT_EQ(sv::uriDecode("% 1"), "% 1");
    EXPECT_EQ(sv::uriDecode("%-1"), "%-1");
}

TEST(CanonicalUri, SignerEncodesRawPathOnceForS3AndTwiceOtherwise) {
    EXPECT_EQ(sv::encodePath(""), "/");
    EXPECT_EQ(sv::encodePath("/b/a b"), "/b/a%20b");
    EXPECT_EQ(sv::canonicalUri("/b/a b", "s3"), "/b/a%20b");
    EXPECT_EQ(sv::canonicalUri("/b/a b", "sqs"), "/b/a%2520b");
    EXPECT_EQ(sv::canonicalUri("/b/a+b", "s3"), "/b/a%2Bb");
    EXPECT_TRUE(sv::singleEncodesPath("s3"));
    EXPECT_FALSE(sv::singleEncodesPath("sts"));
}

TEST(CanonicalUri, VerifierNormalizesWirePaths) {
    // Vaulthalla goldens.
    EXPECT_EQ(sv::canonicalUriFromWire("/photos/a b/%7Efile.txt", "s3"), "/photos/a%20b/~file.txt");
    EXPECT_EQ(sv::canonicalUriFromWire("/photos/a+b.txt", "s3"), "/photos/a%2Bb.txt");
    EXPECT_EQ(sv::canonicalUriFromWire("", "s3"), "/");
    EXPECT_EQ(sv::canonicalUriFromWire("/", "s3"), "/");
    EXPECT_EQ(sv::canonicalUriFromWire("/a%2Fb", "s3"), "/a/b");
    EXPECT_EQ(sv::canonicalUriFromWire("/%e2%82%ac", "s3"), "/%E2%82%AC");
    EXPECT_EQ(sv::canonicalUriFromWire("/a%2", "s3"), "/a%252");
    EXPECT_EQ(sv::canonicalUriFromWire("/a%zz", "s3"), "/a%25zz");
    EXPECT_EQ(sv::canonicalUriFromWire("noslash", "s3"), "/noslash");
    // Deliberate difference: Vaulthalla gave "/a%01" and "/a%FF".
    EXPECT_EQ(sv::canonicalUriFromWire("/a%+1", "s3"), "/a%25%2B1");
    EXPECT_EQ(sv::canonicalUriFromWire("/a%-1", "s3"), "/a%25-1");
    // Non-S3 services: the wire path encoded again.
    EXPECT_EQ(sv::canonicalUriFromWire("/b/a%20b", "sqs"), "/b/a%2520b");
}

TEST(CanonicalQuery, SignerEncodesAndSorts) {
    EXPECT_EQ(sv::canonicalQuery({}), "");
    EXPECT_EQ(sv::canonicalQuery({{"b", "1"}, {"B", "2"}, {"a", "x y"}, {"uploads", ""}}), "B=2&a=x%20y&b=1&uploads=");
    EXPECT_EQ(sv::canonicalQuery({{"k", "a=b"}}), "k=a%3Db");
}

TEST(CanonicalQuery, VerifierDecodesReencodesAndSorts) {
    // Vaulthalla goldens.
    EXPECT_EQ(sv::canonicalQueryFromWire("b=two&a=1&X-Amz-Signature=dead&a=0&space=a%20b", true),
              "a=0&a=1&b=two&space=a%20b");
    EXPECT_EQ(sv::canonicalQueryFromWire("prefix=a+b&space=a%20b", true), "prefix=a%2Bb&space=a%20b");
    EXPECT_EQ(sv::canonicalQueryFromWire("uploads", true), "uploads=");
    EXPECT_EQ(sv::canonicalQueryFromWire("a=1&&b=2&", true), "a=1&b=2");
    EXPECT_EQ(sv::canonicalQueryFromWire("k=a=b", true), "k=a%3Db");
    EXPECT_EQ(sv::canonicalQueryFromWire("x=%2f%2F", true), "x=%2F%2F");
    EXPECT_EQ(sv::canonicalQueryFromWire("versionId=3%2FL4k%2B%3D", true), "versionId=3%2FL4k%2B%3D");
    EXPECT_EQ(sv::canonicalQueryFromWire("=v", true), "=v");
    EXPECT_EQ(sv::canonicalQueryFromWire("%41=1", true), "A=1");
    EXPECT_EQ(sv::canonicalQueryFromWire("", true), "");
    // Header-signed requests keep X-Amz-Signature in the canonical query.
    EXPECT_EQ(sv::canonicalQueryFromWire("X-Amz-Signature=dead&a=1", false), "X-Amz-Signature=dead&a=1");
    // Deliberate difference: Vaulthalla gave "a=%01".
    EXPECT_EQ(sv::canonicalQueryFromWire("a=%+1", true), "a=%25%2B1");
}

TEST(CanonicalQuery, ParseQueryKeepsOrderAndDecodes) {
    const auto params = sv::parseQuery("b=1&a&&c=x%20y&b=0");
    ASSERT_EQ(params.size(), 4U);
    EXPECT_EQ(params[0], (std::pair<std::string, std::string>{"b", "1"}));
    EXPECT_EQ(params[1], (std::pair<std::string, std::string>{"a", ""}));
    EXPECT_EQ(params[2], (std::pair<std::string, std::string>{"c", "x y"}));
    EXPECT_EQ(params[3], (std::pair<std::string, std::string>{"b", "0"}));
}

// Ported from Vaulthalla test_s3_canonical_query.cpp (storage::s3::curl::canonicalQueryString).
TEST(CanonicalQuery, SortEncodedQuerySortsByNameThenValue) {
    EXPECT_EQ(sv::sortEncodedQuery("list-type=2&max-keys=1000&continuation-token=1a%2Bb%2F%3D"),
              "continuation-token=1a%2Bb%2F%3D&list-type=2&max-keys=1000");
    EXPECT_EQ(sv::sortEncodedQuery("list-type=2&prefix=dir%2Fsub&continuation-token=t"),
              "continuation-token=t&list-type=2&prefix=dir%2Fsub");
    EXPECT_EQ(sv::sortEncodedQuery("uploadId=abc&partNumber=2"), "partNumber=2&uploadId=abc");
    EXPECT_EQ(sv::sortEncodedQuery("a=2&b=0&a=1"), "a=1&a=2&b=0");
    EXPECT_EQ(sv::sortEncodedQuery("b=1&B=2"), "B=2&b=1");
}

TEST(CanonicalQuery, SortEncodedQueryValuelessParametersGetAnEmptyValue) {
    EXPECT_EQ(sv::sortEncodedQuery("uploads"), "uploads=");
    EXPECT_EQ(sv::sortEncodedQuery("versioning"), "versioning=");
    EXPECT_EQ(sv::sortEncodedQuery("uploads&prefix=a"), "prefix=a&uploads=");
    EXPECT_EQ(sv::sortEncodedQuery(""), "");
    EXPECT_EQ(sv::sortEncodedQuery("a=1&&b=2&"), "a=1&b=2");
}

TEST(CanonicalQuery, SortEncodedQueryDoesNotReencode) {
    EXPECT_EQ(sv::sortEncodedQuery("prefix=a%20b&marker=x%2By"), "marker=x%2By&prefix=a%20b");
    EXPECT_EQ(sv::sortEncodedQuery("k=a=b"), "k=a=b");
}

TEST(CanonicalHeaders, TrimAllAndCombine) {
    EXPECT_EQ(sv::canonicalHeaderValue("  a   b\t c  "), "a b c");
    EXPECT_EQ(sv::canonicalHeaderValue("\r\n x \n"), "x");
    EXPECT_EQ(sv::canonicalHeaderValue(""), "");
    EXPECT_EQ(sv::canonicalHeaderValue("   "), "");
    const auto normalized = sv::normalizeHeaders({{"X-A", " 1 "}, {"x-a", "2"}, {"Host", "h"}});
    EXPECT_EQ(normalized.at("x-a"), "1,2");
    const auto c = sv::canonicalHeaders(normalized);
    EXPECT_EQ(c.canonical, "host:h\nx-a:1,2\n");
    EXPECT_EQ(c.signed_headers, "host;x-a");
    EXPECT_EQ(sv::canonicalHeadersFor(normalized, "x-a;Host;missing"), "x-a:1,2\nhost:h\n");
}

TEST(Dates, FormatAndParse) {
    using vl::sigv4::test::at;
    EXPECT_EQ(sv::amzDate(at(1440938160)), "20150830T123600Z");
    EXPECT_EQ(sv::dateStamp(at(1440938160)), "20150830");
    EXPECT_EQ(sv::amzDate(at(0)), "19700101T000000Z");
    EXPECT_EQ(sv::amzDate(at(951782399)), "20000228T235959Z");
    EXPECT_EQ(sv::amzDate(at(951782400 + 86399)), "20000229T235959Z");
    // Sub-second parts are truncated, never rounded up.
    EXPECT_EQ(sv::amzDate(at(1440938160) + std::chrono::milliseconds{999}), "20150830T123600Z");

    const auto parsed = sv::parseAmzDate("20150830T123600Z");
    ASSERT_TRUE(parsed.has_value());
    EXPECT_EQ(*parsed, at(1440938160));
    EXPECT_EQ(sv::parseAmzDate("20000229T120000Z"), at(951825600));
    for (const char* bad : {"", "20150830T123600", "20150830T123600ZZ", "20150830 123600Z", "20151330T123600Z",
                            "20150230T123600Z", "20150830T243600Z", "20150830T126000Z", "20150830T123660Z",
                            "2015083OT123600Z", "-0150830T123600Z", "19990229T000000Z"})
        EXPECT_FALSE(sv::parseAmzDate(bad).has_value()) << bad;
}

TEST(Crypto, Primitives) {
    EXPECT_EQ(sv::sha256Hex(""), sv::kEmptyPayloadSha256);
    EXPECT_EQ(sv::sha256Hex("abc"), "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad");
    // RFC 4231 test case 2.
    EXPECT_EQ(sv::hmacSha256Hex("Jefe", "what do ya want for nothing?"),
              "5bdcc146bf60754e6a042426089575c75a003f089d2739839dec58b964ec3843");
    EXPECT_EQ(sv::hmacSha256Hex("", ""), "b613679a0814d9ec772f95d778c35fc5ff1697c493715653c6c712144292c5ad");
    EXPECT_EQ(sv::hexEncode(std::string_view("\x00\xff", 2)), "00ff");
    // AWS documentation example of a derived signing key (AWS General Reference, "Examples of how to derive a
    // signing key"): secret wJalrXUtnFEMI/K7MDENG+bPxRfiCYEXAMPLEKEY, 20120215, us-east-1, iam.
    EXPECT_EQ(sv::hexEncode(sv::deriveSigningKey("wJalrXUtnFEMI/K7MDENG+bPxRfiCYEXAMPLEKEY", "20120215", "us-east-1",
                                                 "iam")),
              "f4780e2d9f65fa895f9c67b32ce1baf0b0d8a43505a000a1a9e090d414db404d");
    EXPECT_TRUE(sv::constantTimeEqual("abc", "abc"));
    EXPECT_TRUE(sv::constantTimeEqual("", ""));
    EXPECT_FALSE(sv::constantTimeEqual("abc", "abd"));
    EXPECT_FALSE(sv::constantTimeEqual("abc", "abcd"));
}

TEST(Errors, NamesAndAwsCodes) {
    EXPECT_EQ(sv::errorCodeName(sv::ErrorCode::SignatureMismatch), "SignatureMismatch");
    EXPECT_EQ(sv::awsErrorCode(sv::ErrorCode::SignatureMismatch), "SignatureDoesNotMatch");
    EXPECT_EQ(sv::awsErrorCode(sv::ErrorCode::RequestTimeTooSkewed), "RequestTimeTooSkewed");
    EXPECT_EQ(sv::awsErrorCode(sv::ErrorCode::UnknownAccessKey), "InvalidAccessKeyId");
    EXPECT_EQ(sv::awsErrorCode(sv::ErrorCode::MalformedAuthorization), "AuthorizationHeaderMalformed");
    EXPECT_EQ(sv::awsErrorCode(sv::ErrorCode::MalformedAuthorization, true), "AuthorizationQueryParametersError");
    EXPECT_EQ(sv::awsErrorCode(sv::ErrorCode::PayloadHashMismatch), "XAmzContentSHA256Mismatch");
    EXPECT_EQ(sv::awsErrorCode(sv::ErrorCode::None), "");
    for (int code = 0; code <= static_cast<int>(sv::ErrorCode::SignatureMismatch); ++code) {
        EXPECT_NE(sv::errorCodeName(static_cast<sv::ErrorCode>(code)), "Unknown");
        if (code != 0) {
            EXPECT_FALSE(sv::awsErrorCode(static_cast<sv::ErrorCode>(code)).empty());
        }
    }
}
