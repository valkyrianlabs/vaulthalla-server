// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Valkyrian Labs LLC
//
// Vaulthalla's SigV4 characterization goldens (tests/vectors/vaulthalla-goldens.txt, ported from vaulthalla-server
// PR #306): what each of Vaulthalla's four implementations produced for 25 request shapes.
//
//   upstream  storage::s3::sigv4::sign             general signer (spec-correct; the library's byte-for-byte target)
//   gateway   protocols::s3::sigv4                 S3 gateway verifier
//   legacy    storage::s3::curl::buildAuthorizationHeader   vault data-path signer
//   ses       SesProvider signAwsV4
//
// The cases are rebuilt here with the same inputs and driven through this library:
//  - sign() must reproduce every upstream record (authorization, canonical request, string to sign);
//  - the verifier must reproduce every gateway record for S3, and accept the request;
//  - legacy and ses must agree with the library except where they are known to deviate from SigV4 (the table in
//    KnownDeviationsOfLegacyAndSes, explained in docs/compat-notes.md).

#include "support.hpp"

#include <gtest/gtest.h>

#include <algorithm>
#include <fstream>
#include <map>
#include <set>
#include <string>
#include <vector>

#ifndef VL_SIGV4_VECTORS_DIR
#error "VL_SIGV4_VECTORS_DIR must point at tests/vectors"
#endif

namespace {

namespace sv = vl::sigv4;

constexpr std::time_t k20150830T123600Z = 1440938160;
constexpr std::time_t k20130524T000000Z = 1369353600;
constexpr std::time_t k20261102T101500Z = 1793614500;

constexpr const char* kSuiteAccessKey = "AKIDEXAMPLE";
constexpr const char* kSuiteSecretKey = "wJalrXUtnFEMI/K7MDENG+bPxRfiCYEXAMPLEKEY";
constexpr const char* kS3DocsAccessKey = "AKIAIOSFODNN7EXAMPLE";
constexpr const char* kS3DocsSecretKey = "wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY";
// The STS session token from AWS's documentation (carries '/', '+', '=').
constexpr const char* kSessionToken =
    "AQoDYXdzEPT//////////wEXAMPLEtc764bNrC9SAPBSM22wDOk4x4HIZ8j4FZTwdQWLWsKWHGBuFqwAeMicRXmxfpSPfIeoIYRqTflfKD8YUuw"
    "thAx7mSEI/qkPpKPi/kMcGdQrmGdeehM4IC1NtBmUpp2wUE8phUZampKsburEDy0KPkyQDYwT7WZ0wq5VSXDvp75YU9HFvlRd8Tx6q6fE8YQcH"
    "NVXAkiY9q6d+xo0rKwT38xVqr7ZD0u0iPPkUL64lIZbqBAz+scqKmlzm8FDrypNC9Yjc8fPOLn9FX9KSYvKTr4rvx3iSIlTJabIQwj2ICCR/oLx"
    "BA==";
constexpr const char* kVersionId = "3/L4kqtJlcpXroDTDmJ+rmSpXd3dIbrHY+MTRCxf3vjVBH40Nr8X8gdRQBpUMLUo=";
constexpr const char* kContinuationToken = "1ueGcxLPRx1Tr/XYExHnhbYLgveDs2J+wm36Hy4vbOwM=";
constexpr const char* kUploadId = "VXBsb2FkIElEIGZvciA2aWWpbmcncyBteS1tb3ZpZS5tMnRzIHVwbG9hZA";
constexpr const char* kS3Host = "s3.us-east-1.amazonaws.com";
constexpr const char* kSesBody =
    R"json({"Content":{"Simple":{"Body":{"Html":{"Charset":"UTF-8","Data":"<strong>Hello</strong>"},"Text":{"Charset":"UTF-8","Data":"Hello"}},"Subject":{"Charset":"UTF-8","Data":"[Vaulthalla] Test operator email"}}},"Destination":{"ToAddresses":["admin@example.com"]},"FromEmailAddress":"Vaulthalla <ops@example.com>","ReplyToAddresses":["reply@example.com"]})json";

struct Case {
    std::string name;
    std::string service = "s3";
    std::string region = "us-east-1";
    std::string access_key = kSuiteAccessKey;
    std::string secret_key = kSuiteSecretKey;
    std::string session_token{};
    std::time_t time = k20261102T101500Z;
    std::string method = "GET";
    std::string host = kS3Host;
    std::string path = "/";
    sv::QueryParams query{};
    sv::HeaderList headers{};
    std::string body{};
    bool unsigned_payload = false;
};

Case suiteCase(std::string name) {
    Case c;
    c.name = "aws-suite/" + std::move(name);
    c.service = "service";
    c.time = k20150830T123600Z;
    c.host = "example.amazonaws.com";
    return c;
}

Case s3DocsCase(std::string name) {
    Case c;
    c.name = "aws-s3-docs/" + std::move(name);
    c.access_key = kS3DocsAccessKey;
    c.secret_key = kS3DocsSecretKey;
    c.time = k20130524T000000Z;
    c.host = "examplebucket.s3.amazonaws.com";
    return c;
}

Case s3Case(std::string name, std::string method, std::string path, const bool unsignedPayload = true) {
    Case c;
    c.name = "s3/" + std::move(name);
    c.method = std::move(method);
    c.path = std::move(path);
    c.unsigned_payload = unsignedPayload;
    return c;
}

// The same 25 cases as vaulthalla-server core/tests/unit/test_sigv4_goldens.cpp.
const std::vector<Case>& cases() {
    static const std::vector<Case> all = [] {
        std::vector<Case> v;
        v.push_back(suiteCase("get-vanilla"));
        {
            auto c = suiteCase("get-vanilla-query-order-key-case");
            c.query = {{"Param2", "value2"}, {"Param1", "value1"}};
            v.push_back(c);
        }
        {
            auto c = suiteCase("get-vanilla-query-unreserved");
            const std::string unreserved = "-._~0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
            c.query = {{unreserved, unreserved}};
            v.push_back(c);
        }
        {
            auto c = suiteCase("get-utf8");
            c.path = "/\xe1\x88\xb4";
            v.push_back(c);
        }
        {
            auto c = suiteCase("post-x-www-form-urlencoded");
            c.method = "POST";
            c.headers = {{"Content-Type", "application/x-www-form-urlencoded"}};
            c.body = "Param1=value1";
            v.push_back(c);
        }
        {
            auto c = s3DocsCase("get-object-range");
            c.path = "/test.txt";
            c.headers = {{"Range", "bytes=0-9"}};
            v.push_back(c);
        }
        {
            auto c = s3DocsCase("get-bucket-lifecycle");
            c.query = {{"lifecycle", ""}};
            v.push_back(c);
        }
        v.push_back(s3Case("get-object", "GET", "/vh-bucket/photos/cat.jpg"));
        {
            auto c = s3Case("get-object-range", "GET", "/vh-bucket/photos/cat.jpg");
            c.headers = {{"Range", "bytes=0-1048575"}};
            v.push_back(c);
        }
        v.push_back(s3Case("head-object", "HEAD", "/vh-bucket/photos/cat.jpg"));
        v.push_back(s3Case("delete-object", "DELETE", "/vh-bucket/photos/cat.jpg"));
        {
            auto c = s3Case("put-object-payload-hash", "PUT", "/vh-bucket/notes/hello.txt", false);
            c.body = "hello vaulthalla\n";
            v.push_back(c);
        }
        {
            auto c = s3Case("put-object-headers-case-and-space", "PUT", "/vh-bucket/notes/hello.txt", false);
            c.body = "hello vaulthalla\n";
            c.headers = {{"Content-Type", "text/plain"}, {"X-Amz-Meta-Owner", "  Cooper   Larson "}};
            v.push_back(c);
        }
        v.push_back(s3Case("key-special-chars", "GET", "/vh-bucket/dir one/a b+c=d~e%f.txt"));
        v.push_back(s3Case("key-utf8", "GET", "/vh-bucket/caf\xc3\xa9/r\xc3\xa9sum\xc3\xa9.pdf"));
        {
            auto c = s3Case("get-object-version", "GET", "/vh-bucket/photos/cat.jpg");
            c.query = {{"versionId", kVersionId}};
            v.push_back(c);
        }
        {
            auto c = s3Case("delete-object-version", "DELETE", "/vh-bucket/photos/cat.jpg");
            c.query = {{"versionId", kVersionId}};
            v.push_back(c);
        }
        {
            auto c = s3Case("list-v2-continuation", "GET", "/vh-bucket");
            c.query = {{"list-type", "2"}, {"max-keys", "1000"}, {"continuation-token", kContinuationToken}};
            v.push_back(c);
        }
        {
            auto c = s3Case("multipart-initiate", "POST", "/vh-bucket/big/movie.m2ts");
            c.query = {{"uploads", ""}};
            v.push_back(c);
        }
        {
            auto c = s3Case("multipart-upload-part", "PUT", "/vh-bucket/big/movie.m2ts", false);
            c.query = {{"partNumber", "7"}, {"uploadId", kUploadId}};
            c.body = "part seven bytes";
            v.push_back(c);
        }
        {
            auto c = s3Case("multipart-complete", "POST", "/vh-bucket/big/movie.m2ts", false);
            c.query = {{"uploadId", kUploadId}};
            c.body = "<CompleteMultipartUpload><Part><PartNumber>1</PartNumber><ETag>\"etag-1\"</ETag></Part>"
                     "</CompleteMultipartUpload>";
            v.push_back(c);
        }
        {
            auto c = s3Case("multipart-abort", "DELETE", "/vh-bucket/big/movie.m2ts");
            c.query = {{"uploadId", kUploadId}};
            v.push_back(c);
        }
        {
            auto c = s3Case("session-token", "GET", "/vh-bucket/photos/cat.jpg");
            c.session_token = kSessionToken;
            v.push_back(c);
        }
        {
            auto c = s3Case("r2-get-object", "GET", "/vh-bucket/photos/cat.jpg");
            c.name = "r2/get-object";
            c.host = "0123456789abcdef0123456789abcdef.r2.cloudflarestorage.com";
            c.region = "auto";
            v.push_back(c);
        }
        {
            Case c;
            c.name = "ses/send-email";
            c.service = "ses";
            c.method = "POST";
            c.host = "email.us-east-1.amazonaws.com";
            c.path = "/v2/email/outbound-emails";
            c.body = kSesBody;
            c.headers = {{"Content-Type", "application/json"}, {"X-Amz-Content-Sha256", sv::sha256Hex(c.body)}};
            v.push_back(c);
        }
        return v;
    }();
    return all;
}

using Records = std::map<std::string, std::string>;   // "<case> <impl> <field>" -> value

const Records& fixture() {
    static const Records records = [] {
        Records out;
        std::ifstream in(std::string(VL_SIGV4_VECTORS_DIR) + "/vaulthalla-goldens.txt", std::ios::binary);
        std::string line, key, value;
        bool inRecord = false;
        const auto flush = [&] {
            if (inRecord) out[key] = value.empty() ? value : value.substr(0, value.size() - 1);
        };
        while (std::getline(in, line)) {
            if (line.starts_with("@@ ")) {
                flush();
                key = line.substr(3);
                value.clear();
                inRecord = true;
            } else if (inRecord) {
                value += line + "\n";
            }
        }
        flush();
        return out;
    }();
    return records;
}

const std::string& record(const Case& c, const std::string& impl, const std::string& field) {
    static const std::string kNone = "<no record>";
    const auto it = fixture().find(c.name + " " + impl + " " + field);
    return it == fixture().end() ? kNone : it->second;
}

bool hasRecord(const Case& c, const std::string& impl) {
    return fixture().contains(c.name + " " + impl + " canonical_request");
}

sv::Request requestOf(const Case& c) {
    return {.method = c.method,
            .host = c.host,
            .path = c.path,
            .query = c.query,
            .headers = c.headers,
            .payload_hash = c.unsigned_payload ? std::string(sv::kUnsignedPayload) : sv::sha256Hex(c.body)};
}

sv::Signed signCase(const Case& c) {
    const sv::Credentials credentials{.access_key = c.access_key, .secret_key = c.secret_key,
                                      .session_token = c.session_token};
    return sv::sign(requestOf(c), credentials, c.region, c.service, sv::test::at(c.time));
}

// The query as the URL carries it in Vaulthalla: caller order, a bare name for an empty value ("?uploads").
std::string wireQuery(const Case& c) {
    std::string out;
    for (const auto& [name, value] : c.query) {
        if (!out.empty()) out.push_back('&');
        out += sv::uriEncode(name, true);
        if (!value.empty()) out += "=" + sv::uriEncode(value, true);
    }
    return out;
}

// What the gateway receives when the signer's output is sent: the caller's own header names and values, plus what the
// signer added.
sv::VerificationInput gatewayInput(const Case& c, const sv::Signed& sent) {
    sv::VerificationInput input{.method = c.method, .target = sent.encoded_path, .host = c.host, .headers = c.headers,
                                .body = c.body, .body_sha256 = std::nullopt};
    if (const auto q = wireQuery(c); !q.empty()) input.target += "?" + q;
    for (const auto& [name, value] : sent.headers) {
        const bool callerSent =
            std::ranges::any_of(c.headers, [&](const auto& h) { return sv::toLower(h.first) == name; });
        if (!callerSent) input.headers.emplace_back(name, value);
    }
    return input;
}

sv::VerifyOptions optionsFor(const Case& c) {
    sv::VerifyOptions options;
    options.service = c.service;
    return options;
}

}

TEST(VaulthallaGoldens, FixtureLoaded) {
    EXPECT_EQ(fixture().size(), 233U);
    for (const auto& c : cases()) EXPECT_TRUE(hasRecord(c, "upstream")) << c.name;
    EXPECT_EQ(cases().size(), 25U);
}

TEST(VaulthallaGoldens, SignerReproducesEveryUpstreamRecord) {
    for (const auto& c : cases()) {
        const auto s = signCase(c);
        EXPECT_EQ(s.authorization, record(c, "upstream", "authorization")) << c.name;
        EXPECT_EQ(s.canonical_request, record(c, "upstream", "canonical_request")) << c.name;
        EXPECT_EQ(s.string_to_sign, record(c, "upstream", "string_to_sign")) << c.name;
    }
}

TEST(VaulthallaGoldens, VerifierReproducesGatewayRecordsAndAcceptsEveryCase) {
    for (const auto& c : cases()) {
        const auto sent = signCase(c);
        const auto input = gatewayInput(c, sent);
        const auto options = optionsFor(c);
        const auto parsed = sv::parseAuthorization(input, options);
        ASSERT_TRUE(parsed.has_value()) << c.name << ": " << parsed.error().message;
        const auto canonical = sv::canonicalRequestFor(input, *parsed, options);
        // The verifier rebuilds exactly what the signer signed.
        EXPECT_EQ(canonical, sent.canonical_request) << c.name;
        if (c.name != "aws-suite/get-utf8") {
            EXPECT_EQ(canonical, record(c, "gateway", "canonical_request")) << c.name;
            EXPECT_EQ(sv::signatureFor(input, *parsed, c.secret_key, options), record(c, "gateway", "signature"))
                << c.name;
        }
        const auto result = sv::verify(input, c.secret_key, sv::test::at(c.time), options);
        EXPECT_TRUE(result.ok()) << c.name << ": " << result.message;
    }
}

// Point 3 of the compat notes. Vaulthalla's gateway (S3-only in production) single-encoded every path; for a non-S3
// service the wire path must be encoded once more. The record differs only there.
TEST(VaulthallaGoldens, NonS3PathIsEncodedAgainRelativeToTheWire) {
    const auto& c = *std::ranges::find_if(cases(), [](const Case& x) { return x.name == "aws-suite/get-utf8"; });
    const auto sent = signCase(c);
    EXPECT_EQ(sent.encoded_path, "/%E1%88%B4");
    EXPECT_NE(sent.canonical_request.find("\n/%25E1%2588%25B4\n"), std::string::npos);
    EXPECT_NE(record(c, "gateway", "canonical_request").find("\n/%E1%88%B4\n"), std::string::npos);
    // The client that sent "/%E1%88%B4" is botocore: SigV4Auth over that URL gives this signature.
    EXPECT_EQ(sent.signature, "697b34846207a3f72246f99d74ae1ee4fe54f44bb06730c58a0d339eb079596d");
}

// Where legacy and SES deviate from SigV4 (and so from the library). Pinning the exact set keeps docs/compat-notes.md
// honest: a migrated caller's signatures change for these cases only.
TEST(VaulthallaGoldens, KnownDeviationsOfLegacyAndSes) {
    std::set<std::string> deviations;
    for (const auto& c : cases()) {
        const auto s = signCase(c);
        for (const std::string impl : {"legacy", "ses"}) {
            if (!hasRecord(c, impl)) continue;
            if (record(c, impl, "canonical_request") != s.canonical_request ||
                record(c, impl, "authorization") != s.authorization)
                deviations.insert(c.name + " " + impl);
        }
    }
    const std::set<std::string> expected{
        // ses hard-codes service "ses" in the scope, so every non-SES case it can sign differs by design (it has no
        // UNSIGNED-PAYLOAD and no session tokens, so those cases have no ses record).
        "aws-s3-docs/get-bucket-lifecycle ses",   // also: unsorted query, bare "lifecycle" (no "=")
        "aws-s3-docs/get-object-range ses",
        "aws-suite/get-utf8 legacy",              // legacy hard-codes "s3" and single-encodes the path
        "aws-suite/get-utf8 ses",
        "aws-suite/get-vanilla legacy",           // legacy hard-codes service "s3" in the scope
        "aws-suite/get-vanilla ses",
        "aws-suite/get-vanilla-query-order-key-case legacy",
        "aws-suite/get-vanilla-query-order-key-case ses",
        "aws-suite/get-vanilla-query-unreserved legacy",
        "aws-suite/get-vanilla-query-unreserved ses",
        "aws-suite/post-x-www-form-urlencoded legacy",
        "aws-suite/post-x-www-form-urlencoded ses",
        "s3/multipart-complete ses",
        "s3/multipart-upload-part ses",
        "s3/put-object-headers-case-and-space legacy",   // untrimmed header values
        "s3/put-object-headers-case-and-space ses",
        "s3/put-object-payload-hash ses",
        "ses/send-email legacy",                  // legacy hard-codes service "s3"
    };
    for (const auto& d : deviations) EXPECT_TRUE(expected.contains(d)) << "unexpected deviation: " << d;
    for (const auto& e : expected) EXPECT_TRUE(deviations.contains(e)) << "expected deviation is gone: " << e;
    // SES itself agrees with the library on the one request it really sends.
    EXPECT_FALSE(deviations.contains("ses/send-email ses"));
}

// Point 1: legacy and SES signed header values untrimmed; SigV4 trims and collapses spaces.
TEST(VaulthallaGoldens, HeaderValuesAreTrimmedAndCollapsed) {
    const auto& c = *std::ranges::find_if(cases(), [](const Case& x) {
        return x.name == "s3/put-object-headers-case-and-space";
    });
    const auto s = signCase(c);
    EXPECT_NE(s.canonical_request.find("\nx-amz-meta-owner:Cooper Larson\n"), std::string::npos);
    EXPECT_NE(record(c, "legacy", "canonical_request").find("\nx-amz-meta-owner:  Cooper   Larson \n"),
              std::string::npos);
    EXPECT_EQ(s.authorization, record(c, "upstream", "authorization"));
    // The gateway verifies the library's (and upstream's) signature, and so would AWS.
    EXPECT_TRUE(sv::verify(gatewayInput(c, s), c.secret_key, sv::test::at(c.time)).ok());
}

// Point 2: SES signed the query as written; SigV4 sorts it and writes a flag parameter as "name=".
TEST(VaulthallaGoldens, QueryIsSortedAndFlagParametersGetAnEquals) {
    const auto& c = *std::ranges::find_if(cases(), [](const Case& x) {
        return x.name == "aws-s3-docs/get-bucket-lifecycle";
    });
    const auto s = signCase(c);
    EXPECT_EQ(s.query_string, "lifecycle=");
    EXPECT_EQ(s.signature, "fea454ca298b7da1c68078a5d1bdbfbbe0d65c699e0f91ac7a200a0136783543");   // AWS published
    EXPECT_NE(record(c, "ses", "canonical_request").find("\nlifecycle\n"), std::string::npos);

    const auto& list = *std::ranges::find_if(cases(), [](const Case& x) { return x.name == "s3/list-v2-continuation"; });
    EXPECT_TRUE(signCase(list).query_string.starts_with("continuation-token="));
}
