// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Valkyrian Labs LLC
//
// Randomized robustness of the request parser and verifier: random and mutated Authorization headers, targets and
// header sets must never crash, throw or trip the sanitizers, and must never verify. A plain loop with a fixed seed
// (reproducible); set VL_SIGV4_FUZZ_ITERATIONS to run longer.

#include "support.hpp"

#include <gtest/gtest.h>

#include <cstdlib>
#include <random>
#include <string>
#include <vector>

namespace {

namespace sv = vl::sigv4;

std::size_t iterations() {
    if (const char* env = std::getenv("VL_SIGV4_FUZZ_ITERATIONS"); env && *env) return std::strtoull(env, nullptr, 10);
    return 20000;
}

const std::vector<std::string> kTokens{
    "AWS4-HMAC-SHA256", " ", "  ", "\t", ",", ", ", "=", "/", ";", "%", "%2F", "%zz", "%", "?", "&", "+",
    "Credential", "SignedHeaders", "Signature", "Credential=", "SignedHeaders=", "Signature=", "AKIDEXAMPLE",
    "20261102", "20261102T101500Z", "us-east-1", "s3", "aws4_request", "host", "x-amz-date", "host;x-amz-date",
    "deadbeef", "0123456789abcdef", "X-Amz-Algorithm=", "X-Amz-Credential=", "X-Amz-Date=", "X-Amz-Expires=",
    "X-Amz-SignedHeaders=", "X-Amz-Signature=", "X-Amz-Security-Token=", "604800", "604801", "0", "-1",
    "18446744073709551616", "\xe1\x88\xb4", std::string(1, '\0'), "\xff", "\r\n", "UNSIGNED-PAYLOAD",
    "STREAMING-AWS4-HMAC-SHA256-PAYLOAD"};

std::string randomString(std::mt19937_64& rng, const std::size_t maxTokens) {
    std::uniform_int_distribution<std::size_t> count(0, maxTokens);
    std::uniform_int_distribution<std::size_t> pick(0, kTokens.size() - 1);
    std::uniform_int_distribution<int> mode(0, 3);
    std::uniform_int_distribution<int> byte(0, 255);
    std::string out;
    const auto n = count(rng);
    for (std::size_t i = 0; i < n; ++i) {
        if (mode(rng) == 0) out.push_back(static_cast<char>(byte(rng)));
        else out += kTokens[pick(rng)];
    }
    return out;
}

std::string mutate(std::string value, std::mt19937_64& rng) {
    std::uniform_int_distribution<int> op(0, 4);
    std::uniform_int_distribution<int> byte(0, 255);
    const auto rounds = std::uniform_int_distribution<int>(1, 4)(rng);
    for (int r = 0; r < rounds && !value.empty(); ++r) {
        std::uniform_int_distribution<std::size_t> at(0, value.size() - 1);
        switch (op(rng)) {
            case 0: value[at(rng)] = static_cast<char>(byte(rng)); break;
            case 1: value.erase(at(rng), 1); break;
            case 2: value.insert(at(rng), 1, static_cast<char>(byte(rng))); break;
            case 3: value.resize(at(rng)); break;
            default: value.insert(at(rng), kTokens[static_cast<std::size_t>(byte(rng)) % kTokens.size()]); break;
        }
    }
    return value;
}

void exercise(const sv::VerificationInput& input, const sv::TimePoint now) {
    const auto parsed = sv::parseAuthorization(input);
    if (parsed) {
        (void)sv::canonicalRequestFor(input, *parsed);
        EXPECT_FALSE(sv::verify(input, *parsed, "secret", now).ok());
    } else {
        EXPECT_NE(parsed.error().code, sv::ErrorCode::None);
        EXPECT_FALSE(parsed.error().message.empty());
    }
    const auto result = sv::verify(input, "secret", now);
    EXPECT_FALSE(result.ok());
    EXPECT_FALSE(result.message.empty());
    const sv::SecretLookup lookup = [](std::string_view) -> std::optional<std::string> { return "secret"; };
    EXPECT_FALSE(sv::verify(input, lookup, now).ok());
}

}

TEST(Robustness, RandomAuthorizationHeadersAndTargets) {
    std::mt19937_64 rng(0x5167'7634ULL);
    const auto now = sv::test::at(sv::test::k20261102T000000Z);
    for (std::size_t i = 0; i < iterations(); ++i) {
        sv::VerificationInput input{.method = "GET",
                                    .target = "/" + randomString(rng, 6) + "?" + randomString(rng, 12),
                                    .host = "h",
                                    .headers = {{"Authorization", randomString(rng, 16)},
                                                {"x-amz-date", randomString(rng, 2)},
                                                {randomString(rng, 2), randomString(rng, 3)}},
                                    .body = {},
                                    .body_sha256 = std::nullopt};
        if (i % 3 == 0) input.headers.erase(input.headers.begin());   // presigned-only shapes
        ASSERT_NO_THROW(exercise(input, now)) << i;
    }
}

TEST(Robustness, MutatedValidRequests) {
    std::mt19937_64 rng(0x7631'0001ULL);
    const auto now = sv::test::at(sv::test::k20261102T000000Z);
    const auto request = sv::test::makeRequest("GET", "s3.example.test", "/bucket/a b+c.txt", {{"versionId", "v+/="}},
                                               {{"Range", "bytes=0-9"}});
    const auto s = sv::sign(request, sv::test::kS3Docs, "us-east-1", "s3", now);
    const auto p = sv::presign(request, sv::test::kS3Docs, "us-east-1", "s3", now, std::chrono::seconds{600});
    ASSERT_TRUE(p.has_value());

    for (std::size_t i = 0; i < iterations(); ++i) {
        sv::VerificationInput header{.method = "GET", .target = s.target(), .host = {}, .headers = {}, .body = {},
                                     .body_sha256 = std::nullopt};
        for (const auto& [name, value] : s.headers) header.headers.emplace_back(name, value);
        auto& authorization = header.headers.front();   // map order: "authorization" first
        authorization.second = mutate(authorization.second, rng);
        if (i % 2 == 0) header.target = mutate(header.target, rng);
        ASSERT_NO_THROW(exercise(header, now)) << i;

        sv::VerificationInput presigned{.method = "GET", .target = mutate(p->target(), rng), .host = "s3.example.test",
                                        .headers = {}, .body = {}, .body_sha256 = std::nullopt};
        // A mutation can leave the signed request intact (e.g. one that only touches X-Amz-Signature's case);
        // only a request that still verifies with the right secret is acceptable then.
        const auto parsed = sv::parseAuthorization(presigned);
        if (parsed) {
            const auto result = sv::verify(presigned, sv::test::kS3Docs.secret_key, now);
            if (result.ok()) {
                EXPECT_EQ(sv::canonicalRequestFor(presigned, *parsed), p->canonical_request);
            }
        }
        ASSERT_NO_THROW((void)sv::verify(presigned, "secret", now)) << i;
    }
}
