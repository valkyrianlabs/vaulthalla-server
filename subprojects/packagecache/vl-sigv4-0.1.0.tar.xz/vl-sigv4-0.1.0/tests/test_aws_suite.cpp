// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Valkyrian Labs LLC
//
// AWS SigV4 test suite (aws-sig-v4-test-suite, 2015-08-30, service "service", region us-east-1, AKIDEXAMPLE). Every
// signature here was reproduced with botocore 1.34 (SigV4Auth with a fixed clock) or, for the repeated-header
// cases botocore cannot express, with an independent HMAC computation of the suite's canonical request.
//
// Not reproduced: get-space / get-utf8 / get-slash* / get-relative* (the suite puts unencoded or non-normalized
// paths on the wire; this signer takes raw paths and double-encodes them for non-S3 services, as botocore does),
// get-header-value-multiline (obsolete line folding) and post-sts-token (its token is not reproduced here; session
// tokens are covered in the S3 tests).

#include "support.hpp"

#include <gtest/gtest.h>

namespace {

using vl::sigv4::HeaderList;
using vl::sigv4::QueryParams;
using vl::sigv4::Signed;
using vl::sigv4::sign;
using vl::sigv4::test::at;
using vl::sigv4::test::k20150830T123600Z;
using vl::sigv4::test::kSuite;
using vl::sigv4::test::makeRequest;

constexpr auto kUnreserved = "-._~0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";

Signed suite(const std::string& method, const std::string& path, QueryParams query = {}, HeaderList headers = {},
             const std::string& body = {}) {
    return sign(makeRequest(method, "example.amazonaws.com", path, std::move(query), std::move(headers), body), kSuite,
                "us-east-1", "service", at(k20150830T123600Z));
}

}

TEST(AwsSuite, GetVanilla) {
    const auto s = suite("GET", "/");
    EXPECT_EQ(s.signature, "5fa00fa31553b73ebf1942676e86291e8372ff2a2260956d9b8aae1d763fbf31");
    EXPECT_EQ(s.authorization,
              "AWS4-HMAC-SHA256 Credential=AKIDEXAMPLE/20150830/us-east-1/service/aws4_request, "
              "SignedHeaders=host;x-amz-date, Signature=5fa00fa31553b73ebf1942676e86291e8372ff2a2260956d9b8aae1d763fbf31");
    EXPECT_EQ(s.canonical_request,
              "GET\n/\n\nhost:example.amazonaws.com\nx-amz-date:20150830T123600Z\n\nhost;x-amz-date\n"
              "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855");
    EXPECT_EQ(s.string_to_sign,
              "AWS4-HMAC-SHA256\n20150830T123600Z\n20150830/us-east-1/service/aws4_request\n"
              "bb579772317eb040ac9ed261061d46c1f17a8133879d6129b6e1c25292927e63");
    EXPECT_EQ(s.headers.at("x-amz-date"), "20150830T123600Z");
    EXPECT_EQ(s.headers.at("host"), "example.amazonaws.com");
    EXPECT_FALSE(s.headers.contains("x-amz-content-sha256"));   // S3 only
    EXPECT_EQ(s.target(), "/");
}

TEST(AwsSuite, GetVanillaEmptyQuery) {
    // get-vanilla-query: "GET /?" signs like get-vanilla.
    EXPECT_EQ(suite("GET", "/", {}).signature, "5fa00fa31553b73ebf1942676e86291e8372ff2a2260956d9b8aae1d763fbf31");
}

TEST(AwsSuite, GetVanillaEmptyQueryKey) {
    EXPECT_EQ(suite("GET", "/", {{"Param1", "value1"}}).signature,
              "a67d582fa61cc504c4bae71f336f98b97f1ea3c7a6bfe1b6e45aec72011b9aeb");
}

TEST(AwsSuite, GetVanillaQueryOrderKeyCase) {
    const auto s = suite("GET", "/", {{"Param2", "value2"}, {"Param1", "value1"}});
    EXPECT_EQ(s.query_string, "Param1=value1&Param2=value2");
    EXPECT_EQ(s.signature, "b97d918cfa904a5beff61c982a1b6f458b799221646efd99d3219ec94cdf2500");
    EXPECT_EQ(s.target(), "/?Param1=value1&Param2=value2");
}

TEST(AwsSuite, GetVanillaQueryOrderKey) {
    const auto s = suite("GET", "/", {{"Param1", "value2"}, {"Param1", "Value1"}});
    EXPECT_EQ(s.query_string, "Param1=Value1&Param1=value2");
    EXPECT_EQ(s.signature, "eedbc4e291e521cf13422ffca22be7d2eb8146eecf653089df300a15b2382bd1");
}

TEST(AwsSuite, GetVanillaQueryOrderValue) {
    const auto s = suite("GET", "/", {{"Param1", "value2"}, {"Param1", "value1"}});
    EXPECT_EQ(s.query_string, "Param1=value1&Param1=value2");
    EXPECT_EQ(s.signature, "5772eed61e12b33fae39ee5e7012498b51d56abc0abb7c60486157bd471c4694");
}

TEST(AwsSuite, GetVanillaQueryUnreserved) {
    EXPECT_EQ(suite("GET", "/", {{kUnreserved, kUnreserved}}).signature,
              "9c3e54bfcdf0b19771a7f523ee5669cdf59bc7cc0884027167c21bb143a40197");
}

TEST(AwsSuite, GetVanillaUtf8Query) {
    const auto s = suite("GET", "/", {{"\xe1\x88\xb4", "bar"}});
    EXPECT_EQ(s.query_string, "%E1%88%B4=bar");
    EXPECT_EQ(s.signature, "2cdec8eed098649ff3a119c94853b13c643bcf08f8b0a1d91e12c9027818dd04");
}

TEST(AwsSuite, GetUnreserved) {
    EXPECT_EQ(suite("GET", std::string("/") + kUnreserved).signature,
              "07ef7494c76fa4850883e2b006601f940f8a34d404d0cfa977f52a65bbf5f24f");
}

TEST(AwsSuite, GetHeaderKeyDuplicate) {
    const auto s = suite("GET", "/", {}, {{"My-Header1", "value2"}, {"My-Header1", "value2"}, {"My-Header1", "value1"}});
    EXPECT_EQ(s.headers.at("my-header1"), "value2,value2,value1");
    EXPECT_EQ(s.signature, "c9d5ea9f3f72853aea855b47ea873832890dbdd183b4468f858259531a5138ea");
}

TEST(AwsSuite, GetHeaderValueOrder) {
    const auto s = suite("GET", "/", {},
                         {{"My-Header1", "value4"}, {"My-Header1", "value1"}, {"My-Header1", "value3"},
                          {"My-Header1", "value2"}});
    EXPECT_EQ(s.signature, "08c7e5a9acfcfeb3ab6b2185e75ce8b1deb5e634ec47601a50643f830c755c01");
}

TEST(AwsSuite, GetHeaderValueTrim) {
    const auto s = suite("GET", "/", {}, {{"My-Header1", " value1"}, {"My-Header2", " \"a   b   c\" "}});
    EXPECT_NE(s.canonical_request.find("my-header1:value1\nmy-header2:\"a b c\"\n"), std::string::npos);
    EXPECT_EQ(s.signature, "acc3ed3afb60bb290fc8d2dd0098b9911fcaa05412b367055dee359757a9c736");
}

TEST(AwsSuite, PostVanilla) {
    EXPECT_EQ(suite("POST", "/").signature, "5da7c1a2acd57cee7505fc6676e4e544621c30862966e37dddb68e92efbe5d6b");
}

TEST(AwsSuite, PostHeaderKeyCase) {
    // The suite sends X-Amz-Date in mixed case; sign() always sets x-amz-date itself and replaces a caller's copy.
    EXPECT_EQ(suite("POST", "/", {}, {{"X-Amz-Date", "20990101T000000Z"}}).signature,
              "5da7c1a2acd57cee7505fc6676e4e544621c30862966e37dddb68e92efbe5d6b");
}

TEST(AwsSuite, PostVanillaQuery) {
    EXPECT_EQ(suite("POST", "/", {{"Param1", "value1"}}).signature,
              "28038455d6de14eafc1f9222cf5aa6f1a96197d7deb8263271d420d138af7f11");
}

TEST(AwsSuite, PostHeaderKeySort) {
    const auto s = suite("POST", "/", {}, {{"My-Header1", "value1"}});
    EXPECT_NE(s.authorization.find("SignedHeaders=host;my-header1;x-amz-date,"), std::string::npos);
    EXPECT_EQ(s.signature, "c5410059b04c1ee005303aed430f6e6645f61f4dc9e1461ec8f8916fdf18852c");
}

TEST(AwsSuite, PostHeaderValueCase) {
    EXPECT_EQ(suite("POST", "/", {}, {{"My-Header1", "VALUE1"}}).signature,
              "cdbc9802e29d2942e5e10b5bccfdd67c5f22c7c4e8ae67b53629efa58b974b7d");
}

TEST(AwsSuite, PostXWwwFormUrlencoded) {
    const auto s = suite("POST", "/", {}, {{"Content-Type", "application/x-www-form-urlencoded"}}, "Param1=value1");
    EXPECT_NE(s.authorization.find("SignedHeaders=content-type;host;x-amz-date,"), std::string::npos);
    EXPECT_EQ(s.signature, "ff11897932ad3f4e8b18135d722051e5ac45fc38421b1da7b9d196a0fe09473a");
}

TEST(AwsSuite, PostXWwwFormUrlencodedParameters) {
    EXPECT_EQ(suite("POST", "/", {}, {{"Content-Type", "application/x-www-form-urlencoded; charset=utf8"}},
                    "Param1=value1")
                  .signature,
              "1a72ec8f64bd914b0e42e42607c7fbce7fb2c7465f63e3092b3b0d39fa77a6fe");
}
