// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Valkyrian Labs LLC
//
// S3 and service-specific signing vectors:
//  - the worked examples of the AWS S3 SigV4 documentation (header auth and presigned URL), whose published
//    signatures are reproduced here and with botocore;
//  - goldens captured from Vaulthalla's signer (core/src/storage/s3/sigv4/Signer.cpp at 608aac48) for the request
//    shapes Vaulthalla sends: ranges, versionId with + / =, keys with spaces and UTF-8, UNSIGNED-PAYLOAD, session
//    tokens, multipart, copy, R2, STS, SQS, SES. The library must keep producing them byte for byte;
//  - presigned URLs cross-checked with botocore 1.34 (S3SigV4QueryAuth / SigV4QueryAuth).

#include "support.hpp"

#include <gtest/gtest.h>

namespace {

using vl::sigv4::Credentials;
using vl::sigv4::presign;
using vl::sigv4::Request;
using vl::sigv4::sha256Hex;
using vl::sigv4::sign;
using vl::sigv4::Signed;
using vl::sigv4::test::at;
using vl::sigv4::test::k20130524T000000Z;
using vl::sigv4::test::k20261102T000000Z;
using vl::sigv4::test::kS3Docs;
using vl::sigv4::test::kS3DocsWithToken;
using vl::sigv4::test::makeRequest;
using vl::sigv4::test::param;

const std::string kEmpty = sha256Hex("");

Signed s3Docs(const Request& request) { return sign(request, kS3Docs, "us-east-1", "s3", at(k20130524T000000Z)); }

Signed golden(const Request& request, const Credentials& credentials, const std::string& region,
              const std::string& service) {
    return sign(request, credentials, region, service, at(k20261102T000000Z));
}

Request withPayloadHash(Request request, std::string payloadHash) {
    request.payload_hash = std::move(payloadHash);
    return request;
}

}

// --- AWS S3 documentation ----------------------------------------------------------------------------------------

TEST(S3Docs, GetObjectWithRange) {
    const auto s = s3Docs(makeRequest("GET", "examplebucket.s3.amazonaws.com", "/test.txt", {}, {{"Range", "bytes=0-9"}}));
    EXPECT_EQ(s.signature, "f0e8bdb87c964420e857bd35b5d6ed310bd44f0170aba48dd91039c6036bdb41");
    EXPECT_NE(s.authorization.find("SignedHeaders=host;range;x-amz-content-sha256;x-amz-date,"), std::string::npos);
    EXPECT_EQ(s.headers.at("x-amz-content-sha256"), kEmpty);
    EXPECT_EQ(s.string_to_sign,
              "AWS4-HMAC-SHA256\n20130524T000000Z\n20130524/us-east-1/s3/aws4_request\n"
              "7344ae5b7ee6c3e7e6b0fe0640412a37625d1fbfff95c48bbb2dc43964946972");
}

TEST(S3Docs, PutObject) {
    const auto s = s3Docs(makeRequest("PUT", "examplebucket.s3.amazonaws.com", "/test$file.text", {},
                                      {{"Date", "Fri, 24 May 2013 00:00:00 GMT"},
                                       {"x-amz-storage-class", "REDUCED_REDUNDANCY"}},
                                      "Welcome to Amazon S3."));
    EXPECT_EQ(s.encoded_path, "/test%24file.text");
    EXPECT_EQ(s.headers.at("x-amz-content-sha256"),
              "44ce7dd67c959e0d3524ffac1771dfbba87d2b6b4b4e99e42034a8b803f8b072");
    EXPECT_NE(s.authorization.find("SignedHeaders=date;host;x-amz-content-sha256;x-amz-date;x-amz-storage-class,"),
              std::string::npos);
    EXPECT_EQ(s.signature, "98ad721746da40c64f1a55b78f14c238d841ea1380cd77a1b5971af0ece108bd");
}

TEST(S3Docs, GetBucketLifecycle) {
    const auto s = s3Docs(makeRequest("GET", "examplebucket.s3.amazonaws.com", "/", {{"lifecycle", ""}}));
    EXPECT_EQ(s.query_string, "lifecycle=");
    EXPECT_EQ(s.signature, "fea454ca298b7da1c68078a5d1bdbfbbe0d65c699e0f91ac7a200a0136783543");
}

TEST(S3Docs, ListObjects) {
    const auto s = s3Docs(makeRequest("GET", "examplebucket.s3.amazonaws.com", "/", {{"max-keys", "2"}, {"prefix", "J"}}));
    EXPECT_EQ(s.query_string, "max-keys=2&prefix=J");
    EXPECT_EQ(s.signature, "34b48302e7b5fa45bde8084f4b7868a86f0a534bc59db6670ed5711ef69dc6f7");
}

TEST(S3Docs, PresignedGetObject) {
    const auto p = presign(makeRequest("GET", "examplebucket.s3.amazonaws.com", "/test.txt"), kS3Docs, "us-east-1",
                           "s3", at(k20130524T000000Z), std::chrono::seconds{86400});
    ASSERT_TRUE(p.has_value()) << p.error().message;
    EXPECT_EQ(p->signature, "aeeed9bbccd4d02ee5c0109b86d86835f995330da4c265957d157751f604d404");
    EXPECT_EQ(p->canonical_request,
              "GET\n/test.txt\n"
              "X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Credential=AKIAIOSFODNN7EXAMPLE%2F20130524%2Fus-east-1%2Fs3%2F"
              "aws4_request&X-Amz-Date=20130524T000000Z&X-Amz-Expires=86400&X-Amz-SignedHeaders=host\n"
              "host:examplebucket.s3.amazonaws.com\n\nhost\nUNSIGNED-PAYLOAD");
    EXPECT_EQ(p->url(),
              "https://examplebucket.s3.amazonaws.com/test.txt?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Credential="
              "AKIAIOSFODNN7EXAMPLE%2F20130524%2Fus-east-1%2Fs3%2Faws4_request&X-Amz-Date=20130524T000000Z&"
              "X-Amz-Expires=86400&X-Amz-SignedHeaders=host&X-Amz-Signature="
              "aeeed9bbccd4d02ee5c0109b86d86835f995330da4c265957d157751f604d404");
}

// --- botocore presigns -------------------------------------------------------------------------------------------

TEST(Presign, S3WithSessionTokenVersionIdAndEncodedKey) {
    Request request = makeRequest("GET", "vh-bucket.s3.us-east-2.amazonaws.com", "/dir/a b+c.txt",
                                  {{"versionId", "3/L4k+="}});
    const auto p = presign(request, kS3DocsWithToken, "us-east-2", "s3", at(k20261102T000000Z),
                           std::chrono::seconds{3600});
    ASSERT_TRUE(p.has_value());
    EXPECT_EQ(p->encoded_path, "/dir/a%20b%2Bc.txt");
    EXPECT_EQ(param(p->query_string, "X-Amz-Security-Token"),
              "FwoGZXIvYXdzEXAMPLE%2F%2F%2F%2F%2F%2F%2F%2F%2F%2FwEaDEXAMPLETOKEN%2B%2F%3D");
    EXPECT_EQ(param(p->query_string, "versionId"), "3%2FL4k%2B%3D");
    EXPECT_EQ(p->signature, "2f3e31f1c1dc5e62d3783cd7ea4c6c5c8598e02966732d67fb1f60979d33dd21");
    EXPECT_TRUE(p->query_string.ends_with("&X-Amz-Signature=" + p->signature));
}

TEST(Presign, StsGetCallerIdentityWithExtraSignedHeader) {
    // The shape of an EKS authentication token: a presigned STS call with x-k8s-aws-id signed.
    const auto p = presign(makeRequest("GET", "sts.amazonaws.com", "/",
                                       {{"Action", "GetCallerIdentity"}, {"Version", "2011-06-15"}},
                                       {{"x-k8s-aws-id", "my-cluster"}}),
                           kS3Docs, "us-east-1", "sts", at(k20261102T000000Z), std::chrono::seconds{60});
    ASSERT_TRUE(p.has_value());
    EXPECT_EQ(param(p->query_string, "X-Amz-SignedHeaders"), "host%3Bx-k8s-aws-id");
    EXPECT_TRUE(p->canonical_request.ends_with(sha256Hex("")));   // non-S3: the (empty) body's hash
    EXPECT_EQ(p->signature, "4cb84a377e5227c1152102dd3f9a486c95db652f20814e9e15cd35aae3020887");
}

TEST(Presign, ExpiryBounds) {
    const auto request = makeRequest("GET", "examplebucket.s3.amazonaws.com", "/test.txt");
    const auto now = at(k20261102T000000Z);
    EXPECT_TRUE(presign(request, kS3Docs, "us-east-1", "s3", now, std::chrono::seconds{1}).has_value());
    EXPECT_TRUE(presign(request, kS3Docs, "us-east-1", "s3", now, std::chrono::seconds{604800}).has_value());

    const auto tooLong = presign(request, kS3Docs, "us-east-1", "s3", now, std::chrono::seconds{604801});
    ASSERT_FALSE(tooLong.has_value());
    EXPECT_EQ(tooLong.error().code, vl::sigv4::ErrorCode::ExpiresTooLarge);
    const auto zero = presign(request, kS3Docs, "us-east-1", "s3", now, std::chrono::seconds{0});
    ASSERT_FALSE(zero.has_value());
    EXPECT_EQ(zero.error().code, vl::sigv4::ErrorCode::InvalidExpires);
    EXPECT_FALSE(presign(request, kS3Docs, "us-east-1", "s3", now, std::chrono::seconds{-5}).has_value());
}

// --- Vaulthalla signer goldens (Signer.cpp at 608aac48) ----------------------------------------------------------

TEST(VaulthallaGolden, S3RangeMatchesDocs) {
    const auto s = s3Docs(makeRequest("GET", "examplebucket.s3.amazonaws.com", "/test.txt", {}, {{"Range", "bytes=0-9"}}));
    EXPECT_EQ(s.authorization,
              "AWS4-HMAC-SHA256 Credential=AKIAIOSFODNN7EXAMPLE/20130524/us-east-1/s3/aws4_request, "
              "SignedHeaders=host;range;x-amz-content-sha256;x-amz-date, "
              "Signature=f0e8bdb87c964420e857bd35b5d6ed310bd44f0170aba48dd91039c6036bdb41");
}

TEST(VaulthallaGolden, VersionIdWithPlusSlashEquals) {
    const auto s = golden(makeRequest("GET", "examplebucket.s3.amazonaws.com", "/photos/my file+name=1.txt",
                                      {{"versionId", "3/L4kqtJlcpXroDTDmJ+rmSpXd3dIbrHY+MTRCxf3vjVBH40Nr8X8gdRQBpUMLUo="}}),
                          kS3Docs, "us-east-1", "s3");
    EXPECT_EQ(s.encoded_path, "/photos/my%20file%2Bname%3D1.txt");
    EXPECT_EQ(s.query_string, "versionId=3%2FL4kqtJlcpXroDTDmJ%2BrmSpXd3dIbrHY%2BMTRCxf3vjVBH40Nr8X8gdRQBpUMLUo%3D");
    EXPECT_EQ(s.signature, "fb8e8fe3af4bd0ae712d877729170eba592d56cc5043bcf508013db675b2c016");
}

TEST(VaulthallaGolden, PutUnsignedPayloadUtf8KeyAndTrimmedMeta) {
    const auto s = golden(withPayloadHash(makeRequest("PUT", "vh-bucket.s3.us-east-2.amazonaws.com",
                                                      "/dir/sub dir/\xc3\xbcn\xc3\xaf" "code \xc3\xa9.txt", {},
                                                      {{"Content-Type", "text/plain"},
                                                       {"x-amz-meta-note", "  a   b\t c  "}}),
                                          "UNSIGNED-PAYLOAD"),
                          kS3Docs, "us-east-2", "s3");
    EXPECT_EQ(s.encoded_path, "/dir/sub%20dir/%C3%BCn%C3%AFcode%20%C3%A9.txt");
    EXPECT_EQ(s.headers.at("x-amz-content-sha256"), "UNSIGNED-PAYLOAD");
    EXPECT_EQ(s.headers.at("x-amz-meta-note"), "a b c");
    EXPECT_EQ(s.signature, "8ca00a4ba09cf811726dd151c850dcf7104a4634006854e64b3f579c187f7534");
}

TEST(VaulthallaGolden, ListObjectsV2WithSessionToken) {
    const auto s = golden(makeRequest("GET", "s3.us-east-2.amazonaws.com", "/vh-bucket",
                                      {{"list-type", "2"}, {"prefix", "a b/"}, {"continuation-token", "1a+b/="},
                                       {"max-keys", "1000"}, {"delimiter", "/"}}),
                          kS3DocsWithToken, "us-east-2", "s3");
    EXPECT_EQ(s.query_string,
              "continuation-token=1a%2Bb%2F%3D&delimiter=%2F&list-type=2&max-keys=1000&prefix=a%20b%2F");
    EXPECT_EQ(s.headers.at("x-amz-security-token"), kS3DocsWithToken.session_token);
    EXPECT_NE(s.authorization.find("SignedHeaders=host;x-amz-content-sha256;x-amz-date;x-amz-security-token,"),
              std::string::npos);
    EXPECT_EQ(s.signature, "25e05fc9943b274dfdf1ab47931b5e5c93fd46d6bb5f2eba20531f37514e3c7c");
}

TEST(VaulthallaGolden, CopyObject) {
    const auto s = golden(makeRequest("PUT", "vh-bucket.s3.amazonaws.com", "/dest key.txt", {},
                                      {{"x-amz-copy-source", "/vh-bucket/src%20key.txt?versionId=abc%2B%2F%3D"},
                                       {"x-amz-metadata-directive", "COPY"}}),
                          kS3Docs, "us-east-1", "s3");
    EXPECT_EQ(s.signature, "d0add584f30a546e33a54e78e678bd5f17f7a7f47d2b3eded222df93c4c214ad");
}

TEST(VaulthallaGolden, MultipartInitiateAndUploadPart) {
    const auto init = golden(makeRequest("POST", "vh-bucket.s3.amazonaws.com", "/big.bin", {{"uploads", ""}}), kS3Docs,
                             "us-east-1", "s3");
    EXPECT_EQ(init.query_string, "uploads=");
    EXPECT_EQ(init.signature, "39e81308e8ca4975b4a8620252cae7b40f8357f3fd17a96b953bdc61e610556c");

    const auto part = golden(makeRequest("PUT", "vh-bucket.s3.amazonaws.com", "/big.bin",
                                         {{"uploadId", "u+id/=="}, {"partNumber", "2"}}, {}, "part-two"),
                             kS3Docs, "us-east-1", "s3");
    EXPECT_EQ(part.query_string, "partNumber=2&uploadId=u%2Bid%2F%3D%3D");
    EXPECT_EQ(part.signature, "81b177bb621c6aa7346459681aa5e1dcb7ffc8ea98a014bb74f177465d28ebd9");
}

TEST(VaulthallaGolden, HostWithPortAndEmptyPath) {
    const auto s = golden(makeRequest("GET", "localhost:9000", "", {{"location", ""}}), kS3Docs, "us-east-1", "s3");
    EXPECT_EQ(s.encoded_path, "/");
    EXPECT_EQ(s.headers.at("host"), "localhost:9000");
    EXPECT_EQ(s.signature, "aff9d4543def9185458fa7fea3e26af99df3ff3975405ae016feec2adf93e80c");
}

TEST(VaulthallaGolden, R2AutoRegionHead) {
    const auto s = golden(withPayloadHash(makeRequest("HEAD", "acct.r2.cloudflarestorage.com",
                                                      "/bucket/key with spaces & ampersand"),
                                          "UNSIGNED-PAYLOAD"),
                          kS3Docs, "auto", "s3");
    EXPECT_EQ(s.encoded_path, "/bucket/key%20with%20spaces%20%26%20ampersand");
    EXPECT_EQ(s.signature, "32ee217c5fba5c11598394a9f6645407b2bd86cf82e6345ac3e82c8c1039de97");
}

TEST(VaulthallaGolden, StsPostWithSessionToken) {
    const auto s = golden(makeRequest("POST", "sts.amazonaws.com", "/", {},
                                      {{"Content-Type", "application/x-www-form-urlencoded; charset=utf-8"}},
                                      "Action=GetCallerIdentity&Version=2011-06-15"),
                          kS3DocsWithToken, "us-east-1", "sts");
    EXPECT_FALSE(s.headers.contains("x-amz-content-sha256"));
    EXPECT_NE(s.authorization.find("SignedHeaders=content-type;host;x-amz-date;x-amz-security-token,"),
              std::string::npos);
    EXPECT_EQ(s.signature, "67c1a80f4bb7833c41fa1f126bc9d576042657cae39554bfed068448a03b79c0");
}

TEST(VaulthallaGolden, SqsDoubleEncodesPath) {
    const auto s = golden(makeRequest("GET", "sqs.us-east-1.amazonaws.com", "/123456789012/my queue",
                                      {{"Action", "GetQueueAttributes"}, {"AttributeName.1", "All"}}),
                          kS3Docs, "us-east-1", "sqs");
    EXPECT_EQ(s.encoded_path, "/123456789012/my%20queue");
    EXPECT_NE(s.canonical_request.find("\n/123456789012/my%2520queue\n"), std::string::npos);
    EXPECT_EQ(s.signature, "50e45b362b40191e33b4fdd3cf23fdea4c112a458bc7f1006f4547c49775f1b4");
}

TEST(VaulthallaGolden, SesSendEmailMatchesSesProviderShape) {
    // SesProvider::signAwsV4 signs content-type, host, x-amz-content-sha256 and x-amz-date over the JSON body.
    const std::string body = "{\"a\":1}";
    const auto s = golden(makeRequest("POST", "email.us-east-1.amazonaws.com", "/v2/email/outbound-emails", {},
                                      {{"content-type", "application/json"}, {"x-amz-content-sha256", sha256Hex(body)}},
                                      body),
                          kS3Docs, "us-east-1", "ses");
    EXPECT_NE(s.authorization.find("SignedHeaders=content-type;host;x-amz-content-sha256;x-amz-date,"),
              std::string::npos);
    EXPECT_EQ(s.signature, "7682409f6d5d3dd8c9fb89cbd9b82f191e9089d0f2564e3a175b0df48fffcec3");
}

TEST(VaulthallaGolden, EmptyPayloadHashMeansEmptyBody) {
    auto request = makeRequest("GET", "examplebucket.s3.amazonaws.com", "/test.txt", {}, {{"Range", "bytes=0-9"}});
    request.payload_hash.clear();
    EXPECT_EQ(s3Docs(request).signature, "f0e8bdb87c964420e857bd35b5d6ed310bd44f0170aba48dd91039c6036bdb41");
}

// The composable primitives give the same answer as sign(): what a caller migrating hand-rolled signing (the
// curl data-plane signer, SesProvider) would build.
TEST(Primitives, ComposeToTheSameSignature) {
    namespace sv = vl::sigv4;
    const auto s = s3Docs(makeRequest("GET", "examplebucket.s3.amazonaws.com", "/", {{"max-keys", "2"}, {"prefix", "J"}}));
    const auto headers = sv::canonicalHeaders({{"host", "examplebucket.s3.amazonaws.com"},
                                               {"x-amz-content-sha256", kEmpty},
                                               {"x-amz-date", "20130524T000000Z"}});
    const auto creq = sv::canonicalRequest("GET", "/", sv::sortEncodedQuery("prefix=J&max-keys=2"), headers.canonical,
                                           headers.signed_headers, kEmpty);
    EXPECT_EQ(creq, s.canonical_request);
    const auto scope = sv::credentialScope("20130524", "us-east-1", "s3");
    const auto signature = sv::signatureHex(
        sv::deriveSigningKey(kS3Docs.secret_key, "20130524", "us-east-1", "s3"),
        sv::stringToSign("20130524T000000Z", scope, creq));
    EXPECT_EQ(sv::authorizationHeader(kS3Docs.access_key, scope, headers.signed_headers, signature), s.authorization);
}
