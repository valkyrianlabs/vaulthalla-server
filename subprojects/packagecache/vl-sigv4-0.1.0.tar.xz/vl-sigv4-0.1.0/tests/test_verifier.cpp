// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Valkyrian Labs LLC
//
// Verifier: sign -> verify round trips (header and presigned, S3 and other services), the DB-free cases of
// Vaulthalla's S3GatewaySigV4Test ported to the library API, and the negative paths.

#include "support.hpp"

#include <gtest/gtest.h>

#include <algorithm>

namespace {

namespace sv = vl::sigv4;
using sv::ErrorCode;
using sv::ParsedAuth;
using sv::VerificationInput;
using sv::VerifyOptions;
using sv::test::at;
using sv::test::k20261102T000000Z;
using sv::test::kS3Docs;
using sv::test::kS3DocsWithToken;
using sv::test::makeRequest;

const std::string kSecret = "wJalrXUtnFEMI/K7MDENG+bPxRfiCYEXAMPLEKEY";
const std::string kAccessKey = "VHTESTACCESSKEY";
const sv::Credentials kGateway{.access_key = kAccessKey, .secret_key = kSecret, .session_token = {}};
const sv::TimePoint kNow = at(k20261102T000000Z) + std::chrono::hours{9} + std::chrono::minutes{30};

// What the server receives for a request signed by sign().
VerificationInput received(const sv::Request& request, const sv::Signed& s, const std::string_view body = {}) {
    VerificationInput input{.method = request.method, .target = s.target(), .host = {}, .headers = {}, .body = body,
                            .body_sha256 = std::nullopt};
    for (const auto& [name, value] : s.headers) input.headers.emplace_back(name, value);
    return input;
}

VerificationInput received(const sv::Request& request, const sv::Presigned& p) {
    return {.method = request.method, .target = p.target(), .host = {}, .headers = {{"Host", p.host}}, .body = {},
            .body_sha256 = std::nullopt};
}

void setHeader(VerificationInput& input, const std::string& name, const std::string& value) {
    const auto lowered = sv::toLower(name);
    std::erase_if(input.headers, [&](const auto& h) { return sv::toLower(h.first) == lowered; });
    input.headers.emplace_back(name, value);
}

void eraseHeader(VerificationInput& input, const std::string& name) {
    const auto lowered = sv::toLower(name);
    std::erase_if(input.headers, [&](const auto& h) { return sv::toLower(h.first) == lowered; });
}

std::string authorizationFor(const ParsedAuth& auth) {
    return sv::authorizationHeader(auth.credential.access_key, auth.credential.str(), auth.signed_headers,
                                   auth.signature);
}

ParsedAuth gatewayAuth(const std::string& amzDate, std::string signedHeaders, std::string payloadHash) {
    return {.credential = {.access_key = kAccessKey, .date = amzDate.substr(0, 8), .region = "us-east-1",
                           .service = "s3"},
            .signed_headers = std::move(signedHeaders),
            .signature = {},
            .amz_date = amzDate,
            .payload_hash = std::move(payloadHash),
            .presigned = false,
            .expires = {},
            .session_token = std::nullopt};
}

// The verifier inputs used across the negative tests: a signed S3 GET.
struct Signed {
    sv::Request request;
    sv::Signed signature;
    VerificationInput input;
};

Signed signedGet(const sv::TimePoint when = kNow) {
    Signed out{.request = makeRequest("GET", "localhost:39000", "/bucket/photos/a b+c.txt", {{"versionId", "v+1/="}},
                                      {{"Range", "bytes=0-9"}}),
               .signature = {},
               .input = {}};
    out.signature = sv::sign(out.request, kGateway, "us-east-1", "s3", when);
    out.input = received(out.request, out.signature);
    return out;
}

}

// --- round trips -------------------------------------------------------------------------------------------------

TEST(RoundTrip, S3HeaderAuth) {
    const auto [request, signature, input] = signedGet();
    const auto result = sv::verify(input, kSecret, kNow);
    EXPECT_TRUE(result.ok()) << result.message;
    EXPECT_TRUE(static_cast<bool>(result));
    EXPECT_EQ(result.access_key, kAccessKey);
    ASSERT_TRUE(result.auth.has_value());
    EXPECT_FALSE(result.auth->presigned);
    EXPECT_EQ(result.canonical_request, signature.canonical_request);
    EXPECT_EQ(result.string_to_sign, signature.string_to_sign);
}

TEST(RoundTrip, S3PutWithBodyUtf8KeyAndMetadata) {
    const std::string body = "hello, \xc3\xa9t\xc3\xa9";
    const auto request = makeRequest("PUT", "s3.example.test", "/bucket/dir/\xc3\xbc key+=&.txt", {},
                                     {{"Content-Type", "text/plain"}, {"x-amz-meta-note", "  spaced   out "},
                                      {"Content-Length", std::to_string(body.size())}},
                                     body);
    const auto s = sv::sign(request, kGateway, "auto", "s3", kNow);
    const auto result = sv::verify(received(request, s, body), kSecret, kNow);
    EXPECT_TRUE(result.ok()) << result.message;
}

TEST(RoundTrip, S3UnsignedPayloadAndSessionToken) {
    auto request = makeRequest("PUT", "s3.example.test", "/bucket/key", {{"partNumber", "3"}, {"uploadId", "u+/="}});
    request.payload_hash = "UNSIGNED-PAYLOAD";
    const auto s = sv::sign(request, kS3DocsWithToken, "us-east-1", "s3", kNow);
    const std::string body = "any body at all";
    auto input = received(request, s, body);
    const auto result = sv::verify(input, kS3DocsWithToken.secret_key, kNow);
    EXPECT_TRUE(result.ok()) << result.message;
    ASSERT_TRUE(result.auth.has_value());
    EXPECT_EQ(result.auth->session_token, kS3DocsWithToken.session_token);

    VerifyOptions noTokens;
    noTokens.reject_session_tokens = true;
    const auto rejected = sv::verify(input, kS3DocsWithToken.secret_key, kNow, noTokens);
    EXPECT_EQ(rejected.code, ErrorCode::SessionTokenNotSupported);
    EXPECT_EQ(sv::awsErrorCode(rejected.code), "InvalidToken");
}

TEST(RoundTrip, RepeatedHeadersAndMixedCaseNames) {
    const auto request = makeRequest("GET", "s3.example.test", "/bucket/key", {},
                                     {{"X-Amz-Meta-Tag", "one"}, {"x-amz-meta-tag", "two"}});
    const auto s = sv::sign(request, kGateway, "us-east-1", "s3", kNow);
    EXPECT_EQ(s.headers.at("x-amz-meta-tag"), "one,two");
    VerificationInput input{.method = "GET", .target = s.target(), .host = "s3.example.test",
                            .headers = {{"X-Amz-Date", s.headers.at("x-amz-date")},
                                        {"X-Amz-Content-Sha256", s.headers.at("x-amz-content-sha256")},
                                        {"X-AMZ-META-TAG", "one"},
                                        {"x-amz-meta-tag", "  two "},
                                        {"Authorization", s.authorization}},
                            .body = {}, .body_sha256 = std::nullopt};
    // No Host header: VerificationInput::host stands in for it.
    const auto result = sv::verify(input, kSecret, kNow);
    EXPECT_TRUE(result.ok()) << result.message;
}

TEST(RoundTrip, SecretLookup) {
    const auto [request, signature, input] = signedGet();
    int calls = 0;
    const sv::SecretLookup lookup = [&](const std::string_view key) -> std::optional<std::string> {
        ++calls;
        if (key == kAccessKey) return kSecret;
        return std::nullopt;
    };
    EXPECT_TRUE(sv::verify(input, lookup, kNow).ok());
    EXPECT_EQ(calls, 1);

    const sv::SecretLookup none = [&](std::string_view) -> std::optional<std::string> {
        ++calls;
        return std::nullopt;
    };
    const auto unknown = sv::verify(input, none, kNow);
    EXPECT_EQ(unknown.code, ErrorCode::UnknownAccessKey);
    EXPECT_EQ(unknown.access_key, kAccessKey);
    EXPECT_EQ(sv::awsErrorCode(unknown.code), "InvalidAccessKeyId");
    EXPECT_EQ(calls, 2);

    // A request that fails the secret-free checks never reaches the lookup.
    const auto skewed = sv::verify(input, lookup, kNow + std::chrono::hours{1});
    EXPECT_EQ(skewed.code, ErrorCode::RequestTimeTooSkewed);
    EXPECT_EQ(calls, 2);
    EXPECT_EQ(sv::verify(input, sv::SecretLookup{}, kNow).code, ErrorCode::UnknownAccessKey);
}

TEST(RoundTrip, ParsedThenVerified) {
    const auto [request, signature, input] = signedGet();
    const auto parsed = sv::parseAuthorization(input);
    ASSERT_TRUE(parsed.has_value()) << parsed.error().message;
    EXPECT_EQ(parsed->credential.access_key, kAccessKey);
    EXPECT_EQ(parsed->credential.region, "us-east-1");
    EXPECT_EQ(parsed->signed_headers, "host;range;x-amz-content-sha256;x-amz-date");
    EXPECT_EQ(parsed->signature, signature.signature);
    EXPECT_EQ(parsed->payload_hash, sv::sha256Hex(""));
    EXPECT_TRUE(sv::verify(input, *parsed, kSecret, kNow).ok());
    EXPECT_EQ(sv::signatureFor(input, *parsed, kSecret), signature.signature);
}

TEST(RoundTrip, OtherServiceHeaderAuth) {
    const auto request = makeRequest("POST", "sqs.us-east-1.amazonaws.com", "/123456789012/my queue",
                                     {{"Action", "SendMessage"}}, {{"Content-Type", "application/x-www-form-urlencoded"}},
                                     "MessageBody=hi");
    const auto s = sv::sign(request, kGateway, "us-east-1", "sqs", kNow);
    const std::string body = "MessageBody=hi";
    VerifyOptions options;
    options.service = "sqs";
    options.region = "us-east-1";
    const auto result = sv::verify(received(request, s, body), kSecret, kNow, options);
    EXPECT_TRUE(result.ok()) << result.message;
    EXPECT_NE(result.canonical_request.find("\n/123456789012/my%2520queue\n"), std::string::npos);

    // The default options accept S3 only.
    EXPECT_EQ(sv::verify(received(request, s, body), kSecret, kNow).code, ErrorCode::UnsupportedService);
    // Without x-amz-content-sha256 the body is hashed.
    const std::string tampered = "MessageBody=ho";
    EXPECT_EQ(sv::verify(received(request, s, tampered), kSecret, kNow, options).code, ErrorCode::SignatureMismatch);
}

TEST(RoundTrip, S3Presigned) {
    const auto request = makeRequest("GET", "localhost:39000", "/bucket/dir/a b+c.txt", {{"versionId", "3/L4k+="}});
    const auto p = sv::presign(request, kS3DocsWithToken, "us-east-1", "s3", kNow, std::chrono::seconds{900});
    ASSERT_TRUE(p.has_value());
    const auto input = received(request, *p);
    const auto result = sv::verify(input, kS3DocsWithToken.secret_key, kNow + std::chrono::minutes{10});
    EXPECT_TRUE(result.ok()) << result.message;
    ASSERT_TRUE(result.auth.has_value());
    EXPECT_TRUE(result.auth->presigned);
    EXPECT_EQ(result.auth->expires, std::chrono::seconds{900});
    EXPECT_EQ(result.auth->payload_hash, "UNSIGNED-PAYLOAD");
    EXPECT_EQ(result.auth->session_token, kS3DocsWithToken.session_token);
    EXPECT_EQ(result.canonical_request, p->canonical_request);

    // Exactly at expiry still valid; one second later expired.
    EXPECT_TRUE(sv::verify(input, kS3DocsWithToken.secret_key, kNow + std::chrono::seconds{900}).ok());
    const auto expired = sv::verify(input, kS3DocsWithToken.secret_key, kNow + std::chrono::seconds{901});
    EXPECT_EQ(expired.code, ErrorCode::PresignExpired);
    EXPECT_EQ(expired.message, "Request has expired");
    EXPECT_EQ(sv::awsErrorCode(expired.code, true), "AccessDenied");

    // Query order on the wire does not matter.
    auto reordered = input;
    const auto q = reordered.target.find('?');
    auto params = sv::parseQuery(std::string_view(reordered.target).substr(q + 1));
    std::ranges::reverse(params);
    std::string wire;
    for (const auto& [name, value] : params) {
        if (!wire.empty()) wire.push_back('&');
        wire += sv::uriEncode(name, true) + "=" + sv::uriEncode(value, true);
    }
    reordered.target = reordered.target.substr(0, q + 1) + wire;
    EXPECT_TRUE(sv::verify(reordered, kS3DocsWithToken.secret_key, kNow).ok());
}

TEST(RoundTrip, OtherServicePresigned) {
    const auto request = makeRequest("GET", "sts.amazonaws.com", "/",
                                     {{"Action", "GetCallerIdentity"}, {"Version", "2011-06-15"}},
                                     {{"x-k8s-aws-id", "my-cluster"}});
    const auto p = sv::presign(request, kGateway, "us-east-1", "sts", kNow, std::chrono::seconds{60});
    ASSERT_TRUE(p.has_value());
    auto input = received(request, *p);
    input.headers.emplace_back("x-k8s-aws-id", "my-cluster");
    VerifyOptions options;
    options.service = "sts";
    const auto result = sv::verify(input, kSecret, kNow, options);
    EXPECT_TRUE(result.ok()) << result.message;

    eraseHeader(input, "x-k8s-aws-id");
    const auto missing = sv::verify(input, kSecret, kNow, options);
    EXPECT_EQ(missing.code, ErrorCode::SignedHeaderMissing);
    EXPECT_EQ(missing.message, "Signed header missing from request: x-k8s-aws-id");
}

// --- ported from Vaulthalla S3GatewaySigV4Test -------------------------------------------------------------------

TEST(GatewayPort, VerifiesHeaderSignatureAndRejectsTampering) {
    const auto amzDate = sv::amzDate(kNow);
    const std::string payload = "payload";
    VerificationInput input{.method = "PUT",
                            .target = "/bucket/path/to/object.txt?partNumber=1&uploadId=upload",
                            .host = "localhost:39000",
                            .headers = {{"host", "localhost:39000"},
                                        {"x-amz-content-sha256", sv::sha256Hex("payload")},
                                        {"x-amz-date", amzDate}},
                            .body = payload,
                            .body_sha256 = std::nullopt};
    auto auth = gatewayAuth(amzDate, "host;x-amz-content-sha256;x-amz-date", sv::sha256Hex("payload"));
    auth.signature = sv::signatureFor(input, auth, kSecret);
    input.headers.emplace_back("authorization", authorizationFor(auth));

    const auto ok = sv::verify(input, kSecret, kNow);
    EXPECT_TRUE(ok.ok()) << ok.message;
    EXPECT_EQ(ok.access_key, kAccessKey);

    input.body = {};
    input.body_sha256 = sv::sha256Hex("payload");
    const auto streamed = sv::verify(input, kSecret, kNow);
    EXPECT_TRUE(streamed.ok()) << streamed.message;

    input.body_sha256 = sv::sha256Hex("tampered");
    const auto bad = sv::verify(input, kSecret, kNow);
    EXPECT_EQ(bad.code, ErrorCode::PayloadHashMismatch);
    EXPECT_EQ(bad.message, "Payload hash mismatch");
    EXPECT_EQ(sv::awsErrorCode(bad.code), "XAmzContentSHA256Mismatch");
}

TEST(GatewayPort, AcceptsAwsStreamingUnsignedPayloadTrailerHashConstant) {
    const auto amzDate = sv::amzDate(kNow);
    const std::string wire = "aws-chunked-wire-body";
    VerificationInput input{.method = "PUT",
                            .target = "/bucket/object.txt",
                            .host = "localhost:39000",
                            .headers = {{"host", "localhost:39000"},
                                        {"x-amz-content-sha256", "STREAMING-UNSIGNED-PAYLOAD-TRAILER"},
                                        {"x-amz-date", amzDate},
                                        {"x-amz-decoded-content-length", "5"},
                                        {"x-amz-trailer", "x-amz-checksum-crc32"}},
                            .body = wire,
                            .body_sha256 = sv::sha256Hex("decoded")};
    auto auth = gatewayAuth(amzDate, "host;x-amz-content-sha256;x-amz-date;x-amz-decoded-content-length;x-amz-trailer",
                            "STREAMING-UNSIGNED-PAYLOAD-TRAILER");
    auth.signature = sv::signatureFor(input, auth, kSecret);
    input.headers.emplace_back("authorization", authorizationFor(auth));

    const auto ok = sv::verify(input, kSecret, kNow);
    EXPECT_TRUE(ok.ok()) << ok.message;
    EXPECT_EQ(ok.access_key, kAccessKey);
}

TEST(GatewayPort, RejectsMissingSignedHeader) {
    const auto amzDate = sv::amzDate(kNow);
    VerificationInput input{.method = "GET",
                            .target = "/bucket/object.txt",
                            .host = "localhost:39000",
                            .headers = {{"host", "localhost:39000"},
                                        {"x-amz-content-sha256", "UNSIGNED-PAYLOAD"},
                                        {"x-amz-date", amzDate}},
                            .body = {},
                            .body_sha256 = std::nullopt};
    auto auth = gatewayAuth(amzDate, "host;x-amz-content-sha256;x-amz-date;x-amz-meta-missing", "UNSIGNED-PAYLOAD");
    auth.signature = sv::signatureFor(input, auth, kSecret);
    input.headers.emplace_back("authorization", authorizationFor(auth));

    const auto result = sv::verify(input, kSecret, kNow);
    EXPECT_EQ(result.code, ErrorCode::SignedHeaderMissing);
    EXPECT_EQ(result.message, "Signed header missing from request: x-amz-meta-missing");
}

namespace {

// What the AWS CLI's CRT transfer client sends: "Content-Length: 0" on a bodiless request, signed.
VerificationInput signedWithZeroContentLength(const std::string& method) {
    const auto amzDate = sv::amzDate(kNow);
    VerificationInput input{.method = method,
                            .target = "/bucket/object.txt",
                            .host = "s3.example.test",
                            .headers = {{"Host", "s3.example.test"},
                                        {"Content-Length", "0"},
                                        {"x-amz-content-sha256", sv::sha256Hex("")},
                                        {"x-amz-date", amzDate}},
                            .body = {},
                            .body_sha256 = std::nullopt};
    auto auth = gatewayAuth(amzDate, "content-length;host;x-amz-content-sha256;x-amz-date", sv::sha256Hex(""));
    auth.signature = sv::signatureFor(input, auth, kSecret);
    input.headers.emplace_back("Authorization", authorizationFor(auth));
    return input;
}

}

TEST(GatewayPort, CanonicalizesSignedContentLengthStrippedByProxyAsZero) {
    for (const std::string method : {"GET", "HEAD", "DELETE", "POST"}) {
        auto input = signedWithZeroContentLength(method);
        const auto direct = sv::verify(input, kSecret, kNow);
        EXPECT_TRUE(direct.ok()) << method << ": " << direct.message;

        eraseHeader(input, "Content-Length");
        const auto proxied = sv::verify(input, kSecret, kNow);
        EXPECT_TRUE(proxied.ok()) << method << " without Content-Length: " << proxied.message;
        EXPECT_EQ(proxied.access_key, kAccessKey);

        VerifyOptions strict;
        strict.imply_zero_content_length = false;
        EXPECT_EQ(sv::verify(input, kSecret, kNow, strict).code, ErrorCode::SignedHeaderMissing);
    }
}

TEST(GatewayPort, MissingSignedContentLengthIsOnlyImpliedForAnEmptyUnchunkedBody) {
    {
        auto input = signedWithZeroContentLength("PUT");
        eraseHeader(input, "Content-Length");
        input.headers.emplace_back("Transfer-Encoding", "chunked");
        const auto result = sv::verify(input, kSecret, kNow);
        EXPECT_EQ(result.code, ErrorCode::SignedHeaderMissing);
        EXPECT_EQ(result.message, "Signed header missing from request: content-length");
    }
    {
        const std::string body = "payload";
        auto input = signedWithZeroContentLength("PUT");
        eraseHeader(input, "Content-Length");
        setHeader(input, "x-amz-content-sha256", "UNSIGNED-PAYLOAD");
        input.body = body;
        const auto result = sv::verify(input, kSecret, kNow);
        EXPECT_EQ(result.code, ErrorCode::SignedHeaderMissing);
        EXPECT_EQ(result.message, "Signed header missing from request: content-length");
    }
    {
        auto input = signedWithZeroContentLength("PUT");
        eraseHeader(input, "Content-Length");
        input.body_sha256 = sv::sha256Hex("streamed");
        EXPECT_FALSE(sv::verify(input, kSecret, kNow).ok());
    }
    {
        // A length the client signed as non-zero cannot be satisfied by an empty request.
        const auto amzDate = sv::amzDate(kNow);
        VerificationInput input{.method = "PUT",
                                .target = "/bucket/object.txt",
                                .host = "s3.example.test",
                                .headers = {{"host", "s3.example.test"},
                                            {"content-length", "5"},
                                            {"x-amz-content-sha256", "UNSIGNED-PAYLOAD"},
                                            {"x-amz-date", amzDate}},
                                .body = {},
                                .body_sha256 = std::nullopt};
        auto auth = gatewayAuth(amzDate, "content-length;host;x-amz-content-sha256;x-amz-date", "UNSIGNED-PAYLOAD");
        auth.signature = sv::signatureFor(input, auth, kSecret);
        eraseHeader(input, "content-length");
        input.headers.emplace_back("authorization", authorizationFor(auth));
        const auto result = sv::verify(input, kSecret, kNow);
        EXPECT_EQ(result.code, ErrorCode::SignatureMismatch);
        EXPECT_EQ(result.message, "Signature mismatch");
    }
}

TEST(GatewayPort, RejectsMalformedPresignedExpiresWithoutThrowing) {
    VerificationInput input{.method = "GET",
                            .target = "/bucket/object.txt"
                                      "?X-Amz-Algorithm=AWS4-HMAC-SHA256"
                                      "&X-Amz-Credential=VHTESTACCESSKEY%2F20260531%2Fus-east-1%2Fs3%2Faws4_request"
                                      "&X-Amz-Date=20260531T120000Z"
                                      "&X-Amz-Expires=not-a-number"
                                      "&X-Amz-SignedHeaders=host"
                                      "&X-Amz-Signature=deadbeef",
                            .host = "localhost:39000",
                            .headers = {{"host", "localhost:39000"}},
                            .body = {},
                            .body_sha256 = std::nullopt};
    EXPECT_NO_THROW({
        const auto result = sv::verify(input, "secret", kNow);
        EXPECT_EQ(result.code, ErrorCode::InvalidExpires);
        EXPECT_EQ(result.message, "Invalid X-Amz-Expires");
    });
}

TEST(GatewayPort, RejectsPresignedUrlsDatedTooFarInFuture) {
    const auto amzDate = sv::amzDate(kNow + std::chrono::hours{1});
    VerificationInput input{.method = "GET",
                            .target = "/bucket/object.txt"
                                      "?X-Amz-Algorithm=AWS4-HMAC-SHA256"
                                      "&X-Amz-Credential=VHTESTACCESSKEY%2F" + amzDate.substr(0, 8) +
                                      "%2Fus-east-1%2Fs3%2Faws4_request"
                                      "&X-Amz-Date=" + amzDate +
                                      "&X-Amz-Expires=60"
                                      "&X-Amz-SignedHeaders=host"
                                      "&X-Amz-Signature=deadbeef",
                            .host = "localhost:39000",
                            .headers = {{"host", "localhost:39000"}},
                            .body = {},
                            .body_sha256 = std::nullopt};
    const auto result = sv::verify(input, "secret", kNow);
    EXPECT_EQ(result.code, ErrorCode::RequestTimeTooSkewed);
    EXPECT_EQ(result.message, "Signature date is outside allowed skew");
}

// --- negatives ---------------------------------------------------------------------------------------------------

TEST(Negative, BadSignature) {
    auto [request, signature, input] = signedGet();
    auto flipped = signature.signature;
    flipped[10] = flipped[10] == '0' ? '1' : '0';
    setHeader(input, "authorization",
              sv::authorizationHeader(kAccessKey, sv::credentialScope(sv::dateStamp(kNow), "us-east-1", "s3"),
                                      "host;range;x-amz-content-sha256;x-amz-date", flipped));
    const auto result = sv::verify(input, kSecret, kNow);
    EXPECT_EQ(result.code, ErrorCode::SignatureMismatch);
    EXPECT_EQ(sv::awsErrorCode(result.code), "SignatureDoesNotMatch");
    EXPECT_EQ(result.canonical_request, signature.canonical_request);   // diagnostics for the client

    EXPECT_EQ(sv::verify(signedGet().input, "wrong-secret", kNow).code, ErrorCode::SignatureMismatch);

    // Hex case does not matter.
    auto upper = signature.signature;
    std::ranges::transform(upper, upper.begin(), [](const char c) { return c >= 'a' && c <= 'f' ? c - 32 : c; });
    setHeader(input, "authorization",
              sv::authorizationHeader(kAccessKey, sv::credentialScope(sv::dateStamp(kNow), "us-east-1", "s3"),
                                      "host;range;x-amz-content-sha256;x-amz-date", upper));
    EXPECT_TRUE(sv::verify(input, kSecret, kNow).ok());
}

TEST(Negative, TamperedRequest) {
    {
        auto [request, signature, input] = signedGet();
        input.target = "/bucket/photos/other.txt?versionId=v%2B1%2F%3D";
        EXPECT_EQ(sv::verify(input, kSecret, kNow).code, ErrorCode::SignatureMismatch);
    }
    {
        auto [request, signature, input] = signedGet();
        input.method = "DELETE";
        EXPECT_EQ(sv::verify(input, kSecret, kNow).code, ErrorCode::SignatureMismatch);
    }
    {
        auto [request, signature, input] = signedGet();
        setHeader(input, "range", "bytes=0-99");
        EXPECT_EQ(sv::verify(input, kSecret, kNow).code, ErrorCode::SignatureMismatch);
    }
}

TEST(Negative, ClockSkew) {
    const auto [request, signature, input] = signedGet();
    EXPECT_TRUE(sv::verify(input, kSecret, kNow + std::chrono::minutes{15}).ok());
    EXPECT_TRUE(sv::verify(input, kSecret, kNow - std::chrono::minutes{15}).ok());
    const auto late = sv::verify(input, kSecret, kNow + std::chrono::minutes{15} + std::chrono::seconds{1});
    EXPECT_EQ(late.code, ErrorCode::RequestTimeTooSkewed);
    EXPECT_EQ(late.message, "Signature date is outside allowed skew");
    EXPECT_EQ(sv::awsErrorCode(late.code), "RequestTimeTooSkewed");
    EXPECT_EQ(sv::verify(input, kSecret, kNow - std::chrono::minutes{16}).code, ErrorCode::RequestTimeTooSkewed);

    VerifyOptions tight;
    tight.max_skew = std::chrono::seconds{30};
    EXPECT_EQ(sv::verify(input, kSecret, kNow + std::chrono::minutes{1}, tight).code, ErrorCode::RequestTimeTooSkewed);
}

TEST(Negative, PresignExpiryLimits) {
    const auto request = makeRequest("GET", "localhost:39000", "/bucket/key");
    const auto p = sv::presign(request, kGateway, "us-east-1", "s3", kNow, std::chrono::seconds{604800});
    ASSERT_TRUE(p.has_value());
    auto input = received(request, *p);
    EXPECT_TRUE(sv::verify(input, kSecret, kNow + std::chrono::hours{24 * 7}).ok());
    EXPECT_EQ(sv::verify(input, kSecret, kNow + std::chrono::hours{24 * 7} + std::chrono::seconds{1}).code,
              ErrorCode::PresignExpired);

    VerifyOptions oneHour;
    oneHour.max_presign_expiry = std::chrono::hours{1};
    const auto capped = sv::verify(input, kSecret, kNow, oneHour);
    EXPECT_EQ(capped.code, ErrorCode::ExpiresTooLarge);
    EXPECT_EQ(sv::awsErrorCode(capped.code, true), "AuthorizationQueryParametersError");

    const auto replaceExpires = [&](const std::string& value) {
        auto copy = input;
        const auto pos = copy.target.find("X-Amz-Expires=604800");
        copy.target.replace(pos, std::string("X-Amz-Expires=604800").size(), value);
        return copy;
    };
    const auto overSeven = sv::verify(replaceExpires("X-Amz-Expires=604801"), kSecret, kNow);
    EXPECT_EQ(overSeven.code, ErrorCode::ExpiresTooLarge);
    EXPECT_EQ(overSeven.message, "X-Amz-Expires exceeds maximum allowed value");
    EXPECT_EQ(sv::verify(replaceExpires("X-Amz-Expires=99999999999999999999999"), kSecret, kNow).code,
              ErrorCode::InvalidExpires);
    EXPECT_EQ(sv::verify(replaceExpires("X-Amz-Expires=0"), kSecret, kNow).code, ErrorCode::InvalidExpires);
    EXPECT_EQ(sv::verify(replaceExpires("X-Amz-Expires=-1"), kSecret, kNow).code, ErrorCode::InvalidExpires);
    EXPECT_EQ(sv::verify(replaceExpires("X-Amz-Expires=+60"), kSecret, kNow).code, ErrorCode::InvalidExpires);
    const auto missing = sv::verify(replaceExpires("X-Amz-Other=1"), kSecret, kNow);
    EXPECT_EQ(missing.code, ErrorCode::InvalidExpires);
    EXPECT_EQ(missing.message, "Missing X-Amz-Expires");

    VerifyOptions noPresign;
    noPresign.allow_presigned = false;
    EXPECT_EQ(sv::verify(input, kSecret, kNow, noPresign).code, ErrorCode::MissingAuthorization);
}

TEST(Negative, PayloadHashMismatch) {
    const std::string body = "real body";
    auto request = makeRequest("PUT", "s3.example.test", "/bucket/key", {}, {}, "claimed body");
    const auto s = sv::sign(request, kGateway, "us-east-1", "s3", kNow);
    const auto result = sv::verify(received(request, s, body), kSecret, kNow);
    EXPECT_EQ(result.code, ErrorCode::PayloadHashMismatch);
}

TEST(Negative, SignedStreamingPayloadIsUnsupported) {
    auto request = makeRequest("PUT", "s3.example.test", "/bucket/key");
    request.payload_hash = "STREAMING-AWS4-HMAC-SHA256-PAYLOAD";
    const auto s = sv::sign(request, kGateway, "us-east-1", "s3", kNow);
    const auto result = sv::verify(received(request, s), kSecret, kNow);
    EXPECT_EQ(result.code, ErrorCode::UnsupportedPayloadHash);
    EXPECT_EQ(sv::awsErrorCode(result.code), "NotImplemented");
}

TEST(Negative, MissingSignedHeaderAfterSigning) {
    auto [request, signature, input] = signedGet();
    eraseHeader(input, "range");
    const auto result = sv::verify(input, kSecret, kNow);
    EXPECT_EQ(result.code, ErrorCode::SignedHeaderMissing);
    EXPECT_EQ(result.message, "Signed header missing from request: range");
}

TEST(Negative, MissingAuthorization) {
    VerificationInput input{.method = "GET", .target = "/bucket/key", .host = "h", .headers = {}, .body = {},
                            .body_sha256 = std::nullopt};
    const auto result = sv::verify(input, kSecret, kNow);
    EXPECT_EQ(result.code, ErrorCode::MissingAuthorization);
    EXPECT_EQ(result.message, "Missing Authorization header");
    EXPECT_EQ(sv::awsErrorCode(result.code), "AccessDenied");
    EXPECT_FALSE(result.auth.has_value());
}

TEST(Negative, AmbiguousAuthorization) {
    const auto request = makeRequest("GET", "localhost:39000", "/bucket/key");
    const auto p = sv::presign(request, kGateway, "us-east-1", "s3", kNow, std::chrono::seconds{60});
    ASSERT_TRUE(p.has_value());
    auto input = received(request, *p);
    input.headers.emplace_back("Authorization", sv::sign(request, kGateway, "us-east-1", "s3", kNow).authorization);
    EXPECT_EQ(sv::verify(input, kSecret, kNow).code, ErrorCode::AmbiguousAuthorization);
}

TEST(Negative, MalformedAuthorizationHeaders) {
    const auto date = sv::amzDate(kNow);
    const auto scope = kAccessKey + "/" + date.substr(0, 8) + "/us-east-1/s3/aws4_request";
    const std::string sig = std::string(64, 'a');
    struct Case {
        std::string header;
        ErrorCode code;
    };
    const std::vector<Case> cases{
        {"Bearer abc", ErrorCode::UnsupportedAlgorithm},
        {"AWS4-HMAC-SHA1 Credential=" + scope + ", SignedHeaders=host, Signature=" + sig, ErrorCode::UnsupportedAlgorithm},
        {"AWS4-HMAC-SHA256Credential=" + scope + ", SignedHeaders=host, Signature=" + sig,
         ErrorCode::UnsupportedAlgorithm},
        {"AWS4-HMAC-SHA256", ErrorCode::MalformedAuthorization},
        {"AWS4-HMAC-SHA256 ", ErrorCode::MalformedAuthorization},
        {"AWS4-HMAC-SHA256 garbage", ErrorCode::MalformedAuthorization},
        {"AWS4-HMAC-SHA256 Credential=" + scope, ErrorCode::MalformedAuthorization},
        {"AWS4-HMAC-SHA256 Credential=" + scope + ", SignedHeaders=host", ErrorCode::MalformedAuthorization},
        {"AWS4-HMAC-SHA256 Credential=" + scope + ", Signature=" + sig, ErrorCode::MalformedAuthorization},
        {"AWS4-HMAC-SHA256 Credential=" + scope + ", Credential=" + scope + ", SignedHeaders=host, Signature=" + sig,
         ErrorCode::MalformedAuthorization},
        {"AWS4-HMAC-SHA256 Credential=" + scope + ", =x, SignedHeaders=host, Signature=" + sig,
         ErrorCode::MalformedAuthorization},
        {"AWS4-HMAC-SHA256 Credential=" + scope + ", SignedHeaders=host;;x-amz-date, Signature=" + sig,
         ErrorCode::MalformedAuthorization},
        {"AWS4-HMAC-SHA256 Credential=" + scope + ", SignedHeaders=host;x-amz-date;host, Signature=" + sig,
         ErrorCode::MalformedAuthorization},
        {"AWS4-HMAC-SHA256 Credential=" + kAccessKey + "/" + date.substr(0, 8) +
             "/us-east-1/s3, SignedHeaders=host, Signature=" + sig,
         ErrorCode::InvalidCredentialScope},
        {"AWS4-HMAC-SHA256 Credential=" + scope + "/, SignedHeaders=host, Signature=" + sig,
         ErrorCode::InvalidCredentialScope},
        {"AWS4-HMAC-SHA256 Credential=/" + date.substr(0, 8) + "/us-east-1/s3/aws4_request, SignedHeaders=host, "
         "Signature=" + sig,
         ErrorCode::InvalidCredentialScope},
        {"AWS4-HMAC-SHA256 Credential=" + kAccessKey + "/2026-11-02/us-east-1/s3/aws4_request, SignedHeaders=host, "
         "Signature=" + sig,
         ErrorCode::InvalidCredentialScope},
        {"AWS4-HMAC-SHA256 Credential=" + kAccessKey + "/" + date.substr(0, 8) +
             "/us-east-1/s3/aws5_request, SignedHeaders=host, Signature=" + sig,
         ErrorCode::InvalidCredentialScope},
        {"AWS4-HMAC-SHA256 Credential=" + kAccessKey + "/" + date.substr(0, 8) +
             "/us-east-1/sqs/aws4_request, SignedHeaders=host, Signature=" + sig,
         ErrorCode::UnsupportedService},
    };
    for (const auto& c : cases) {
        VerificationInput input{.method = "GET", .target = "/bucket/key", .host = "h",
                                .headers = {{"x-amz-date", date}, {"Authorization", c.header}}, .body = {},
                                .body_sha256 = std::nullopt};
        const auto parsed = sv::parseAuthorization(input);
        ASSERT_FALSE(parsed.has_value()) << c.header;
        EXPECT_EQ(parsed.error().code, c.code) << c.header << ": " << parsed.error().message;
        const auto result = sv::verify(input, kSecret, kNow);
        EXPECT_EQ(result.code, c.code) << c.header;
        EXPECT_FALSE(result.message.empty());
    }
}

TEST(Negative, RegionPinnedByOptions) {
    const auto [request, signature, input] = signedGet();
    VerifyOptions pinned;
    pinned.region = "eu-west-1";
    EXPECT_EQ(sv::verify(input, kSecret, kNow, pinned).code, ErrorCode::RegionMismatch);
    pinned.region = "us-east-1";
    EXPECT_TRUE(sv::verify(input, kSecret, kNow, pinned).ok());
}

TEST(Negative, DateProblems) {
    {
        auto [request, signature, input] = signedGet();
        eraseHeader(input, "x-amz-date");
        const auto result = sv::verify(input, kSecret, kNow);
        EXPECT_EQ(result.code, ErrorCode::MissingDate);
        EXPECT_EQ(result.message, "Missing x-amz-date");
    }
    {
        auto [request, signature, input] = signedGet();
        setHeader(input, "x-amz-date", "2026-11-02T09:30:00Z");
        EXPECT_EQ(sv::verify(input, kSecret, kNow).code, ErrorCode::InvalidDate);
    }
    {
        // Signed yesterday at 23:59:00 with today's scope date.
        const auto when = at(k20261102T000000Z) - std::chrono::minutes{1};
        auto [request, signature, input] = signedGet(when);
        setHeader(input, "authorization",
                  sv::authorizationHeader(kAccessKey, sv::credentialScope("20261102", "us-east-1", "s3"),
                                          "host;range;x-amz-content-sha256;x-amz-date", signature.signature));
        const auto result = sv::verify(input, kSecret, when);
        EXPECT_EQ(result.code, ErrorCode::ScopeDateMismatch);
        VerifyOptions lenient;
        lenient.require_scope_date_match = false;
        EXPECT_EQ(sv::verify(input, kSecret, when, lenient).code, ErrorCode::SignatureMismatch);
    }
}

TEST(Negative, SignedHeadersAndSignatureRequired) {
    const auto amzDate = sv::amzDate(kNow);
    VerificationInput input{.method = "GET", .target = "/bucket/key", .host = "h",
                            .headers = {{"host", "h"}, {"x-amz-date", amzDate}, {"x-amz-content-sha256", "UNSIGNED-PAYLOAD"}},
                            .body = {}, .body_sha256 = std::nullopt};
    const auto scope = kAccessKey + "/" + amzDate.substr(0, 8) + "/us-east-1/s3/aws4_request";

    auto withAuth = [&](const std::string& value) {
        auto copy = input;
        copy.headers.emplace_back("authorization", value);
        return copy;
    };
    EXPECT_EQ(sv::verify(withAuth("AWS4-HMAC-SHA256 Credential=" + scope + ", SignedHeaders=, Signature=ab"), kSecret,
                         kNow)
                  .code,
              ErrorCode::MissingSignedHeaders);
    EXPECT_EQ(sv::verify(withAuth("AWS4-HMAC-SHA256 Credential=" + scope + ", SignedHeaders=host;x-amz-date, Signature="),
                         kSecret, kNow)
                  .code,
              ErrorCode::MissingSignature);

    // host must be signed (AWS requires it); the option turns the check off.
    auto auth = gatewayAuth(amzDate, "x-amz-content-sha256;x-amz-date", "UNSIGNED-PAYLOAD");
    auth.signature = sv::signatureFor(input, auth, kSecret);
    const auto hostless = withAuth(authorizationFor(auth));
    const auto result = sv::verify(hostless, kSecret, kNow);
    EXPECT_EQ(result.code, ErrorCode::HostNotSigned);
    VerifyOptions lenient;
    lenient.require_signed_host = false;
    EXPECT_TRUE(sv::verify(hostless, kSecret, kNow, lenient).ok());
}

TEST(Negative, HeaderSignedRequestKeepsXAmzSignatureInQuery) {
    // Only presigned verification drops X-Amz-Signature from the canonical query.
    const auto request = makeRequest("GET", "s3.example.test", "/bucket/key", {{"X-Amz-Signature", "client-value"}});
    const auto s = sv::sign(request, kGateway, "us-east-1", "s3", kNow);
    const auto result = sv::verify(received(request, s), kSecret, kNow);
    EXPECT_TRUE(result.ok()) << result.message;
}

// --- compatibility arbiters --------------------------------------------------------------------------------------

// The AWS suite's get-utf8 and get-space put unencoded bytes on the wire ("GET /ሴ", "GET /example space/"). For a
// non-S3 service the canonical URI is the wire path URI-encoded once more, so these verify with the suite's published
// signatures exactly; a client sending the encoded path ("/%E1%88%B4", what sign() does) is verified one encoding
// deeper (see VaulthallaGoldens.NonS3PathIsEncodedAgainRelativeToTheWire).
TEST(AwsSuiteVerify, RawWirePathsVerifyWithPublishedSignatures) {
    struct Case {
        std::string target;
        std::string signature;
    };
    for (const auto& c : {Case{"/\xe1\x88\xb4", "8318018e0b0f223aa2bbf98705b62bb787dc9c0e678f255a891fd03141be5d85"},
                          Case{"/example space/", "652487583200325589f1fba4c7e578f72c47cb61beeca81406b39ddec1366741"}}) {
        VerificationInput input{
            .method = "GET",
            .target = c.target,
            .host = {},
            .headers = {{"Host", "example.amazonaws.com"},
                        {"X-Amz-Date", "20150830T123600Z"},
                        {"Authorization", "AWS4-HMAC-SHA256 Credential=AKIDEXAMPLE/20150830/us-east-1/service/"
                                          "aws4_request, SignedHeaders=host;x-amz-date, Signature=" + c.signature}},
            .body = {},
            .body_sha256 = std::nullopt};
        VerifyOptions options;
        options.service = "service";
        const auto result = sv::verify(input, sv::test::kSuite.secret_key, at(sv::test::k20150830T123600Z), options);
        EXPECT_TRUE(result.ok()) << c.target << ": " << result.message;
    }
}

// Vaulthalla's legacy signer took the scope date from the clock and x-amz-date from the caller; around midnight UTC
// they disagreed. sign() derives both from the one injected instant, and the verifier rejects a mismatch.
TEST(Dates, ScopeDateAndAmzDateComeFromTheSameInstant) {
    const auto lastMoment = at(k20261102T000000Z) - std::chrono::milliseconds{1};   // 2026-11-01T23:59:59.999Z
    const auto request = makeRequest("GET", "s3.example.test", "/bucket/key");
    const auto s = sv::sign(request, kGateway, "us-east-1", "s3", lastMoment);
    EXPECT_EQ(s.headers.at("x-amz-date"), "20261101T235959Z");
    EXPECT_NE(s.authorization.find("/20261101/us-east-1/s3/aws4_request"), std::string::npos);
    EXPECT_TRUE(sv::verify(received(request, s), kSecret, lastMoment + std::chrono::seconds{2}).ok());

    // What the legacy signer produced one tick later: x-amz-date of the 1st, scope of the 2nd.
    auto input = received(request, s);
    const auto headers = sv::normalizeHeaders(input.headers);
    auto authorization = headers.at("authorization");
    authorization.replace(authorization.find("/20261101/"), 10, "/20261102/");
    setHeader(input, "authorization", authorization);
    const auto result = sv::verify(input, kSecret, lastMoment + std::chrono::seconds{2});
    EXPECT_EQ(result.code, ErrorCode::ScopeDateMismatch);
}
