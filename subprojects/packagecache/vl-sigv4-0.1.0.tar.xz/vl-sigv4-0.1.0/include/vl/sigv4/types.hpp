// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Valkyrian Labs LLC
//
// Shared vocabulary of vl-sigv4: clock, header and query containers, credentials, credential scope and the error
// codes the signer (presign) and the verifier report.
#pragma once

#include <chrono>
#include <cstdint>
#include <string>
#include <string_view>
#include <utility>
#include <vector>

namespace vl::sigv4 {

// Every function that depends on the time takes it as a parameter; the library never reads a clock.
using Clock = std::chrono::system_clock;
using TimePoint = Clock::time_point;

inline constexpr std::string_view kAlgorithm = "AWS4-HMAC-SHA256";
inline constexpr std::string_view kUnsignedPayload = "UNSIGNED-PAYLOAD";
inline constexpr std::string_view kStreamingUnsignedPayloadTrailer = "STREAMING-UNSIGNED-PAYLOAD-TRAILER";
// SHA-256 of the empty string, hex.
inline constexpr std::string_view kEmptyPayloadSha256 =
    "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855";
// AWS caps X-Amz-Expires at seven days.
inline constexpr std::chrono::seconds kMaxPresignExpiry{604800};
// AWS's allowed clock skew between the signer and the verifier.
inline constexpr std::chrono::seconds kDefaultMaxSkew{15 * 60};

// Header lists keep every occurrence in order: names compare case-insensitively, and repeated names are combined
// with ',' in the order given (SigV4 canonical headers).
using HeaderList = std::vector<std::pair<std::string, std::string>>;
// Raw (unencoded) query parameters; a flag-only parameter ("?uploads") has an empty value.
using QueryParams = std::vector<std::pair<std::string, std::string>>;

struct Credentials {
    std::string access_key;
    std::string secret_key;
    std::string session_token{};   // optional; sent and signed as x-amz-security-token
};

// Credential=<access_key>/<date>/<region>/<service>/aws4_request
struct CredentialScope {
    std::string access_key;
    std::string date;      // YYYYMMDD
    std::string region;
    std::string service;

    // "<date>/<region>/<service>/aws4_request" (the scope without the access key).
    [[nodiscard]] std::string str() const;
};

// Why a request did not verify (or a presign could not be produced). Each has a stable name (errorCodeName) and
// maps to the S3 error code a gateway should answer with (awsErrorCode).
enum class ErrorCode : std::uint8_t {
    None = 0,
    MissingAuthorization,       // neither an Authorization header nor X-Amz-Algorithm in the query
    AmbiguousAuthorization,     // both an Authorization header and presigned query parameters
    UnsupportedAlgorithm,       // not AWS4-HMAC-SHA256
    MalformedAuthorization,     // the Authorization header could not be parsed
    InvalidCredentialScope,     // Credential is not <key>/<YYYYMMDD>/<region>/<service>/aws4_request
    UnsupportedService,         // scope service differs from VerifyOptions::service
    RegionMismatch,             // scope region differs from VerifyOptions::region
    InvalidExpires,             // X-Amz-Expires missing, not a number, or 0
    ExpiresTooLarge,            // X-Amz-Expires above the limit (at most 604800)
    MissingDate,                // no x-amz-date header / X-Amz-Date parameter
    InvalidDate,                // the date is not YYYYMMDD'T'HHMMSS'Z'
    ScopeDateMismatch,          // credential scope date differs from the request date
    RequestTimeTooSkewed,       // request date outside the allowed skew
    PresignExpired,             // presigned URL past X-Amz-Date + X-Amz-Expires
    MissingSignedHeaders,       // SignedHeaders empty or missing
    HostNotSigned,              // SignedHeaders does not include host
    MissingSignature,           // Signature empty or missing
    SignedHeaderMissing,        // a header named in SignedHeaders is absent from the request
    SessionTokenNotSupported,   // a session token was presented and VerifyOptions::reject_session_tokens is set
    UnsupportedPayloadHash,     // a signed streaming payload mode (STREAMING-AWS4-HMAC-SHA256-PAYLOAD, ...)
    PayloadHashMismatch,        // x-amz-content-sha256 differs from the body's SHA-256
    UnknownAccessKey,           // the secret lookup has no secret for the access key
    SignatureMismatch,          // the signature does not match
};

struct Error {
    ErrorCode code = ErrorCode::None;
    std::string message{};
};

// Stable identifier for logs and metrics ("SignatureMismatch").
[[nodiscard]] std::string_view errorCodeName(ErrorCode code) noexcept;
// The S3 error code a gateway answers with ("SignatureDoesNotMatch", "RequestTimeTooSkewed", ...). Malformed
// authorization maps to AuthorizationQueryParametersError for presigned requests, AuthorizationHeaderMalformed
// otherwise. ErrorCode::None maps to "".
[[nodiscard]] std::string_view awsErrorCode(ErrorCode code, bool presigned = false) noexcept;

}
