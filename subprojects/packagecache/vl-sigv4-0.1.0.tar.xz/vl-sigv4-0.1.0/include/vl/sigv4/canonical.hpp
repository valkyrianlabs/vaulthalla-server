// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Valkyrian Labs LLC
//
// Building blocks of the SigV4 canonical request and string to sign. sign(), presign() and verify() are built from
// these; they are public so callers with unusual requests (or a migration from hand-rolled signing) can compose
// their own.
#pragma once

#include "vl/sigv4/types.hpp"

#include <map>
#include <optional>
#include <string>
#include <string_view>

namespace vl::sigv4 {

// --- encoding ----------------------------------------------------------------------------------------------------

// RFC 3986 percent-encoding: every byte but A-Z a-z 0-9 - _ . ~ becomes %XX (upper-case hex). '/' is kept unless
// encodeSlash. '+' and ' ' are both encoded ("%2B", "%20").
[[nodiscard]] std::string uriEncode(std::string_view value, bool encodeSlash);

// Strict percent-decoding: "%" followed by two hex digits becomes that byte; any other '%' is kept literally. '+' is
// not a space.
[[nodiscard]] std::string uriDecode(std::string_view value);

// True for the services whose canonical URI is the request path encoded once (S3). Every other service
// double-encodes, as the SigV4 specification says.
[[nodiscard]] bool singleEncodesPath(std::string_view service) noexcept;

// --- canonical URI -----------------------------------------------------------------------------------------------

// The path to put on the wire for a raw (unencoded) path: uriEncode(path, false), "/" when empty. Paths are not
// normalized ("." and ".." segments and repeated slashes are kept).
[[nodiscard]] std::string encodePath(std::string_view rawPath);

// Canonical URI of a raw path, as the signer builds it: encodePath() for S3, encoded a second time otherwise.
[[nodiscard]] std::string canonicalUri(std::string_view rawPath, std::string_view service);

// Canonical URI of a path as received on the wire, as the verifier builds it, with a leading "/" ensured.
// S3: the wire path decoded and re-encoded, so that equivalent encodings ("%7E" and "~", "+" and "%2B") agree.
// Other services: the wire path URI-encoded once more, exactly as sent (no normalization), which is the SigV4
// "double encoding" (a raw key is encoded once on the wire and again in the canonical request). The AWS suite's
// get-utf8 and get-space requests carry unencoded bytes on the wire and so verify with a single encoding.
[[nodiscard]] std::string canonicalUriFromWire(std::string_view wirePath, std::string_view service);

// --- canonical query ---------------------------------------------------------------------------------------------

// Canonical query of raw parameters: names and values uriEncode()d (slash included), sorted by name then value
// (byte order), joined as name=value&... A flag-only parameter becomes "name=".
[[nodiscard]] std::string canonicalQuery(const QueryParams& rawParams);

// Canonical query of a query string as received on the wire: each name and value decoded and re-encoded, empty
// parts dropped, sorted. omitSignature drops X-Amz-Signature (presigned verification).
[[nodiscard]] std::string canonicalQueryFromWire(std::string_view wireQuery, bool omitSignature);

// Sorts an already-encoded query without re-encoding it: empty parts dropped, "name" becomes "name=", then sorted
// by name then value as written. This is what Vaulthalla's legacy data-plane signer
// (storage::s3::curl::canonicalQueryString) does; prefer canonicalQuery() / canonicalQueryFromWire().
[[nodiscard]] std::string sortEncodedQuery(std::string_view encodedQuery);

// Parses a wire query into decoded (name, value) pairs in their original order; empty parts dropped.
[[nodiscard]] QueryParams parseQuery(std::string_view wireQuery);

// --- canonical headers -------------------------------------------------------------------------------------------

// Header value trimmed of leading and trailing whitespace, with each interior run of whitespace collapsed to one
// space (SigV4 "Trimall"). Whitespace: space, \t, \n, \v, \f, \r.
[[nodiscard]] std::string canonicalHeaderValue(std::string_view value);

// ASCII lower case.
[[nodiscard]] std::string toLower(std::string_view value);

// Lower-cased names mapped to their canonical values; repeated names are combined with ',' in list order.
[[nodiscard]] std::map<std::string, std::string> normalizeHeaders(const HeaderList& headers);

struct CanonicalHeaders {
    std::string canonical;        // "name:value\n" for each header, sorted by name
    std::string signed_headers;   // "name;name;..."
};

// Canonical headers over every entry of an already normalized map (lower-case names, canonical values).
[[nodiscard]] CanonicalHeaders canonicalHeaders(const std::map<std::string, std::string>& normalized);

// Canonical headers for the names listed in signedHeaders (";"-separated), looked up case-insensitively in a
// normalized map, in the order listed. Names missing from the map are skipped.
[[nodiscard]] std::string canonicalHeadersFor(const std::map<std::string, std::string>& normalized,
                                              std::string_view signedHeaders);

// --- request, scope, string to sign ------------------------------------------------------------------------------

// method \n uri \n query \n canonicalHeaders \n signedHeaders \n payloadHash (canonicalHeaders ends in its own \n).
[[nodiscard]] std::string canonicalRequest(std::string_view method, std::string_view canonicalUri,
                                           std::string_view canonicalQuery, std::string_view canonicalHeaders,
                                           std::string_view signedHeaders, std::string_view payloadHash);

// "<date>/<region>/<service>/aws4_request"
[[nodiscard]] std::string credentialScope(std::string_view date, std::string_view region, std::string_view service);

// "AWS4-HMAC-SHA256\n<amzDate>\n<scope>\n<hex sha256 of canonicalRequest>"
[[nodiscard]] std::string stringToSign(std::string_view amzDate, std::string_view scope,
                                       std::string_view canonicalRequest);

// "AWS4-HMAC-SHA256 Credential=<key>/<scope>, SignedHeaders=<...>, Signature=<...>"
[[nodiscard]] std::string authorizationHeader(std::string_view accessKey, std::string_view scope,
                                              std::string_view signedHeaders, std::string_view signature);

// --- dates -------------------------------------------------------------------------------------------------------

// YYYYMMDD'T'HHMMSS'Z' (UTC, truncated to the second).
[[nodiscard]] std::string amzDate(TimePoint t);
// YYYYMMDD (UTC).
[[nodiscard]] std::string dateStamp(TimePoint t);
// Strict inverse of amzDate(): exactly 16 characters and a valid calendar date and time, else nullopt.
[[nodiscard]] std::optional<TimePoint> parseAmzDate(std::string_view value);

}
