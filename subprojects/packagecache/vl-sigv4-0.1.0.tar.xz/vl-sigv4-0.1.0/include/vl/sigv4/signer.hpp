// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Valkyrian Labs LLC
//
// Client side: sign a request with an Authorization header, or presign a URL.
//
// Canonical URI: S3 encodes the path once (keys are opaque, so "a+b" is sent and signed as "a%2Bb"); every other
// service double-encodes it, as the SigV4 specification says. Canonical query: RFC 3986 encoding of names and values,
// sorted by name then value; the same string is what the URL carries. Signed headers: every header of the request
// (lower-cased names, trimmed values, repeated names combined) plus host and x-amz-date, x-amz-content-sha256 for S3,
// and x-amz-security-token when a session token is set.
#pragma once

#include "vl/sigv4/types.hpp"

#include <chrono>
#include <expected>
#include <map>
#include <string>
#include <string_view>

namespace vl::sigv4 {

struct Request {
    std::string method;          // GET, PUT, POST, HEAD, DELETE
    std::string host;            // host[:port], exactly as the URL has it
    std::string path = "/";      // raw, unencoded ("/bucket/a key.txt")
    QueryParams query{};         // raw names and values ({"versionId", "a+b/="}, {"uploads", ""})
    HeaderList headers{};        // extra headers to sign; names in any case
    std::string payload_hash{};  // hex SHA-256 of the body, or "UNSIGNED-PAYLOAD"; empty = the empty body's hash
};

struct Signed {
    std::map<std::string, std::string> headers;   // every header to send, authorization included (lower-case names)
    std::string encoded_path;                     // the path to put in the URL
    std::string query_string;                     // canonical query, also what the URL carries
    std::string canonical_request;
    std::string string_to_sign;
    std::string signature;                        // lower-case hex
    std::string authorization;                    // the Authorization header value

    // encoded_path, plus "?" and query_string when there is one: the HTTP request-target.
    [[nodiscard]] std::string target() const;
};

// Signs with an Authorization header. now supplies x-amz-date and the credential scope date. The request's host,
// x-amz-date, x-amz-content-sha256 (S3) and x-amz-security-token headers are set by sign() and override any the
// caller passed under those names.
[[nodiscard]] Signed sign(const Request& request, const Credentials& credentials, std::string_view region,
                          std::string_view service, TimePoint now);

struct Presigned {
    std::string host;
    std::string encoded_path;
    std::string query_string;      // full query, X-Amz-Signature included
    std::string canonical_request;
    std::string string_to_sign;
    std::string signature;

    // encoded_path + "?" + query_string.
    [[nodiscard]] std::string target() const;
    // scheme://host + target().
    [[nodiscard]] std::string url(std::string_view scheme = "https") const;
};

// A presigned URL valid for `expires` from `now`: 1 s to 604800 s (seven days), else ErrorCode::InvalidExpires or
// ErrorCode::ExpiresTooLarge. Signed headers are host plus request.headers (which the user of the URL must then
// send). The payload is UNSIGNED-PAYLOAD for S3; other services sign request.payload_hash (empty = the empty body's
// hash). A session token is added as X-Amz-Security-Token and signed.
[[nodiscard]] std::expected<Presigned, Error> presign(const Request& request, const Credentials& credentials,
                                                      std::string_view region, std::string_view service,
                                                      TimePoint now, std::chrono::seconds expires);

}
