// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Valkyrian Labs LLC
#pragma once

#include "vl/keykit/account_key.hpp"
#include "vl/keykit/kev1.hpp"
#include "vl/keykit/secret.hpp"
#include "vl/keykit/seed.hpp"

#include <array>
#include <cstddef>
#include <cstdint>
#include <functional>
#include <optional>
#include <span>
#include <stdexcept>
#include <string_view>
#include <vector>

// KAK1: the account key (its 16-byte recovery seed) wrapped to one holder's public key (vaulthalla-cloud
// docs/design/key-manager.md, "Unlock methods"): what a Desktop holder keeps, what a rotation delivers to each holder
// and what a transfer delivers to a new device. KEV1's construction and both its suites, its own magic and label, and
// the account and the key generation bound into the authenticated prefix. Vectors: vectors/vhc.json `kak1`.
//
//   offset  len  field
//    0       8   magic 89 56 48 41 0D 0A 1A 0A ("\x89VHA\r\n\x1a\n")
//    8       2   version 1
//   10       2   suite: 1 = X25519, 2 = P-256 ECDH (a Secure Enclave key); HKDF-SHA-256 and AES-256-GCM in both
//   12       4   generation of the account key (>= 1)
//   16      16   account public_id (the UUID's 16 bytes)
//   32      16   fingerprint of that generation (account_key.hpp)
//   48      32   recipient_id = SHA-256(holder public key: 32 raw bytes, or the 65-byte uncompressed P-256 point)
//   80       2   epk_len (32 or 65)
//   82   epk_len epk, fresh per envelope
//   82+e    32   AES-256-GCM(K, nonce 0^12, seed (16 bytes), AAD = bytes[0 .. 82+e))
//
//   K = HKDF-Expand(HKDF-Extract(salt = epk ‖ holder public key, IKM = Z), "vhc.kak1.wrap" ‖ prefix, 32)
//
// Sizes: 146 bytes (X25519), 179 (P-256). Reader checks, in order: bad_magic, unsupported_version, unsupported_suite,
// account_mismatch, key_mismatch (another generation or fingerprint than the statement the reader expects),
// recipient_mismatch, bad_length, bad_ephemeral, wrap_auth_failed, seed_mismatch (the unwrapped seed doesn't derive the
// fingerprint: a writer's bug, never accepted).
namespace vl::keykit::kak1 {

inline constexpr std::array<uint8_t, 8> kMagic{0x89, 0x56, 0x48, 0x41, 0x0D, 0x0A, 0x1A, 0x0A};
inline constexpr uint16_t kVersion = 1;
inline constexpr std::size_t kFixedPrefixSize = 82;
inline constexpr std::size_t kWrappedSize = kSeedSize + 16;

enum class ErrorCode : uint8_t {
    BadMagic,
    UnsupportedVersion,
    UnsupportedSuite,
    AccountMismatch,
    KeyMismatch,
    RecipientMismatch,
    BadLength,
    BadEphemeral,
    WrapAuthFailed,
    SeedMismatch,
};

[[nodiscard]] std::string_view errorCodeName(ErrorCode code);

class Error : public std::runtime_error {
public:
    explicit Error(ErrorCode code);
    [[nodiscard]] ErrorCode code() const noexcept { return code_; }

private:
    ErrorCode code_;
};

// Wraps the account key `seed` of generation `statement` to a holder. The seed must derive the statement's keys
// (std::invalid_argument otherwise, and for a holder key that isn't a valid key of its suite). The ephemeral key is
// fresh from the CSPRNG; `ephemeralSecretForTesting` (the vectors) fixes it.
[[nodiscard]] std::vector<uint8_t> wrap(const RecoverySeed& seed, const account::KeyStatement& statement,
                                        kev1::Suite suite, std::span<const uint8_t> holderPublicKey,
                                        std::span<const uint8_t> ephemeralSecretForTesting = {});

// The reader, for a holder whose secret key is in memory. `statement` is the generation the holder expects (from
// GET /v1/keys/account, verified). Throws Error with the first check that fails.
[[nodiscard]] RecoverySeed unwrap(std::span<const uint8_t> envelope, std::span<const uint8_t> holderSecretKey,
                                  kev1::Suite expectedSuite, const account::KeyStatement& statement);

// The same reader for a key that never leaves its hardware (a Secure Enclave P-256 key): `agree` computes Z, the
// X25519 output or the P-256 x-coordinate, of the holder key with the envelope's ephemeral public key, and returns
// nullopt when it refuses the point (bad_ephemeral). It is called only with a point valid for the suite; an all-zero Z
// it returns is bad_ephemeral too, as for unwrap.
using Agreement = std::function<std::optional<SecretBytes>(std::span<const uint8_t> ephemeralPublicKey)>;
[[nodiscard]] RecoverySeed unwrapWith(std::span<const uint8_t> envelope, std::span<const uint8_t> holderPublicKey,
                                      kev1::Suite expectedSuite, const account::KeyStatement& statement,
                                      const Agreement& agree);

// The prefix's fields, read without a key (the cloud validating what it stores and relays). Applies the reader's
// structural checks (magic, version, suite, length); it authenticates nothing.
struct Header {
    uint16_t suite{};
    uint32_t generation{};
    std::array<uint8_t, 16> public_id{};
    account::Fingerprint fingerprint{};
    kev1::Digest recipient_id{};
};
[[nodiscard]] Header inspect(std::span<const uint8_t> envelope);

}
