// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Valkyrian Labs LLC
//
// Calls the C API from Swift the way Vaulthalla Desktop will: a comparison code against the cloud's vector, a new
// account key and its statement, KAK1 to a P-256 holder key whose agreement CryptoKit performs through the callback (a
// software key standing in for the Secure Enclave), and a storage credential's exchange through a one-time key.

import CryptoKit
import Foundation
import VLKeykit

func check(_ status: vl_keykit_status, _ what: String) {
    guard status == VL_KEYKIT_OK else {
        FileHandle.standardError.write(Data("FAIL: \(what): \(String(cString: vl_keykit_status_name(status)))\n".utf8))
        exit(1)
    }
}

func text(_ capacity: Int, _ fill: (UnsafeMutablePointer<CChar>, UnsafeMutablePointer<Int>) -> vl_keykit_status,
          _ what: String) -> String {
    var buffer = [CChar](repeating: 0, count: capacity)
    var length = capacity
    check(buffer.withUnsafeMutableBufferPointer { fill($0.baseAddress!, &length) }, what)
    return String(decoding: buffer[0..<length].map { UInt8(bitPattern: $0) }, as: UTF8.self)
}

// 1. The request code of vaulthalla-cloud's design vector.
let id = "0123456789abcdefghjkmnpqrs", payload = #"{"generation":1}"#
let code = text(Int(VL_KEYKIT_CODE_TEXT_SIZE), { out, length in
    vl_keykit_request_code(id, id.utf8.count, payload, payload.utf8.count, out, length)
}, "request code")
guard code == "4c0c-4ab7-e42c-29ef" else { print("FAIL: request code \(code)"); exit(1) }

// 2. A new account key and its generation-1 statement.
var seed: OpaquePointer?
check(vl_keykit_seed_generate(&seed), "seed")
defer { vl_keykit_seed_free(seed) }
let publicId = "5f0c3a3e-8d1b-4c2a-9e47-6b1d2f3a4c5e"
let statement = text(Int(VL_KEYKIT_STATEMENT_MAX_SIZE), { out, length in
    vl_keykit_statement_build(seed, publicId, publicId.utf8.count, 1, nil, Int32(VL_KEYKIT_REASON_INITIAL), out, length)
}, "statement")

// 3. KAK1 to a P-256 holder key; unwrapped through the agreement callback.
final class Holder { let key = P256.KeyAgreement.PrivateKey() }
let holder = Holder()
let holderPublic = [UInt8](holder.key.publicKey.x963Representation)  // 65-byte uncompressed point
var envelope = [UInt8](repeating: 0, count: Int(VL_KEYKIT_KAK1_MAX_SIZE))
var envelopeLength = envelope.count
check(vl_keykit_kak1_wrap(seed, statement, statement.utf8.count, UInt16(VL_KEYKIT_SUITE_P256), holderPublic,
                          holderPublic.count, &envelope, &envelopeLength), "kak1 wrap")

let agree: vl_keykit_agree_fn = { context, epk, epkLength, z in
    let holder = Unmanaged<Holder>.fromOpaque(context!).takeUnretainedValue()
    guard let epk, let z,
          let peer = try? P256.KeyAgreement.PublicKey(x963Representation: Data(bytes: epk, count: epkLength)),
          let shared = try? holder.key.sharedSecretFromKeyAgreement(with: peer) else { return 1 }
    shared.withUnsafeBytes { raw in
        guard raw.count == 32 else { return }
        z.update(from: raw.bindMemory(to: UInt8.self).baseAddress!, count: 32)
    }
    return 0
}
var opened: OpaquePointer?
check(vl_keykit_kak1_unwrap_with(envelope, envelopeLength, holderPublic, holderPublic.count,
                                 UInt16(VL_KEYKIT_SUITE_P256), statement, statement.utf8.count, agree,
                                 Unmanaged.passUnretained(holder).toOpaque(), &opened), "kak1 unwrap_with")
defer { vl_keykit_seed_free(opened) }
check(vl_keykit_seed_matches(opened, statement, statement.utf8.count), "the unwrapped key is the statement's")

// 4. A storage credential sealed to a one-time key, opened under its binding and read into a buffer.
var oneTime: OpaquePointer?
check(vl_keykit_credential_key_generate(&oneTime), "one-time key")
defer { vl_keykit_credential_key_free(oneTime) }
var oneTimePublic = [UInt8](repeating: 0, count: 32)
check(vl_keykit_credential_key_public(oneTime, &oneTimePublic), "one-time public key")
let installation = "t8strmqnma7qe89214v79ecrmc", keyId = "005abc", vaultUid = [UInt8](repeating: 7, count: 16)
let secret = Array("an application key".utf8)
var sealed = [UInt8](repeating: 0, count: Int(VL_KEYKIT_CREDENTIAL_SEALED_MAX_SIZE))
var sealedLength = sealed.count
check(vl_keykit_credential_seal(secret, secret.count, installation, installation.utf8.count, vaultUid, keyId,
                                keyId.utf8.count, oneTimePublic, &sealed, &sealedLength), "credential seal")
var credential: OpaquePointer?
check(vl_keykit_credential_open(sealed, sealedLength, oneTime, installation, installation.utf8.count, vaultUid, keyId,
                                keyId.utf8.count, &credential), "credential open")
defer { vl_keykit_credential_free(credential) }
var read = [UInt8](repeating: 0, count: Int(VL_KEYKIT_CREDENTIAL_SECRET_MAX_SIZE))
var readLength = read.count
check(vl_keykit_credential_secret(credential, &read, &readLength), "credential secret")
guard Array(read[0..<readLength]) == secret else { print("FAIL: credential secret"); exit(1) }
read.withUnsafeMutableBytes { $0.initializeMemory(as: UInt8.self, repeating: 0) }

print("OK: VLKeykit \(String(cString: vl_keykit_version())): request code \(code), KAK1 P-256 round trip through CryptoKit, storage credential")
