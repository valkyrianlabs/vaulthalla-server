// swift-tools-version: 6.0
// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Valkyrian Labs LLC
//
// Proves VLKeykit.xcframework links and runs from Swift (run.sh builds it and copies it to Frameworks/). macOS only;
// not part of the meson build or the Linux CI.

import PackageDescription

let package = Package(
    name: "KeykitCheck",
    platforms: [.macOS("27.0")],
    targets: [
        .binaryTarget(name: "VLKeykit", path: "Frameworks/VLKeykit.xcframework"),
        .executableTarget(name: "KeykitCheck", dependencies: ["VLKeykit"]),
    ]
)
