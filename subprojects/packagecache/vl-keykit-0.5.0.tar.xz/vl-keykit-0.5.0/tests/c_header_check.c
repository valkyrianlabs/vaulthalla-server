/* SPDX-License-Identifier: MIT */
/* Copyright (c) 2026 Valkyrian Labs LLC */
/* The C API's header compiled as C11, and a few calls made from C (test_c_api.cpp runs this). */
#include "vl/keykit/vl_keykit.h"

#include <string.h>

int vl_keykit_c_header_check(void);

int vl_keykit_c_header_check(void) {
    static const char id[] = "0123456789abcdefghjkmnpqrs";
    static const char payload[] = "{\"generation\":1}";
    char code[VL_KEYKIT_CODE_TEXT_SIZE];
    size_t len = sizeof code;
    if (vl_keykit_request_code(id, sizeof id - 1, payload, sizeof payload - 1, code, &len) != VL_KEYKIT_OK) return 1;
    if (len != VL_KEYKIT_CODE_TEXT_SIZE || memcmp(code, "4c0c-4ab7-e42c-29ef", len) != 0) return 2;

    vl_keykit_seed* seed = NULL;
    if (vl_keykit_seed_generate(&seed) != VL_KEYKIT_OK || seed == NULL) return 3;
    char text[VL_KEYKIT_SEED_TEXT_SIZE];
    len = sizeof text;
    const vl_keykit_status status = vl_keykit_seed_export_text(seed, text, &len);
    memset(text, 0, sizeof text);
    vl_keykit_seed_free(seed);
    if (status != VL_KEYKIT_OK || len != VL_KEYKIT_SEED_TEXT_SIZE) return 4;

    if (strcmp(vl_keykit_status_name(VL_KEYKIT_ERR_KAK1_WRAP_AUTH_FAILED), "kak1_wrap_auth_failed") != 0) return 5;

    /* A storage credential's exchange: a one-time key, a credential sealed to it, opened and read. */
    vl_keykit_credential_key* key = NULL;
    uint8_t pk[VL_KEYKIT_PUBLIC_KEY_SIZE];
    if (vl_keykit_credential_key_generate(&key) != VL_KEYKIT_OK || vl_keykit_credential_key_public(key, pk) != VL_KEYKIT_OK)
        return 6;
    static const char installation[] = "t8strmqnma7qe89214v79ecrmc"; /* canonical: the last symbol's spare bits are 0 */
    static const uint8_t uid[VL_KEYKIT_UID_SIZE] = {1, 2, 3};
    static const uint8_t secret[] = "secret";
    uint8_t sealed[VL_KEYKIT_CREDENTIAL_SEALED_MAX_SIZE];
    size_t sealed_len = sizeof sealed;
    if (vl_keykit_credential_seal(secret, 6, installation, sizeof installation - 1, uid, "k1", 2, pk, sealed, &sealed_len) != VL_KEYKIT_OK)
        return 7;
    vl_keykit_credential* credential = NULL;
    const vl_keykit_status opened =
        vl_keykit_credential_open(sealed, sealed_len, key, installation, sizeof installation - 1, uid, "k1", 2, &credential);
    vl_keykit_credential_key_free(key);
    if (opened != VL_KEYKIT_OK) return 8;
    uint8_t out[VL_KEYKIT_CREDENTIAL_SECRET_MAX_SIZE];
    len = sizeof out;
    const vl_keykit_status read = vl_keykit_credential_secret(credential, out, &len);
    vl_keykit_credential_free(credential);
    const int same = read == VL_KEYKIT_OK && len == 6 && memcmp(out, secret, 6) == 0;
    memset(out, 0, sizeof out);
    if (!same) return 9;
    return 0;
}
