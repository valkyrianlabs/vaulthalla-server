// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Valkyrian Labs LLC
//
// KAK1, sealed vault labels and sealed storage credentials against vectors/vhc.json: positives byte for byte with the
// vectors' ephemeral keys, negatives by their first failing check, fresh round trips, tampering and wiping.
#include "sealing.hpp"  // white box: the hardware-key callback is played by the library's own ECDH
#include "support.hpp"
#include "vl/keykit/base64url.hpp"
#include "vl/keykit/kak1.hpp"
#include "vl/keykit/storage_credential.hpp"
#include "vl/keykit/vault_label.hpp"

#include <gtest/gtest.h>

#include <atomic>

namespace vl::keykit::test {

namespace {

const Json& vhc(const char* section) { return vhcVectors().at(section); }

Uid uidOf(const Json& j) {
    const auto b = hex(j);
    Uid u{};
    if (b.size() != u.size()) throw std::invalid_argument("a uid is 16 bytes");
    std::copy(b.begin(), b.end(), u.begin());
    return u;
}

account::KeyStatement statementOf(const Json& j) { return account::parseStatement(str(j)); }

credential::Context contextOf(const Json& c) {
    return {.installation_id = str(c.at("installation_id")),
            .vault_uid = uidOf(c.at("vault_uid_hex")),
            .key_id = str(c.at("key_id"))};
}

// The first error a call throws, by the format's spelling, or "accepted".
template <typename Error>
std::string errorOf(const auto& fn) {
    try {
        fn();
    } catch (const Error& e) {
        return std::string(errorCodeName(e.code()));
    }
    return "accepted";
}

// What a Secure Enclave does for KAK1: Z of its key with the envelope's ephemeral public key.
kak1::Agreement hardwareKey(const kev1::Suite suite, const Bytes& secret, int* calls) {
    return [=](const std::span<const uint8_t> epk) {
        ++*calls;
        const auto mine = detail::secretKey(suite, secret);
        const auto peer = detail::publicKey(suite, epk);
        return detail::agree(mine.get(), peer.get());
    };
}

std::atomic<int> wiped{0};
std::atomic<bool> allZero{true};
void observe(const void*, const std::span<const uint8_t> after) {
    ++wiped;
    if (!std::ranges::all_of(after, [](const uint8_t b) { return b == 0; })) allZero = false;
}

}

// ---- KAK1 ---------------------------------------------------------------------------------------------------------

TEST(Kak1Vectors, PositiveEnvelopesAreReproducedAndUnwrap) {
    const auto& positives = vhc("kak1").at("positive");
    ASSERT_EQ(positives.size(), 2u);
    for (const auto& v : positives) {
        SCOPED_TRACE(str(v.at("name")));
        const auto suite = static_cast<kev1::Suite>(v.at("suite").get<uint16_t>());
        const auto statement = statementOf(v.at("statement"));
        const auto seed = RecoverySeed::fromBytes(hex(v.at("seed_hex")));
        const auto sk = hex(v.at("holder_sk_hex"));
        EXPECT_EQ(toHex(kev1::publicKeyOf(suite, sk)), str(v.at("holder_pk_hex")));
        const auto env = kak1::wrap(seed, statement, suite, hex(v.at("holder_pk_hex")), hex(v.at("ephemeral_sk_hex")));
        EXPECT_EQ(toHex(env), str(v.at("envelope_hex")));
        EXPECT_EQ(env.size(), suite == kev1::Suite::X25519 ? 146u : 179u);
        EXPECT_EQ(toHex(kak1::unwrap(env, sk, suite, statement).bytes()), str(v.at("seed_hex")));

        int calls = 0;
        const auto viaHardware =
            kak1::unwrapWith(env, hex(v.at("holder_pk_hex")), suite, statement, hardwareKey(suite, sk, &calls));
        EXPECT_EQ(toHex(viaHardware.bytes()), str(v.at("seed_hex")));
        EXPECT_EQ(calls, 1);

        const auto h = kak1::inspect(env);
        EXPECT_EQ(h.suite, static_cast<uint16_t>(suite));
        EXPECT_EQ(h.generation, statement.generation);
        EXPECT_EQ(h.fingerprint, account::fingerprint(statement));
        EXPECT_EQ(toHex(h.recipient_id), str(v.at("recipient_id_hex")));
    }
}

TEST(Kak1Vectors, NegativeEnvelopesFailAtTheirFirstCheck) {
    const auto& negatives = vhc("kak1").at("negative");
    ASSERT_GE(negatives.size(), 15u);
    for (const auto& n : negatives) {
        SCOPED_TRACE(str(n.at("name")));
        const auto suite = static_cast<kev1::Suite>(n.at("suite_expected").get<uint16_t>());
        const auto env = hex(n.at("envelope_hex"));
        const auto statement = statementOf(n.at("statement"));
        const auto sk = hex(n.at("holder_sk_hex"));
        using kak1::Error;
        EXPECT_EQ(errorOf<Error>([&] { (void)kak1::unwrap(env, sk, suite, statement); }), str(n.at("error")));
        int calls = 0;
        EXPECT_EQ(errorOf<Error>([&] {
                      (void)kak1::unwrapWith(env, kev1::publicKeyOf(suite, sk), suite, statement,
                                             hardwareKey(suite, sk, &calls));
                  }),
                  str(n.at("error")));
    }
}

TEST(Kak1, FreshEnvelopesRoundTripAndRefuseMisuse) {
    const auto account = RecoverySeed::generate();
    const auto statement =
        account::statementFor(account, "01234567-89ab-4cde-8f01-23456789abcd", 1, std::nullopt, account::Reason::Initial);
    for (const auto suite : {kev1::Suite::X25519, kev1::Suite::P256}) {
        const auto sk = SecretBytes::random(32);
        const auto pk = kev1::publicKeyOf(suite, sk.bytes());
        const auto a = kak1::wrap(account, statement, suite, pk);
        const auto b = kak1::wrap(account, statement, suite, pk);
        EXPECT_NE(a, b);  // a fresh ephemeral key per envelope
        EXPECT_EQ(kak1::unwrap(a, sk.bytes(), suite, statement).text(), account.text());
        for (std::size_t i = 0; i < a.size(); ++i) {
            auto bad = a;
            bad[i] ^= 0x01;
            EXPECT_THROW((void)kak1::unwrap(bad, sk.bytes(), suite, statement), kak1::Error) << i;
        }
        int calls = 0;
        const kak1::Agreement refuses = [&](std::span<const uint8_t>) {
            ++calls;
            return std::optional<SecretBytes>{};
        };
        EXPECT_EQ(errorOf<kak1::Error>([&] { (void)kak1::unwrapWith(a, pk, suite, statement, refuses); }),
                  "bad_ephemeral");
        EXPECT_EQ(calls, 1);
    }
    const auto other = RecoverySeed::generate();
    const auto pk = kev1::publicKeyOf(kev1::Suite::X25519, SecretBytes::random(32).bytes());
    EXPECT_THROW((void)kak1::wrap(other, statement, kev1::Suite::X25519, pk), std::invalid_argument);
    EXPECT_THROW((void)kak1::wrap(account, statement, kev1::Suite::P256, pk), std::invalid_argument);
    EXPECT_THROW((void)kak1::wrap(account, statement, static_cast<kev1::Suite>(3), pk), std::invalid_argument);
    EXPECT_EQ(kak1::errorCodeName(static_cast<kak1::ErrorCode>(200)), "unknown");
}

// ---- vault labels -------------------------------------------------------------------------------------------------

TEST(VaultLabelVectors, PositiveLabelsAreReproducedAndOpen) {
    const auto& positives = vhc("vault_label").at("positive");
    ASSERT_GE(positives.size(), 3u);
    for (const auto& v : positives) {
        SCOPED_TRACE(str(v.at("name")));
        const auto statement = statementOf(v.at("statement"));
        const auto uid = uidOf(v.at("vault_uid_hex"));
        const auto name = str(v.at("label"));
        EXPECT_EQ(name.size(), v.at("label_bytes").get<std::size_t>());
        EXPECT_TRUE(label::isSealableName(name));
        const auto sealed = label::seal(name, statement, uid, hex(v.at("ephemeral_sk_hex")));
        EXPECT_EQ(toHex(sealed), str(v.at("sealed_hex")));
        EXPECT_EQ(sealed.size(), label::kSealedSize);
        EXPECT_EQ(label::open(sealed, hex(v.at("account_x25519_sk_hex")), statement, uid), name);
        EXPECT_EQ(label::sealedGeneration(sealed), statement.generation);
    }
}

TEST(VaultLabelVectors, NegativeLabelsFailAtTheirFirstCheck) {
    const auto& negatives = vhc("vault_label").at("negative");
    ASSERT_GE(negatives.size(), 14u);
    for (const auto& n : negatives) {
        SCOPED_TRACE(str(n.at("name")));
        EXPECT_EQ(errorOf<label::Error>([&] {
                      (void)label::open(hex(n.at("sealed_hex")), hex(n.at("account_x25519_sk_hex")),
                                        statementOf(n.at("statement")), uidOf(n.at("vault_uid_hex")));
                  }),
                  str(n.at("error")));
    }
}

TEST(VaultLabel, FreshLabelsRoundTripAndHideTheirLength) {
    const auto account = RecoverySeed::generate();
    const auto statement =
        account::statementFor(account, "01234567-89ab-4cde-8f01-23456789abcd", 1, std::nullopt, account::Reason::Initial);
    const auto uid = newUid();
    const auto a = label::seal("a", statement, uid);
    const auto b = label::seal(std::string(128, 'b'), statement, uid);
    EXPECT_EQ(a.size(), b.size());
    EXPECT_NE(label::seal("a", statement, uid), a);
    EXPECT_EQ(label::open(a, account.x25519SecretKey().bytes(), statement, uid), "a");
    EXPECT_EQ(label::open(b, account.x25519SecretKey().bytes(), statement, uid), std::string(128, 'b'));
    for (std::size_t i = 0; i < a.size(); ++i) {
        auto bad = a;
        bad[i] ^= 0x01;
        EXPECT_THROW((void)label::open(bad, account.x25519SecretKey().bytes(), statement, uid), label::Error) << i;
    }
    EXPECT_FALSE(label::isSealableName(""));
    EXPECT_FALSE(label::isSealableName(std::string(129, 'x')));
    EXPECT_FALSE(label::isSealableName(std::string_view("nul\0in", 6)));
    EXPECT_FALSE(label::isSealableName("\xc3\x28"));
    EXPECT_FALSE(label::isSealableName("\xed\xa0\x80"));  // a surrogate
    EXPECT_FALSE(label::isSealableName("\xc2\x85"));      // U+0085, a C1 control
    EXPECT_TRUE(label::isSealableName("Fotos \xe2\x80\x93 Familie"));
    EXPECT_THROW((void)label::seal("", statement, uid), std::invalid_argument);
    EXPECT_THROW((void)label::open(a, Bytes(31, 1), statement, uid), std::invalid_argument);
    EXPECT_EQ(label::errorCodeName(static_cast<label::ErrorCode>(200)), "unknown");
}

// ---- sealed storage credentials ----------------------------------------------------------------------------------

TEST(StorageCredentialVectors, PositiveCredentialsAreReproducedAndOpen) {
    const auto& positives = vhc("storage_credential").at("positive");
    ASSERT_GE(positives.size(), 1u);
    for (const auto& v : positives) {
        SCOPED_TRACE(str(v.at("name")));
        const auto context = contextOf(v.at("context"));
        const auto secret = str(v.at("secret"));
        const Bytes secretBytes(secret.begin(), secret.end());
        EXPECT_EQ(toHex(kev1::publicKeyOf(kev1::Suite::X25519, hex(v.at("server_sk_hex")))), str(v.at("server_pk_hex")));
        const auto sealed =
            credential::seal(secretBytes, context, hex(v.at("server_pk_hex")), hex(v.at("ephemeral_sk_hex")));
        EXPECT_EQ(toHex(sealed), str(v.at("sealed_hex")));
        EXPECT_EQ(base64UrlEncode(sealed), str(v.at("sealed_base64url")));
        const auto opened = credential::open(sealed, hex(v.at("server_sk_hex")), context);
        EXPECT_TRUE(equalConstantTime(opened.bytes(), secretBytes));
    }
}

TEST(StorageCredentialVectors, NegativeCredentialsFailAtTheirFirstCheck) {
    const auto& negatives = vhc("storage_credential").at("negative");
    ASSERT_GE(negatives.size(), 10u);
    for (const auto& n : negatives) {
        SCOPED_TRACE(str(n.at("name")));
        EXPECT_EQ(errorOf<credential::Error>([&] {
                      (void)credential::open(hex(n.at("sealed_hex")), hex(n.at("server_sk_hex")),
                                             contextOf(n.at("context")));
                  }),
                  str(n.at("error")));
    }
}

TEST(StorageCredential, FreshCredentialsRoundTripWipeAndRefuseMisuse) {
    const credential::Context context{.installation_id = toBase32(newUid()), .vault_uid = newUid(), .key_id = "005abc"};
    const auto serverSecret = SecretBytes::random(32);
    const auto serverPublic = kev1::publicKeyOf(kev1::Suite::X25519, serverSecret.bytes());
    const Bytes secret(31, 'K');
    const auto sealed = credential::seal(secret, context, serverPublic);
    EXPECT_EQ(sealed.size(), credential::kPrefixSize + secret.size() + 16);
    EXPECT_NE(credential::seal(secret, context, serverPublic), sealed);
    for (std::size_t i = 0; i < sealed.size(); ++i) {
        auto bad = sealed;
        bad[i] ^= 0x01;
        EXPECT_THROW((void)credential::open(bad, serverSecret.bytes(), context), credential::Error) << i;
    }

    wiped = 0;
    allZero = true;
    setWipeObserverForTesting(&observe);
    {
        const auto opened = credential::open(sealed, serverSecret.bytes(), context);
        EXPECT_TRUE(equalConstantTime(opened.bytes(), secret));
    }
    setWipeObserverForTesting(nullptr);
    EXPECT_GE(wiped.load(), 3);  // at least Z, the key and the opened secret
    EXPECT_TRUE(allZero.load());

    auto bad = context;
    bad.installation_id = "KCEYPK9VFN5TV6YX5C6QPFEBDM";
    EXPECT_THROW((void)credential::seal(secret, bad, serverPublic), std::invalid_argument);
    bad = context;
    bad.key_id = "has space";
    EXPECT_THROW((void)credential::seal(secret, bad, serverPublic), std::invalid_argument);
    bad.key_id = std::string(129, 'k');
    EXPECT_THROW((void)credential::open(sealed, serverSecret.bytes(), bad), std::invalid_argument);
    EXPECT_THROW((void)credential::seal(Bytes{}, context, serverPublic), std::invalid_argument);
    EXPECT_THROW((void)credential::seal(Bytes(1025, 1), context, serverPublic), std::invalid_argument);
    EXPECT_THROW((void)credential::seal(secret, context, Bytes(31, 1)), std::invalid_argument);
    EXPECT_THROW((void)credential::open(sealed, Bytes(31, 1), context), std::invalid_argument);
    EXPECT_EQ(credential::errorCodeName(static_cast<credential::ErrorCode>(200)), "unknown");
}

}
