// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Valkyrian Labs LLC
// Key provenance (attestation.hpp) and its C API against vectors/vectors.json `key_provenance`.
#include "support.hpp"

#include "vl/keykit/attestation.hpp"
#include "vl/keykit/uid.hpp"
#include "vl/keykit/vl_keykit.h"

#include <gtest/gtest.h>

#include <array>
#include <fstream>
#include <stdexcept>
#include <string>

namespace pv = vl::keykit::provenance;
using namespace vl::keykit::test;

namespace {

// vectors/key_provenance.json, read once.
const Json& kp() {
    static const Json doc = [] {
        std::ifstream in(std::string(VL_KEYKIT_VECTORS_DIR) + "/key_provenance.json");
        if (!in) throw std::runtime_error("cannot open vectors/key_provenance.json");
        return Json::parse(in);
    }();
    return doc;
}

std::string cKeyCheck(const Bytes& key, uint64_t vaultId, uint32_t version, vl_keykit_status* status) {
    std::array<char, 32> out{};
    std::size_t len = out.size();
    *status = vl_keykit_key_check(key.data(), key.size(), vaultId, version, out.data(), &len);
    return *status == VL_KEYKIT_OK ? std::string(out.data(), len) : std::string();
}

}

TEST(Provenance, KeyChecksMatchTheVectors) {
    for (const auto& c : kp().at("key_checks")) {
        const auto key = fromHex(c.at("key_hex"));
        const auto want = c.at("key_check").get<std::string>();
        EXPECT_EQ(pv::keyCheck(key, c.at("vault_id"), c.at("version")), want);
        vl_keykit_status s{};
        EXPECT_EQ(cKeyCheck(key, c.at("vault_id"), c.at("version"), &s), want);
        EXPECT_EQ(s, VL_KEYKIT_OK);
        EXPECT_TRUE(pv::keyCheckEquals(want, want));
    }
}

TEST(Provenance, AttestationsMatchTheVectorsAndVerify) {
    for (const auto& a : kp().at("attestations")) {
        const auto seed = fromHex(a.at("seed_hex"));
        const std::string node = a.at("node_id"), check = a.at("key_check");
        const uint64_t vault = a.at("vault_id");
        const uint32_t version = a.at("version");
        EXPECT_EQ(pv::attestationMessage(node, vault, version, check), fromHex(a.at("message_hex")));
        const auto pk = pv::attestationPublicKey(seed);
        EXPECT_EQ(Bytes(pk.begin(), pk.end()), fromHex(a.at("public_key_hex")));
        const auto sig = pv::attest(seed, node, vault, version, check);
        EXPECT_EQ(Bytes(sig.begin(), sig.end()), fromHex(a.at("signature_hex")));
        EXPECT_TRUE(pv::verifyAttestation(pk, node, vault, version, check, sig));
        // The C API: the same bytes, and the same verdict.
        std::array<uint8_t, 32> cpk{};
        std::array<uint8_t, 64> csig{};
        ASSERT_EQ(vl_keykit_attestation_public_key(seed.data(), seed.size(), cpk.data()), VL_KEYKIT_OK);
        ASSERT_EQ(vl_keykit_attest(seed.data(), seed.size(), node.data(), node.size(), vault, version, check.data(),
                                   check.size(), csig.data()),
                  VL_KEYKIT_OK);
        EXPECT_EQ(cpk, pk);
        EXPECT_EQ(csig, sig);
        int valid = 0;
        ASSERT_EQ(vl_keykit_attestation_verify(cpk.data(), cpk.size(), node.data(), node.size(), vault, version,
                                               check.data(), check.size(), csig.data(), csig.size(), &valid),
                  VL_KEYKIT_OK);
        EXPECT_EQ(valid, 1);
        // Another vault id, version or node: not this attestation.
        EXPECT_FALSE(pv::verifyAttestation(pk, node, vault + 1, version, check, sig));
        EXPECT_FALSE(pv::verifyAttestation(pk, node, vault, version + 1, check, sig));
        EXPECT_FALSE(pv::verifyAttestation(pk, node + "x", vault, version, check, sig));
    }
}

TEST(Provenance, AMacsOriginVaultIdIsDerivedFromTheUid) {
    for (const auto& u : kp().at("mac_origin_vault_ids")) {
        const auto uid = vl::keykit::fromBase32(u.at("vault_uid").get<std::string>());
        ASSERT_TRUE(uid);
        EXPECT_EQ(pv::macOriginVaultId(*uid), u.at("vault_id").get<uint32_t>());
        uint32_t out = 0;
        ASSERT_EQ(vl_keykit_mac_origin_vault_id(uid->data(), &out), VL_KEYKIT_OK);
        EXPECT_EQ(out, u.at("vault_id").get<uint32_t>());
        EXPECT_GE(out, 1u);
        EXPECT_LE(out, pv::kMaxVaultId);
    }
}

TEST(Provenance, NegativesAreRefusedWithTheirCodes) {
    for (const auto& n : kp().at("negative")) {
        const std::string what = n.at("what"), error = n.at("error");
        if (what == "verify") {
            EXPECT_FALSE(pv::verifyAttestation(fromHex(n.at("public_key_hex")), n.at("node_id").get<std::string>(),
                                               n.at("vault_id"), n.at("version"), n.at("key_check").get<std::string>(),
                                               fromHex(n.at("signature_hex"))))
                << error;
            continue;
        }
        try {
            if (what == "key_check")
                (void)pv::keyCheck(fromHex(n.at("key_hex")), n.at("vault_id"), n.at("version"));
            else
                (void)pv::attestationMessage(n.at("node_id").get<std::string>(), n.at("vault_id"), n.at("version"),
                                             n.at("key_check").get<std::string>());
            ADD_FAILURE() << error << " accepted";
        } catch (const pv::Error& e) {
            EXPECT_EQ(pv::errorCodeName(e.code()), error);
        }
    }
    vl_keykit_status s{};
    (void)cKeyCheck(Bytes(31, 0), 1, 1, &s);
    EXPECT_EQ(s, VL_KEYKIT_ERR_PROVENANCE_BAD_KEY);
    EXPECT_STREQ(vl_keykit_status_name(s), "provenance_bad_key");
    (void)cKeyCheck(Bytes(32, 0), 0, 1, &s);
    EXPECT_EQ(s, VL_KEYKIT_ERR_PROVENANCE_BAD_VAULT_ID);
    std::array<uint8_t, 64> sig{};
    const Bytes seed(32, 1);
    EXPECT_EQ(vl_keykit_attest(seed.data(), 31, "n", 1, 1, 1, "00000000000000000000000000000000", 32, sig.data()),
              VL_KEYKIT_ERR_PROVENANCE_BAD_SEED);
    EXPECT_EQ(vl_keykit_attest(seed.data(), 32, "n", 1, 1, 1, "0000000000000000000000000000000G", 32, sig.data()),
              VL_KEYKIT_ERR_PROVENANCE_BAD_KEY_CHECK);
    EXPECT_EQ(vl_keykit_attest(seed.data(), 32, "", 0, 1, 1, "00000000000000000000000000000000", 32, sig.data()),
              VL_KEYKIT_ERR_PROVENANCE_BAD_NODE_ID);
    int valid = 1;
    EXPECT_EQ(vl_keykit_attestation_verify(seed.data(), 31, "n", 1, 1, 1, "00", 2, sig.data(), 64, &valid), VL_KEYKIT_OK);
    EXPECT_EQ(valid, 0);
    EXPECT_FALSE(pv::keyCheckEquals("ab", "ab"));
}
