# Golden vectors

## `vectors.json`: Vaulthalla's formats (a verbatim copy)

`vectors.json` and `vh_crypto_vectors.py` are **verbatim copies** of Vaulthalla's
`design/encryption/vectors/` (vaulthalla-server 0bae6b39, v1.22.2). They stay byte-identical so
that every implementation of these formats is checked against one file:

- **this library** (C++): the `kev1`, `recovery_seed` and `object_ids` sections;
- **vaulthalla-server**: its own copy also carries `vhf1` and `manifest`, and its tests compare the shared sections
  with this copy through the `vectors_dir` variable of `vl_keykit_dep`;
- **Vaulthalla Desktop** (Swift, vaulthalla-desktop#49): the same file.

The normative text is Vaulthalla's `design/encryption/03-metadata-recovery.md` §5. A change to any vector needs the
spec change and an independent check (`python3 vh_crypto_vectors.py --check` regenerates the file, compares it byte
for byte and runs its separate reader). Change it upstream first and copy it again, never "regenerate to green" here.
`meson test` runs the `--check` as `vectors-reference` where Python's `cryptography` package is installed (CI always).

## `key_provenance.json`: key checks and attestations (a verbatim copy)

`key_provenance.json` and `key_provenance_vectors.py` are verbatim copies of vaulthalla-server's
`design/encryption/vectors/` (spec 03 §6.5): the key check, an origin's attestation and a Mac's origin vault id, which
`attestation.hpp` implements for the server and Vaulthalla Desktop. Changed upstream first, like `vectors.json`.

## `vhc.json`: the Vaulthalla Cloud formats (owned here)

`vhc.json` and `vhc_vectors.py` are **this repository's own**: the account key statement, fingerprint and chain, the
signed recovery policy (`vhc-recovery-policy-v1`), KAK1, sealed vault labels (`vh.vault-label.v1`), the sealed
storage credential (`vhc-storage-credential-v1`), the holder proof (`vhc-account-key-holder-v1`), the request,
transfer and restore comparison codes and the account public id's bytes. The normative text is the header of each
format in `include/vl/keykit/` (`account_key.hpp`, `recovery_policy.hpp`, `kak1.hpp`, `vault_label.hpp`,
`storage_credential.hpp`, `holder_proof.hpp`, `key_codes.hpp`), drawn from vaulthalla-cloud `docs/design/key-manager.md`, `account-model.md` and
`managed-storage.md` and vaulthalla-server `design/cloud/key-manager.md` and `managed-remotes.md`. vaulthalla-cloud,
vaulthalla-server and Vaulthalla Desktop check their implementations against this one file (through `vectors_dir`).

`python3 vhc_vectors.py --check` regenerates it, compares it byte for byte and runs its separate readers over every
vector; `meson test` runs it as `vhc-vectors-reference`. A change to one of these formats changes the header, the
generator and the C++ together, with a version bump of the format when bytes already written would read differently.
