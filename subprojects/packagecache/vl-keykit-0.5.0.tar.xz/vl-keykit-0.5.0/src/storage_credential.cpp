// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Valkyrian Labs LLC
#include "vl/keykit/storage_credential.hpp"

#include "sealing.hpp"
#include "text.hpp"

#include <algorithm>
#include <utility>

namespace vl::keykit::credential {

namespace {

constexpr std::array<std::pair<ErrorCode, std::string_view>, 6> kErrorNames{{
    {ErrorCode::BadMagic, "bad_magic"},
    {ErrorCode::UnsupportedVersion, "unsupported_version"},
    {ErrorCode::UnsupportedSuite, "unsupported_suite"},
    {ErrorCode::BadLength, "bad_length"},
    {ErrorCode::BadEphemeral, "bad_ephemeral"},
    {ErrorCode::AuthFailed, "auth_failed"},
}};

constexpr std::string_view kLabel = "vhc-storage-credential-v1";
constexpr uint16_t kSuite = static_cast<uint16_t>(kev1::Suite::X25519);
constexpr std::size_t kOffVersion = 8, kOffSuite = 10, kOffEpk = 12;
constexpr std::size_t kTag = detail::kGcmTag;

std::vector<uint8_t> aad(const std::span<const uint8_t> prefix, const Context& c) {
    std::vector<uint8_t> out(prefix.begin(), prefix.end());
    const auto context = std::string(kLabel) + "\n" + c.installation_id + "\n" + toBase32(c.vault_uid) + "\n" + c.key_id;
    detail::append(out, detail::viewBytes(context));
    return out;
}

}

std::string_view errorCodeName(const ErrorCode code) {
    for (const auto& [c, name] : kErrorNames)
        if (c == code) return name;
    return "unknown";
}

Error::Error(const ErrorCode code)
    : std::runtime_error("sealed credential rejected: " + std::string(errorCodeName(code))), code_(code) {}

void validate(const Context& c) {
    if (!fromBase32(c.installation_id)) throw std::invalid_argument("the installation id is not a 26-symbol id");
    if (c.key_id.empty() || c.key_id.size() > kMaxKeyIdSize ||
        !std::ranges::all_of(c.key_id, [](const char ch) { return ch >= 0x21 && ch <= 0x7e; }))
        throw std::invalid_argument("the key id is not 1-128 printable ASCII characters");
}

std::vector<uint8_t> seal(const std::span<const uint8_t> secret, const Context& context,
                          const std::span<const uint8_t> serverPublicKey,
                          const std::span<const uint8_t> ephemeralSecretForTesting) {
    if (secret.empty() || secret.size() > kMaxSecretSize) throw std::invalid_argument("a secret is 1-1024 bytes");
    validate(context);
    const auto peer = detail::publicKey(kev1::Suite::X25519, serverPublicKey);
    if (!peer) throw std::invalid_argument("the server public key is not an X25519 key");
    const auto esk = detail::ephemeralSecret(kev1::Suite::X25519, ephemeralSecretForTesting);
    const auto mine = detail::secretKey(kev1::Suite::X25519, esk.bytes());
    if (!mine) throw std::invalid_argument("the ephemeral secret key is not an X25519 key");
    const auto epk = kev1::publicKeyOf(kev1::Suite::X25519, esk.bytes());
    const auto z = detail::agree(mine.get(), peer.get());
    if (!z) throw Error(ErrorCode::BadEphemeral);

    std::vector<uint8_t> out(kMagic.begin(), kMagic.end());
    detail::putBe16(out, kVersion);
    detail::putBe16(out, kSuite);
    detail::append(out, epk);
    const auto key = detail::deriveKey(z->bytes(), epk, serverPublicKey, kLabel, out);
    detail::append(out, detail::aeadSeal(key.bytes(), secret, aad(out, context)));
    return out;
}

SecretBytes open(const std::span<const uint8_t> sealed, const std::span<const uint8_t> serverSecretKey,
                 const Context& context) {
    validate(context);
    if (serverSecretKey.size() != kev1::kX25519KeySize) throw std::invalid_argument("an X25519 secret is 32 bytes");
    if (sealed.size() < kPrefixSize || !std::equal(kMagic.begin(), kMagic.end(), sealed.begin()))
        throw Error(ErrorCode::BadMagic);
    if (detail::be16(sealed.data() + kOffVersion) != kVersion) throw Error(ErrorCode::UnsupportedVersion);
    if (detail::be16(sealed.data() + kOffSuite) != kSuite) throw Error(ErrorCode::UnsupportedSuite);
    if (sealed.size() < kPrefixSize + 1 + kTag || sealed.size() > kPrefixSize + kMaxSecretSize + kTag)
        throw Error(ErrorCode::BadLength);
    const auto prefix = sealed.first(kPrefixSize);
    const auto epk = sealed.subspan(kOffEpk, kev1::kX25519KeySize);
    const auto rpk = kev1::publicKeyOf(kev1::Suite::X25519, serverSecretKey);
    const auto mine = detail::secretKey(kev1::Suite::X25519, serverSecretKey);
    const auto peer = detail::publicKey(kev1::Suite::X25519, epk);
    const auto z = detail::agree(mine.get(), peer.get());
    if (!z) throw Error(ErrorCode::BadEphemeral);
    const auto key = detail::deriveKey(z->bytes(), epk, rpk, kLabel, prefix);
    auto secret = detail::aeadOpen(key.bytes(), sealed.subspan(kPrefixSize), aad(prefix, context));
    if (!secret) throw Error(ErrorCode::AuthFailed);
    return std::move(*secret);
}

}
