// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Valkyrian Labs LLC
#include "vl/keykit/key_codes.hpp"

#include "openssl.hpp"
#include "vl/keykit/account_key.hpp"
#include "vl/keykit/kev1.hpp"
#include "vl/keykit/kit.hpp"
#include "vl/keykit/uid.hpp"

#include <algorithm>
#include <stdexcept>

namespace vl::keykit::codes {

namespace {

constexpr char kCodeDigits[] = "0123456789abcdef";

std::string lowerHex(const std::span<const uint8_t> bytes) {
    std::string out;
    out.reserve(bytes.size() * 2);
    for (const auto b : bytes) {
        out.push_back(kCodeDigits[b >> 4]);
        out.push_back(kCodeDigits[b & 0x0f]);
    }
    return out;
}

// The first 8 bytes of SHA-256(input) as xxxx-xxxx-xxxx-xxxx.
std::string comparisonCode(const std::string& input) {
    const auto digest = detail::sha256(detail::viewBytes(input));
    std::string out;
    out.reserve(kCodeTextSize);
    for (std::size_t i = 0; i < 8; ++i) {
        if (i && i % 2 == 0) out.push_back('-');
        out.push_back(kCodeDigits[digest[i] >> 4]);
        out.push_back(kCodeDigits[digest[i] & 0x0f]);
    }
    return out;
}

// 26 symbols of the uid alphabet (the padding bits unchecked, as the cloud's vectors need).
bool isIdText(const std::string_view text) {
    return text.size() == kUidTextSize &&
           std::ranges::all_of(text, [](const char c) { return kBase32Alphabet.find(c) != std::string_view::npos; });
}

}

std::string requestCode(const std::string_view requestId, const std::string_view payload) {
    if (!isIdText(requestId)) throw std::invalid_argument("a request id is 26 base32 symbols");
    return comparisonCode("vhc-key-request-v1\n" + std::string(requestId) + "\n" +
                          lowerHex(detail::sha256(detail::viewBytes(payload))));
}

std::string transferCode(const std::string_view publicId, const std::span<const uint8_t> temporaryPublicKey) {
    if (!account::parsePublicId(publicId)) throw std::invalid_argument("the account public id is not a canonical UUID");
    const bool x25519 = temporaryPublicKey.size() == kev1::kX25519KeySize;
    const bool p256 = temporaryPublicKey.size() == kev1::kP256PointSize && temporaryPublicKey[0] == 0x04;
    if (!x25519 && !p256) throw std::invalid_argument("a temporary key is 32 bytes (X25519) or a 65-byte P-256 point");
    return comparisonCode("vhc-key-transfer-v1\n" + std::string(publicId) + "\n" + base64Encode(temporaryPublicKey));
}

std::string restoreCode(const std::string_view vaultUid, const std::span<const uint8_t> temporaryPublicKey) {
    if (!isIdText(vaultUid)) throw std::invalid_argument("a vault uid is 26 base32 symbols");
    if (temporaryPublicKey.size() != kev1::kX25519KeySize)
        throw std::invalid_argument("a restore's temporary key is 32 bytes (X25519)");
    return comparisonCode("vhc-restore-v1\n" + std::string(vaultUid) + "\n" + base64Encode(temporaryPublicKey));
}

}
