// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Valkyrian Labs LLC
#include "vl/keykit/holder_proof.hpp"

#include "openssl.hpp"
#include "sealing.hpp"
#include "vl/keykit/base64url.hpp"
#include "vl/keykit/uid.hpp"

#include <algorithm>
#include <optional>
#include <stdexcept>

namespace vl::keykit::account {

namespace {

// The first input check that fails, in the header's order.
std::optional<ErrorCode> holderInputError(const std::string_view installationId, const kev1::Suite suite,
                                          const std::span<const uint8_t> holderPublicKey) {
    if (!fromBase32(installationId)) return ErrorCode::BadInstallationId;
    if (suite != kev1::Suite::X25519 && suite != kev1::Suite::P256) return ErrorCode::UnsupportedSuite;
    const bool usable = suite == kev1::Suite::X25519 ? detail::isStrictX25519PublicKey(holderPublicKey)
                                                     : detail::publicKey(suite, holderPublicKey) != nullptr;
    if (!usable) return ErrorCode::BadKey;
    return std::nullopt;
}

}

std::string holderMessage(const KeyStatement& key, const std::string_view installationId, const kev1::Suite suite,
                          const std::span<const uint8_t> holderPublicKey) {
    if (const auto error = holderInputError(installationId, suite, holderPublicKey)) throw Error(*error);
    (void)encode(key);  // a statement parse would accept, so its public id and generation are canonical
    std::string out(kHolderMagic);
    out += "\n" + key.public_id;
    out += "\n" + std::to_string(key.generation);
    out += "\n" + fingerprintText(fingerprint(key));
    out += "\n" + std::string(installationId);
    out += "\n" + std::to_string(static_cast<unsigned>(suite));
    out += "\n" + base64UrlEncode(holderPublicKey);
    return out;
}

Signature signHolderProof(const KeyStatement& key, const RecoverySeed& seed, const std::string_view installationId,
                          const kev1::Suite suite, const std::span<const uint8_t> holderPublicKey) {
    const auto message = holderMessage(key, installationId, suite, holderPublicKey);
    if (!std::ranges::equal(seed.x25519PublicKey(), key.x25519_public) ||
        !std::ranges::equal(seed.ed25519PublicKey(), key.ed25519_public))
        throw std::invalid_argument("the seed is not this statement's key");
    return signBytes(detail::viewBytes(message), seed);
}

void checkHolderProof(const KeyStatement& key, const std::string_view installationId, const kev1::Suite suite,
                      const std::span<const uint8_t> holderPublicKey, const Signature& proof) {
    const auto message = holderMessage(key, installationId, suite, holderPublicKey);
    if (!verifyBytes(key.ed25519_public, detail::viewBytes(message), proof)) throw Error(ErrorCode::BadSignature);
}

bool verifyHolderProof(const KeyStatement& key, const std::string_view installationId, const kev1::Suite suite,
                       const std::span<const uint8_t> holderPublicKey, const Signature& proof) noexcept {
    try {
        checkHolderProof(key, installationId, suite, holderPublicKey, proof);
        return true;
    } catch (...) {
        return false;
    }
}

}
