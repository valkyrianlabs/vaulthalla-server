// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Valkyrian Labs LLC
#include "vl/keykit/recovery_policy.hpp"

#include "openssl.hpp"
#include "sealing.hpp"
#include "text.hpp"
#include "vl/keykit/base64url.hpp"

#include <algorithm>
#include <utility>

namespace vl::keykit::account {

namespace {

constexpr std::string_view kPolicyVersionStem = "vhc-recovery-policy-v";
constexpr std::size_t kHeaderLines = 5;

bool labelOk(const std::string_view label) {
    return detail::isLabel(detail::viewBytes(label), kMaxRecipientLabelSize);
}

PublicKey decodeKey(const std::string_view field) {
    const auto bytes = base64UrlDecode(field);
    if (!bytes) throw Error(ErrorCode::BadBase64Url);
    if (bytes->size() != kPublicKeySize) throw Error(ErrorCode::BadKey);
    PublicKey out{};
    std::ranges::copy(*bytes, out.begin());
    return out;
}

Digest decodeDigest(const std::string_view field) {
    const auto bytes = base64UrlDecode(field);
    if (!bytes) throw Error(ErrorCode::BadBase64Url);
    if (bytes->size() != 32) throw Error(ErrorCode::BadRecipient);
    Digest out{};
    std::ranges::copy(*bytes, out.begin());
    return out;
}

PolicyRecipient parseRecipient(const std::string_view line) {
    const auto fields = detail::splitLines(line, ' ');
    if (fields.size() != 6) throw Error(ErrorCode::BadRecipient);
    const auto rid = decodeDigest(fields[0]);
    PolicyRecipient r;
    r.x25519_public = decodeKey(fields[1]);
    if (!detail::isStrictX25519PublicKey(r.x25519_public)) throw Error(ErrorCode::BadKey);
    if (r.recipientId() != rid) throw Error(ErrorCode::RecipientIdMismatch);
    if (fields[2] != "1") throw Error(ErrorCode::UnsupportedSuite);
    if (fields[3] != "customer") throw Error(ErrorCode::UnsupportedClass);
    const auto label = base64UrlDecode(fields[4]);
    if (!label) throw Error(ErrorCode::BadBase64Url);
    r.label.assign(label->begin(), label->end());
    if (!labelOk(r.label)) throw Error(ErrorCode::BadLabel);
    if (fields[5] != "account") throw Error(ErrorCode::UnsupportedScope);
    return r;
}

std::vector<PolicyRecipient> sortedRecipients(std::vector<PolicyRecipient> recipients) {
    std::ranges::sort(recipients, [](const PolicyRecipient& a, const PolicyRecipient& b) {
        return a.recipientId() < b.recipientId();
    });
    return recipients;
}

}

Digest PolicyRecipient::recipientId() const { return detail::sha256(x25519_public); }

std::string encode(const RecoveryPolicy& p) {
    if (!detail::parseUuid(p.public_id)) throw std::invalid_argument("the account public id is not a canonical UUID");
    if (p.sequence == 0) throw std::invalid_argument("policy sequences start at 1");
    if (p.generation == 0) throw std::invalid_argument("generations start at 1");
    if (!detail::isTimestamp(p.issued_at)) throw std::invalid_argument("issued_at is not YYYY-MM-DDTHH:MM:SSZ");
    if (p.recipients.size() > kMaxPolicyRecipients) throw std::invalid_argument("too many policy recipients");
    const auto recipients = sortedRecipients(p.recipients);
    std::string out = std::string(kPolicyMagic) + "\n" + p.public_id + "\n" + std::to_string(p.sequence) + "\n" +
                      std::to_string(p.generation) + "\n" + p.issued_at;
    for (std::size_t i = 0; i < recipients.size(); ++i) {
        const auto& r = recipients[i];
        if (!detail::isStrictX25519PublicKey(r.x25519_public))
            throw std::invalid_argument("a recipient key is non-canonical or of low order");
        if (!labelOk(r.label)) throw std::invalid_argument("a recipient label is empty, too long or not plain UTF-8");
        const auto rid = r.recipientId();
        if (i > 0 && rid == recipients[i - 1].recipientId())
            throw std::invalid_argument("a recipient is listed twice");
        out += "\n" + base64UrlEncode(rid) + " " + base64UrlEncode(r.x25519_public) + " 1 customer " +
               base64UrlEncode(detail::viewBytes(r.label)) + " account";
    }
    return out;
}

RecoveryPolicy parsePolicy(const std::string_view text) {
    const auto lines = detail::splitLines(text);
    if (lines[0] != kPolicyMagic) {
        if (detail::isOtherVersion(lines[0], kPolicyVersionStem)) throw Error(ErrorCode::UnsupportedVersion);
        throw Error(ErrorCode::BadPolicy);
    }
    if (lines.size() < kHeaderLines) throw Error(ErrorCode::BadPolicy);
    RecoveryPolicy p;
    if (!detail::parseUuid(lines[1])) throw Error(ErrorCode::BadPublicId);
    p.public_id = std::string(lines[1]);
    const auto sequence = detail::parsePositive32(lines[2]);
    if (!sequence) throw Error(ErrorCode::BadSequence);
    p.sequence = *sequence;
    const auto generation = detail::parsePositive32(lines[3]);
    if (!generation) throw Error(ErrorCode::BadGeneration);
    p.generation = *generation;
    if (!detail::isTimestamp(lines[4])) throw Error(ErrorCode::BadIssuedAt);
    p.issued_at = std::string(lines[4]);
    if (lines.size() - kHeaderLines > kMaxPolicyRecipients) throw Error(ErrorCode::TooManyRecipients);
    for (std::size_t i = kHeaderLines; i < lines.size(); ++i) {
        auto r = parseRecipient(lines[i]);
        if (!p.recipients.empty() && !(p.recipients.back().recipientId() < r.recipientId()))
            throw Error(ErrorCode::UnsortedRecipients);
        p.recipients.push_back(std::move(r));
    }
    return p;
}

Digest policyHash(const std::string_view text) { return detail::sha256(detail::viewBytes(text)); }

SignedPolicy signPolicy(const RecoveryPolicy& policy, const RecoverySeed& key, const KeyStatement& current) {
    if (policy.public_id != current.public_id) throw std::invalid_argument("the policy names another account");
    if (policy.generation != current.generation) throw std::invalid_argument("the policy names another generation");
    PublicKey ed{};
    const auto pk = key.ed25519PublicKey();
    if (pk.size() != ed.size()) throw std::invalid_argument("bad Ed25519 public key");
    std::ranges::copy(pk, ed.begin());
    if (ed != current.ed25519_public) throw std::invalid_argument("the seed is not this generation's key");
    SignedPolicy out{.policy = encode(policy)};
    out.signature = signBytes(detail::viewBytes(out.policy), key);
    return out;
}

VerifiedPolicy verifyPolicy(const SignedPolicy& signedPolicy, const KeyStatement& pinned) {
    VerifiedPolicy out{.policy = parsePolicy(signedPolicy.policy), .hash = policyHash(signedPolicy.policy)};
    if (out.policy.public_id != pinned.public_id) throw Error(ErrorCode::AccountMismatch);
    if (out.policy.generation != pinned.generation) throw Error(ErrorCode::GenerationMismatch);
    if (!verifyBytes(pinned.ed25519_public, detail::viewBytes(signedPolicy.policy), signedPolicy.signature))
        throw Error(ErrorCode::BadSignature);
    for (const auto& r : out.policy.recipients)
        if (r.x25519_public == pinned.x25519_public) throw Error(ErrorCode::AccountKeyListed);
    return out;
}

PolicyFloor floorOf(const VerifiedPolicy& policy) noexcept { return {policy.policy.sequence, policy.hash}; }

std::string_view sequenceVerdictName(const SequenceVerdict verdict) {
    switch (verdict) {
        case SequenceVerdict::Newer: return "newer";
        case SequenceVerdict::Unchanged: return "unchanged";
        case SequenceVerdict::Older: return "older";
        case SequenceVerdict::Conflict: return "conflict";
    }
    return "unknown";
}

SequenceVerdict compareToFloor(const VerifiedPolicy& policy, const PolicyFloor& floor) noexcept {
    const auto seq = policy.policy.sequence;
    if (seq > floor.sequence) return SequenceVerdict::Newer;
    if (seq < floor.sequence) return SequenceVerdict::Older;
    return equalConstantTime(policy.hash, floor.hash) ? SequenceVerdict::Unchanged : SequenceVerdict::Conflict;
}

bool isNextSequence(const uint32_t stored, const uint32_t candidate) noexcept {
    return stored < UINT32_MAX && candidate == stored + 1;
}

}
