// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Valkyrian Labs LLC
#include "vl/keykit/kev1.hpp"

#include "sealing.hpp"

#include <algorithm>
#include <utility>

namespace vl::keykit::kev1 {

namespace {

constexpr std::array<std::pair<ErrorCode, std::string_view>, 12> kErrorNames{{
    {ErrorCode::BadMagic, "bad_magic"},
    {ErrorCode::UnsupportedVersion, "unsupported_version"},
    {ErrorCode::UnsupportedSuite, "unsupported_suite"},
    {ErrorCode::BadPurpose, "bad_purpose"},
    {ErrorCode::UnsupportedRecipientClass, "unsupported_recipient_class"},
    {ErrorCode::ReservedNonzero, "reserved_nonzero"},
    {ErrorCode::VaultMismatch, "vault_mismatch"},
    {ErrorCode::RecipientMismatch, "recipient_mismatch"},
    {ErrorCode::BadLength, "bad_length"},
    {ErrorCode::BadEphemeral, "bad_ephemeral"},
    {ErrorCode::WrapAuthFailed, "wrap_auth_failed"},
    {ErrorCode::BadKeyVersion, "bad_key_version"},
}};

constexpr std::string_view kInfo = "vh.kev1.wrap";
constexpr std::size_t kOffVersion = 8, kOffSuite = 10, kOffPurpose = 12, kOffClass = 13, kOffReserved = 14,
                      kOffKeyVersion = 16, kOffVaultUid = 20, kOffRecipient = 36, kOffEpkLen = 68;

using detail::be16;
using detail::be32;
using detail::epkSize;
using detail::knownSuite;
using detail::putBe16;
using detail::putBe32;

// Structural checks shared by inspect() and unwrap(), in the reader's order up to the version.
void checkPrefix(const std::span<const uint8_t> env) {
    if (env.size() < kFixedPrefixSize || !std::equal(kMagic.begin(), kMagic.end(), env.begin()))
        throw Error(ErrorCode::BadMagic);
    if (be16(env.data() + kOffVersion) != kVersion) throw Error(ErrorCode::UnsupportedVersion);
}

}

std::string_view errorCodeName(const ErrorCode code) {
    for (const auto& [c, name] : kErrorNames)
        if (c == code) return name;
    return "unknown";
}

Error::Error(const ErrorCode code)
    : std::runtime_error("KEV1 envelope rejected: " + std::string(errorCodeName(code))), code_(code) {}

bool skippedByRestore(const ErrorCode code) noexcept {
    return code == ErrorCode::BadPurpose || code == ErrorCode::UnsupportedRecipientClass ||
           code == ErrorCode::RecipientMismatch;
}

Digest recipientId(const std::span<const uint8_t> publicKey) { return detail::sha256(publicKey); }

std::vector<uint8_t> publicKeyOf(const Suite suite, const std::span<const uint8_t> secretKey) {
    if (suite == Suite::P256) return detail::p256Point(secretKey);
    if (secretKey.size() != kX25519KeySize) throw std::invalid_argument("an X25519 secret key is 32 bytes");
    const auto pk = detail::rawPublicKey(EVP_PKEY_X25519, secretKey);
    return {pk.begin(), pk.end()};
}

std::vector<uint8_t> wrap(const std::span<const uint8_t> vaultKey, const Suite suite, const uint32_t keyVersion,
                          const VaultUid& vaultUid, const std::span<const uint8_t> recipientPublicKey,
                          const std::span<const uint8_t> ephemeralSecretForTesting) {
    if (vaultKey.size() != kVaultKeySize) throw std::invalid_argument("a KEV1 vault key is 32 bytes");
    if (keyVersion == 0) throw std::invalid_argument("KEV1 key versions start at 1");
    if (!knownSuite(static_cast<uint16_t>(suite))) throw std::invalid_argument("unknown KEV1 suite");
    const auto peer = detail::publicKey(suite, recipientPublicKey);
    if (!peer) throw std::invalid_argument("the recipient public key is not a valid key for its suite");

    const auto esk = detail::ephemeralSecret(suite, ephemeralSecretForTesting);
    const auto mine = detail::secretKey(suite, esk.bytes());
    if (!mine) throw std::invalid_argument("the ephemeral secret key is not valid for its suite");
    const auto epk = publicKeyOf(suite, esk.bytes());
    const auto z = detail::agree(mine.get(), peer.get());
    if (!z) throw Error(ErrorCode::BadEphemeral);

    std::vector<uint8_t> env(kMagic.begin(), kMagic.end());
    putBe16(env, kVersion);
    putBe16(env, static_cast<uint16_t>(suite));
    env.push_back(kPurposeVaultKey);
    env.push_back(kClassCustomer);
    putBe16(env, 0);
    putBe32(env, keyVersion);
    env.insert(env.end(), vaultUid.begin(), vaultUid.end());
    const auto rid = recipientId(recipientPublicKey);
    env.insert(env.end(), rid.begin(), rid.end());
    putBe16(env, static_cast<uint16_t>(epk.size()));
    env.insert(env.end(), epk.begin(), epk.end());

    const auto kWrap = detail::deriveKey(z->bytes(), epk, recipientPublicKey, kInfo, env);
    const auto wrapped = detail::aeadSeal(kWrap.bytes(), vaultKey, env);
    env.insert(env.end(), wrapped.begin(), wrapped.end());
    return env;
}

Header inspect(const std::span<const uint8_t> env) {
    checkPrefix(env);
    Header h;
    h.suite = be16(env.data() + kOffSuite);
    if (!knownSuite(h.suite)) throw Error(ErrorCode::UnsupportedSuite);
    h.purpose = env[kOffPurpose];
    if (h.purpose != kPurposeVaultKey) throw Error(ErrorCode::BadPurpose);
    h.recipient_class = env[kOffClass];
    if (h.recipient_class != kClassCustomer) throw Error(ErrorCode::UnsupportedRecipientClass);
    if (env[kOffReserved] != 0 || env[kOffReserved + 1] != 0) throw Error(ErrorCode::ReservedNonzero);
    h.key_version = be32(env.data() + kOffKeyVersion);
    std::copy_n(env.begin() + kOffVaultUid, h.vault_uid.size(), h.vault_uid.begin());
    std::copy_n(env.begin() + kOffRecipient, h.recipient_id.size(), h.recipient_id.begin());
    const auto epkLen = be16(env.data() + kOffEpkLen);
    if (epkLen != epkSize(static_cast<Suite>(h.suite)) || env.size() != kFixedPrefixSize + epkLen + kWrappedSize)
        throw Error(ErrorCode::BadLength);
    return h;
}

Unwrapped unwrap(const std::span<const uint8_t> env, const std::span<const uint8_t> recipientSecretKey,
                 const Suite expectedSuite, const VaultUid& vaultUid) {
    checkPrefix(env);
    const auto suite = be16(env.data() + kOffSuite);
    if (suite != static_cast<uint16_t>(expectedSuite) || !knownSuite(suite)) throw Error(ErrorCode::UnsupportedSuite);
    if (env[kOffPurpose] != kPurposeVaultKey) throw Error(ErrorCode::BadPurpose);
    if (env[kOffClass] != kClassCustomer) throw Error(ErrorCode::UnsupportedRecipientClass);
    if (env[kOffReserved] != 0 || env[kOffReserved + 1] != 0) throw Error(ErrorCode::ReservedNonzero);
    const auto keyVersion = be32(env.data() + kOffKeyVersion);
    if (!equalConstantTime(env.subspan(kOffVaultUid, vaultUid.size()), vaultUid)) throw Error(ErrorCode::VaultMismatch);

    std::vector<uint8_t> rpk;
    try {
        rpk = publicKeyOf(expectedSuite, recipientSecretKey);
    } catch (const std::invalid_argument&) {
        throw Error(ErrorCode::RecipientMismatch);  // not a key of this suite: it can't be the recipient
    }
    const auto rid = recipientId(rpk);
    if (!equalConstantTime(env.subspan(kOffRecipient, rid.size()), rid)) throw Error(ErrorCode::RecipientMismatch);

    const auto epkLen = be16(env.data() + kOffEpkLen);
    if (epkLen != epkSize(expectedSuite) || env.size() != kFixedPrefixSize + epkLen + kWrappedSize)
        throw Error(ErrorCode::BadLength);
    const auto prefix = env.first(kFixedPrefixSize + epkLen);
    const auto epk = env.subspan(kFixedPrefixSize, epkLen);

    const auto mine = detail::secretKey(expectedSuite, recipientSecretKey);
    const auto peer = detail::publicKey(expectedSuite, epk);
    if (!peer) throw Error(ErrorCode::BadEphemeral);
    const auto z = detail::agree(mine.get(), peer.get());
    if (!z) throw Error(ErrorCode::BadEphemeral);
    const auto kWrap = detail::deriveKey(z->bytes(), epk, rpk, kInfo, prefix);
    auto key = detail::aeadOpen(kWrap.bytes(), env.subspan(kFixedPrefixSize + epkLen), prefix);
    if (!key) throw Error(ErrorCode::WrapAuthFailed);
    if (keyVersion == 0) throw Error(ErrorCode::BadKeyVersion);
    return {keyVersion, std::move(*key)};
}

std::string kid(const std::span<const uint8_t> envelope) {
    const auto digest = detail::sha256(envelope);
    Uid head{};
    std::copy_n(digest.begin(), head.size(), head.begin());
    return toBase32(head);
}

std::string objectKey(const std::string_view kid) { return std::string(kObjectPrefix) + std::string(kid); }

}
