// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Valkyrian Labs LLC
#include "text.hpp"

#include "vl/keykit/base64url.hpp"

#include <array>
#include <string>

namespace vl::keykit {

namespace {

constexpr std::string_view kUrlAlphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_";

int urlValue(const char c) {
    if (c >= 'A' && c <= 'Z') return c - 'A';
    if (c >= 'a' && c <= 'z') return c - 'a' + 26;
    if (c >= '0' && c <= '9') return c - '0' + 52;
    if (c == '-') return 62;
    if (c == '_') return 63;
    return -1;
}

int hexValue(const char c) {
    if (c >= '0' && c <= '9') return c - '0';
    if (c >= 'a' && c <= 'f') return c - 'a' + 10;
    return -1;
}

bool isDigit(const char c) { return c >= '0' && c <= '9'; }

}

std::string base64UrlEncode(const std::span<const uint8_t> bytes) {
    std::string out;
    out.reserve((bytes.size() * 4 + 2) / 3);
    std::size_t i = 0;
    for (; i + 3 <= bytes.size(); i += 3) {
        const uint32_t v = static_cast<uint32_t>(bytes[i]) << 16 | static_cast<uint32_t>(bytes[i + 1]) << 8 | bytes[i + 2];
        for (int s = 18; s >= 0; s -= 6) out.push_back(kUrlAlphabet[v >> s & 63]);
    }
    const std::size_t rest = bytes.size() - i;
    if (rest == 1) {
        const uint32_t v = static_cast<uint32_t>(bytes[i]) << 16;
        out.push_back(kUrlAlphabet[v >> 18 & 63]);
        out.push_back(kUrlAlphabet[v >> 12 & 63]);
    } else if (rest == 2) {
        const uint32_t v = static_cast<uint32_t>(bytes[i]) << 16 | static_cast<uint32_t>(bytes[i + 1]) << 8;
        out.push_back(kUrlAlphabet[v >> 18 & 63]);
        out.push_back(kUrlAlphabet[v >> 12 & 63]);
        out.push_back(kUrlAlphabet[v >> 6 & 63]);
    }
    return out;
}

std::optional<std::vector<uint8_t>> base64UrlDecode(const std::string_view text) {
    if (text.size() % 4 == 1) return std::nullopt;
    std::vector<uint8_t> out;
    out.reserve(text.size() * 3 / 4);
    uint32_t acc = 0;
    int bits = 0;
    for (const char c : text) {
        const int v = urlValue(c);
        if (v < 0) return std::nullopt;
        acc = (acc << 6 | static_cast<uint32_t>(v)) & 0xffffff;
        bits += 6;
        if (bits >= 8) {
            bits -= 8;
            out.push_back(static_cast<uint8_t>(acc >> bits));
        }
    }
    if (bits > 0 && (acc & ((1u << bits) - 1)) != 0) return std::nullopt;  // non-zero trailing bits
    return out;
}

namespace detail {

std::vector<std::string_view> splitLines(const std::string_view text, const char separator) {
    std::vector<std::string_view> out;
    std::size_t start = 0;
    for (;;) {
        const auto end = text.find(separator, start);
        if (end == std::string_view::npos) {
            out.push_back(text.substr(start));
            return out;
        }
        out.push_back(text.substr(start, end - start));
        start = end + 1;
    }
}

bool isOtherVersion(const std::string_view line, const std::string_view stem) {
    if (!line.starts_with(stem) || line.size() == stem.size()) return false;
    for (const char c : line.substr(stem.size()))
        if (!isDigit(c)) return false;
    return true;
}

std::optional<uint32_t> parsePositive32(const std::string_view text) {
    if (text.empty() || text.size() > 10 || text[0] == '0') return std::nullopt;
    uint64_t v = 0;
    for (const char c : text) {
        if (!isDigit(c)) return std::nullopt;
        v = v * 10 + static_cast<uint64_t>(c - '0');
    }
    if (v > UINT32_MAX) return std::nullopt;
    return static_cast<uint32_t>(v);
}

std::optional<std::array<uint8_t, 16>> parseUuid(const std::string_view text) {
    if (text.size() != 36) return std::nullopt;
    std::array<uint8_t, 16> out{};
    std::size_t n = 0;
    for (std::size_t i = 0; i < text.size();) {
        if (i == 8 || i == 13 || i == 18 || i == 23) {
            if (text[i] != '-') return std::nullopt;
            ++i;
            continue;
        }
        const int hi = hexValue(text[i]), lo = hexValue(text[i + 1]);
        if (hi < 0 || lo < 0) return std::nullopt;
        out[n++] = static_cast<uint8_t>(hi << 4 | lo);
        i += 2;
    }
    return out;
}

bool isTimestamp(const std::string_view t) {
    if (t.size() != 20 || t[4] != '-' || t[7] != '-' || t[10] != 'T' || t[13] != ':' || t[16] != ':' || t[19] != 'Z')
        return false;
    const auto num = [&](const std::size_t at, const std::size_t len, int& out) {
        out = 0;
        for (std::size_t i = at; i < at + len; ++i) {
            if (!isDigit(t[i])) return false;
            out = out * 10 + (t[i] - '0');
        }
        return true;
    };
    int y = 0, mo = 0, d = 0, h = 0, mi = 0, s = 0;
    if (!num(0, 4, y) || !num(5, 2, mo) || !num(8, 2, d) || !num(11, 2, h) || !num(14, 2, mi) || !num(17, 2, s))
        return false;
    if (y < 2000 || mo < 1 || mo > 12 || d < 1 || h > 23 || mi > 59 || s > 59) return false;
    static constexpr std::array<int, 12> kDays{31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
    const bool leap = (y % 4 == 0 && y % 100 != 0) || y % 400 == 0;
    const int days = kDays[static_cast<std::size_t>(mo - 1)] + (mo == 2 && leap ? 1 : 0);
    return d <= days;
}

bool isLabel(const std::span<const uint8_t> b, const std::size_t maxBytes) {
    if (b.empty() || b.size() > maxBytes) return false;
    for (std::size_t i = 0; i < b.size();) {
        const uint8_t c = b[i];
        uint32_t cp = 0;
        std::size_t len = 0;
        if (c < 0x80) {
            cp = c;
            len = 1;
        } else if (c >= 0xc2 && c <= 0xdf) {
            cp = c & 0x1fu;
            len = 2;
        } else if (c >= 0xe0 && c <= 0xef) {
            cp = c & 0x0fu;
            len = 3;
        } else if (c >= 0xf0 && c <= 0xf4) {
            cp = c & 0x07u;
            len = 4;
        } else {
            return false;
        }
        if (i + len > b.size()) return false;
        for (std::size_t k = 1; k < len; ++k) {
            if ((b[i + k] & 0xc0) != 0x80) return false;
            cp = cp << 6 | (b[i + k] & 0x3fu);
        }
        if ((len == 3 && cp < 0x800) || (len == 4 && (cp < 0x10000 || cp > 0x10ffff))) return false;  // overlong
        if (cp >= 0xd800 && cp <= 0xdfff) return false;                                                  // surrogate
        if (cp < 0x20 || (cp >= 0x7f && cp <= 0x9f)) return false;                                       // control
        i += len;
    }
    return true;
}

}

}
