// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Valkyrian Labs LLC
#pragma once

// Private strict text helpers for the line formats (key statement, recovery policy) and the sealed formats' contexts.
// Not installed.

#include <array>
#include <cstdint>
#include <optional>
#include <span>
#include <string_view>
#include <vector>

namespace vl::keykit::detail {

// Splits on '\n' exactly: "a\nb" is two lines, "a\n" is "a" and "".
[[nodiscard]] std::vector<std::string_view> splitLines(std::string_view text, char separator = '\n');

// Whether `line` is `stem` followed by one or more ASCII digits (another version of a line format).
[[nodiscard]] bool isOtherVersion(std::string_view line, std::string_view stem);

// A canonical decimal in [1, 2^32 - 1]: ASCII digits only, no sign, no leading zero.
[[nodiscard]] std::optional<uint32_t> parsePositive32(std::string_view text);

// A UUID in its canonical text form: 36 characters, 8-4-4-4-12 lower-case hex digits. Its 16 bytes, or nullopt.
[[nodiscard]] std::optional<std::array<uint8_t, 16>> parseUuid(std::string_view text);

// UTC "YYYY-MM-DDTHH:MM:SSZ": year 2000-9999, a real calendar day (Gregorian leap years), no leap second.
[[nodiscard]] bool isTimestamp(std::string_view text);

// A display label: 1 to `maxBytes` bytes of well-formed UTF-8 (no overlong forms, surrogates or code points above
// U+10FFFF) without control characters (U+0000-U+001F, U+007F-U+009F).
[[nodiscard]] bool isLabel(std::span<const uint8_t> bytes, std::size_t maxBytes);

}
