# vl-keykit

Vaulthalla's key-recovery formats for C++23, in one library shared by Vaulthalla Server and Vaulthalla Cloud so the
formats cannot drift:

- **KEV1 key envelopes** (`vl/keykit/kev1.hpp`): one vault key version wrapped to one recipient public key, X25519 or
  P-256 ECDH + HKDF-SHA-256 + AES-256-GCM. Writer, reader with ordered error codes, and a keyless `inspect` for
  services that store envelopes they cannot open. Reserved purposes and recipient classes are refused and reported
  as skippable, so later recipient types fit without a format change.
- **Recovery seed** (`vl/keykit/seed.hpp`): 16 random bytes, 27-symbol Crockford base32 text with a check symbol,
  and the X25519 recovery recipient and Ed25519 signing key derived from it.
- **Recovery kit** (`vl/keykit/kit.hpp`): the `vh.recovery-kit` JSON document (seed, vault uids, pinned attestation
  public keys, checkpoints).
- **Uids** (`vl/keykit/uid.hpp`): 16-byte vault and object uids and their strict base32 form.
- **SecretBytes** (`vl/keykit/secret.hpp`): locked, wiped, move-only memory for every secret the library returns.

And the Vaulthalla Cloud account recovery key, shared by vaulthalla-cloud, vaulthalla-server and Vaulthalla Desktop:

- **Account key statement** (`vl/keykit/account_key.hpp`): the signed `vhc-account-key-v1` statement of each key
  generation, its fingerprint, the chain check across generations (rotations signed by both, replacements) and
  following a server's pin.
- **Recovery policy** (`vl/keykit/recovery_policy.hpp`): the account-signed `vhc-recovery-policy-v1` document,
  verified against a pinned account key, and the sequence rules (the caller keeps the floor).
- **KAK1** (`vl/keykit/kak1.hpp`): the account key wrapped to a holder's X25519 or P-256 key (Secure Enclave keys
  through an agreement callback).
- **Vault labels** (`vl/keykit/vault_label.hpp`): a vault's name sealed to the account key, padded to 128 bytes.
- **Sealed storage credentials** (`vl/keykit/storage_credential.hpp`): a managed bucket's key secret sealed to a
  server's one-time X25519 key, bound to the installation, vault and key id.
- **Holder proof** (`vl/keykit/holder_proof.hpp`): the account key's signature over a Desktop's installation and holder
  key (`vhc-account-key-holder-v1`), presented to register as a holder.
- **Comparison codes** (`vl/keykit/key_codes.hpp`): the request, transfer and restore codes two screens show.
- **base64url** (`vl/keykit/base64url.hpp`): strict unpadded base64url.

And for Swift: a **C API** (`vl/keykit/vl_keykit.h`, plain C11) over what a Desktop does with the account key and
with a managed bucket's sealed storage credential (the one-time key, opening, reading the secret into its own buffer), with
opaque wiped handles for secrets, caller buffers and stable status codes; `scripts/build-xcframework.sh` packages it as
`VLKeykit.xcframework` (macOS, static, OpenSSL linked in) for `import VLKeykit`:

```bash
scripts/build-xcframework.sh     # build-apple/VLKeykit.xcframework (arm64, plus x86_64 where an x86_64 libcrypto.a exists)
tests/apple/run.sh               # builds it and runs a Swift package that imports it
```

Specification: Vaulthalla `design/encryption/03-metadata-recovery.md` §5 for KEV1, the seed and the kit; the format
headers in `include/vl/keykit/` for the cloud formats. Golden vectors: `vectors/` (`vectors.json`, a copy of
vaulthalla-server's; `vhc.json`, this repository's own), shared with vaulthalla-server, vaulthalla-cloud and
Vaulthalla Desktop.

Dependencies: OpenSSL 3 (libcrypto) and nlohmann_json; GoogleTest for the tests.

```bash
meson setup build -Db_sanitize=address,undefined && meson compile -C build && meson test -C build --print-errorlogs
```

Consume it as a meson subproject (`dependency('vl-keykit', fallback: ['vl-keykit', 'vl_keykit_dep'])`) or through
pkg-config (`vl-keykit`).

© 2026 Valkyrian Labs LLC. MIT License (see `LICENSE`).
