# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (c) 2026 Valkyrian Labs LLC
# One C translation unit (c_header_check.c) proves the C API's header is valid C.
add_languages('c', native: false, required: true)

test_sources = files(
  'c_header_check.c',
  'test_c_api.cpp',
  'test_manifest.cpp',
  'test_manifest_interleavings.cpp',
  'test_manifest_reconcile.cpp',
  'test_object_keys.cpp',
  'test_vhf1.cpp',
)

vl_vaultfmt_tests = executable('vl-vaultfmt-tests', test_sources,
  dependencies: [vl_vaultfmt_dep, gtest_dep],
  cpp_args: ['-DVL_VAULTFMT_VECTORS_DIR="' + meson.project_source_root() / 'vectors' + '"'],
  build_by_default: true,
  install: false,
  override_options: ['c_std=c11'],
)

# The interleavings suites enumerate tens of thousands of schedules.
test('vl-vaultfmt', vl_vaultfmt_tests, timeout: 900)

python = find_program('python3', required: false)
if python.found()
  # The independent Python reference: regenerates the vectors, compares them with vectors.json byte for byte, and
  # runs its own reader over every vector. Skipped (exit 77) where the `cryptography` package is missing.
  test('vectors-reference', python,
    args: ['-c', '''
import importlib.util, subprocess, sys
if importlib.util.find_spec("cryptography") is None:
    sys.exit(77)
sys.exit(subprocess.call([sys.executable, sys.argv[1], "--check"]))
''', meson.project_source_root() / 'vectors' / 'vh_crypto_vectors.py'],
  )

  # The vectors, the reference and the C++ suites mean the same thing (tests/vectors_contract.py).
  test('vectors-contract', python, args: [meson.current_source_dir() / 'vectors_contract.py'])
endif
