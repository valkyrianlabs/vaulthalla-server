# Changelog

All notable changes to vl-vaultfmt are recorded here. The format follows [Keep a Changelog](https://keepachangelog.com/),
and versions follow [Semantic Versioning](https://semver.org/) (before 1.0, a minor version may break the API).

## [Unreleased]

## [0.1.0]

### Added

- First version, extracted from vaulthalla-server 1.22.2 (main at fc636330: `core/{include,src}/crypto/vhf1/`,
  `sync/manifest/`, `storage/ObjectKeys`, `core/tests/fuzz/`, `core/tests/helpers/{memory,hooked}_store.hpp`).
  Byte-compatible with it: every `vhf1` and `manifest` golden vector is reproduced, and the server links this library
  in place of its own copy.
  - `vhf1`: the header codec, key schedule, size math, `Writer`, `open`, `ChunkWalker`, `RangeReader`, `Key`, the
    chunk AEAD and the ordered `ErrorCode`s.
  - `keys`: `contentKey`, `uidOfContentKey`, `classify`, `isAllowedKey`, `isAllowedListPrefix`, `importedPathOf`,
    `partSizeFor`, `partCountFor`.
  - `manifest`: documents, content, partitioning, objects, chain rules, the version log, the reader (fallbacks, base
    copy, blind rebuild, restore freshness), the publisher (conditional and version_log, GC, janitor, writers),
    reconcile, the `Session` decision logic over `StateStore`, and the `ObjectStore` seam with `WriteCapability`.
  - `testing/`: the in-memory versioned store and the hooking store, header-only.
- The C API (`vl/vaultfmt/vl_vaultfmt.h`): keyring, object keys, streamed VHF1 sealing and opening, ranged reads, a
  manifest root opened from bytes with the chain rules against a known state, and the tree built from its pinned
  objects (entries, lookup, children, JSON). Status blocks 0-7, 100 + `vhf1::ErrorCode`, 200-202 (document errors),
  300 + `manifest::ChainError`. Tested against the vectors and from C (`tests/c_header_check.c`).
- `vectors/`: a verbatim copy of vaulthalla-server's golden vectors and their Python reference, checked by
  `meson test` (`vectors-reference`, `vectors-contract`).
- The libFuzzer target `fuzz_vhf1` (`-Dfuzz=true`).

### Changed (from the vaulthalla-server code)

- Namespaces `vh::crypto::vhf1` → `vl::vaultfmt::vhf1`, `vh::sync::manifest` → `vl::vaultfmt::manifest`,
  `vh::storage::object_keys` → `vl::vaultfmt::keys`, `vh::test_support::manifest_store` → `vl::vaultfmt::test_support`;
  headers under `<vl/vaultfmt/...>`. No behaviour change.
- `publish` (version_log) keeps the base's index in the root listing as an index and a flag instead of a
  `std::optional<std::size_t>`, which GCC 14 at -O2 and above reported maybe-uninitialized once the library built as one
  unit. No behaviour change.
