# vl-vaultfmt

Vaulthalla's vault format (VHF1 files, the object keys of an opaque_v1 bucket, the encrypted manifest with its publish,
read, reconcile and session logic) for C++23, extracted from vaulthalla-server and shared by vaulthalla-server, the
Desktop-only engine (through the C API) and the portal's WebAssembly reader. Owner: **Valkyrian Labs LLC**. License:
**AGPL-3.0-or-later** (`Copyright (c) 2026 Valkyrian Labs LLC`). Repository: `valkyrianlabs/vl-vaultfmt` (private).
Design: vaulthalla-server `design/core/vault-format-library.md`.

## Map

| Path | What |
| --- | --- |
| `include/vl/vaultfmt/` | public headers: `vhf1/` (`Format`, `Reader`, `Writer`, `Key`, `Aead`), `ObjectKeys`, `manifest/` (`Document`, `Content`, `Partition`, `Objects`, `Chain`, `VersionLog`, `Reader`, `Publisher`, `Reconcile`, `Session`, `Store`, `WriteCapability`), `Fwd`, umbrella `vaultfmt.hpp`; `vl_vaultfmt.h`: the C API (plain C11); `testing/`: header-only test doubles (`memory_store`, `hooked_store`) |
| `src/` | implementation; `c_api.cpp` (the C API over the C++ one) |
| `tests/` | GoogleTest suite: `test_vhf1` and `test_manifest` against `vectors/vectors.json`, `test_manifest_reconcile`, `test_manifest_interleavings` (the version_log protocol under every interleaving and fault, on the in-memory store), `test_object_keys`, `test_c_api` and `c_header_check.c` (compiled as C); `vectors_contract.py` |
| `fuzz/` | the libFuzzer target `fuzz_vhf1` (`-Dfuzz=true`, clang) |
| `vectors/` | `vectors.json` and `vh_crypto_vectors.py`: verbatim copy of vaulthalla-server `design/encryption/vectors/` |
| `subprojects/` | `vl-keykit.wrap` with its release tarball (and the 0.2.0 unity patch) for standalone builds |
| `ci/` | `run-ci` (verbatim from vaulthalla-server), `Containerfile` |

## Commands

```bash
meson setup build -Db_sanitize=address,undefined && meson compile -C build && meson test -C build --print-errorlogs
# macOS: PKG_CONFIG_PATH=$(brew --prefix openssl@3)/lib/pkgconfig:/opt/homebrew/lib/pkgconfig:/opt/homebrew/share/pkgconfig meson setup build-mac
CI_CACHE_NAMES=ccache ./ci/run-ci meson test -C build   # the CI container (Podman); run it on `ssh dev`
CXX=clang++-18 meson setup build-fuzz -Dfuzz=true -Db_sanitize=address,undefined -Db_lundef=false && meson compile -C build-fuzz
```

## Rules

- **Licensing.** AGPL-3.0-or-later. Every source file (C++, meson, scripts, workflows) starts with
  `// SPDX-License-Identifier: AGPL-3.0-or-later` (or `#`) and `Copyright (c) 2026 Valkyrian Labs LLC`; `vectors/` is a
  verbatim copy and keeps the upstream bytes. The LLC owns all of it and uses it in its closed products by that
  ownership, so an outside contribution needs a copyright assignment or contributor agreement. Never import
  third-party code.
- **Scope.** Namespace `vl::vaultfmt` (`vhf1`, `keys`, `manifest`, `test_support`, `capi`). Dependencies: OpenSSL 3,
  nlohmann_json and vl-keykit only. No libsodium, fmt, Boost, logging, database, HTTP client or POSIX I/O: time, sleep,
  alerts and storage reach the library through its parameters and interfaces (`PublishOptions`, `SessionHost`,
  `StateStore`, `ObjectStore`). The only global is the test chunk-wipe observer.
- **Formats are frozen by the vectors.** Output must stay byte-for-byte equal to `vectors/vectors.json`. Decision 2 of
  the design: a VHF1 or manifest format change lands here with its vectors (and vaulthalla-server's spec) in one
  change, then every consumer's identical-copy test (vaulthalla-server, vl-keykit, Desktop) takes the new copy. Never
  edit an expected vector to get green.
- **Readers ignore unknown members; writers rebuild from typed structs.** An older writer republishing drops a newer
  writer's members: a member a second kind of writer needs comes with the writer floor (design, decision 7).
- **Secrets.** Keys are `vhf1::Key` (locked, wiped); plaintext buffers are `SecureBytes`; temporaries are wiped on
  every path; comparisons of secret-dependent bytes are constant time. Never log or put a secret in an exception.
- **The C API is stable.** `vl_vaultfmt.h` is plain C: no C++ type, exception or allocation crosses it. Status values
  are never renumbered or reused (100 + `vhf1::ErrorCode`, 300 + `manifest::ChainError`: new C++ codes are only
  appended, and the header and `kStatusNames` gain them in the same change; `test_c_api.cpp` checks every name). Keys
  stay in the keyring; plaintext leaves only through a sink after its chunk authenticated.
- **Builds are silent.** Zero warnings on GCC 14 and clang at `warning_level=3`, unity on (one unit) and off; fix
  causes, never suppress.
- **Tests with every change**, positive vectors and the negative path; the suite passes under ASan/UBSan.
- **Git.** Changes land on `main` through PRs and CI. Tags and releases (`vX.Y.Z`, the tarball consumers pin) only
  with Cooper's go-ahead. Keep `ci/run-ci` identical to vaulthalla-server's.
