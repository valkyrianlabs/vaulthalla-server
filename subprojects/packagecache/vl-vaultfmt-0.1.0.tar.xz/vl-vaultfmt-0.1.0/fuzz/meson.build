# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (c) 2026 Valkyrian Labs LLC
# libFuzzer target for the VHF1 header parser and chunk walker (vaulthalla-server design/encryption/
# 02-authenticated-file-format.md §7): clang only, -Dfuzz=true, normally with -Db_sanitize=address,undefined.
#   CXX=clang++-18 meson setup build-fuzz -Dfuzz=true -Db_sanitize=address,undefined -Db_lundef=false
#   meson compile -C build-fuzz && build-fuzz/fuzz/fuzz_vhf1 -max_total_time=600 <corpus dir>
# The unit tests replay the same iteration (fuzz::runOne) over the vectors on every build (test_vhf1.cpp).
executable('fuzz_vhf1', 'fuzz_vhf1.cpp',
  dependencies: vl_vaultfmt_dep,
  cpp_args: ['-fsanitize=fuzzer-no-link'],
  link_args: ['-fsanitize=fuzzer'],
  install: false,
)
