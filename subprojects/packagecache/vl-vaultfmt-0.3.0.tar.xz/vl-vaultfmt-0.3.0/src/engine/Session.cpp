// SPDX-License-Identifier: AGPL-3.0-or-later
// Copyright (c) 2026 Valkyrian Labs LLC
#include "vl/vaultfmt/engine/Session.hpp"

#include "vl/vaultfmt/ObjectKeys.hpp"
#include "vl/vaultfmt/manifest/Objects.hpp"
#include "vl/vaultfmt/manifest/Publisher.hpp"
#include "vl/vaultfmt/vhf1/Reader.hpp"

#include <vl/keykit/kev1.hpp>
#include <vl/keykit/secret.hpp>
#include <vl/keykit/uid.hpp>

#include <nlohmann/json.hpp>

#include <openssl/evp.h>

#include <algorithm>
#include <atomic>
#include <format>
#include <map>
#include <set>
#include <utility>

namespace vl::vaultfmt::engine {

namespace mf = manifest;

std::string_view to_string(const Refusal refusal) {
    switch (refusal) {
    case Refusal::NotFound: return "not_found";
    case Refusal::NotADirectory: return "not_a_directory";
    case Refusal::NameExists: return "name_exists";
    case Refusal::InvalidName: return "invalid_name";
    case Refusal::InvalidMove: return "invalid_move";
    case Refusal::KeyNotAdded: return "key_not_added";
    case Refusal::RecipientRequired: return "recipient_required";
    case Refusal::KeyMismatch: return "key_mismatch";
    case Refusal::KeyVersion: return "key_version";
    case Refusal::BadEnvelope: return "bad_envelope";
    case Refusal::NoVault: return "no_vault";
    case Refusal::Busy: return "busy";
    }
    return "unknown";
}

namespace engine_detail {

constexpr uint64_t kReadPiece = 4ull << 20;
constexpr std::size_t kMaxName = 255;

bool live(const Entry& e) { return e.kind != mf::EntryKind::Tombstone && !e.trashed; }

const Entry* find(const mf::Content& c, const std::string& uid) {
    const auto it = std::ranges::lower_bound(c.entries, uid, {}, &Entry::uid);
    return it != c.entries.end() && it->uid == uid ? &*it : nullptr;
}

std::string hex(std::span<const uint8_t> bytes) {
    static constexpr char kDigits[] = "0123456789abcdef";
    std::string out;
    out.reserve(bytes.size() * 2);
    for (const auto b : bytes) {
        out += kDigits[b >> 4];
        out += kDigits[b & 0xf];
    }
    return out;
}

std::optional<vhf1::Salt> saltOf(const std::optional<std::string>& text) {
    if (!text || text->size() != 2 * vhf1::kSaltSize) return std::nullopt;
    vhf1::Salt s{};
    for (std::size_t i = 0; i < s.size(); ++i) {
        const auto nibble = [](const char c) -> int {
            if (c >= '0' && c <= '9') return c - '0';
            if (c >= 'a' && c <= 'f') return c - 'a' + 10;
            return -1;
        };
        const int hi = nibble((*text)[2 * i]), lo = nibble((*text)[2 * i + 1]);
        if (hi < 0 || lo < 0) return std::nullopt;
        s[i] = static_cast<uint8_t>(hi << 4 | lo);
    }
    return s;
}

void checkName(const std::string& name) {
    const bool bad = name.empty() || name == "." || name == ".." || name.size() > kMaxName ||
                     name.find('/') != std::string::npos || name.find('\0') != std::string::npos;
    if (bad) throw Refused(Refusal::InvalidName, "a name must be 1 to 255 bytes, not . or .., without / or NUL");
    try {
        (void)mf::canonicalJson(nlohmann::json(name));   // UTF-8, as every document must be
    } catch (const std::exception&) {
        throw Refused(Refusal::InvalidName, "a name must be UTF-8");
    }
}

const Entry& requireEntry(const mf::Content& c, const std::string& uid) {
    const auto* e = find(c, uid);
    if (!e) throw Refused(Refusal::NotFound, "no entry " + uid);
    return *e;
}

const Entry& requireLive(const mf::Content& c, const std::string& uid) {
    const auto& e = requireEntry(c, uid);
    if (!live(e)) throw Refused(Refusal::NotFound, "entry " + uid + " is not live");
    return e;
}

const Entry& requireDir(const mf::Content& c, const std::string& uid) {
    const auto* e = find(c, uid);
    if (!e) throw Refused(Refusal::NotFound, "no directory " + uid);
    if (!live(*e) || e->kind != mf::EntryKind::Dir) throw Refused(Refusal::NotADirectory, uid + " is not a directory");
    return *e;
}

void requireFree(const mf::Content& c, const std::string& parent, const std::string& name,
                 const std::optional<std::string>& except = std::nullopt) {
    for (const auto& e : c.entries)
        if (live(e) && e.parent == parent && e.name == name && e.uid != except)
            throw Refused(Refusal::NameExists, "the folder already holds an entry of that name");
}

// "/a/b/name" (the trash's `path`).
std::string pathOf(const mf::Content& c, const Entry& e) {
    std::vector<std::string> parts{e.name};
    std::set<std::string> seen;
    for (auto p = e.parent; p && seen.insert(*p).second;) {
        const auto* d = find(c, *p);
        if (!d || !d->parent) break;
        parts.push_back(d->name);
        p = d->parent;
    }
    std::string out;
    for (auto it = parts.rbegin(); it != parts.rend(); ++it) out += "/" + *it;
    return out;
}

// Whether `ancestor` is `uid` or above it.
bool within(const mf::Content& c, const std::string& ancestor, const std::string& uid) {
    std::set<std::string> seen;
    for (std::optional<std::string> at = uid; at && seen.insert(*at).second;) {
        if (*at == ancestor) return true;
        const auto* e = find(c, *at);
        if (!e) return false;
        at = e->parent;
    }
    return false;
}

// `uid` and every entry below it, live ones only, parents before children.
std::vector<const Entry*> subtree(const mf::Content& c, const std::string& uid) {
    std::vector<const Entry*> out{&requireEntry(c, uid)};
    for (std::size_t i = 0; i < out.size(); ++i) {
        if (out[i]->kind != mf::EntryKind::Dir) continue;
        for (const auto& e : c.entries)
            if (live(e) && e.parent == out[i]->uid) out.push_back(&e);
    }
    return out;
}

struct Sha256 {
    EVP_MD_CTX* ctx{EVP_MD_CTX_new()};
    Sha256() {
        if (!ctx || EVP_DigestInit_ex(ctx, EVP_sha256(), nullptr) != 1) throw std::runtime_error("SHA-256 failed");
    }
    ~Sha256() { EVP_MD_CTX_free(ctx); }
    Sha256(const Sha256&) = delete;
    Sha256& operator=(const Sha256&) = delete;
    void update(std::span<const uint8_t> b) {
        if (EVP_DigestUpdate(ctx, b.data(), b.size()) != 1) throw std::runtime_error("SHA-256 failed");
    }
    std::string finish() {
        std::array<uint8_t, 32> out{};
        unsigned int n = 0;
        if (EVP_DigestFinal_ex(ctx, out.data(), &n) != 1 || n != out.size()) throw std::runtime_error("SHA-256 failed");
        return hex(out);
    }
};

std::vector<std::string> sidsOf(const mf::RootDocument& root) {
    std::vector<std::string> out;
    for (const auto& s : root.segments) out.push_back(s.sid);
    for (const auto& s : root.snapshots) out.push_back(s.sid);
    return out;
}

mf::RootRecord recordOf(const mf::Loaded& head, const bool own) {
    return {.epoch = head.acceptance.epoch,
            .root_sha256 = head.acceptance.root_sha256,
            .etag = head.etag,
            .sids = sidsOf(head.root),
            .version_id = head.version_id,
            .base_version_id = head.base_version_id,
            .settle_window = head.settle_window,
            .own = own,
            .base = mf::baseCopyOf(head.root, head.root_bytes, head.segments, head.snapshots),
            .writers = head.root.writers.value_or(std::vector<std::string>{}),
            .producer = head.root.producer.node_id,
            .published_at = head.root.published_at};
}

}

using namespace engine_detail;

struct Session::Impl {
    Uid vaultUid{};
    std::shared_ptr<BucketStore> store;
    Keys keys;
    Options options;
    std::shared_ptr<StateFile> state;
    std::unique_ptr<mf::Session> session;
    mutable std::mutex mutex;   // the working content and the local operations on it
    std::mutex applyMutex;      // one refresh at a time (verify, then apply), as the server's Service::applyRemote
    std::atomic<bool> updateNeeded{false};
    std::atomic<bool> republish{false};

    [[nodiscard]] std::string nowText() const { return mf::isoTime(options.now()); }

    [[nodiscard]] mf::Content collectLocked() const {
        auto c = state->working();
        c.producer = {options.node_id, std::nullopt, options.software};
        return c;
    }

    // The current key, only once keyAdd put its envelopes and recorded it.
    [[nodiscard]] mf::SealingKey sealingLocked() const {
        const auto version = keys.current();
        const auto& listed = state->working().keys;
        if (std::ranges::find(listed, version, &mf::KeyRecord::version) == listed.end())
            throw Refused(Refusal::KeyNotAdded, std::format("key version {} was never added to the vault (keyAdd puts "
                                                            "its envelopes first)",
                                                            version));
        auto key = keys.lookup(version);
        if (!key) throw vhf1::Error(vhf1::ErrorCode::KeyUnavailable);
        return {version, std::move(key)};
    }

    void note(const mf::Notice level, const std::string& message) const {
        if (options.note) options.note(level, message);
    }

    void commit(const Change& change) { (void)state->commit(change); }
};

// ---- the streamed write --------------------------------------------------------------------------------------------

struct Writer::State {
    Session::Impl* impl{};
    std::string uid, parent, name;
    bool overwrite{false};
    std::optional<std::string> expected;
    std::optional<std::string> generationAtBegin;
    uint32_t keyVersion{};
    vhf1::Salt salt{};
    std::unique_ptr<ContentUpload> upload;
    Sha256 sha;
    std::unique_ptr<vhf1::Writer> writer;
    bool done{false};
};

Writer::Writer(std::unique_ptr<State> state) : s_(std::move(state)) {}

Writer::~Writer() {
    if (s_ && !s_->done && s_->upload) s_->upload->abort();
}

void Writer::write(const std::span<const uint8_t> plaintext) {
    if (s_->done) throw std::logic_error("the write is finished");
    try {
        s_->writer->write(plaintext);
    } catch (...) {
        s_->done = true;
        s_->upload->abort();
        throw;
    }
}

WriteResult Writer::finish() {
    if (s_->done) throw std::logic_error("the write is finished");
    s_->done = true;
    mf::PutResult put;
    try {
        s_->writer->finish();
        put = s_->upload->finish();
    } catch (...) {
        s_->upload->abort();
        throw;
    }
    auto& impl = *s_->impl;
    const auto contentHash = s_->sha.finish();
    std::scoped_lock lock(impl.mutex);
    const auto& w = impl.state->working();
    const auto now = impl.nowText();
    WriteResult out;
    Entry e;
    if (s_->overwrite) {
        const auto* cur = find(w, s_->uid);
        if (!cur || !live(*cur) || cur->kind != mf::EntryKind::File)
            throw Refused(Refusal::Busy, "the file was removed while its content was written; nothing was recorded");
        e = *cur;
        out.conflict = e.generation != s_->generationAtBegin || (s_->expected && e.generation != s_->expected);
    } else {
        requireDir(w, s_->parent);
        requireFree(w, s_->parent, s_->name);
        e.uid = s_->uid;
        e.kind = mf::EntryKind::File;
        e.parent = s_->parent;
        e.name = s_->name;
        e.mode = 0644;
        e.ctime = now;
    }
    const auto previous = e.object ? e.object->version_id : std::nullopt;
    e.mtime = now;
    e.size = s_->writer->plaintextSize();
    e.format = 1;
    e.key_version = s_->keyVersion;
    e.generation = hex(s_->salt);
    e.content_hash = contentHash;
    e.object = mf::ObjectRef{put.etag, s_->writer->objectSize(), put.version_id, std::nullopt};
    if (put.version_id) {
        for (auto& v : e.versions)
            if (previous && v.version_id == *previous && !v.noncurrent_at) v.noncurrent_at = now;
        e.versions.insert(e.versions.begin(),
                          mf::FileVersion{*put.version_id, e.generation, s_->keyVersion, s_->writer->objectSize(),
                                          put.etag, now, std::nullopt, false, std::nullopt});
    }
    impl.commit({.put = {e}});
    out.entry = std::move(e);
    return out;
}

// ---- opening ---------------------------------------------------------------------------------------------------------

Session::Session(std::unique_ptr<Impl> impl) : impl_(std::move(impl)) {}
Session::~Session() = default;

std::unique_ptr<Session> Session::open(const Uid& vaultUid, std::shared_ptr<BucketStore> store, Keys keys,
                                       std::shared_ptr<StateBlob> state, Options options, OpenReport* report) {
    if (!store || !state) throw std::invalid_argument("engine::Session needs a store and a state blob");
    if (!keys.lookup || !keys.current) throw std::invalid_argument("engine::Session needs a key lookup and a current version");
    if (options.node_id.empty()) throw std::invalid_argument("engine::Session needs this installation's node id");
    if (const auto mode = store->mode();
        mode != mf::WriteCapability::Conditional && mode != mf::WriteCapability::VersionLog)
        throw std::invalid_argument("engine::Session needs the vault's publish mode (conditional or version_log): the "
                                    "engine never probes a bucket");
    if (!options.now) options.now = [] { return std::time(nullptr); };

    auto impl = std::make_unique<Impl>();
    impl->vaultUid = vaultUid;
    impl->store = std::move(store);
    impl->keys = std::move(keys);
    impl->options = std::move(options);
    impl->state = std::make_shared<StateFile>(std::move(state), vaultUid, impl->options.now, impl->options.compact_after);
    auto& s = *impl;

    OpenReport out;
    out.state = s.state->load(mf::kBaselineWriterRevision);
    if (out.state.condition == StateCondition::Loaded) {
        if (s.state->nodeId() != s.options.node_id)
            throw StateOfAnotherVault("the engine's state was written by installation " + s.state->nodeId());
    } else {
        // Re-anchor (the state is missing or damaged): the bucket's canonical head without an anchor, as a restore
        // reads it (spec 06 §5.1 C1; spec 03 §4.5: freshness unverified).
        std::optional<mf::Loaded> loaded;
        try {
            loaded = mf::loadForRestore(*s.store, vaultUid, s.keys.lookup, std::nullopt).loaded;
        } catch (const mf::NoUsableRoot&) {
            bool anyRoot = s.store->get(std::string(mf::kRootKey)).has_value();
            if (!anyRoot)
                for (const auto& v : s.store->versions(std::string(mf::kRootKey)))
                    if (!v.delete_marker) anyRoot = true;
            if (anyRoot) throw;   // a root this installation can't read: nothing is created over it
        }
        mf::Content working;
        std::optional<mf::RootRecord> record;
        if (loaded) {
            mf::checkWriterFloor(loaded->root, mf::kBaselineWriterRevision);
            if (!loaded->issues.empty() || !loaded->blind_ranges.empty())
                s.note(mf::Notice::Warning, std::format("the root of epoch {} did not load completely ({} segment "
                                                        "issue(s)); what is missing is recovered blind",
                                                        loaded->acceptance.epoch, loaded->issues.size()));
            working = loaded->content;
            record = recordOf(*loaded, false);
            out.anchor = Anchor::Reanchored;
            out.freshness = mf::Freshness::Unverified;
        } else {
            if (!s.options.create_name)
                throw Refused(Refusal::NoVault, "the bucket holds no manifest root and no vault name was given");
            checkName(*s.options.create_name);
            const auto now = s.nowText();
            working.vault = mf::VaultInfo{*s.options.create_name, now, std::nullopt, std::nullopt, std::nullopt};
            Entry root;
            root.uid = mf::uidText(vl::keykit::newUid());
            root.kind = mf::EntryKind::Dir;
            root.mode = 0755;
            root.mtime = now;
            root.ctime = now;
            working.entries.push_back(root);
            out.anchor = Anchor::Created;
        }
        if (s.options.recover_unnamed) {
            // Content uploaded and never published (or in a range the root lost): found only by the blind rebuild,
            // without names (spec 03 §4.3).
            const auto blind = mf::blindRebuild(*s.store, vaultUid, s.keys.lookup);
            std::string rootUid;
            for (const auto& e : working.entries)
                if (!e.parent && e.kind == mf::EntryKind::Dir) rootUid = e.uid;
            const auto recovered = mf::recoveredDirUid(rootUid);
            for (const auto& r : blind.recovered) {
                const auto uid = mf::uidText(r.uid);
                if (find(working, uid)) continue;
                if (!find(working, recovered)) {
                    Entry d;
                    d.uid = recovered;
                    d.kind = mf::EntryKind::Dir;
                    d.parent = rootUid;
                    d.name = std::string(mf::kRecoveredName);
                    d.mode = 0755;
                    d.mtime = d.ctime = s.nowText();
                    for (const auto& e : working.entries)
                        if (live(e) && e.parent == rootUid && e.name == d.name) d.name += " (" + recovered.substr(0, 8) + ")";
                    working.entries.push_back(d);
                    mf::normalize(working);
                }
                Entry f;
                f.uid = uid;
                f.kind = mf::EntryKind::File;
                f.parent = recovered;
                f.name = uid;
                f.mode = 0644;
                f.mtime = f.ctime = s.nowText();
                f.size = r.plaintext_size;
                f.format = 1;
                f.key_version = r.key_version;
                f.generation = r.generation;
                f.object = mf::ObjectRef{std::nullopt, r.object_size, std::nullopt, std::nullopt};
                working.entries.push_back(f);
                mf::normalize(working);
                ++out.recovered;
            }
            if (!blind.rejected.empty())
                s.note(mf::Notice::Warning,
                       std::format("{} object(s) in o/ did not authenticate and were left alone", blind.rejected.size()));
        }
        const bool settled = record && out.recovered == 0;
        s.state->reset(std::move(working), record, s.options.node_id, mf::kBaselineWriterRevision, settled);
    }
    const auto chain = s.state->state();
    if (chain.epoch && chain.root_sha256) out.known = mf::Known{*chain.epoch, *chain.root_sha256, chain.root_version_id};

    mf::SessionHost host;
    Impl* self = impl.get();
    host.collect = [self] {
        std::scoped_lock lock(self->mutex);
        self->state->noteCollected(self->state->revision());
        return self->collectLocked();
    };
    host.currentKey = [self] {
        std::scoped_lock lock(self->mutex);
        return self->sealingLocked();
    };
    host.keys = s.keys.lookup;
    host.nodeId = [self] { return self->options.node_id; };
    host.afterRootPut = s.options.after_root_put;
    host.now = s.options.now;
    host.alert = s.options.alert;
    host.note = s.options.note;
    s.session = std::make_unique<mf::Session>(vaultUid, s.store, s.state, std::move(host));
    if (report) *report = std::move(out);
    return std::unique_ptr<Session>(new Session(std::move(impl)));
}

// ---- reading the working content -------------------------------------------------------------------------------------

std::string Session::rootUid() const {
    std::scoped_lock lock(impl_->mutex);
    for (const auto& e : impl_->state->working().entries)
        if (!e.parent && e.kind == mf::EntryKind::Dir && live(e)) return e.uid;
    throw std::runtime_error("the vault's tree has no root");
}

std::vector<Entry> Session::list(const std::string& dirUid) const {
    std::scoped_lock lock(impl_->mutex);
    const auto& w = impl_->state->working();
    (void)requireDir(w, dirUid);
    std::vector<Entry> out;
    for (const auto& e : w.entries)
        if (live(e) && e.parent == dirUid) out.push_back(e);
    return out;
}

std::optional<Entry> Session::stat(const std::string& uid) const {
    std::scoped_lock lock(impl_->mutex);
    const auto* e = find(impl_->state->working(), uid);
    return e ? std::optional<Entry>(*e) : std::nullopt;
}

std::vector<Entry> Session::trash() const {
    std::scoped_lock lock(impl_->mutex);
    std::vector<Entry> out;
    for (const auto& e : impl_->state->working().entries)
        if (e.trashed) out.push_back(e);
    return out;
}

ChangeLog Session::changes(const uint64_t generation, const uint64_t after) const {
    return impl_->state->changesSince(generation, after);
}

// ---- content -----------------------------------------------------------------------------------------------------------

void Session::read(const std::string& uid, const std::optional<std::string>& versionId, const uint64_t offset,
                   const uint64_t length, const std::function<void(std::span<const uint8_t>)>& sink) const {
    if (!sink) throw std::invalid_argument("read needs a sink");
    std::optional<std::string> generation, version;
    uint64_t objectSize = 0;
    {
        std::scoped_lock lock(impl_->mutex);
        const auto& e = requireEntry(impl_->state->working(), uid);
        if (e.kind != mf::EntryKind::File || !e.object) throw Refused(Refusal::NotFound, uid + " has no content");
        if (!versionId || versionId == e.object->version_id) {
            generation = e.generation;
            objectSize = e.object->size;
            version = e.object->version_id;
        } else {
            const auto it = std::ranges::find(e.versions, *versionId, &mf::FileVersion::version_id);
            if (it == e.versions.end() || it->delete_marker || !it->generation || !it->size)
                throw Refused(Refusal::NotFound, "no readable version " + *versionId + " of " + uid);
            generation = it->generation;
            objectSize = *it->size;
            version = it->version_id;
        }
    }
    const auto salt = saltOf(generation);
    if (!salt) throw Refused(Refusal::NotFound, uid + " names no generation");
    const auto u = mf::parseUid(uid, "bad_segment", "entry uid");
    const auto key = keys::contentKey(u);
    vhf1::Expectation expect{vhf1::Kind::FileContent, impl_->vaultUid, u, *salt};
    const auto head = impl_->store->getContent(key, version, 0, vhf1::kHeaderSize);
    if (!head) throw Refused(Refusal::NotFound, "the object of " + uid + " is missing from the bucket");
    if (head->total != objectSize) throw vhf1::Error(vhf1::ErrorCode::SizeMismatch);
    vhf1::RangeReader reader(vhf1::openHeader(head->bytes, expect, impl_->keys.lookup), objectSize, head->total);
    const auto size = reader.layout().plaintextSize;
    if (offset >= size || length == 0) return;
    const auto end = length > size - offset ? size : offset + length;
    for (uint64_t at = offset; at < end;) {
        const auto pieceEnd = std::min(end, at + kReadPiece);
        const auto plan = reader.plan(at, pieceEnd);
        const auto& span = *plan.objectRange;
        const auto window = impl_->store->getContent(key, version, span.begin, span.size());
        if (!window) throw Refused(Refusal::NotFound, "the object of " + uid + " is missing from the bucket");
        if (window->total != objectSize) throw vhf1::Error(vhf1::ErrorCode::SizeMismatch);
        const auto plaintext = reader.read(at, pieceEnd, window->bytes);
        sink(plaintext.span());
        at = pieceEnd;
    }
}

std::unique_ptr<Writer> Session::writeBegin(const std::string& parentUid, const std::string& name,
                                            const std::optional<std::string>& uid,
                                            const std::optional<std::string>& expectedGeneration,
                                            const std::optional<uint64_t> size) {
    auto st = std::make_unique<Writer::State>();
    st->impl = impl_.get();
    mf::SealingKey sealing;
    {
        std::scoped_lock lock(impl_->mutex);
        const auto& w = impl_->state->working();
        if (uid) {
            const auto& e = requireLive(w, *uid);
            if (e.kind != mf::EntryKind::File) throw Refused(Refusal::NotFound, *uid + " is not a file");
            st->uid = *uid;
            st->overwrite = true;
            st->generationAtBegin = e.generation;
            st->expected = expectedGeneration;
        } else {
            checkName(name);
            (void)requireDir(w, parentUid);
            requireFree(w, parentUid, name);
            st->uid = mf::uidText(vl::keykit::newUid());
            st->parent = parentUid;
            st->name = name;
        }
        sealing = impl_->sealingLocked();
    }
    st->keyVersion = sealing.version;
    vhf1::HeaderParams params;
    params.kind = vhf1::Kind::FileContent;
    params.keyVersion = sealing.version;
    params.vaultUid = impl_->vaultUid;
    params.objectUid = mf::parseUid(st->uid, "bad_segment", "entry uid");
    params.salt = vhf1::freshSalt();
    st->salt = params.salt;
    std::optional<uint64_t> objectSize;
    if (size) objectSize = vhf1::objectSizeFor(*size, params.chunkLog2);
    st->upload = impl_->store->putContent(keys::contentKey(params.objectUid), objectSize);
    if (!st->upload) throw std::runtime_error("the store returned no upload");
    auto* raw = st.get();
    try {
        st->writer = std::make_unique<vhf1::Writer>(params, *sealing.key, [raw](const std::span<const uint8_t> bytes) {
            raw->sha.update(bytes);
            raw->upload->write(bytes);
        });
    } catch (...) {
        st->upload->abort();
        throw;
    }
    return std::unique_ptr<Writer>(new Writer(std::move(st)));
}

// ---- tree changes ------------------------------------------------------------------------------------------------------

Entry Session::mkdir(const std::string& parentUid, const std::string& name) {
    checkName(name);
    std::scoped_lock lock(impl_->mutex);
    const auto& w = impl_->state->working();
    (void)requireDir(w, parentUid);
    requireFree(w, parentUid, name);
    Entry e;
    e.uid = mf::uidText(vl::keykit::newUid());
    e.kind = mf::EntryKind::Dir;
    e.parent = parentUid;
    e.name = name;
    e.mode = 0755;
    e.mtime = e.ctime = impl_->nowText();
    impl_->commit({.put = {e}});
    return e;
}

Entry Session::rename(const std::string& uid, const std::string& name) {
    std::optional<std::string> parent;
    {
        std::scoped_lock lock(impl_->mutex);
        parent = requireLive(impl_->state->working(), uid).parent;
    }
    if (!parent) throw Refused(Refusal::InvalidMove, "the vault root has no name");
    return move(uid, *parent, name);
}

Entry Session::move(const std::string& uid, const std::string& parentUid, const std::optional<std::string>& name) {
    std::scoped_lock lock(impl_->mutex);
    const auto& w = impl_->state->working();
    auto e = requireLive(w, uid);
    if (!e.parent) throw Refused(Refusal::InvalidMove, "the vault root can't move");
    (void)requireDir(w, parentUid);
    if (e.kind == mf::EntryKind::Dir && within(w, uid, parentUid))
        throw Refused(Refusal::InvalidMove, "a directory can't move into itself or below itself");
    const auto finalName = name.value_or(e.name);
    checkName(finalName);
    requireFree(w, parentUid, finalName, uid);
    e.parent = parentUid;
    e.name = finalName;
    e.ctime = impl_->nowText();
    impl_->commit({.put = {e}});
    return e;
}

void Session::trash(const std::string& uid) {
    std::scoped_lock lock(impl_->mutex);
    const auto& w = impl_->state->working();
    const auto& top = requireLive(w, uid);
    if (!top.parent) throw Refused(Refusal::InvalidMove, "the vault root can't be trashed");
    const auto now = impl_->nowText();
    Change c;
    std::set<std::string> removedDirs;
    const auto all = subtree(w, uid);
    for (const auto* e : all)
        if (e->kind == mf::EntryKind::Dir) removedDirs.insert(e->uid);
    for (const auto* e : all) {
        if (e->kind != mf::EntryKind::File) {
            c.remove.push_back(e->uid);
            continue;
        }
        auto t = *e;
        t.trashed = mf::Trashed{now, impl_->options.node_id, pathOf(w, *e)};
        if (t.parent && removedDirs.contains(*t.parent)) t.parent.reset();   // the collector's form: a live folder only
        c.put.push_back(std::move(t));
    }
    // Trash already in a removed folder no longer names it.
    for (const auto& e : w.entries)
        if (e.trashed && e.parent && removedDirs.contains(*e.parent)) {
            auto t = e;
            t.parent.reset();
            c.put.push_back(std::move(t));
        }
    impl_->commit(c);
}

Entry Session::restore(const std::string& uid, const std::optional<std::string>& parentUid,
                       const std::optional<std::string>& name) {
    std::scoped_lock lock(impl_->mutex);
    const auto& w = impl_->state->working();
    auto e = requireEntry(w, uid);
    if (!e.trashed || e.kind != mf::EntryKind::File) throw Refused(Refusal::NotFound, uid + " is not in the trash");
    std::string parent;
    if (parentUid) {
        (void)requireDir(w, *parentUid);
        parent = *parentUid;
    } else if (const auto* p = e.parent ? find(w, *e.parent) : nullptr; p && live(*p) && p->kind == mf::EntryKind::Dir) {
        parent = p->uid;
    } else {
        for (const auto& r : w.entries)
            if (!r.parent && r.kind == mf::EntryKind::Dir && live(r)) parent = r.uid;
    }
    const auto finalName = name.value_or(e.name);
    checkName(finalName);
    requireFree(w, parent, finalName);
    e.trashed.reset();
    e.parent = parent;
    e.name = finalName;
    e.ctime = impl_->nowText();
    impl_->commit({.put = {e}});
    return e;
}

void Session::purge(const std::string& uid) {
    std::scoped_lock lock(impl_->mutex);
    const auto& w = impl_->state->working();
    const auto& top = requireEntry(w, uid);
    if (top.kind == mf::EntryKind::Tombstone) throw Refused(Refusal::NotFound, uid + " is not a file or directory");
    if (!top.trashed && !top.parent) throw Refused(Refusal::InvalidMove, "the vault root can't be purged");
    std::vector<const Entry*> gone = top.trashed ? std::vector<const Entry*>{&top} : subtree(w, uid);
    Change c;
    std::set<std::string> removedDirs;
    for (const auto* e : gone) {
        c.remove.push_back(e->uid);
        if (e->kind == mf::EntryKind::Dir) removedDirs.insert(e->uid);
        if (e->kind != mf::EntryKind::File || !e->object) continue;
        Purge p{e->uid, keys::contentKey(mf::parseUid(e->uid, "bad_segment", "entry uid")), {}, 0};
        for (const auto& v : e->versions) p.version_ids.push_back(v.version_id);
        if (e->object->version_id && std::ranges::find(p.version_ids, *e->object->version_id) == p.version_ids.end())
            p.version_ids.push_back(*e->object->version_id);
        c.purges.push_back(std::move(p));
    }
    for (const auto& e : w.entries)
        if (e.trashed && e.parent && removedDirs.contains(*e.parent)) {
            auto t = e;
            t.parent.reset();
            c.put.push_back(std::move(t));
        }
    impl_->commit(c);
}

// ---- keys -------------------------------------------------------------------------------------------------------------

void Session::keyAdd(const uint32_t version, const std::span<const uint8_t> key,
                     const std::vector<std::vector<uint8_t>>& envelopes, const std::optional<std::string>& keyCheck) {
    if (key.size() != vhf1::kKeySize) throw std::invalid_argument("a vault key is 32 bytes");
    const auto above = [&](const mf::Content& w) {
        if (version == 0 || (!w.keys.empty() && version <= w.keys.back().version))
            throw Refused(Refusal::KeyVersion, std::format("key version {} is not above the vault's", version));
    };
    {
        std::scoped_lock lock(impl_->mutex);
        above(impl_->state->working());
    }
    const auto held = impl_->keys.lookup(version);
    if (!held || !vl::keykit::equalConstantTime(held->bytes(), key))
        throw Refused(Refusal::KeyMismatch, std::format("the keys callback doesn't hold this key as version {}", version));
    if (envelopes.empty())
        throw Refused(Refusal::RecipientRequired, "a key version needs an envelope for a recovery recipient first");
    std::vector<std::string> kids;
    for (const auto& env : envelopes) {
        vl::keykit::kev1::Header h;
        try {
            h = vl::keykit::kev1::inspect(env);
        } catch (const std::exception&) {
            throw Refused(Refusal::BadEnvelope, "an envelope is not KEV1");
        }
        if (h.key_version != version || h.vault_uid != impl_->vaultUid || h.recipient_class != 0 || h.purpose != 1)
            throw Refused(Refusal::BadEnvelope, "an envelope is not this vault's key version for a customer recipient");
        kids.push_back(vl::keykit::kev1::kid(env));
    }
    // Every envelope in the bucket before the version is recorded (and so before anything is sealed under it).
    for (std::size_t i = 0; i < envelopes.size(); ++i) {
        try {
            (void)impl_->store->putOnce(vl::keykit::kev1::objectKey(kids[i]), envelopes[i]);
        } catch (const mf::PreconditionFailed&) {
            // already there: the name is the bytes' hash
        }
    }
    std::ranges::sort(kids);
    kids.erase(std::unique(kids.begin(), kids.end()), kids.end());
    std::scoped_lock lock(impl_->mutex);
    const auto& w = impl_->state->working();
    above(w);
    auto history = w.keys;
    const auto now = impl_->nowText();
    for (auto& k : history)
        if (!k.retired_at) k.retired_at = now;
    history.push_back(mf::KeyRecord{version, keyCheck, std::nullopt, now, std::nullopt, kids, std::nullopt});
    impl_->commit({.keys = history});
}

// ---- the bucket -------------------------------------------------------------------------------------------------------

RefreshReport Session::refresh() {
    auto& s = *impl_;
    std::scoped_lock applying(s.applyMutex);
    RefreshReport out;
    const auto before = s.state->state();
    auto verified = s.session->verifyRemote();
    if (!verified) {
        out.root_missing = true;
        if (before.epoch) s.republish = true;   // the next publish rebuilds it (spec 03 §4.2 (b))
        return out;
    }
    out.known = mf::Known{verified->epoch, verified->root_sha256, std::nullopt};
    if (verified->adopted) {
        out.moved = out.adopted = true;
        return out;
    }
    if (!verified->head) return out;
    out.moved = true;
    const auto& head = *verified->head;
    out.producer = head.root.producer.node_id;
    out.known->version_id = head.version_id;
    // The server applier's order (design/sync/manifest-applier.md, "What it applies, in order"; vault_manifest::Applier).
    if (verified->own_unexplained)
        throw ApplyStopped("manifest_own_unexplained",
                           std::format("the root of epoch {} names this installation as its producer but is not a root "
                                       "it published on its recorded one: another installation may publish under its id",
                                       head.acceptance.epoch));
    if (verified->above_floor) {
        s.updateNeeded = true;
        throw mf::WriterFloorRefused(mf::writerFloorOf(head.root), mf::kBaselineWriterRevision, head.acceptance.epoch);
    }
    if (!head.issues.empty() || !head.blind_ranges.empty())
        throw ApplyStopped("manifest_head_incomplete",
                           std::format("the root of epoch {} did not load completely ({} segment issue(s)); applying it "
                                       "would delete what it lost",
                                       head.acceptance.epoch, head.issues.size()));
    {
        std::scoped_lock lock(s.mutex);
        // The base: the content of `known`, from the local copy; without a usable one, none (a union: nothing deleted).
        const auto st = s.state->state();
        std::optional<mf::Content> base;
        if (st.epoch && st.root_sha256)
            if (const auto copy = s.state->base()) {
                std::string why;
                base = mf::openBaseCopy(*copy, s.vaultUid, s.keys.lookup, mf::Known{*st.epoch, *st.root_sha256}, &why);
                if (!base) s.note(mf::Notice::Warning, "the local base copy is not usable (" + why + "); merging as a union");
            }
        if (!base) {
            out.union_base = true;
            base = mf::Content{};
        }
        const auto ours = s.collectLocked();
        auto rec = mf::reconcile(*base, head.content, ours);
        if (rec.stopped()) {
            std::string codes;
            for (const auto& p : rec.key_problems)
                codes += std::format("{}{} (version {})", codes.empty() ? "" : ", ", p.code, p.version);
            throw ApplyStopped(rec.key_problems.front().code,
                               std::format("the root of epoch {} can't be applied: {}", head.acceptance.epoch, codes));
        }
        auto result = std::move(rec.result);
        // A two-sided content change keeps both generations: ours stays current (reconcile's rule), theirs becomes a
        // version of the file, readable by its version id (a bucket that keeps versions holds both objects).
        const auto now = s.nowText();
        for (const auto& c : rec.conflicts) {
            if (c.kind != mf::ConflictKind::ContentEditEdit || !c.theirs || !c.theirs->object ||
                !c.theirs->object->version_id)
                continue;
            const auto it = std::ranges::lower_bound(result.entries, c.uid, {}, &Entry::uid);
            if (it == result.entries.end() || it->uid != c.uid) continue;
            const auto& theirs = *c.theirs;
            if (std::ranges::find(it->versions, *theirs.object->version_id, &mf::FileVersion::version_id) !=
                it->versions.end())
                continue;
            it->versions.push_back(mf::FileVersion{*theirs.object->version_id, theirs.generation, theirs.key_version,
                                                   theirs.object->size, theirs.object->etag, theirs.mtime, now, false,
                                                   std::nullopt});
        }
        const bool settled = mf::differsFromRecorded(result, head.content).empty();
        std::size_t changed = 0;
        {
            std::map<std::string, const Entry*> was;
            for (const auto& e : ours.entries) was[e.uid] = &e;
            for (const auto& e : result.entries) {
                const auto w = was.find(e.uid);
                if (w == was.end() || !(*w->second == e)) ++changed;
                if (w != was.end()) was.erase(w);
            }
            changed += was.size();
        }
        s.state->applyAndRecord(std::move(result), recordOf(head, head.root.producer.node_id == s.options.node_id),
                                settled);
        out.applied = true;
        out.changed = changed;
        out.conflicts = std::move(rec.conflicts);
    }
    s.session->applied();
    s.note(mf::Notice::Info, std::format("applied the manifest root of epoch {} from {} ({} entr{} changed, {} "
                                         "conflict(s))",
                                         head.acceptance.epoch, head.root.producer.node_id, out.changed,
                                         out.changed == 1 ? "y" : "ies", out.conflicts.size()));
    return out;
}

PublishResult Session::publish() {
    auto& s = *impl_;
    PublishResult out;
    const auto knownNow = [&] {
        const auto st = s.state->state();
        return st.epoch && st.root_sha256 ? mf::Known{*st.epoch, *st.root_sha256, st.root_version_id} : mf::Known{};
    };
    const auto chain = s.state->state();
    const bool writersDue = chain.writers_change && !chain.writers_change->satisfiedBy(chain.writers);
    if (s.state->revision() <= s.state->publishedRevision() && !s.republish && !writersDue) {
        out.known = knownNow();
        out.purged = 0;
    } else {
        for (unsigned round = 0;; ++round) {
            try {
                auto r = s.session->publishIfChanged();
                if (r) {
                    out.published = true;
                    out.segments_written = r->segments_written;
                    out.segments_reused = r->segments_reused;
                } else {
                    s.state->settleCollected();
                }
                s.republish = false;
                break;
            } catch (const mf::HeadMoved&) {
                s.state->noteCollected(0);
                if (round + 1 >= s.options.publish_rounds)
                    throw mf::PublishConflict(std::format("manifest publish conflict after {} rounds of applying another "
                                                          "writer's root",
                                                          round + 1));
                ++out.rounds;
                (void)refresh();
            } catch (...) {
                s.state->noteCollected(0);   // nothing settled: a root of it adopted later settles nothing
                throw;
            }
        }
        out.known = knownNow();
    }
    // Purged files' objects, once a root without them settled and this installation writes the vault alone (another
    // writer may still name an object: its restore, or an edit that beats our purge).
    std::vector<Purge> due;
    std::vector<std::string> resurrected;
    {
        std::scoped_lock lock(s.mutex);
        const auto st = s.state->state();
        const bool solo = st.writers.empty() || (st.writers.size() == 1 && st.writers.front() == s.options.node_id);
        const auto published = s.state->publishedRevision();
        for (auto& p : s.state->purges()) {
            if (find(s.state->working(), p.uid)) resurrected.push_back(p.uid);
            else if (solo && p.revision <= published) due.push_back(std::move(p));
        }
    }
    std::vector<std::string> done = resurrected;
    for (const auto& p : due) {
        try {
            if (p.version_ids.empty()) s.store->remove(p.key);
            for (const auto& v : p.version_ids) s.store->removeVersion(p.key, v);
            done.push_back(p.uid);
            ++out.purged;
        } catch (const std::exception& e) {
            s.note(mf::Notice::Warning, std::string("a purged file's object was not deleted (next publish retries): ") +
                                            e.what());
        }
    }
    s.state->dropPurges(done);
    return out;
}

void Session::join() {
    impl_->state->setWritersChange(mf::WritersChange{mf::WritersChange::Kind::Add, impl_->options.node_id});
    impl_->republish = true;
}

std::optional<mf::GcReport> Session::gcIfDue(const std::time_t now) { return impl_->session->collectGarbageIfDue(now); }

Status Session::status() const {
    auto& s = *impl_;
    Status out;
    const auto st = s.state->state();
    if (st.epoch && st.root_sha256) out.known = mf::Known{*st.epoch, *st.root_sha256, st.root_version_id};
    out.refused = st.refused_reason;
    out.update_needed = s.updateNeeded;
    out.revision = s.state->revision();
    out.unpublished = out.revision > s.state->publishedRevision() || s.republish;
    out.generation = s.state->changesSince(0, 0).generation;
    out.pending_purges = s.state->purges().size();
    return out;
}

}
