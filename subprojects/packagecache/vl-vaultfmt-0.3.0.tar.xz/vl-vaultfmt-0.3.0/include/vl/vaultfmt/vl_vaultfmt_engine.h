/* SPDX-License-Identifier: AGPL-3.0-or-later */
/* Copyright (c) 2026 Valkyrian Labs LLC */
#ifndef VL_VAULTFMT_ENGINE_H
#define VL_VAULTFMT_ENGINE_H

/*
 * The database-free engine's C API (vl/vaultfmt/engine/Session.hpp; docs/engine.md): one opaque_v1 vault kept in its
 * bucket with no server and no database, as Vaulthalla Desktop runs a Desktop-only vault (vaulthalla-server
 * design/core/vault-format-library.md, "Public surface": the design's vlvf_* calls are the vl_vaultfmt_* calls below,
 * one for one). The conventions of vl_vaultfmt.h hold here unchanged: plain C11, opaque handles, statuses with stable
 * names (vl_vaultfmt_status_name knows every code below), pointer + length inputs, the buffer convention for outputs,
 * nothing returned that holds a key, and no C++ exception crossing this boundary.
 *
 * Three callback tables connect the engine to its host, each with a `ctx` the library passes back and keeps until the
 * vault is freed. Callbacks return a vl_vaultfmt_status; they never throw (a Swift callback catches what it calls) and
 * a callback that can't tell whether a write happened returns VL_VAULTFMT_ERR_STORE_OUTCOME_UNKNOWN, never a guess.
 * They may be called on any thread that calls into the vault, and at the same time from two such threads.
 *
 *   store   the bucket: whole objects (manifest, envelopes; at most 256 MiB), content objects streamed both ways.
 *           Replies (bodies, ETags, version ids, listings) go through the vl_vaultfmt_reply the call hands over,
 *           valid only during the callback.
 *   keys    the installation's vault keys: a version's key copied into a 32-byte buffer the library owns and wipes,
 *           and the current version.
 *   state   one blob per vault, loaded whole, replaced atomically and durably (save), optionally appended durably
 *           (append; NULL: every change is a save). vl_vaultfmt_file_state is the library's own file implementation.
 *
 * Threads: a vault handle may be used from several threads at once; its operations are serialized inside, and network
 * work runs outside the lock local operations take. A write handle is one stream: one thread at a time. Free a write
 * before its vault. Listings are immutable and may be read concurrently.
 */

#include "vl_vaultfmt.h"   /* beside this header (installed and in the XCFramework alike) */

#ifdef __cplusplus
extern "C" {
#endif

/* ---- Statuses (stable; appended only). The engine's blocks are 600-612 and 621-631 (620 + engine::Refusal); the
   other blocks of the library are in vl_vaultfmt.h. ------------------------------------------------------------------ */

enum {
    /* The store (callbacks return these; the engine returns them when a store failure ends an operation). */
    VL_VAULTFMT_ERR_STORE_FAILED = 600,                 /* the request failed (transport, refused before sending) */
    VL_VAULTFMT_ERR_STORE_PRECONDITION_FAILED = 601,    /* 412 */
    VL_VAULTFMT_ERR_STORE_CONDITIONS_UNSUPPORTED = 602, /* 501 / NotImplemented: nothing was written */
    VL_VAULTFMT_ERR_STORE_OUTCOME_UNKNOWN = 603,        /* a write that may or may not have happened */
    /* The state */
    VL_VAULTFMT_ERR_STATE_FAILED = 604,      /* the state could not be read or written: the change did not happen */
    VL_VAULTFMT_ERR_STATE_TOO_NEW = 605,     /* written by a newer engine: never read or overwritten */
    VL_VAULTFMT_ERR_STATE_OTHER_VAULT = 606, /* the state blob is another vault's or another installation's */
    /* Publishing and refreshing */
    VL_VAULTFMT_ERR_PUBLISH_CONFLICT = 607,    /* other writers won every round; publish again */
    VL_VAULTFMT_ERR_PUBLISH_UNSETTLED = 608,   /* version_log: our root isn't listed yet; the next publish settles it */
    VL_VAULTFMT_ERR_PUBLISH_UNSUPPORTED = 609, /* the store's mode can't take a manifest */
    VL_VAULTFMT_ERR_NO_USABLE_ROOT = 610,      /* the bucket holds a root no key of this installation opens */
    VL_VAULTFMT_ERR_WRITER_FLOOR = 611,        /* a newer writer's root: this engine reads, and needs an update */
    VL_VAULTFMT_ERR_APPLY_STOPPED = 612,       /* a head the engine won't take in (vl_vaultfmt_vault_last_error says why) */
    /* An operation refused (nothing changed): 620 + engine::Refusal; "not found" is VL_VAULTFMT_ERR_NOT_FOUND */
    VL_VAULTFMT_ERR_NOT_A_DIRECTORY = 621,
    VL_VAULTFMT_ERR_NAME_EXISTS = 622,
    VL_VAULTFMT_ERR_INVALID_NAME = 623,
    VL_VAULTFMT_ERR_INVALID_MOVE = 624,
    VL_VAULTFMT_ERR_KEY_NOT_ADDED = 625,       /* the current key version was never added with its envelopes */
    VL_VAULTFMT_ERR_RECIPIENT_REQUIRED = 626,  /* a key version needs at least one envelope */
    VL_VAULTFMT_ERR_KEY_MISMATCH = 627,        /* the key isn't what the keys callback holds for that version */
    VL_VAULTFMT_ERR_KEY_VERSION = 628,         /* not above every key version of the vault */
    VL_VAULTFMT_ERR_BAD_ENVELOPE = 629,        /* not KEV1 of this vault and version for a customer recipient */
    VL_VAULTFMT_ERR_NO_VAULT = 630,            /* nothing to open, and no name to create the vault with */
    VL_VAULTFMT_ERR_BUSY = 631                 /* a write's file changed under it (removed); nothing was recorded */
};

/* Publish modes (manifest::WriteCapability). The engine never probes: the vault's record says. */
#define VL_VAULTFMT_MODE_CONDITIONAL 1
#define VL_VAULTFMT_MODE_VERSION_LOG 2   /* every Desktop-only vault (managed Backblaze B2) */

/* A store PUT's condition. */
#define VL_VAULTFMT_PUT_PLAIN 0
#define VL_VAULTFMT_PUT_IF_ABSENT 1      /* If-None-Match: * */
#define VL_VAULTFMT_PUT_IF_MATCH 2       /* If-Match: etag */

#define VL_VAULTFMT_SIZE_UNKNOWN UINT64_MAX
#define VL_VAULTFMT_TIME_UNKNOWN INT64_MIN

/* ---- Callback replies ---------------------------------------------------------------------------------------------- */

typedef struct vl_vaultfmt_reply vl_vaultfmt_reply;

/* A body (get, get_range, load): bytes are appended; call as often as needed. */
vl_vaultfmt_status vl_vaultfmt_reply_body(vl_vaultfmt_reply* reply, const uint8_t* bytes, size_t len);
/* The object's ETag as the provider sent it (quoted), and its version id (versioned buckets). */
vl_vaultfmt_status vl_vaultfmt_reply_etag(vl_vaultfmt_reply* reply, const char* etag, size_t len);
vl_vaultfmt_status vl_vaultfmt_reply_version_id(vl_vaultfmt_reply* reply, const char* version_id, size_t len);
/* A ranged read's object size (the Content-Range total). */
vl_vaultfmt_status vl_vaultfmt_reply_total(vl_vaultfmt_reply* reply, uint64_t total);
/* One object of a listing. */
vl_vaultfmt_status vl_vaultfmt_reply_listed(vl_vaultfmt_reply* reply, const char* key, size_t key_len, uint64_t size,
                                            int64_t last_modified, const char* etag, size_t etag_len);
/* One version of a version listing (newest first per key, keys ascending). */
vl_vaultfmt_status vl_vaultfmt_reply_version(vl_vaultfmt_reply* reply, const char* key, size_t key_len,
                                             const char* version_id, size_t version_id_len, uint64_t size,
                                             int64_t last_modified, int32_t delete_marker, const char* etag,
                                             size_t etag_len, int32_t is_latest);

/* ---- Callback tables ----------------------------------------------------------------------------------------------- */

typedef struct vl_vaultfmt_store_table {
    void* ctx;
    int32_t mode;   /* VL_VAULTFMT_MODE_* */
    /* GET key (version_id NULL: the current object): body, ETag, version id. VL_VAULTFMT_ERR_NOT_FOUND for 404 or a
       delete marker. */
    vl_vaultfmt_status (*get)(void* ctx, const char* key, size_t key_len, const char* version_id, size_t version_id_len,
                              vl_vaultfmt_reply* reply);
    /* Bytes [offset, offset + length) (fewer at the end), and the total: content objects and headers. */
    vl_vaultfmt_status (*get_range)(void* ctx, const char* key, size_t key_len, const char* version_id,
                                    size_t version_id_len, uint64_t offset, uint64_t length, vl_vaultfmt_reply* reply);
    /* HEAD: the ETag. */
    vl_vaultfmt_status (*head)(void* ctx, const char* key, size_t key_len, vl_vaultfmt_reply* reply);
    /* PUT a whole object under `condition` (if_match: the ETag for VL_VAULTFMT_PUT_IF_MATCH): ETag and version id. */
    vl_vaultfmt_status (*put)(void* ctx, const char* key, size_t key_len, const uint8_t* bytes, size_t len,
                              int32_t condition, const char* if_match, size_t if_match_len, vl_vaultfmt_reply* reply);
    /* The current objects under a prefix. */
    vl_vaultfmt_status (*list)(void* ctx, const char* prefix, size_t prefix_len, vl_vaultfmt_reply* reply);
    /* The versions of exactly `key` (under_prefix 0; newest first, may stop after stop_at), or of every key under the
       prefix `key` (under_prefix 1). Empty on an unversioned bucket. */
    vl_vaultfmt_status (*versions)(void* ctx, const char* key, size_t key_len, const char* stop_at, size_t stop_at_len,
                                   int32_t under_prefix, vl_vaultfmt_reply* reply);
    /* DELETE (version_id NULL: by name, a delete marker on a versioned bucket; else exactly that version). A key or
       version that is gone is VL_VAULTFMT_OK. */
    vl_vaultfmt_status (*remove)(void* ctx, const char* key, size_t key_len, const char* version_id,
                                 size_t version_id_len);
    /* A streamed plain PUT of a content object: begin (size: the sealed size, or VL_VAULTFMT_SIZE_UNKNOWN), write the
       bytes in order, finish (ETag, version id), or abort (never fails). `*upload` is the callback's own handle. */
    vl_vaultfmt_status (*content_begin)(void* ctx, const char* key, size_t key_len, uint64_t size, void** upload);
    vl_vaultfmt_status (*content_write)(void* ctx, void* upload, const uint8_t* bytes, size_t len);
    vl_vaultfmt_status (*content_finish)(void* ctx, void* upload, vl_vaultfmt_reply* reply);
    void (*content_abort)(void* ctx, void* upload);
} vl_vaultfmt_store_table;

typedef struct vl_vaultfmt_keys_table {
    void* ctx;
    /* The key of `version` into `key` (32 bytes; the library wipes it after copying it into locked memory).
       VL_VAULTFMT_ERR_NOT_FOUND when this installation doesn't hold that version. */
    vl_vaultfmt_status (*lookup)(void* ctx, uint32_t version, uint8_t key[32]);
    /* The version new objects and roots are sealed under. */
    vl_vaultfmt_status (*current)(void* ctx, uint32_t* version);
} vl_vaultfmt_keys_table;

typedef struct vl_vaultfmt_state_table {
    void* ctx;
    /* The whole blob into the reply's body; VL_VAULTFMT_ERR_NOT_FOUND when there is none. */
    vl_vaultfmt_status (*load)(void* ctx, vl_vaultfmt_reply* reply);
    /* Replace the blob atomically (old or new bytes, across a crash too), durable before returning. */
    vl_vaultfmt_status (*save)(void* ctx, const uint8_t* bytes, size_t len);
    /* Optional (NULL): append durably before returning; a crash during it may leave a prefix of `bytes`. */
    vl_vaultfmt_status (*append)(void* ctx, const uint8_t* bytes, size_t len);
} vl_vaultfmt_state_table;

/* The reference state file: `path` (0600; F_FULLFSYNC on Apple platforms; written via path.tmp and a rename). */
typedef struct vl_vaultfmt_file_state vl_vaultfmt_file_state;
vl_vaultfmt_status vl_vaultfmt_file_state_new(const char* path, size_t path_len, vl_vaultfmt_file_state** out);
/* A state table over it (its ctx is the file state, which must outlive every vault using the table). */
vl_vaultfmt_status vl_vaultfmt_file_state_table(vl_vaultfmt_file_state* state, vl_vaultfmt_state_table* out);
void vl_vaultfmt_file_state_free(vl_vaultfmt_file_state* state);

/* ---- Opening ------------------------------------------------------------------------------------------------------- */

typedef struct vl_vaultfmt_vault vl_vaultfmt_vault;

typedef struct vl_vaultfmt_vault_options {
    const char* node_id;       /* this installation's id, required: the root's producer and writers */
    size_t node_id_len;
    const char* software;      /* the root's producer.software, or NULL ("vl-vaultfmt") */
    size_t software_len;
    const char* create_name;   /* NULL: never create; else a new vault of this name when state and bucket are empty */
    size_t create_name_len;
    int32_t skip_recovery;     /* 1: a re-anchor doesn't place unnamed objects under /Recovered (no blind rebuild) */
    int64_t (*now)(void* ctx); /* Unix seconds; NULL: the system clock */
    void* now_ctx;
} vl_vaultfmt_vault_options;

#define VL_VAULTFMT_ANCHOR_STATE 0       /* the state held the vault */
#define VL_VAULTFMT_ANCHOR_REANCHORED 1  /* the state was missing or damaged: read from the bucket */
#define VL_VAULTFMT_ANCHOR_CREATED 2     /* a new vault */

#define VL_VAULTFMT_STATE_FRESH 0
#define VL_VAULTFMT_STATE_LOADED 1
#define VL_VAULTFMT_STATE_DAMAGED 2

typedef struct vl_vaultfmt_open_info {
    int32_t anchor;              /* VL_VAULTFMT_ANCHOR_* */
    int32_t state;               /* VL_VAULTFMT_STATE_*: what the blob held */
    int32_t torn_tail;           /* 1: the last journal record was cut short (a crash during an append), dropped */
    int32_t journal_truncated;   /* 1: a damaged journal record: it and what followed were dropped */
    int32_t freshness_verified;  /* 0 after a re-anchor: nothing bounds replay ("freshness unverified") */
    uint64_t recovered;          /* objects placed under /Recovered */
    int32_t has_known;
    uint64_t epoch;              /* the recorded root */
    char root_sha256[65];
    char message[256];           /* on failure: what went wrong, NUL-terminated (no secrets) */
} vl_vaultfmt_open_info;

/* Opens (or creates) the vault `vault_uid`. The tables are copied; their ctx pointers are kept until the vault is
   freed. `info` may be NULL. */
vl_vaultfmt_status vl_vaultfmt_vault_open(const uint8_t vault_uid[16], const vl_vaultfmt_store_table* store,
                                          const vl_vaultfmt_keys_table* keys, const vl_vaultfmt_state_table* state,
                                          const vl_vaultfmt_vault_options* options, vl_vaultfmt_open_info* info,
                                          vl_vaultfmt_vault** out);

/* The last failure's message on this vault (any thread), NUL-free text through the buffer convention. */
vl_vaultfmt_status vl_vaultfmt_vault_last_error(vl_vaultfmt_vault* vault, char* out, size_t* out_len);

void vl_vaultfmt_vault_free(vl_vaultfmt_vault* vault);

/* ---- Listings: entries (and removed uids, for changes) -------------------------------------------------------------- */

typedef struct vl_vaultfmt_listing vl_vaultfmt_listing;

size_t vl_vaultfmt_listing_count(const vl_vaultfmt_listing* listing);
/* vl_vaultfmt_entry (vl_vaultfmt.h); its strings live until the listing is freed. */
vl_vaultfmt_status vl_vaultfmt_listing_entry(const vl_vaultfmt_listing* listing, size_t index, vl_vaultfmt_entry* out);

typedef struct vl_vaultfmt_file_version {
    const char* version_id;
    const char* generation;   /* hex salt, or NULL */
    uint32_t key_version;     /* 0 when unknown */
    uint64_t size;            /* sealed bytes; 0 when unknown */
    const char* last_modified;
    const char* noncurrent_at;   /* NULL: the current version */
    int32_t delete_marker;
} vl_vaultfmt_file_version;

/* A file's provider versions, newest first. */
size_t vl_vaultfmt_listing_version_count(const vl_vaultfmt_listing* listing, size_t entry);
vl_vaultfmt_status vl_vaultfmt_listing_version(const vl_vaultfmt_listing* listing, size_t entry, size_t index,
                                               vl_vaultfmt_file_version* out);
/* Changes only: the uids whose entries are gone (VL_VAULTFMT_UID_TEXT_SIZE characters, NUL-terminated). */
size_t vl_vaultfmt_listing_removed_count(const vl_vaultfmt_listing* listing);
vl_vaultfmt_status vl_vaultfmt_listing_removed(const vl_vaultfmt_listing* listing, size_t index, const char** uid);
void vl_vaultfmt_listing_free(vl_vaultfmt_listing* listing);

/* ---- Reading the working content -------------------------------------------------------------------------------- */

/* The vault root's uid (VL_VAULTFMT_UID_TEXT_SIZE characters). */
vl_vaultfmt_status vl_vaultfmt_vault_root(vl_vaultfmt_vault* vault, char* out, size_t* out_len);
/* The live entries of a directory. */
vl_vaultfmt_status vl_vaultfmt_vault_list(vl_vaultfmt_vault* vault, const char* dir_uid, size_t dir_uid_len,
                                          vl_vaultfmt_listing** out);
/* One entry (live or trashed): a listing of one; VL_VAULTFMT_ERR_NOT_FOUND when there is none. */
vl_vaultfmt_status vl_vaultfmt_vault_stat(vl_vaultfmt_vault* vault, const char* uid, size_t uid_len,
                                          vl_vaultfmt_listing** out);
/* The vault trash. */
vl_vaultfmt_status vl_vaultfmt_vault_trash(vl_vaultfmt_vault* vault, vl_vaultfmt_listing** out);

typedef struct vl_vaultfmt_changes_info {
    uint64_t generation;   /* the anchor to keep: (generation, revision) */
    uint64_t revision;
    int32_t expired;       /* 1: the anchor is too old or of another generation: enumerate everything again */
} vl_vaultfmt_changes_info;

/* What changed since (generation, after): entries added or changed now, and removed uids. */
vl_vaultfmt_status vl_vaultfmt_vault_changes(vl_vaultfmt_vault* vault, uint64_t generation, uint64_t after,
                                             vl_vaultfmt_changes_info* info, vl_vaultfmt_listing** out);

/* ---- Content ------------------------------------------------------------------------------------------------------- */

/* Plaintext [offset, offset + length) of a file (version_id NULL: its current object), clipped to its size. The sink
   receives only chunks that authenticated, in order. */
vl_vaultfmt_status vl_vaultfmt_vault_read(vl_vaultfmt_vault* vault, const char* uid, size_t uid_len,
                                          const char* version_id, size_t version_id_len, uint64_t offset,
                                          uint64_t length, vl_vaultfmt_sink_fn sink, void* ctx);

typedef struct vl_vaultfmt_write vl_vaultfmt_write;

/* A new file `name` in `parent_uid` (uid NULL), or new content for the file `uid` (parent and name ignored).
   expected_generation (or NULL): the generation the local edit started from. size: the plaintext size, or
   VL_VAULTFMT_SIZE_UNKNOWN. The content is sealed under the current key and streamed to the store's content_* calls. */
vl_vaultfmt_status vl_vaultfmt_write_begin(vl_vaultfmt_vault* vault, const char* parent_uid, size_t parent_uid_len,
                                           const char* name, size_t name_len, const char* uid, size_t uid_len,
                                           const char* expected_generation, size_t expected_generation_len,
                                           uint64_t size, vl_vaultfmt_write** out);
vl_vaultfmt_status vl_vaultfmt_write_chunk(vl_vaultfmt_write* write, const uint8_t* plaintext, size_t len);
/* Uploads the rest and records the version (journalled). `conflict` (may be NULL): 1 when the file's generation was no
   longer the expected one (both are kept: this one current, the other a version). `entry` (may be NULL): the file. */
vl_vaultfmt_status vl_vaultfmt_write_finish(vl_vaultfmt_write* write, int32_t* conflict, vl_vaultfmt_listing** entry);
/* Aborts an unfinished write (its upload too) and frees it. */
void vl_vaultfmt_write_free(vl_vaultfmt_write* write);

/* ---- Tree changes (each journalled before it returns) --------------------------------------------------------------- */

vl_vaultfmt_status vl_vaultfmt_vault_mkdir(vl_vaultfmt_vault* vault, const char* parent_uid, size_t parent_uid_len,
                                           const char* name, size_t name_len, vl_vaultfmt_listing** entry);
vl_vaultfmt_status vl_vaultfmt_vault_rename(vl_vaultfmt_vault* vault, const char* uid, size_t uid_len, const char* name,
                                            size_t name_len);
/* name NULL: keep the name. */
vl_vaultfmt_status vl_vaultfmt_vault_move(vl_vaultfmt_vault* vault, const char* uid, size_t uid_len,
                                          const char* parent_uid, size_t parent_uid_len, const char* name,
                                          size_t name_len);
vl_vaultfmt_status vl_vaultfmt_vault_trash_entry(vl_vaultfmt_vault* vault, const char* uid, size_t uid_len);
/* parent_uid / name NULL: where it was (else the vault root) and its own name. */
vl_vaultfmt_status vl_vaultfmt_vault_restore(vl_vaultfmt_vault* vault, const char* uid, size_t uid_len,
                                             const char* parent_uid, size_t parent_uid_len, const char* name,
                                             size_t name_len);
vl_vaultfmt_status vl_vaultfmt_vault_purge(vl_vaultfmt_vault* vault, const char* uid, size_t uid_len);

/* ---- Keys ------------------------------------------------------------------------------------------------------------ */

typedef struct vl_vaultfmt_bytes {
    const uint8_t* bytes;
    size_t len;
} vl_vaultfmt_bytes;

/* A new key version: `key` (32 bytes, the caller's to wipe) must be what the keys callback returns for it; every
   envelope (KEV1 of this vault and version, customer class; at least one) is PUT before the version is recorded.
   key_check (or NULL): recorded as the version's key check. */
vl_vaultfmt_status vl_vaultfmt_vault_key_add(vl_vaultfmt_vault* vault, uint32_t version, const uint8_t* key,
                                             size_t key_len, const vl_vaultfmt_bytes* envelopes, size_t envelope_count,
                                             const char* key_check, size_t key_check_len);

/* ---- The bucket ---------------------------------------------------------------------------------------------------- */

typedef struct vl_vaultfmt_refresh_info {
    int32_t moved;            /* the head is not the root recorded before */
    int32_t applied;          /* another writer's root taken in */
    int32_t adopted;          /* our own root, PUT and not recorded, recorded */
    int32_t root_missing;     /* no readable root: the next publish rebuilds it */
    int32_t union_base;       /* no usable base copy: merged as a union (nothing deleted) */
    uint64_t epoch;
    char root_sha256[65];
    uint64_t changed;         /* entries the apply changed */
    uint64_t conflicts;       /* decided conflicts and two-sided content changes */
    uint64_t content_conflicts;   /* two-sided content changes (both generations kept) */
} vl_vaultfmt_refresh_info;

/* One HEAD while nothing moved; a new canonical root is reconciled into the working content. */
vl_vaultfmt_status vl_vaultfmt_vault_refresh(vl_vaultfmt_vault* vault, vl_vaultfmt_refresh_info* info);

typedef struct vl_vaultfmt_publish_info {
    int32_t published;        /* a new root is the bucket's head */
    uint64_t epoch;
    char root_sha256[65];
    uint32_t rounds;          /* another writer's root applied first */
    uint32_t segments_written;
    uint32_t segments_reused;
    uint64_t purged;          /* purged files' objects deleted */
} vl_vaultfmt_publish_info;

/* Publishes local changes in the vault's mode (refreshing first when another writer won a round). */
vl_vaultfmt_status vl_vaultfmt_vault_publish(vl_vaultfmt_vault* vault, vl_vaultfmt_publish_info* info);

typedef struct vl_vaultfmt_gc_info {
    int32_t ran;              /* 0: not due (once a day) */
    uint64_t deleted;
    uint64_t retained;
    uint64_t young;
} vl_vaultfmt_gc_info;

/* Superseded segments and root versions, once a day (`now`: Unix seconds). */
vl_vaultfmt_status vl_vaultfmt_vault_gc_if_due(vl_vaultfmt_vault* vault, int64_t now, vl_vaultfmt_gc_info* info);

/* This installation joins the root's writers at the next publish (it opened another Mac's vault from the bucket). */
vl_vaultfmt_status vl_vaultfmt_vault_join(vl_vaultfmt_vault* vault);

typedef struct vl_vaultfmt_vault_status {
    int32_t has_known;
    uint64_t epoch;
    char root_sha256[65];
    int32_t refused;          /* a root was refused: nothing is published until the chain moves on */
    char refused_reason[32];  /* rollback | fork | order_violation | superseded | publish_mode_mismatch */
    int32_t update_needed;    /* a newer writer's root was seen (writer floor) */
    int32_t unpublished;      /* local changes not in the bucket yet */
    uint64_t generation;
    uint64_t revision;
    uint64_t pending_purges;
} vl_vaultfmt_vault_status;

vl_vaultfmt_status vl_vaultfmt_vault_status_get(vl_vaultfmt_vault* vault, vl_vaultfmt_vault_status* out);

#ifdef __cplusplus
}
#endif

#endif
