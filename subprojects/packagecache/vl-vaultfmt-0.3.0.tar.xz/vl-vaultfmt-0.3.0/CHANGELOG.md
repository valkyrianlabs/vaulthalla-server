# Changelog

All notable changes to vl-vaultfmt are recorded here. The format follows [Keep a Changelog](https://keepachangelog.com/),
and versions follow [Semantic Versioning](https://semver.org/) (before 1.0, a minor version may break the API).

## [Unreleased]

## [0.3.0]

Not tagged.

### Added

- The database-free engine (`vl/vaultfmt/engine/`, `docs/engine.md`; vaulthalla-server design work item 9):
  `engine::Session` over a state blob (`StateFile`: one checksummed, versioned blob per vault, a snapshot plus journal
  records; `FileStateBlob`, the reference file with `F_FULLFSYNC`), the streamed content seam (`BucketStore`), and the
  operations: open (from the state, re-anchored from the bucket with "freshness unverified" and a blind rebuild, or
  created), list, stat, trash, changes, authenticated ranged reads, streamed writes, mkdir, rename, move, trash,
  restore, purge, `keyAdd` with the envelopes PUT first, refresh (reconcile in the server applier's order, both
  generations of a two-sided content change kept), publish in the vault's mode (with `HeadMoved` rounds and purges),
  GC, join and status. Test doubles in `testing/engine_store.hpp`.
- The engine's C API (`vl/vaultfmt/vl_vaultfmt_engine.h`): store, keys and state callback tables, replies, vault,
  listing and write handles; statuses 600-612 and 621-631 (620 + `engine::Refusal`), named by
  `vl_vaultfmt_status_name`. Tested from C (`tests/c_engine_lifecycle.c`).
- The writer floor (design decision 7): the root member `writer_floor` (absent = 0, so existing roots and vectors are
  unchanged), `WriterFloorRefused` before any PUT below it, `RemoteHead::above_floor`, `PublishOptions::writer_revision`
  / `writer_floor` / `known_floor`, `SessionHost::writerRevision` / `writerFloor`, `kBaselineWriterRevision` = 1.
  Vectors: `vectors/writer_floor.json` from `writer_floor_vectors.py` (`--check` in meson as `writer-floor-reference`).
- `scripts/build-xcframework.sh` (VLVaultfmt.xcframework, static arm64) and the Swift check `tests/apple/`; a macOS CI
  job that runs only when the org variable `CI_MACOS_RUNNER` routes it to the Mac runners.
- The protocol suites ported from vaulthalla-server's `test_manifest.cpp` onto the memory store
  (`tests/test_manifest_protocol.cpp`, `tests/fake_bucket.hpp`: ManifestPublish, ManifestPublishVersionLog,
  ManifestChain, ManifestChainVersionLog, ManifestContent, ManifestReplay, ManifestBaseCopy, ManifestStore, 51 tests).

### Changed

- The manifest fixtures `test_manifest.cpp` and the protocol suites share are one header (`tests/manifest_fixtures.hpp`).
- `vl_vaultfmt_status_name` names the engine's codes from `c_api.cpp`'s one table (the engine's header is plain C), so
  the WebAssembly reader, which doesn't compile the engine, names them too. The artifact is re-recorded (the engine's
  names and `writer_floor`): 1,325,508 bytes, 574,243 gzipped.

## [0.2.0]

### Added

- The reader's C API (`vl_vaultfmt.h`, "The reader"; `src/c_api_reader.cpp`), read only and over bytes the caller
  supplies: the canonical head over a version listing of `.vaulthalla/root` (`vl_vaultfmt_head_*`: rule C1 from the
  caller's anchor or none, the versions it needs named in at most two rounds, the decision as JSON with "freshness
  unverified" when there is no anchor), KEV1 envelopes unwrapped into the keyring with a recipient handle (the account
  recovery key from its seed text, or a raw X25519 or P-256 secret), plaintext buffers usable as sinks, the tree listed
  and stat-ed as JSON, and a file's object opened bound to its entry. Statuses 400 + vl-keykit's `kev1::ErrorCode`,
  450-452 (seed text), 500-503 (reader), each named.
- `manifest::loadCanonicalRoot`: the version_log root choice of `load()` without fetching segments.
- The WebAssembly reader (`wasm/`): `vl-vaultfmt-reader.wasm` built reproducibly by `wasm/build.sh` (Emscripten 6.0.13
  by image digest, OpenSSL 3.5.9 and nlohmann_json 3.11.3 from checksum-pinned tarballs; standalone, `-Oz`, LTO,
  `-fwasm-exceptions`, no threads or filesystem; 1,324,887 bytes, 575,279 gzipped), its checksum, the reference binding
  `reader.ts`, and Node tests over every golden vector and a vault the native library builds (`wasm/tests/fixture.json`
  from `tests/make_reader_fixture`). A CI job rebuilds it and runs them.
- `tests/test_c_api_reader.cpp` and the libFuzzer target `fuzz_reader` over the reader's byte-facing entry points, with
  oracles (the unit tests replay it).

## [0.1.0]

### Added

- First version, extracted from vaulthalla-server 1.22.2 (main at fc636330: `core/{include,src}/crypto/vhf1/`,
  `sync/manifest/`, `storage/ObjectKeys`, `core/tests/fuzz/`, `core/tests/helpers/{memory,hooked}_store.hpp`).
  Byte-compatible with it: every `vhf1` and `manifest` golden vector is reproduced, and the server links this library
  in place of its own copy.
  - `vhf1`: the header codec, key schedule, size math, `Writer`, `open`, `ChunkWalker`, `RangeReader`, `Key`, the
    chunk AEAD and the ordered `ErrorCode`s.
  - `keys`: `contentKey`, `uidOfContentKey`, `classify`, `isAllowedKey`, `isAllowedListPrefix`, `importedPathOf`,
    `partSizeFor`, `partCountFor`.
  - `manifest`: documents, content, partitioning, objects, chain rules, the version log, the reader (fallbacks, base
    copy, blind rebuild, restore freshness), the publisher (conditional and version_log, GC, janitor, writers),
    reconcile, the `Session` decision logic over `StateStore`, and the `ObjectStore` seam with `WriteCapability`.
  - `testing/`: the in-memory versioned store and the hooking store, header-only.
- The C API (`vl/vaultfmt/vl_vaultfmt.h`): keyring, object keys, streamed VHF1 sealing and opening, ranged reads, a
  manifest root opened from bytes with the chain rules against a known state, and the tree built from its pinned
  objects (entries, lookup, children, JSON). Status blocks 0-7, 100 + `vhf1::ErrorCode`, 200-202 (document errors),
  300 + `manifest::ChainError`. Tested against the vectors and from C (`tests/c_header_check.c`).
- `vectors/`: a verbatim copy of vaulthalla-server's golden vectors and their Python reference, checked by
  `meson test` (`vectors-reference`, `vectors-contract`).
- The libFuzzer target `fuzz_vhf1` (`-Dfuzz=true`).

### Changed (from the vaulthalla-server code)

- Namespaces `vh::crypto::vhf1` → `vl::vaultfmt::vhf1`, `vh::sync::manifest` → `vl::vaultfmt::manifest`,
  `vh::storage::object_keys` → `vl::vaultfmt::keys`, `vh::test_support::manifest_store` → `vl::vaultfmt::test_support`;
  headers under `<vl/vaultfmt/...>`. No behaviour change.
- `publish` (version_log) keeps the base's index in the root listing as an index and a flag instead of a
  `std::optional<std::size_t>`, which GCC 14 at -O2 and above reported maybe-uninitialized once the library built as one
  unit. No behaviour change.
