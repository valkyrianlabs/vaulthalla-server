// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Valkyrian Labs LLC
//
// Signed streaming payloads: aws-chunked bodies under STREAMING-AWS4-HMAC-SHA256-PAYLOAD(-TRAILER), as the AWS Java
// SDK and MinIO's clients send over plain HTTP, plus the unsigned aws-chunked framing of
// STREAMING-UNSIGNED-PAYLOAD-TRAILER.
//
// Wire format (AWS "Transferring Payload in Multiple Chunks" and "Signature calculations for trailing headers"):
//
//     <hex size>;chunk-signature=<sig>\r\n<data>\r\n          one per chunk; the last one has size 0
//     0;chunk-signature=<sig>\r\n\r\n                          the final chunk, without trailers
//     0;chunk-signature=<sig>\r\n<name>:<value>\r\n...x-amz-trailer-signature:<sig>\r\n\r\n      with trailers
//     <hex size>\r\n<data>\r\n ... 0\r\n<name>:<value>\r\n...\r\n                             unsigned framing
//
// Signatures chain from the request's (seed) signature:
//
//     chunk:   HMAC(signing key, "AWS4-HMAC-SHA256-PAYLOAD\n<x-amz-date>\n<scope>\n<previous>\n<sha256("")>\n
//              <sha256(chunk data)>")
//     trailer: HMAC(signing key, "AWS4-HMAC-SHA256-TRAILER\n<x-amz-date>\n<scope>\n<previous>\n
//              <sha256(canonical trailers)>")     canonical trailers: "<lower-case name>:<trimmed value>\n" each
//
// Server side, in order:
//   1. verify() with VerifyOptions::allow_streaming_signed_payload. A success with VerifyResult::body_pending means
//      the headers are authentic and the body is not.
//   2. ChunkVerifier::forRequest(result, secret), handed to an AwsChunkedDecoder that reads the raw body in pieces of
//      any size and passes the decoded data on as it goes (a chunk is never held whole).
//   3. Act on nothing until AwsChunkedDecoder::finish() succeeds: data handed out before then is unverified.
// Every failure is an Error with an ErrorCode; nothing throws on bad input (only an OpenSSL failure throws).
#pragma once

#include "vl/sigv4/crypto.hpp"
#include "vl/sigv4/signer.hpp"
#include "vl/sigv4/types.hpp"
#include "vl/sigv4/verifier.hpp"

#include <cstddef>
#include <cstdint>
#include <expected>
#include <functional>
#include <optional>
#include <string>
#include <string_view>
#include <utility>
#include <vector>

namespace vl::sigv4 {

namespace detail {

// A string wiped (OPENSSL_cleanse) when destroyed or overwritten: holds a derived signing key.
class WipedString {
public:
    WipedString() = default;
    explicit WipedString(std::string bytes) noexcept : bytes_(std::move(bytes)) {}
    WipedString(WipedString&& other) noexcept : bytes_(std::move(other.bytes_)) { other.wipe(); }
    WipedString& operator=(WipedString&& other) noexcept {
        if (this != &other) {
            wipe();
            bytes_ = std::move(other.bytes_);
            other.wipe();
        }
        return *this;
    }
    WipedString(const WipedString&) = delete;
    WipedString& operator=(const WipedString&) = delete;
    ~WipedString() { wipe(); }

    [[nodiscard]] const std::string& str() const noexcept { return bytes_; }

private:
    void wipe() noexcept;
    std::string bytes_;
};

}

// What the chunk signatures chain from: the request's signature and what it was signed with.
struct StreamingSeed {
    std::string seed_signature;               // the request's signature, lower-case hex
    std::string amz_date;                     // x-amz-date
    CredentialScope scope;                    // date, region, service (access_key is not used)
    bool trailer = false;                     // STREAMING-AWS4-HMAC-SHA256-PAYLOAD-TRAILER: signed trailers follow
};

// The seed of a request verify() accepted with body_pending (ErrorCode::UnsupportedPayloadHash when the request is not
// a signed streaming one, its own code when it did not verify).
[[nodiscard]] std::expected<StreamingSeed, Error> streamingSeed(const VerifyResult& verified);
// The seed of a request sign() produced with payload_hash kStreamingSignedPayload or kStreamingSignedPayloadTrailer.
[[nodiscard]] std::expected<StreamingSeed, Error> streamingSeed(const Signed& signedRequest);

// --- primitives --------------------------------------------------------------------------------------------------

// "AWS4-HMAC-SHA256-PAYLOAD\n<amzDate>\n<scope>\n<previousSignature>\n<sha256("")>\n<chunkSha256Hex>"
[[nodiscard]] std::string chunkStringToSign(std::string_view amzDate, std::string_view scope,
                                            std::string_view previousSignature, std::string_view chunkSha256Hex);
// "AWS4-HMAC-SHA256-TRAILER\n<amzDate>\n<scope>\n<previousSignature>\n<trailersSha256Hex>"
[[nodiscard]] std::string trailerStringToSign(std::string_view amzDate, std::string_view scope,
                                              std::string_view previousSignature, std::string_view trailersSha256Hex);
// "<lower-case name>:<value trimmed as a canonical header value>\n" per trailer, in the order given (what the AWS SDKs
// and MinIO's clients sign; AWS's example: "x-amz-checksum-crc32c:sOO8/Q==\n").
[[nodiscard]] std::string canonicalTrailers(const HeaderList& trailers);
// The names listed in an x-amz-trailer header ("x-amz-checksum-crc32c, x-amz-checksum-sha256"), lower-cased and
// trimmed; empty entries dropped.
[[nodiscard]] std::vector<std::string> parseTrailerNames(std::string_view xAmzTrailer);

// --- server: the signature chain ---------------------------------------------------------------------------------

// Verifies a signed streaming body chunk by chunk, independent of how the caller parses the framing. Feed each chunk
// as beginChunk(signature, size), update(data) any number of times, endChunk(); the zero-length chunk is the final one.
// In -TRAILER mode verifyTrailer() follows it. finish() succeeds only once the whole chain verified.
//
// Every call returns an Error rather than throwing; the first error sticks (every later call returns it). Holds the
// derived signing key (never the secret) and wipes it on destruction. Move-only.
class ChunkVerifier {
public:
    // signingKey: deriveSigningKey(secret, scope.date, scope.region, scope.service), raw bytes.
    ChunkVerifier(StreamingSeed seed, std::string signingKey);
    // For a request verify() accepted with body_pending, with the same secret it was verified with.
    [[nodiscard]] static std::expected<ChunkVerifier, Error> forRequest(const VerifyResult& verified,
                                                                        std::string_view secretKey);
    // From a seed and the secret (the signing key is derived from seed.scope).
    [[nodiscard]] static ChunkVerifier fromSecret(StreamingSeed seed, std::string_view secretKey);

    ChunkVerifier(ChunkVerifier&&) noexcept = default;
    ChunkVerifier& operator=(ChunkVerifier&&) noexcept = default;
    ChunkVerifier(const ChunkVerifier&) = delete;
    ChunkVerifier& operator=(const ChunkVerifier&) = delete;
    ~ChunkVerifier() = default;

    // Starts a chunk of `size` bytes whose declared signature (hex, any case) is `signature`.
    [[nodiscard]] std::expected<void, Error> beginChunk(std::string_view signature, std::uint64_t size);
    // Part of the current chunk's data (MalformedChunkedEncoding beyond the declared size).
    [[nodiscard]] std::expected<void, Error> update(std::string_view data);
    // Ends the chunk: its data must have reached the declared size; the signature must continue the chain
    // (ChunkSignatureMismatch).
    [[nodiscard]] std::expected<void, Error> endChunk();
    // beginChunk + update + endChunk for a chunk held whole.
    [[nodiscard]] std::expected<void, Error> verifyChunk(std::string_view signature, std::string_view data);
    // -TRAILER mode, after the final chunk: the trailers as received (in order) and x-amz-trailer-signature.
    [[nodiscard]] std::expected<void, Error> verifyTrailer(const HeaderList& trailers, std::string_view signature);
    // Success only when the final chunk (and in -TRAILER mode the trailer) verified: IncompleteBody otherwise.
    [[nodiscard]] std::expected<void, Error> finish() const;

    [[nodiscard]] bool complete() const noexcept;
    [[nodiscard]] bool expectsTrailer() const noexcept { return seed_.trailer; }
    [[nodiscard]] std::uint64_t chunks() const noexcept { return chunks_; }          // chunks verified, final included
    [[nodiscard]] std::uint64_t decodedLength() const noexcept { return decoded_; }  // data bytes verified
    // The last verified signature (the seed before the first chunk).
    [[nodiscard]] const std::string& previousSignature() const noexcept { return previous_; }

private:
    std::expected<void, Error> fail(ErrorCode code, std::string message);

    StreamingSeed seed_;
    std::string scope_;
    detail::WipedString key_;
    std::string previous_;
    std::string declared_;
    Sha256 hash_;
    std::uint64_t size_ = 0;
    std::uint64_t received_ = 0;
    std::uint64_t chunks_ = 0;
    std::uint64_t decoded_ = 0;
    bool inChunk_ = false;
    bool final_ = false;
    bool trailerDone_ = false;
    std::optional<Error> error_{};
};

// --- server: the aws-chunked framing -----------------------------------------------------------------------------

struct ChunkedDecoderOptions {
    std::size_t max_chunk_size = kDefaultMaxChunkSize;   // larger chunks fail with ChunkTooLarge
    std::size_t max_line_length = 4096;                  // a chunk header or trailer line, CRLF included
    std::size_t max_trailer_bytes = 16u * 1024u;         // the whole trailer section
    // x-amz-decoded-content-length: the decoded body must have exactly this length (DecodedLengthMismatch, reported as
    // soon as a chunk header would exceed it).
    std::optional<std::uint64_t> decoded_length{};
    // x-amz-trailer (parseTrailerNames): the trailers received must be exactly these names, in any order.
    std::optional<std::vector<std::string>> declared_trailers{};
};

// Push parser for an aws-chunked body: feed() the raw bytes in pieces of any size; the decoded data goes to the sink
// as it arrives. Strict framing: hex sizes without sign, prefix or whitespace, CRLF line ends (trailer lines may end in
// a bare LF, as MinIO's Go client writes them), no data after the end. With a ChunkVerifier every chunk must carry
// exactly ";chunk-signature=<64 hex>" and is verified when its data ends; without one, chunk extensions are ignored.
//
// Data reaches the sink before its chunk's signature is checked (so a 16 MiB chunk is never held): treat everything
// the sink received as untrusted until finish() succeeds. Errors stick, like ChunkVerifier's. Move-only.
class AwsChunkedDecoder {
public:
    using Sink = std::function<void(std::string_view)>;

    // Unsigned framing: STREAMING-UNSIGNED-PAYLOAD-TRAILER, or an aws-chunked body under UNSIGNED-PAYLOAD or a body
    // hash. Trailers are accepted (unsigned).
    explicit AwsChunkedDecoder(ChunkedDecoderOptions options = {});
    // Signed framing, verified by `verifier` (STREAMING-AWS4-HMAC-SHA256-PAYLOAD; with -TRAILER the trailers and
    // x-amz-trailer-signature are required after the final chunk).
    explicit AwsChunkedDecoder(ChunkVerifier verifier, ChunkedDecoderOptions options = {});

    // Consumes `bytes`; decoded data is passed to `sink` (may be empty: data discarded). An exception thrown by the
    // sink propagates and leaves the decoder unusable.
    [[nodiscard]] std::expected<void, Error> feed(std::string_view bytes, const Sink& sink = {});
    // End of the body: IncompleteBody unless the final chunk and the trailer section were read, then the signature
    // chain (signed framing) and decoded_length are checked. Only after this succeeds is the body authentic.
    [[nodiscard]] std::expected<void, Error> finish();

    [[nodiscard]] bool done() const noexcept;                    // the trailer section ended (finish() still required)
    [[nodiscard]] const HeaderList& trailers() const noexcept { return trailers_; }   // lower-case names, trimmed values
    [[nodiscard]] std::uint64_t decodedLength() const noexcept { return decoded_; }
    [[nodiscard]] bool isSigned() const noexcept { return verifier_.has_value(); }

private:
    enum class State : std::uint8_t { ChunkHeader, ChunkData, ChunkDataCr, ChunkDataLf, Trailers, Done };

    std::expected<void, Error> fail(ErrorCode code, std::string message);
    std::expected<void, Error> chunkHeader(std::string_view line);
    std::expected<void, Error> trailerLine(std::string_view line, bool crlf);
    std::expected<void, Error> endOfTrailers();

    ChunkedDecoderOptions options_;
    std::optional<ChunkVerifier> verifier_{};
    State state_ = State::ChunkHeader;
    std::string line_;
    std::uint64_t remaining_ = 0;
    std::uint64_t decoded_ = 0;
    std::size_t trailerBytes_ = 0;
    bool afterBareLf_ = false;   // the last trailer line ended in a bare LF (MinIO's Go client)
    HeaderList trailers_;
    std::optional<std::string> trailerSignature_{};
    std::optional<Error> error_{};
};

// --- client: signing a streaming body ----------------------------------------------------------------------------

// Signs chunks for a request sign()ed with payload_hash kStreamingSignedPayload(Trailer) and encodes the body. The
// request must also carry Content-Encoding: aws-chunked, x-amz-decoded-content-length and (unless sent with
// Transfer-Encoding) the encoded Content-Length (awsChunkedLength). Move-only; wipes the signing key on destruction.
class ChunkSigner {
public:
    ChunkSigner(StreamingSeed seed, std::string_view secretKey);
    // For a request sign() produced (UnsupportedPayloadHash unless it is signed streaming).
    [[nodiscard]] static std::expected<ChunkSigner, Error> forRequest(const Signed& signedRequest,
                                                                      std::string_view secretKey);

    ChunkSigner(ChunkSigner&&) noexcept = default;
    ChunkSigner& operator=(ChunkSigner&&) noexcept = default;
    ChunkSigner(const ChunkSigner&) = delete;
    ChunkSigner& operator=(const ChunkSigner&) = delete;
    ~ChunkSigner() = default;

    // The next chunk's signature (empty data: the final chunk), advancing the chain.
    [[nodiscard]] std::string signChunk(std::string_view data);
    // The trailer signature, after the final chunk (-TRAILER mode).
    [[nodiscard]] std::string signTrailer(const HeaderList& trailers);
    // "<hex size>;chunk-signature=<sig>\r\n<data>\r\n" for non-empty data.
    [[nodiscard]] std::string encodeChunk(std::string_view data);
    // The final chunk and the end of the body: "0;chunk-signature=<sig>\r\n\r\n", or with -TRAILER the trailers and
    // their signature. Trailers without -TRAILER throw std::invalid_argument (a programming error).
    [[nodiscard]] std::string encodeFinal(const HeaderList& trailers = {});

    [[nodiscard]] bool trailer() const noexcept { return seed_.trailer; }
    [[nodiscard]] const std::string& previousSignature() const noexcept { return previous_; }

private:
    StreamingSeed seed_;
    std::string scope_;
    detail::WipedString key_;
    std::string previous_;
};

// A whole payload as a signed aws-chunked body: chunkSize-byte chunks (the last one shorter), then encodeFinal().
// chunkSize 0 throws std::invalid_argument.
[[nodiscard]] std::string encodeAwsChunked(ChunkSigner& signer, std::string_view payload, std::size_t chunkSize,
                                           const HeaderList& trailers = {});
// The same framing without signatures (STREAMING-UNSIGNED-PAYLOAD-TRAILER): "<hex>\r\n<data>\r\n" ... "0\r\n",
// trailers, "\r\n".
[[nodiscard]] std::string encodeAwsChunkedUnsigned(std::string_view payload, std::size_t chunkSize,
                                                   const HeaderList& trailers = {});
// The encoded length of a payload of decodedLength bytes as those functions frame it (the Content-Length to sign).
// mode: StreamingSigned, StreamingSignedTrailer or StreamingUnsignedTrailer (std::invalid_argument otherwise).
[[nodiscard]] std::uint64_t awsChunkedLength(std::uint64_t decodedLength, std::size_t chunkSize, PayloadMode mode,
                                             const HeaderList& trailers = {});

}
