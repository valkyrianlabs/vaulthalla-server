// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Valkyrian Labs LLC
//
// Server side: parse and verify SigV4-signed requests (Authorization header or presigned query), as an
// S3-compatible gateway does. No exceptions on authentication failure: every outcome is a VerifyResult with an
// ErrorCode and a message.
//
// The secret: pass it directly when the caller has already looked it up (parseAuthorization() first gives the
// access key), or pass a SecretLookup and verify() calls it with the access key from the request. Either way the
// secret is used only inside the call.
#pragma once

#include "vl/sigv4/types.hpp"

#include <chrono>
#include <cstdint>
#include <expected>
#include <functional>
#include <optional>
#include <string>
#include <string_view>

namespace vl::sigv4 {

// The request as the server received it. Nothing here is owned beyond the call: body is a view and must outlive it.
struct VerificationInput {
    std::string method;                       // "GET", ...
    std::string target;                       // request-target as received: encoded path, optionally "?query"
    std::string host{};                       // used as the host header when the request has none
    HeaderList headers{};                     // as received; names in any case, repeated names allowed
    std::string_view body{};                  // the body as read (empty when streamed: set body_sha256)
    std::optional<std::string> body_sha256{}; // hex SHA-256 of the (decoded) body when the caller hashed it itself
};

struct ParsedAuth {
    CredentialScope credential;
    std::string signed_headers;               // as sent ("host;x-amz-date")
    std::string signature;                    // as sent
    std::string amz_date;                     // x-amz-date header or X-Amz-Date parameter
    std::string payload_hash;                 // what the canonical request ends with
    bool presigned = false;
    std::chrono::seconds expires{0};          // presigned only
    std::optional<std::string> session_token{}; // x-amz-security-token header / X-Amz-Security-Token parameter
};

struct VerifyOptions {
    // Credential scope service the verifier accepts. Also selects the URI encoding (S3 single, others double) and
    // the presigned payload (UNSIGNED-PAYLOAD for S3, the body's hash otherwise).
    std::string service = "s3";
    // When set, the scope region must equal it; unset accepts any region (S3-compatible gateways: "us-east-1",
    // "auto", ...).
    std::optional<std::string> region{};
    std::chrono::seconds max_skew = kDefaultMaxSkew;
    // Upper bound for X-Amz-Expires; values above kMaxPresignExpiry are clamped to it.
    std::chrono::seconds max_presign_expiry = kMaxPresignExpiry;
    bool allow_presigned = true;
    // Reject requests carrying a session token (a gateway with long-lived keys only).
    bool reject_session_tokens = false;
    // The scope date must equal the date of x-amz-date (AWS rejects a mismatch).
    bool require_scope_date_match = true;
    // host must be among the signed headers (AWS requires it).
    bool require_signed_host = true;
    // Proxies (Cloudflare) drop "Content-Length: 0" from bodiless requests, while clients that sign content-length
    // signed it as 0. When the request has neither Content-Length nor Transfer-Encoding and an empty body, treat it
    // as "content-length: 0" (as MinIO does). It never lets through a request with a body.
    bool imply_zero_content_length = true;
    // Accept signed streaming payloads (STREAMING-AWS4-HMAC-SHA256-PAYLOAD and -TRAILER). verify() then checks the
    // headers and the seed signature only and sets VerifyResult::body_pending: the body is NOT verified. The caller
    // must run it through a ChunkVerifier (streaming.hpp) and act on nothing it carries until that finishes. Off,
    // such requests fail with UnsupportedPayloadHash.
    bool allow_streaming_signed_payload = false;
};

struct VerifyResult {
    ErrorCode code = ErrorCode::None;
    std::string message{};
    std::string access_key{};                 // from the request, once parsed (also on most failures)
    std::optional<ParsedAuth> auth{};         // the parsed authorization, once parsed
    std::string canonical_request{};          // set once the signature was computed (diagnostics)
    std::string string_to_sign{};
    PayloadMode payload_mode = PayloadMode::Hashed;   // how the body is covered (from the parsed payload hash)
    // ok() with body_pending: the request's headers are authentic but its body is not verified yet (signed streaming
    // payload). Create a ChunkVerifier from this result (ChunkVerifier::forRequest, streaming.hpp), feed it the body,
    // and treat the request as failed unless its finish() succeeds.
    bool body_pending = false;

    [[nodiscard]] bool ok() const noexcept { return code == ErrorCode::None; }
    explicit operator bool() const noexcept { return ok(); }
};

// Returns the secret for an access key, or nullopt when the key is unknown or disabled.
using SecretLookup = std::function<std::optional<std::string>(std::string_view accessKey)>;

// Reads the Authorization header or the presigned query parameters, and checks their shape: algorithm, credential
// scope (service and region per options), X-Amz-Expires bounds, session token policy. Never throws on bad input.
[[nodiscard]] std::expected<ParsedAuth, Error> parseAuthorization(const VerificationInput& input,
                                                                  const VerifyOptions& options = {});

// Verifies with a known secret: parse, date and skew (or presign window), signed headers present, payload hash,
// then the signature in constant time.
[[nodiscard]] VerifyResult verify(const VerificationInput& input, std::string_view secret, TimePoint now,
                                  const VerifyOptions& options = {});

// Same, with the secret looked up by the request's access key (ErrorCode::UnknownAccessKey when the lookup returns
// nullopt). The lookup is called at most once, after the request parsed.
[[nodiscard]] VerifyResult verify(const VerificationInput& input, const SecretLookup& lookup, TimePoint now,
                                  const VerifyOptions& options = {});

// Same, for an already parsed authorization (avoids parsing twice when the caller parsed to find the secret).
[[nodiscard]] VerifyResult verify(const VerificationInput& input, const ParsedAuth& auth, std::string_view secret,
                                  TimePoint now, const VerifyOptions& options = {});

// The canonical request and the signature the verifier expects for a parsed authorization (tests, diagnostics).
[[nodiscard]] std::string canonicalRequestFor(const VerificationInput& input, const ParsedAuth& auth,
                                              const VerifyOptions& options = {});
[[nodiscard]] std::string signatureFor(const VerificationInput& input, const ParsedAuth& auth, std::string_view secret,
                                       const VerifyOptions& options = {});

}
