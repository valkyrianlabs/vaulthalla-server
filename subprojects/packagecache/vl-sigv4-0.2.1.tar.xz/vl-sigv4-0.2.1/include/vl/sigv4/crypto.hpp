// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Valkyrian Labs LLC
//
// The SigV4 primitives: SHA-256, HMAC-SHA-256, key derivation and a constant-time comparison (OpenSSL 3).
// They throw std::runtime_error only if OpenSSL itself fails (out of memory); authentication never throws.
#pragma once

#include <memory>
#include <string>
#include <string_view>

namespace vl::sigv4 {

// Lower-case hex of arbitrary bytes.
[[nodiscard]] std::string hexEncode(std::string_view bytes);

// SHA-256 digest (32 raw bytes) and its lower-case hex form.
[[nodiscard]] std::string sha256(std::string_view data);
[[nodiscard]] std::string sha256Hex(std::string_view data);

// Incremental SHA-256 (data fed in pieces, as a streaming body arrives). Move-only.
class Sha256 {
public:
    Sha256();
    Sha256(Sha256&&) noexcept = default;
    Sha256& operator=(Sha256&&) noexcept = default;
    Sha256(const Sha256&) = delete;
    Sha256& operator=(const Sha256&) = delete;
    ~Sha256() = default;

    void update(std::string_view data);
    // The digest of everything fed since construction or the last finish(), as 32 raw bytes or lower-case hex; the
    // state is then reset for the next message.
    [[nodiscard]] std::string finish();
    [[nodiscard]] std::string finishHex();

private:
    struct Free {
        void operator()(void* ctx) const noexcept;
    };
    std::unique_ptr<void, Free> ctx_;
};

// HMAC-SHA-256 (32 raw bytes) and its lower-case hex form.
[[nodiscard]] std::string hmacSha256(std::string_view key, std::string_view data);
[[nodiscard]] std::string hmacSha256Hex(std::string_view key, std::string_view data);

// kSigning = HMAC(HMAC(HMAC(HMAC("AWS4" + secret, date), region), service), "aws4_request"), raw bytes.
[[nodiscard]] std::string deriveSigningKey(std::string_view secretKey, std::string_view date, std::string_view region,
                                           std::string_view service);

// Hex signature of a string to sign under a derived signing key.
[[nodiscard]] std::string signatureHex(std::string_view signingKey, std::string_view stringToSign);

// Compares in time independent of where the inputs differ (CRYPTO_memcmp). Inputs of different length compare
// unequal at once: the length of a signature is not secret.
[[nodiscard]] bool constantTimeEqual(std::string_view a, std::string_view b) noexcept;

}
