# vl-sigv4

AWS Signature Version 4 for C++23: a client **signer** (Authorization header and presigned URLs) and a server
**verifier** (header and presigned authentication, as an S3-compatible gateway needs). OpenSSL 3 is the only
dependency. A product of Valkyrian Labs LLC, MIT licensed.

- Byte-compatible with the AWS SigV4 test suite, the AWS S3 documentation examples and botocore, and with the signer
  Vaulthalla shipped (its characterization goldens are part of the test suite).
- No globals and no clock reads: time is a parameter everywhere.
- The verifier never throws on bad input; every outcome is a result with an `ErrorCode`, a message and the S3 error
  code to answer with.
- Signed streaming uploads (`STREAMING-AWS4-HMAC-SHA256-PAYLOAD`, `-TRAILER`): an incremental aws-chunked decoder that
  verifies the chunk signature chain as the body arrives, and the matching chunk signer.

## API sketch

Headers live in `include/vl/sigv4/` (`#include <vl/sigv4/sigv4.hpp>` for all of them); everything is in
`namespace vl::sigv4`.

```cpp
#include <vl/sigv4/sigv4.hpp>
namespace sv = vl::sigv4;

// Sign (Authorization header)
const sv::Credentials creds{.access_key = "AKIA...", .secret_key = "...", .session_token = {}};
const sv::Request request{
    .method = "GET",
    .host = "bucket.s3.us-east-1.amazonaws.com",
    .path = "/photos/a b+c.jpg",                   // raw: sign() encodes it
    .query = {{"versionId", "3/L4k+="}},           // raw pairs
    .headers = {{"Range", "bytes=0-9"}},
    .payload_hash = std::string(sv::kUnsignedPayload),   // or sv::sha256Hex(body); empty = empty body
};
const sv::Signed s = sv::sign(request, creds, "us-east-1", "s3", sv::Clock::now());
// s.target() -> "/photos/a%20b%2Bc.jpg?versionId=3%2FL4k%2B%3D"; s.headers: every header to send (lower-case)

// Presign (1 s .. 7 days)
std::expected<sv::Presigned, sv::Error> url =
    sv::presign(request, creds, "us-east-1", "s3", sv::Clock::now(), std::chrono::hours{1});
// url->url() -> "https://bucket.s3...amazonaws.com/photos/...?X-Amz-Algorithm=...&X-Amz-Signature=..."

// Verify (server side)
sv::VerificationInput input{.method = "GET", .target = rawTarget, .host = hostHeader,
                            .headers = receivedHeaders, .body = body, .body_sha256 = std::nullopt};
sv::VerifyOptions options;                  // service "s3", ±15 min skew, presign <= 7 days, host must be signed
const sv::SecretLookup lookup = [&](std::string_view accessKey) -> std::optional<std::string> { /* ... */ };
const sv::VerifyResult r = sv::verify(input, lookup, sv::Clock::now(), options);
if (!r) reply(403, sv::awsErrorCode(r.code, r.auth && r.auth->presigned), r.message);
```

Signed streaming bodies (aws-chunked, as `mc` and the AWS Java SDK send over plain HTTP):

```cpp
// Server: the headers first, then the body, chunk by chunk.
options.allow_streaming_signed_payload = true;
const sv::VerifyResult r = sv::verify(input, secret, sv::Clock::now(), options);   // input.body empty
if (r.body_pending) {                       // headers authentic, body not yet
    sv::ChunkedDecoderOptions limits;
    limits.decoded_length = decodedLength;  // x-amz-decoded-content-length
    sv::AwsChunkedDecoder decoder(*sv::ChunkVerifier::forRequest(r, secret), limits);
    while (/* read raw bytes */) {
        if (auto ok = decoder.feed(raw, [&](std::string_view data) { tempFile.write(data); }); !ok) return fail(ok.error());
    }
    if (auto ok = decoder.finish(); !ok) return fail(ok.error());   // only now is the body authentic
    // decoder.trailers(): x-amz-checksum-* trailers (-TRAILER)
}

// Client: sign() with payload_hash = kStreamingSignedPayload (plus Content-Encoding: aws-chunked,
// x-amz-decoded-content-length and Content-Length = awsChunkedLength(...)), then chain the chunks.
auto signer = sv::ChunkSigner::forRequest(signedRequest, creds.secret_key);
const std::string body = sv::encodeAwsChunked(*signer, payload, 64 * 1024);
```

| Header | Contents |
| --- | --- |
| `types.hpp` | `Clock`/`TimePoint`, `HeaderList`, `QueryParams`, `Credentials`, `CredentialScope`, `PayloadMode`/`payloadMode`, `ErrorCode`, `Error`, `errorCodeName`, `awsErrorCode`, constants |
| `crypto.hpp` | `sha256`/`sha256Hex`, `Sha256` (incremental), `hmacSha256`/`hmacSha256Hex`, `deriveSigningKey`, `signatureHex`, `hexEncode`, `constantTimeEqual` |
| `canonical.hpp` | `uriEncode`/`uriDecode`, `encodePath`, `canonicalUri`, `canonicalUriFromWire`, `canonicalQuery`, `canonicalQueryFromWire`, `sortEncodedQuery`, `parseQuery`, `canonicalHeaderValue`, `normalizeHeaders`, `canonicalHeaders`, `canonicalHeadersFor`, `canonicalRequest`, `credentialScope`, `stringToSign`, `authorizationHeader`, `amzDate`, `dateStamp`, `parseAmzDate` |
| `signer.hpp` | `Request`, `Signed`, `sign()`, `Presigned`, `presign()` |
| `verifier.hpp` | `VerificationInput`, `ParsedAuth`, `VerifyOptions`, `VerifyResult`, `SecretLookup`, `parseAuthorization()`, three `verify()` overloads, `canonicalRequestFor()`, `signatureFor()` |
| `streaming.hpp` | `StreamingSeed`, `streamingSeed()`, `ChunkVerifier`, `ChunkedDecoderOptions`, `AwsChunkedDecoder`, `ChunkSigner`, `encodeAwsChunked()`, `encodeAwsChunkedUnsigned()`, `awsChunkedLength()`, `chunkStringToSign()`, `trailerStringToSign()`, `canonicalTrailers()`, `parseTrailerNames()` |

Rules worth knowing:

- **Paths.** `sign()` takes raw paths. S3 encodes the path once (the wire path is the canonical URI); every other
  service URI-encodes the wire path again in the canonical request (SigV4 "double encoding"). Paths are not
  normalized.
- **Secrets in the verifier.** Pass the secret directly, or a `SecretLookup` that `verify()` calls once with the
  request's access key, after the secret-free checks (dates, signed headers, payload hash) passed. Or call
  `parseAuthorization()` first and `verify(input, parsed, secret, now, options)`.
- **Strictness.** The verifier enforces what AWS enforces: scope date equal to `x-amz-date`, `host` signed, well-formed
  Authorization parameters, `1 <= X-Amz-Expires <= 604800`. `VerifyOptions` documents each knob.
- **Payloads.** `UNSIGNED-PAYLOAD` and `STREAMING-UNSIGNED-PAYLOAD-TRAILER` skip the body check. Servers that stream
  the body pass the hash they computed in `body_sha256` instead of the body.
- **Signed streaming.** `STREAMING-AWS4-HMAC-SHA256-PAYLOAD` and `-TRAILER` are refused (`UnsupportedPayloadHash`,
  S3 `NotImplemented`) unless `VerifyOptions::allow_streaming_signed_payload` is set. With it, a successful `verify()`
  has `body_pending` set: the headers are authentic, the body is not. Run the body through an `AwsChunkedDecoder` with
  `ChunkVerifier::forRequest(result, secret)` and act on nothing until `finish()` succeeds: the decoder hands data on
  before each chunk's signature is checked, so that a chunk (up to 16 MiB by default) is never held whole. Missing
  final chunk, truncation, reordered or dropped chunks, bad signatures and framing errors each have an `ErrorCode`.
  SigV4a streaming (`STREAMING-AWS4-ECDSA-P256-SHA256-PAYLOAD`) stays unsupported.

`docs/compat-notes.md` lists how this differs from the four implementations it replaces in Vaulthalla.

## Using it from meson

As a subproject pinned to a release, `subprojects/vl-sigv4.wrap`. The repository is private, so the release URL
needs GitHub credentials: commit the release tarball in the consumer's `subprojects/packagecache/`, which meson uses
before it tries to download (and Debian builds run with `--wrap-mode=nodownload`). Take `source_hash` from the
release's `vl-sigv4-<version>.tar.xz.sha256sum`:

```ini
[wrap-file]
directory = vl-sigv4-0.2.1
source_url = https://github.com/valkyrianlabs/vl-sigv4/releases/download/v0.2.1/vl-sigv4-0.2.1.tar.xz
source_filename = vl-sigv4-0.2.1.tar.xz
source_hash = <sha256 from vl-sigv4-0.2.1.tar.xz.sha256sum>

[provide]
vl-sigv4 = vl_sigv4_dep
```

For development against a tag, `[wrap-git]` with `url = https://github.com/valkyrianlabs/vl-sigv4.git` and
`revision = v0.2.1` works too.

```meson
vl_sigv4_dep = dependency('vl-sigv4', fallback: ['vl-sigv4', 'vl_sigv4_dep'])
```

Built as a subproject it installs nothing and skips its tests. An installed copy is found through
pkg-config (`vl-sigv4.pc`, which requires `libcrypto >= 3.0`).

## Building

```bash
meson setup build -Db_sanitize=address,undefined
meson compile -C build
meson test -C build --print-errorlogs
```

Needs a C++23 compiler (GCC 14, Apple clang 17+), meson ≥ 1.3, OpenSSL 3 and, for the tests, GoogleTest
(`-Dtests=disabled` skips them). On macOS point `PKG_CONFIG_PATH` at Homebrew's `openssl@3`. The build must be
warning-free; CI fails on any warning. CI runs in `ci/run-ci` (see `ci/README.md`).

## License

MIT, see [LICENSE](LICENSE). Copyright (c) 2026 Valkyrian Labs LLC. Parts of the code and tests come from Vaulthalla
(AGPL-3.0-or-later), whose copyright owner, Valkyrian Labs LLC, relicensed them under MIT for this library.
