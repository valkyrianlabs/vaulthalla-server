// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Valkyrian Labs LLC

#include "vl/sigv4/verifier.hpp"

#include "vl/sigv4/canonical.hpp"
#include "vl/sigv4/crypto.hpp"

#include <algorithm>
#include <charconv>
#include <cstdint>
#include <map>
#include <set>
#include <utility>
#include <vector>

namespace vl::sigv4 {

namespace {

using HeaderMap = std::map<std::string, std::string>;

std::unexpected<Error> fail(const ErrorCode code, std::string message) {
    return std::unexpected(Error{.code = code, .message = std::move(message)});
}

struct Target {
    std::string_view path;
    std::string_view query;
};

Target splitTarget(const std::string_view target) {
    const auto q = target.find('?');
    if (q == std::string_view::npos) return {.path = target, .query = {}};
    return {.path = target.substr(0, q), .query = target.substr(q + 1)};
}

std::vector<std::string_view> splitView(const std::string_view value, const char sep) {
    std::vector<std::string_view> out;
    std::size_t start = 0;
    while (true) {
        const auto end = value.find(sep, start);
        if (end == std::string_view::npos) {
            out.push_back(value.substr(start));
            return out;
        }
        out.push_back(value.substr(start, end - start));
        start = end + 1;
    }
}

const std::string* firstParam(const QueryParams& params, const std::string_view name) {
    for (const auto& [key, value] : params)
        if (key == name) return &value;
    return nullptr;
}

const std::string* findHeader(const HeaderMap& headers, const std::string_view name) {
    const auto it = headers.find(std::string(name));
    return it == headers.end() ? nullptr : &it->second;
}

std::string payloadSha256(const VerificationInput& input) {
    return input.body_sha256 ? toLower(*input.body_sha256) : sha256Hex(input.body);
}

// A request with neither Content-Length nor Transfer-Encoding has no body (RFC 9112 section 6.3). Only then, and
// only when nothing was read, may a missing Content-Length be taken to be 0.
bool framedWithoutBody(const VerificationInput& input, const HeaderMap& headers) {
    if (headers.contains("content-length") || headers.contains("transfer-encoding")) return false;
    if (!input.body.empty()) return false;
    return !input.body_sha256 || toLower(*input.body_sha256) == kEmptyPayloadSha256;
}

HeaderMap requestHeaders(const VerificationInput& input, const VerifyOptions& options) {
    auto headers = normalizeHeaders(input.headers);
    if (!input.host.empty() && !headers.contains("host")) headers["host"] = canonicalHeaderValue(input.host);
    if (options.imply_zero_content_length && framedWithoutBody(input, headers)) headers["content-length"] = "0";
    return headers;
}

bool isDigits(const std::string_view value) {
    return !value.empty() && std::ranges::all_of(value, [](const char c) { return c >= '0' && c <= '9'; });
}

std::expected<CredentialScope, Error> parseCredentialScope(const std::string_view value,
                                                           const VerifyOptions& options) {
    const auto parts = splitView(value, '/');
    if (parts.size() != 5 || parts[0].empty() || parts[1].size() != 8 || !isDigits(parts[1]) || parts[2].empty() ||
        parts[3].empty() || parts[4] != "aws4_request")
        return fail(ErrorCode::InvalidCredentialScope, "Invalid credential scope");
    if (!options.service.empty() && parts[3] != options.service)
        return fail(ErrorCode::UnsupportedService, "Unsupported SigV4 service");
    if (options.region && parts[2] != *options.region)
        return fail(ErrorCode::RegionMismatch, "Credential scope region does not match");
    return CredentialScope{.access_key = std::string(parts[0]),
                           .date = std::string(parts[1]),
                           .region = std::string(parts[2]),
                           .service = std::string(parts[3])};
}

std::expected<std::chrono::seconds, Error> parseExpires(const std::string* raw, const VerifyOptions& options) {
    if (raw == nullptr || raw->empty()) return fail(ErrorCode::InvalidExpires, "Missing X-Amz-Expires");
    std::uint64_t value = 0;
    const auto* begin = raw->data();
    const auto* end = begin + raw->size();
    const auto [ptr, ec] = std::from_chars(begin, end, value);
    if (!isDigits(*raw) || ec != std::errc{} || ptr != end || value == 0)
        return fail(ErrorCode::InvalidExpires, "Invalid X-Amz-Expires");
    const auto limit = std::min(options.max_presign_expiry, kMaxPresignExpiry);
    if (limit.count() < 0 || value > static_cast<std::uint64_t>(limit.count()))
        return fail(ErrorCode::ExpiresTooLarge, "X-Amz-Expires exceeds maximum allowed value");
    return std::chrono::seconds{static_cast<std::chrono::seconds::rep>(value)};
}

// "AWS4-HMAC-SHA256 Credential=..., SignedHeaders=..., Signature=..." into its parameters.
std::expected<std::map<std::string, std::string>, Error> authParams(const std::string_view header) {
    auto rest = header.substr(kAlgorithm.size());
    if (rest.empty() || (rest.front() != ' ' && rest.front() != '\t'))
        return fail(rest.empty() ? ErrorCode::MalformedAuthorization : ErrorCode::UnsupportedAlgorithm,
                    rest.empty() ? "Malformed Authorization header" : "Unsupported authorization algorithm");

    std::map<std::string, std::string> out;
    for (const auto rawPart : splitView(rest, ',')) {
        const auto part = canonicalHeaderValue(rawPart);
        if (part.empty()) continue;
        const auto eq = part.find('=');
        if (eq == std::string::npos || eq == 0) return fail(ErrorCode::MalformedAuthorization, "Malformed Authorization header");
        if (!out.emplace(part.substr(0, eq), part.substr(eq + 1)).second)
            return fail(ErrorCode::MalformedAuthorization, "Malformed Authorization header");
    }
    if (!out.contains("Credential") || !out.contains("SignedHeaders") || !out.contains("Signature"))
        return fail(ErrorCode::MalformedAuthorization, "Malformed Authorization header");
    return out;
}

// Empty names ("host;;x-amz-date") and repeated names are malformed. An empty list is reported later, by verify().
bool signedHeadersWellFormed(const std::string_view signedHeaders) {
    if (signedHeaders.empty()) return true;
    std::set<std::string> seen;
    for (const auto name : splitView(signedHeaders, ';')) {
        if (name.empty()) return false;
        if (!seen.insert(toLower(name)).second) return false;
    }
    return true;
}

VerifyResult failure(VerifyResult result, const ErrorCode code, std::string message) {
    result.code = code;
    result.body_pending = false;
    result.message = std::move(message);
    return result;
}

VerifyResult failure(const Error& error) {
    VerifyResult result;
    result.code = error.code;
    result.message = error.message;
    return result;
}

// Everything but the signature: dates, signed headers, payload hash. Cheap and secret-free, so it runs before a
// secret lookup.
VerifyResult precheck(const VerificationInput& input, const ParsedAuth& auth, const TimePoint now,
                      const VerifyOptions& options) {
    VerifyResult result;
    result.access_key = auth.credential.access_key;
    result.auth = auth;

    if (auth.amz_date.empty()) return failure(std::move(result), ErrorCode::MissingDate, "Missing x-amz-date");
    const auto date = parseAmzDate(auth.amz_date);
    if (!date) return failure(std::move(result), ErrorCode::InvalidDate, "Invalid x-amz-date");
    if (options.require_scope_date_match && auth.credential.date != std::string_view(auth.amz_date).substr(0, 8))
        return failure(std::move(result), ErrorCode::ScopeDateMismatch, "Credential scope date does not match x-amz-date");

    if (auth.presigned) {
        if (*date - now > options.max_skew)
            return failure(std::move(result), ErrorCode::RequestTimeTooSkewed, "Signature date is outside allowed skew");
        if (now > *date + auth.expires)
            return failure(std::move(result), ErrorCode::PresignExpired, "Request has expired");
    } else if (std::chrono::abs(now - *date) > options.max_skew) {
        return failure(std::move(result), ErrorCode::RequestTimeTooSkewed, "Signature date is outside allowed skew");
    }

    if (auth.signed_headers.empty())
        return failure(std::move(result), ErrorCode::MissingSignedHeaders, "Missing signed headers");
    const auto names = splitView(auth.signed_headers, ';');
    if (options.require_signed_host &&
        std::ranges::none_of(names, [](const std::string_view name) { return toLower(name) == "host"; }))
        return failure(std::move(result), ErrorCode::HostNotSigned, "host is not a signed header");
    if (auth.signature.empty()) return failure(std::move(result), ErrorCode::MissingSignature, "Missing signature");

    const auto headers = requestHeaders(input, options);
    for (const auto name : names) {
        const auto lowered = toLower(name);
        if (!headers.contains(lowered))
            return failure(std::move(result), ErrorCode::SignedHeaderMissing,
                           "Signed header missing from request: " + lowered);
    }

    result.payload_mode = payloadMode(auth.payload_hash);
    switch (result.payload_mode) {
        case PayloadMode::Unsigned:
        case PayloadMode::StreamingUnsignedTrailer: break;
        case PayloadMode::StreamingSigned:
        case PayloadMode::StreamingSignedTrailer:
            if (!options.allow_streaming_signed_payload)
                return failure(std::move(result), ErrorCode::UnsupportedPayloadHash,
                               "Signed streaming payloads are not accepted: " + auth.payload_hash);
            result.body_pending = true;
            break;
        case PayloadMode::Unsupported:
            return failure(std::move(result), ErrorCode::UnsupportedPayloadHash,
                           "Unsupported payload signing mode: " + auth.payload_hash);
        case PayloadMode::Hashed:
            if (toLower(auth.payload_hash) != payloadSha256(input))
                return failure(std::move(result), ErrorCode::PayloadHashMismatch, "Payload hash mismatch");
            break;
    }
    return result;
}

VerifyResult checkSignature(VerifyResult result, const VerificationInput& input, const ParsedAuth& auth,
                            const std::string_view secret, const VerifyOptions& options) {
    result.canonical_request = canonicalRequestFor(input, auth, options);
    result.string_to_sign = stringToSign(auth.amz_date, auth.credential.str(), result.canonical_request);
    const auto expected = signatureHex(
        deriveSigningKey(secret, auth.credential.date, auth.credential.region, auth.credential.service),
        result.string_to_sign);
    if (!constantTimeEqual(toLower(auth.signature), expected))
        return failure(std::move(result), ErrorCode::SignatureMismatch, "Signature mismatch");
    return result;
}

}

std::expected<ParsedAuth, Error> parseAuthorization(const VerificationInput& input, const VerifyOptions& options) {
    const auto params = parseQuery(splitTarget(input.target).query);
    const auto headers = normalizeHeaders(input.headers);
    const auto* authorization = findHeader(headers, "authorization");
    ParsedAuth out;

    if (const auto* algorithm = firstParam(params, "X-Amz-Algorithm")) {
        if (authorization != nullptr)
            return fail(ErrorCode::AmbiguousAuthorization, "Only one authentication mechanism is allowed");
        if (!options.allow_presigned)
            return fail(ErrorCode::MissingAuthorization, "Presigned requests are not accepted");
        if (*algorithm != kAlgorithm) return fail(ErrorCode::UnsupportedAlgorithm, "Unsupported presigned algorithm");

        const auto* credential = firstParam(params, "X-Amz-Credential");
        auto scope = parseCredentialScope(credential ? std::string_view(*credential) : std::string_view{}, options);
        if (!scope) return std::unexpected(scope.error());
        const auto expires = parseExpires(firstParam(params, "X-Amz-Expires"), options);
        if (!expires) return std::unexpected(expires.error());

        const auto value = [&](const std::string_view name) {
            const auto* found = firstParam(params, name);
            return found ? *found : std::string{};
        };
        out.credential = std::move(*scope);
        out.signed_headers = value("X-Amz-SignedHeaders");
        out.signature = value("X-Amz-Signature");
        out.amz_date = value("X-Amz-Date");
        out.payload_hash = singleEncodesPath(out.credential.service) ? std::string(kUnsignedPayload)
                                                                     : payloadSha256(input);
        out.presigned = true;
        out.expires = *expires;
        if (const auto* token = firstParam(params, "X-Amz-Security-Token")) out.session_token = *token;
    } else {
        if (authorization == nullptr || authorization->empty())
            return fail(ErrorCode::MissingAuthorization, "Missing Authorization header");
        if (!authorization->starts_with(kAlgorithm))
            return fail(ErrorCode::UnsupportedAlgorithm, "Unsupported authorization algorithm");
        auto authParameters = authParams(*authorization);
        if (!authParameters) return std::unexpected(authParameters.error());
        auto& fields = *authParameters;

        auto scope = parseCredentialScope(fields.at("Credential"), options);
        if (!scope) return std::unexpected(scope.error());

        out.credential = std::move(*scope);
        out.signed_headers = std::move(fields.at("SignedHeaders"));
        out.signature = std::move(fields.at("Signature"));
        const auto* date = findHeader(headers, "x-amz-date");
        out.amz_date = date ? *date : std::string{};
        const auto* contentSha = findHeader(headers, "x-amz-content-sha256");
        out.payload_hash = contentSha && !contentSha->empty() ? *contentSha : payloadSha256(input);
        if (const auto* token = findHeader(headers, "x-amz-security-token")) out.session_token = *token;
    }

    if (!signedHeadersWellFormed(out.signed_headers))
        return fail(ErrorCode::MalformedAuthorization, out.presigned ? "Malformed X-Amz-SignedHeaders"
                                                                     : "Malformed SignedHeaders");
    if (options.reject_session_tokens && out.session_token && !out.session_token->empty())
        return fail(ErrorCode::SessionTokenNotSupported, "Temporary security tokens are not supported");
    return out;
}

VerifyResult verify(const VerificationInput& input, const ParsedAuth& auth, const std::string_view secret,
                    const TimePoint now, const VerifyOptions& options) {
    auto result = precheck(input, auth, now, options);
    if (!result.ok()) return result;
    return checkSignature(std::move(result), input, auth, secret, options);
}

VerifyResult verify(const VerificationInput& input, const std::string_view secret, const TimePoint now,
                    const VerifyOptions& options) {
    const auto parsed = parseAuthorization(input, options);
    if (!parsed) return failure(parsed.error());
    return verify(input, *parsed, secret, now, options);
}

VerifyResult verify(const VerificationInput& input, const SecretLookup& lookup, const TimePoint now,
                    const VerifyOptions& options) {
    const auto parsed = parseAuthorization(input, options);
    if (!parsed) return failure(parsed.error());
    auto result = precheck(input, *parsed, now, options);
    if (!result.ok()) return result;
    const auto secret = lookup ? lookup(parsed->credential.access_key) : std::nullopt;
    if (!secret) return failure(std::move(result), ErrorCode::UnknownAccessKey, "Unknown access key");
    return checkSignature(std::move(result), input, *parsed, *secret, options);
}

std::string canonicalRequestFor(const VerificationInput& input, const ParsedAuth& auth, const VerifyOptions& options) {
    const auto [path, query] = splitTarget(input.target);
    const auto headers = requestHeaders(input, options);
    return canonicalRequest(input.method, canonicalUriFromWire(path, auth.credential.service),
                            canonicalQueryFromWire(query, auth.presigned), canonicalHeadersFor(headers, auth.signed_headers),
                            auth.signed_headers, auth.payload_hash);
}

std::string signatureFor(const VerificationInput& input, const ParsedAuth& auth, const std::string_view secret,
                         const VerifyOptions& options) {
    const auto toSign = stringToSign(auth.amz_date, auth.credential.str(), canonicalRequestFor(input, auth, options));
    return signatureHex(deriveSigningKey(secret, auth.credential.date, auth.credential.region, auth.credential.service),
                        toSign);
}

}
