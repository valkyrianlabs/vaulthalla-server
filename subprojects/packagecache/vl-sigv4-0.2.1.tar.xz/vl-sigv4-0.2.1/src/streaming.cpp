// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Valkyrian Labs LLC

#include "vl/sigv4/streaming.hpp"

#include "vl/sigv4/canonical.hpp"
#include "vl/sigv4/crypto.hpp"

#include <openssl/crypto.h>

#include <algorithm>
#include <array>
#include <charconv>
#include <stdexcept>

namespace vl::sigv4 {

namespace {

constexpr std::string_view kChunkSignaturePrefix = ";chunk-signature=";
constexpr std::string_view kTrailerSignatureName = "x-amz-trailer-signature";
constexpr std::size_t kSignatureHexLength = 64;

std::unexpected<Error> unexpectedError(const ErrorCode code, std::string message) {
    return std::unexpected(Error{.code = code, .message = std::move(message)});
}

bool isHexDigit(const char c) noexcept {
    return (c >= '0' && c <= '9') || (c >= 'a' && c <= 'f') || (c >= 'A' && c <= 'F');
}

bool isHex(const std::string_view value) noexcept {
    return !value.empty() && std::ranges::all_of(value, isHexDigit);
}

// RFC 9110 token characters (header field names).
bool isTokenChar(const char c) noexcept {
    if ((c >= '0' && c <= '9') || (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z')) return true;
    return std::string_view("!#$%&'*+-.^_`|~").find(c) != std::string_view::npos;
}

std::string hexSize(const std::uint64_t size) {
    std::array<char, 16> buffer{};
    const auto [end, ec] = std::to_chars(buffer.data(), buffer.data() + buffer.size(), size, 16);
    (void)ec;   // 16 hex digits always fit a uint64
    return {buffer.data(), end};
}

std::vector<std::string_view> splitLines(const std::string_view value) {
    std::vector<std::string_view> out;
    std::size_t start = 0;
    while (start <= value.size()) {
        const auto end = std::min(value.find('\n', start), value.size());
        out.push_back(value.substr(start, end - start));
        start = end + 1;
    }
    return out;
}

std::optional<CredentialScope> scopeFromString(const std::string_view scope) {
    std::array<std::string_view, 4> parts{};
    std::size_t start = 0;
    for (std::size_t i = 0; i < parts.size(); ++i) {
        const auto end = scope.find('/', start);
        if ((end == std::string_view::npos) != (i == parts.size() - 1)) return std::nullopt;
        parts[i] = scope.substr(start, end == std::string_view::npos ? std::string_view::npos : end - start);
        start = end + 1;
    }
    if (parts[3] != "aws4_request" || parts[0].empty() || parts[1].empty() || parts[2].empty()) return std::nullopt;
    return CredentialScope{.access_key = {},
                           .date = std::string(parts[0]),
                           .region = std::string(parts[1]),
                           .service = std::string(parts[2])};
}

std::string encodeTrailers(const HeaderList& trailers) {
    std::string out;
    for (const auto& [name, value] : trailers) {
        out += toLower(name);
        out += ':';
        out += canonicalHeaderValue(value);
        out += "\r\n";
    }
    return out;
}

void requireChunkSize(const std::size_t chunkSize) {
    if (chunkSize == 0) throw std::invalid_argument("vl::sigv4: aws-chunked chunk size must be positive");
}

}

void detail::WipedString::wipe() noexcept {
    if (!bytes_.empty()) OPENSSL_cleanse(bytes_.data(), bytes_.size());
    bytes_.clear();
}

// --- seeds and primitives ----------------------------------------------------------------------------------------

std::expected<StreamingSeed, Error> streamingSeed(const VerifyResult& verified) {
    if (!verified.ok()) return std::unexpected(Error{.code = verified.code, .message = verified.message});
    if (!verified.body_pending || !verified.auth)
        return unexpectedError(ErrorCode::UnsupportedPayloadHash, "Not a signed streaming request");
    const auto& auth = *verified.auth;
    return StreamingSeed{.seed_signature = toLower(auth.signature),
                         .amz_date = auth.amz_date,
                         .scope = auth.credential,
                         .trailer = verified.payload_mode == PayloadMode::StreamingSignedTrailer};
}

std::expected<StreamingSeed, Error> streamingSeed(const Signed& signedRequest) {
    const auto contentSha = signedRequest.headers.find("x-amz-content-sha256");
    const auto mode = contentSha == signedRequest.headers.end() ? PayloadMode::Hashed : payloadMode(contentSha->second);
    if (mode != PayloadMode::StreamingSigned && mode != PayloadMode::StreamingSignedTrailer)
        return unexpectedError(ErrorCode::UnsupportedPayloadHash, "Not a signed streaming request");
    const auto date = signedRequest.headers.find("x-amz-date");
    // The string to sign is "AWS4-HMAC-SHA256\n<amz date>\n<scope>\n<hash>".
    const auto lines = splitLines(signedRequest.string_to_sign);
    const auto scope = lines.size() == 4 ? scopeFromString(lines[2]) : std::nullopt;
    if (date == signedRequest.headers.end() || !scope || lines[1] != date->second)
        return unexpectedError(ErrorCode::MalformedAuthorization, "Signed request has no usable x-amz-date or scope");
    return StreamingSeed{.seed_signature = toLower(signedRequest.signature),
                         .amz_date = date->second,
                         .scope = *scope,
                         .trailer = mode == PayloadMode::StreamingSignedTrailer};
}

std::string chunkStringToSign(const std::string_view amzDate, const std::string_view scope,
                              const std::string_view previousSignature, const std::string_view chunkSha256Hex) {
    std::string out(kChunkAlgorithm);
    for (const auto part : {amzDate, scope, previousSignature, kEmptyPayloadSha256, chunkSha256Hex}) {
        out += '\n';
        out += part;
    }
    return out;
}

std::string trailerStringToSign(const std::string_view amzDate, const std::string_view scope,
                                const std::string_view previousSignature, const std::string_view trailersSha256Hex) {
    std::string out(kTrailerAlgorithm);
    for (const auto part : {amzDate, scope, previousSignature, trailersSha256Hex}) {
        out += '\n';
        out += part;
    }
    return out;
}

std::string canonicalTrailers(const HeaderList& trailers) {
    std::string out;
    for (const auto& [name, value] : trailers) {
        out += toLower(name);
        out += ':';
        out += canonicalHeaderValue(value);
        out += '\n';
    }
    return out;
}

std::vector<std::string> parseTrailerNames(const std::string_view xAmzTrailer) {
    std::vector<std::string> out;
    std::size_t start = 0;
    while (start <= xAmzTrailer.size()) {
        const auto end = std::min(xAmzTrailer.find(',', start), xAmzTrailer.size());
        auto name = canonicalHeaderValue(xAmzTrailer.substr(start, end - start));
        if (!name.empty()) out.push_back(toLower(name));
        start = end + 1;
    }
    return out;
}

// --- ChunkVerifier -----------------------------------------------------------------------------------------------

ChunkVerifier::ChunkVerifier(StreamingSeed seed, std::string signingKey)
    : seed_(std::move(seed)), scope_(seed_.scope.str()), key_(std::move(signingKey)),
      previous_(toLower(seed_.seed_signature)) {}

std::expected<ChunkVerifier, Error> ChunkVerifier::forRequest(const VerifyResult& verified,
                                                              const std::string_view secretKey) {
    auto seed = streamingSeed(verified);
    if (!seed) return std::unexpected(seed.error());
    return fromSecret(std::move(*seed), secretKey);
}

ChunkVerifier ChunkVerifier::fromSecret(StreamingSeed seed, const std::string_view secretKey) {
    auto key = deriveSigningKey(secretKey, seed.scope.date, seed.scope.region, seed.scope.service);
    return {std::move(seed), std::move(key)};
}

std::expected<void, Error> ChunkVerifier::fail(const ErrorCode code, std::string message) {
    error_ = Error{.code = code, .message = std::move(message)};
    return std::unexpected(*error_);
}

std::expected<void, Error> ChunkVerifier::beginChunk(const std::string_view signature, const std::uint64_t size) {
    if (error_) return std::unexpected(*error_);
    if (final_) return fail(ErrorCode::MalformedChunkedEncoding, "Chunk after the final chunk");
    if (inChunk_) return fail(ErrorCode::MalformedChunkedEncoding, "Chunk started before the previous one ended");
    declared_ = toLower(signature);
    size_ = size;
    received_ = 0;
    inChunk_ = true;
    return {};
}

std::expected<void, Error> ChunkVerifier::update(const std::string_view data) {
    if (error_) return std::unexpected(*error_);
    if (!inChunk_) return fail(ErrorCode::MalformedChunkedEncoding, "Chunk data outside a chunk");
    if (data.size() > size_ - received_)
        return fail(ErrorCode::MalformedChunkedEncoding, "Chunk data exceeds its declared size");
    hash_.update(data);
    received_ += data.size();
    return {};
}

std::expected<void, Error> ChunkVerifier::endChunk() {
    if (error_) return std::unexpected(*error_);
    if (!inChunk_) return fail(ErrorCode::MalformedChunkedEncoding, "No chunk to end");
    if (received_ != size_) return fail(ErrorCode::IncompleteBody, "Chunk data shorter than its declared size");
    inChunk_ = false;
    const auto expected =
        signatureHex(key_.str(), chunkStringToSign(seed_.amz_date, scope_, previous_, hash_.finishHex()));
    if (!constantTimeEqual(declared_, expected))
        return fail(ErrorCode::ChunkSignatureMismatch, "Chunk signature mismatch (chunk " +
                                                           std::to_string(chunks_ + 1) + ")");
    previous_ = expected;
    declared_.clear();
    ++chunks_;
    decoded_ += size_;
    if (size_ == 0) final_ = true;
    return {};
}

std::expected<void, Error> ChunkVerifier::verifyChunk(const std::string_view signature, const std::string_view data) {
    if (auto r = beginChunk(signature, data.size()); !r) return r;
    if (auto r = update(data); !r) return r;
    return endChunk();
}

std::expected<void, Error> ChunkVerifier::verifyTrailer(const HeaderList& trailers, const std::string_view signature) {
    if (error_) return std::unexpected(*error_);
    if (!seed_.trailer)
        return fail(ErrorCode::MalformedChunkedEncoding, "Trailer signature in a payload signed without trailers");
    if (!final_) return fail(ErrorCode::MalformedChunkedEncoding, "Trailer before the final chunk");
    if (trailerDone_) return fail(ErrorCode::MalformedChunkedEncoding, "Repeated trailer signature");
    const auto expected = signatureHex(
        key_.str(), trailerStringToSign(seed_.amz_date, scope_, previous_, sha256Hex(canonicalTrailers(trailers))));
    if (!constantTimeEqual(toLower(signature), expected))
        return fail(ErrorCode::ChunkSignatureMismatch, "Trailer signature mismatch");
    previous_ = expected;
    trailerDone_ = true;
    return {};
}

std::expected<void, Error> ChunkVerifier::finish() const {
    if (error_) return std::unexpected(*error_);
    if (inChunk_ || !final_)
        return unexpectedError(ErrorCode::IncompleteBody, "Body ended before the final zero-length chunk");
    if (seed_.trailer && !trailerDone_)
        return unexpectedError(ErrorCode::IncompleteBody, "Body ended before the trailer signature");
    return {};
}

bool ChunkVerifier::complete() const noexcept {
    return !error_ && final_ && (!seed_.trailer || trailerDone_);
}

// --- AwsChunkedDecoder -------------------------------------------------------------------------------------------

AwsChunkedDecoder::AwsChunkedDecoder(ChunkedDecoderOptions options) : options_(std::move(options)) {}

AwsChunkedDecoder::AwsChunkedDecoder(ChunkVerifier verifier, ChunkedDecoderOptions options)
    : options_(std::move(options)), verifier_(std::move(verifier)) {}

std::expected<void, Error> AwsChunkedDecoder::fail(const ErrorCode code, std::string message) {
    error_ = Error{.code = code, .message = std::move(message)};
    return std::unexpected(*error_);
}

bool AwsChunkedDecoder::done() const noexcept { return !error_ && state_ == State::Done; }

std::expected<void, Error> AwsChunkedDecoder::feed(const std::string_view bytes, const Sink& sink) {
    if (error_) return std::unexpected(*error_);
    std::size_t i = 0;
    while (i < bytes.size()) {
        switch (state_) {
            case State::ChunkHeader:
            case State::Trailers: {
                const auto rest = bytes.substr(i);
                const auto newline = rest.find('\n');
                const auto take = newline == std::string_view::npos ? rest.size() : newline + 1;
                const bool header = state_ == State::ChunkHeader;
                if (line_.size() + take > options_.max_line_length)
                    return fail(ErrorCode::MalformedChunkedEncoding,
                                header ? "Chunk header too long" : "Trailer line too long");
                if (!header) {
                    trailerBytes_ += take;
                    if (trailerBytes_ > options_.max_trailer_bytes)
                        return fail(ErrorCode::MalformedChunkedEncoding, "Trailer section too large");
                }
                line_.append(rest.substr(0, take));
                i += take;
                if (newline == std::string_view::npos) break;

                std::string_view line(line_);
                line.remove_suffix(1);
                std::expected<void, Error> handled;
                if (header) {
                    if (line.empty() || line.back() != '\r')
                        return fail(ErrorCode::MalformedChunkedEncoding, "Chunk header not terminated by CRLF");
                    line.remove_suffix(1);
                    handled = chunkHeader(line);
                } else {
                    const bool crlf = !line.empty() && line.back() == '\r';
                    if (crlf) line.remove_suffix(1);
                    handled = trailerLine(line, crlf);
                }
                line_.clear();
                if (!handled) return handled;
                break;
            }
            case State::ChunkData: {
                const auto n = static_cast<std::size_t>(
                    std::min<std::uint64_t>(remaining_, static_cast<std::uint64_t>(bytes.size() - i)));
                const auto piece = bytes.substr(i, n);
                if (verifier_) {
                    if (auto r = verifier_->update(piece); !r) return fail(r.error().code, r.error().message);
                }
                if (sink) sink(piece);
                remaining_ -= n;
                decoded_ += n;
                i += n;
                if (remaining_ == 0) state_ = State::ChunkDataCr;
                break;
            }
            case State::ChunkDataCr:
            case State::ChunkDataLf: {
                const char expected = state_ == State::ChunkDataCr ? '\r' : '\n';
                if (bytes[i] != expected)
                    return fail(ErrorCode::MalformedChunkedEncoding,
                                "Chunk data not followed by CRLF (chunk size mismatch)");
                ++i;
                if (state_ == State::ChunkDataCr) {
                    state_ = State::ChunkDataLf;
                    break;
                }
                if (verifier_) {
                    if (auto r = verifier_->endChunk(); !r) return fail(r.error().code, r.error().message);
                }
                state_ = State::ChunkHeader;
                break;
            }
            case State::Done:
                return fail(ErrorCode::MalformedChunkedEncoding, "Data after the end of the aws-chunked body");
        }
    }
    return {};
}

std::expected<void, Error> AwsChunkedDecoder::chunkHeader(const std::string_view line) {
    const auto semi = line.find(';');
    const auto sizeHex = line.substr(0, semi);
    if (sizeHex.size() > 16 || !isHex(sizeHex))
        return fail(ErrorCode::MalformedChunkedEncoding, "Invalid chunk size");
    std::uint64_t size = 0;
    (void)std::from_chars(sizeHex.data(), sizeHex.data() + sizeHex.size(), size, 16);   // at most 16 hex digits

    if (size > options_.max_chunk_size)
        return fail(ErrorCode::ChunkTooLarge, "Chunk of " + std::to_string(size) + " bytes exceeds the limit of " +
                                                  std::to_string(options_.max_chunk_size));
    if (options_.decoded_length && size > *options_.decoded_length - decoded_)
        return fail(ErrorCode::DecodedLengthMismatch, "Body is longer than x-amz-decoded-content-length");

    if (verifier_) {
        const auto extension = semi == std::string_view::npos ? std::string_view{} : line.substr(semi);
        const auto signature = extension.substr(std::min(extension.size(), kChunkSignaturePrefix.size()));
        if (!extension.starts_with(kChunkSignaturePrefix) || signature.size() != kSignatureHexLength ||
            !isHex(signature))
            return fail(ErrorCode::MalformedChunkedEncoding, "Missing or malformed chunk-signature");
        if (auto r = verifier_->beginChunk(signature, size); !r) return fail(r.error().code, r.error().message);
    }

    if (size == 0) {
        if (verifier_) {
            if (auto r = verifier_->endChunk(); !r) return fail(r.error().code, r.error().message);
        }
        state_ = State::Trailers;
    } else {
        remaining_ = size;
        state_ = State::ChunkData;
    }
    return {};
}

std::expected<void, Error> AwsChunkedDecoder::trailerLine(const std::string_view line, const bool crlf) {
    const bool signedTrailer = verifier_ && verifier_->expectsTrailer();
    if (line.empty()) {
        // MinIO's Go client ends each trailer line with a bare LF and then writes a CRLF of its own: before
        // x-amz-trailer-signature ("k:v\n\r\nx-amz-trailer-signature:...\r\n\r\n") and, unsigned, before the final
        // CRLF ("k:v\n\r\n\r\n"). A CRLF right after a bare-LF trailer line separates; it does not end the section.
        if (crlf && afterBareLf_) {
            afterBareLf_ = false;
            return {};
        }
        // With signed trailers nothing ends before x-amz-trailer-signature.
        if (signedTrailer && !trailerSignature_) return {};
        return endOfTrailers();
    }
    afterBareLf_ = !crlf;
    if (trailerSignature_)
        return fail(ErrorCode::MalformedChunkedEncoding, "Trailer after x-amz-trailer-signature");

    const auto colon = line.find(':');
    if (colon == std::string_view::npos || colon == 0 || !std::ranges::all_of(line.substr(0, colon), isTokenChar))
        return fail(ErrorCode::MalformedChunkedEncoding, "Malformed trailer line");
    auto name = toLower(line.substr(0, colon));
    auto value = canonicalHeaderValue(line.substr(colon + 1));

    if (name == kTrailerSignatureName) {
        if (!signedTrailer)
            return fail(ErrorCode::MalformedChunkedEncoding, "x-amz-trailer-signature in a body without signed trailers");
        if (value.size() != kSignatureHexLength || !isHex(value))
            return fail(ErrorCode::MalformedChunkedEncoding, "Malformed x-amz-trailer-signature");
        trailerSignature_ = std::move(value);
        return {};
    }
    if (verifier_ && !signedTrailer)
        return fail(ErrorCode::MalformedChunkedEncoding, "Trailers in a payload signed without trailers");
    if (std::ranges::any_of(trailers_, [&](const auto& trailer) { return trailer.first == name; }))
        return fail(ErrorCode::MalformedChunkedEncoding, "Repeated trailer: " + name);
    trailers_.emplace_back(std::move(name), std::move(value));
    return {};
}

std::expected<void, Error> AwsChunkedDecoder::endOfTrailers() {
    if (verifier_ && verifier_->expectsTrailer()) {
        if (auto r = verifier_->verifyTrailer(trailers_, *trailerSignature_); !r)
            return fail(r.error().code, r.error().message);
    }
    if (options_.declared_trailers) {
        const auto& declared = *options_.declared_trailers;
        const bool same = declared.size() == trailers_.size() &&
                          std::ranges::all_of(declared, [&](const std::string& name) {
                              return std::ranges::any_of(trailers_, [&](const auto& t) { return t.first == name; });
                          });
        if (!same) return fail(ErrorCode::MalformedChunkedEncoding, "Trailers differ from x-amz-trailer");
    }
    state_ = State::Done;
    return {};
}

std::expected<void, Error> AwsChunkedDecoder::finish() {
    if (error_) return std::unexpected(*error_);
    if (state_ != State::Done)
        return fail(ErrorCode::IncompleteBody, state_ == State::Trailers
                                                   ? "aws-chunked body ended inside the trailers"
                                                   : "aws-chunked body ended before the final chunk");
    if (verifier_) {
        if (auto r = verifier_->finish(); !r) return fail(r.error().code, r.error().message);
    }
    if (options_.decoded_length && decoded_ != *options_.decoded_length)
        return fail(ErrorCode::DecodedLengthMismatch, "Body is shorter than x-amz-decoded-content-length");
    return {};
}

// --- ChunkSigner -------------------------------------------------------------------------------------------------

ChunkSigner::ChunkSigner(StreamingSeed seed, const std::string_view secretKey)
    : seed_(std::move(seed)), scope_(seed_.scope.str()),
      key_(deriveSigningKey(secretKey, seed_.scope.date, seed_.scope.region, seed_.scope.service)),
      previous_(toLower(seed_.seed_signature)) {}

std::expected<ChunkSigner, Error> ChunkSigner::forRequest(const Signed& signedRequest,
                                                          const std::string_view secretKey) {
    auto seed = streamingSeed(signedRequest);
    if (!seed) return std::unexpected(seed.error());
    return ChunkSigner(std::move(*seed), secretKey);
}

std::string ChunkSigner::signChunk(const std::string_view data) {
    previous_ = signatureHex(key_.str(), chunkStringToSign(seed_.amz_date, scope_, previous_, sha256Hex(data)));
    return previous_;
}

std::string ChunkSigner::signTrailer(const HeaderList& trailers) {
    previous_ = signatureHex(key_.str(), trailerStringToSign(seed_.amz_date, scope_, previous_,
                                                             sha256Hex(canonicalTrailers(trailers))));
    return previous_;
}

std::string ChunkSigner::encodeChunk(const std::string_view data) {
    if (data.empty()) throw std::invalid_argument("vl::sigv4: the zero-length chunk is encodeFinal()");
    std::string out = hexSize(data.size());
    out += kChunkSignaturePrefix;
    out += signChunk(data);
    out += "\r\n";
    out += data;
    out += "\r\n";
    return out;
}

std::string ChunkSigner::encodeFinal(const HeaderList& trailers) {
    if (!seed_.trailer && !trailers.empty())
        throw std::invalid_argument("vl::sigv4: trailers need STREAMING-AWS4-HMAC-SHA256-PAYLOAD-TRAILER");
    std::string out = "0";
    out += kChunkSignaturePrefix;
    out += signChunk({});
    out += "\r\n";
    if (seed_.trailer) {
        out += encodeTrailers(trailers);
        out += kTrailerSignatureName;
        out += ':';
        out += signTrailer(trailers);
        out += "\r\n";
    }
    out += "\r\n";
    return out;
}

std::string encodeAwsChunked(ChunkSigner& signer, const std::string_view payload, const std::size_t chunkSize,
                             const HeaderList& trailers) {
    requireChunkSize(chunkSize);
    std::string out;
    for (std::size_t offset = 0; offset < payload.size(); offset += chunkSize)
        out += signer.encodeChunk(payload.substr(offset, chunkSize));
    out += signer.encodeFinal(trailers);
    return out;
}

std::string encodeAwsChunkedUnsigned(const std::string_view payload, const std::size_t chunkSize,
                                     const HeaderList& trailers) {
    requireChunkSize(chunkSize);
    std::string out;
    for (std::size_t offset = 0; offset < payload.size(); offset += chunkSize) {
        const auto chunk = payload.substr(offset, chunkSize);
        out += hexSize(chunk.size());
        out += "\r\n";
        out += chunk;
        out += "\r\n";
    }
    out += "0\r\n";
    out += encodeTrailers(trailers);
    out += "\r\n";
    return out;
}

std::uint64_t awsChunkedLength(const std::uint64_t decodedLength, const std::size_t chunkSize, const PayloadMode mode,
                               const HeaderList& trailers) {
    requireChunkSize(chunkSize);
    if (mode != PayloadMode::StreamingSigned && mode != PayloadMode::StreamingSignedTrailer &&
        mode != PayloadMode::StreamingUnsignedTrailer)
        throw std::invalid_argument("vl::sigv4: awsChunkedLength needs a streaming payload mode");
    if (mode == PayloadMode::StreamingSigned && !trailers.empty())
        throw std::invalid_argument("vl::sigv4: trailers need STREAMING-AWS4-HMAC-SHA256-PAYLOAD-TRAILER");
    const bool isSigned = mode != PayloadMode::StreamingUnsignedTrailer;
    const std::uint64_t signature = isSigned ? kChunkSignaturePrefix.size() + kSignatureHexLength : 0;

    const auto chunkLength = [&](const std::uint64_t size) { return hexSize(size).size() + signature + 2 + size + 2; };
    const std::uint64_t full = decodedLength / chunkSize;
    const std::uint64_t rest = decodedLength % chunkSize;
    std::uint64_t total = full * chunkLength(chunkSize) + (rest > 0 ? chunkLength(rest) : 0);

    total += 1 + signature + 2;   // "0[;chunk-signature=...]\r\n"
    if (mode != PayloadMode::StreamingSigned) total += encodeTrailers(trailers).size();
    if (mode == PayloadMode::StreamingSignedTrailer) total += kTrailerSignatureName.size() + 1 + kSignatureHexLength + 2;
    return total + 2;
}

}
