# vl-sigv4

AWS Signature Version 4 for C++23: client signer (`sign`, `presign`) and server verifier (`parseAuthorization`,
`verify`), consolidated from Vaulthalla's four implementations. Owner: **Valkyrian Labs LLC**. License: **MIT**
(`Copyright (c) 2026 Valkyrian Labs LLC`). Repository: `valkyrianlabs/vl-sigv4` (private).

## Map

| Path | What |
| --- | --- |
| `include/vl/sigv4/` | public headers: `types`, `crypto`, `canonical`, `signer`, `verifier`, `streaming` (aws-chunked, chunk signatures), umbrella `sigv4.hpp` |
| `src/` | implementation (one `.cpp` per header, plus `types.cpp`) |
| `tests/` | GoogleTest suite; `tests/vectors/vaulthalla-goldens.txt` is Vaulthalla's characterization fixture |
| `docs/compat-notes.md` | differences from Vaulthalla's four implementations; the migration checklist |
| `ci/` | `run-ci` (verbatim copy from Vaulthalla), slim `Containerfile`, README |
| `.github/workflows/ci.yml` | vps-ci pool, ASan/UBSan build, no-warnings gate, tests, pkg-config consumer check |

## Commands

```bash
meson setup build -Db_sanitize=address,undefined && meson compile -C build && meson test -C build --print-errorlogs
# macOS (Apple clang): PKG_CONFIG_PATH=$(brew --prefix openssl@3)/lib/pkgconfig:/opt/homebrew/lib/pkgconfig meson setup build-mac
./ci/run-ci meson test -C build      # the CI container (Podman); heavy runs go to `ssh dev`
```

## Rules

- **Licensing.** MIT. Every source file (C++, meson, scripts) starts with `// SPDX-License-Identifier: MIT` (or `#`)
  and `Copyright (c) 2026 Valkyrian Labs LLC`. Code may be taken from Vaulthalla (AGPL) only because the LLC owns
  both; never import third-party code.
- **Scope.** Namespace `vl::sigv4`; public headers only under `include/vl/sigv4/`. Dependencies: OpenSSL 3 (libcrypto)
  only; GoogleTest for tests. No Boost (Beast adapters stay in the consumer), no globals, no static mutable state.
- **Time is injected.** Nothing reads a clock: every time-dependent call takes `TimePoint now`.
- **No exceptions on authentication failure.** The verifier returns `VerifyResult` / `std::expected` with an
  `ErrorCode`; only an OpenSSL failure throws. Never log or return secrets.
- **Spec first, byte-compatible.** Signatures follow SigV4 and must stay byte-for-byte compatible with the AWS suite,
  the AWS S3 docs examples, botocore, and Vaulthalla's upstream signer goldens. A change to any expected vector needs
  an independent source (AWS publication, botocore, a hand HMAC computation), never "regenerate to green".
  Behaviour that differs from Vaulthalla goes into `docs/compat-notes.md` in the same change.
- **Builds are silent.** Zero warnings on GCC 14 and clang at `warning_level=3` (CI greps setup and compile output);
  fix causes, never suppress. No file-scope `using namespace`. Tests brace gtest macros inside `if`.
- **Tests with every change**: positive vectors and the negative path. Keep `Robustness` passing under ASan/UBSan.
- **Git.** Work lands on `main` through CI. No tags or releases without Cooper's go-ahead. A vl-release
  `release.toml` is not set up yet.
- Keep `ci/run-ci` identical to Vaulthalla's; the Ubuntu base image digest matches the other Valkyrian Labs C++
  repositories (apthalla).
