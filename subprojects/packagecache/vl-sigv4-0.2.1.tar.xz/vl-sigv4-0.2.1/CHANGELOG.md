# Changelog

All notable changes to vl-sigv4 are recorded here. The format follows [Keep a Changelog](https://keepachangelog.com/),
and versions follow [Semantic Versioning](https://semver.org/) (before 1.0, a minor version may break the API).

## [Unreleased]

## [0.2.1] - 2026-11-03

### Fixed

- `AwsChunkedDecoder` accepts the trailer layout of MinIO's Go client (`mc`, minio-go): each trailer line ends in a bare
  LF and is followed by a CRLF of its own, `name:value\n\r\n\r\n` for `STREAMING-UNSIGNED-PAYLOAD-TRAILER` (what
  `mc cp --checksum` sends). 0.2.0 ended the trailers at that CRLF and refused the final one as data after the end.

### Added

- Tests: uploads captured from mc over plain HTTP (single-chunk and multi-chunk signed streaming, and the unsigned
  trailer layout), verified at the time they were signed.

## [0.2.0] - 2026-11-03

### Added

- Signed streaming payloads (`STREAMING-AWS4-HMAC-SHA256-PAYLOAD` and `STREAMING-AWS4-HMAC-SHA256-PAYLOAD-TRAILER`),
  new header `streaming.hpp`:
  - `ChunkVerifier`: verifies the chunk signature chain from a verified request's seed signature, with chunk data fed
    in pieces of any size, the final zero-length chunk required, and the trailer signature (`AWS4-HMAC-SHA256-TRAILER`)
    in `-TRAILER` mode. `ChunkVerifier::forRequest(result, secret)` builds one from a `verify()` result.
  - `AwsChunkedDecoder`: incremental push parser for aws-chunked bodies, signed (each chunk verified as its data ends)
    or unsigned (`STREAMING-UNSIGNED-PAYLOAD-TRAILER`); trailers, `x-amz-decoded-content-length` and `x-amz-trailer`
    checks, limits on chunk size (16 MiB default), header lines and the trailer section.
  - `ChunkSigner`, `encodeAwsChunked()`, `encodeAwsChunkedUnsigned()`, `awsChunkedLength()`: the client side.
  - Primitives: `chunkStringToSign()`, `trailerStringToSign()`, `canonicalTrailers()`, `parseTrailerNames()`,
    `streamingSeed()`.
- `VerifyOptions::allow_streaming_signed_payload` (off by default): `verify()` then accepts the signed streaming
  payload hashes, checks the seed signature and sets `VerifyResult::body_pending`; the body is unverified until a
  `ChunkVerifier` finishes. `VerifyResult::payload_mode` reports how the body is covered.
- `PayloadMode` and `payloadMode()`, constants `kStreamingSignedPayload`, `kStreamingSignedPayloadTrailer`,
  `kChunkAlgorithm`, `kTrailerAlgorithm`, `kDefaultMaxChunkSize`.
- `ErrorCode`s `MalformedChunkedEncoding`, `ChunkTooLarge` (both `InvalidRequest`), `IncompleteBody`,
  `DecodedLengthMismatch` (both `IncompleteBody`), `ChunkSignatureMismatch` (`SignatureDoesNotMatch`), appended so
  the existing values keep their numbers.
- `Sha256`: incremental SHA-256 (`crypto.hpp`).
- Tests: AWS's published chunked-upload examples (with and without trailers) byte for byte, every seed, chunk and
  trailer signature; round trips; each failure class; randomized robustness of the decoder.

### Changed

- `UnsupportedPayloadHash` now also covers a signed streaming payload without the opt-in (as before) and any other
  `STREAMING-*` mode (SigV4a); its message names the mode.

## [0.1.0] - 2026-11-02

First release: AWS Signature Version 4 consolidated from Vaulthalla's four implementations (relicensed MIT by
Valkyrian Labs LLC, the copyright owner).

### Added

- `sign()`: Authorization-header signing for S3 (single-encoded path, `x-amz-content-sha256`) and every other
  service (double-encoded path), session tokens, `UNSIGNED-PAYLOAD`.
- `presign()`: presigned URLs, `X-Amz-Expires` 1 s to 604800 s, session tokens.
- `parseAuthorization()` and three `verify()` overloads (secret, secret lookup, already parsed): header and presigned
  authentication, ±15 min skew, presign window, signed-header presence, payload hash (`UNSIGNED-PAYLOAD`,
  `STREAMING-UNSIGNED-PAYLOAD-TRAILER`), constant-time comparison, `ErrorCode` results with S3 error code mapping.
- Canonicalization and crypto primitives (`canonical.hpp`, `crypto.hpp`).
- Tests: AWS SigV4 suite vectors, AWS S3 documentation examples, botocore-checked presigns, Vaulthalla's signer and
  verifier goldens (233-record characterization fixture), round trips, verifier negatives, randomized robustness.
- meson build (static library, `vl_sigv4_dep`, `meson.override_dependency('vl-sigv4')`), pkg-config file, CI in
  `ci/run-ci` on the vps-ci pool with ASan/UBSan and a no-warnings gate.
