// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Valkyrian Labs LLC
//
// Signed streaming payloads (STREAMING-AWS4-HMAC-SHA256-PAYLOAD and -TRAILER) and the aws-chunked decoder.
//
// Vectors: AWS S3 API Reference, "Signature Calculations for the Authorization Header: Transferring Payload in
// Multiple Chunks (Chunked Upload)" and "Signature calculations for trailing headers (chunked uploads)": the 66560-byte
// 'a' body in 65536 + 1024 + 0 byte chunks, every canonical request, string to sign and signature as published there.
// Each value was also recomputed by hand (Python hashlib/hmac, independent of this library) before it was pinned.

#include "support.hpp"

#include <gtest/gtest.h>

#include <algorithm>
#include <cctype>
#include <cstdlib>
#include <random>
#include <stdexcept>
#include <string>
#include <vector>

namespace {

namespace sv = vl::sigv4;
using sv::ErrorCode;
using sv::PayloadMode;
using sv::test::at;
using sv::test::k20130524T000000Z;
using sv::test::k20261102T000000Z;
using sv::test::kS3Docs;

const std::string kScope = "20130524/us-east-1/s3/aws4_request";
const std::string kDate = "20130524T000000Z";
const std::string kPayload = std::string(65536 + 1024, 'a');

// --- AWS example: STREAMING-AWS4-HMAC-SHA256-PAYLOAD --------------------------------------------------------------

const std::string kAwsCanonical =
    "PUT\n/examplebucket/chunkObject.txt\n\n"
    "content-encoding:aws-chunked\ncontent-length:66824\nhost:s3.amazonaws.com\n"
    "x-amz-content-sha256:STREAMING-AWS4-HMAC-SHA256-PAYLOAD\nx-amz-date:20130524T000000Z\n"
    "x-amz-decoded-content-length:66560\nx-amz-storage-class:REDUCED_REDUNDANCY\n\n"
    "content-encoding;content-length;host;x-amz-content-sha256;x-amz-date;x-amz-decoded-content-length;"
    "x-amz-storage-class\n"
    "STREAMING-AWS4-HMAC-SHA256-PAYLOAD";
const std::string kAwsStringToSign = "AWS4-HMAC-SHA256\n20130524T000000Z\n20130524/us-east-1/s3/aws4_request\n"
                                     "cee3fed04b70f867d036f722359b0b1f2f0e5dc0efadbc082b76c4c60e316455";
const std::string kAwsSeed = "4f232c4386841ef735655705268965c44a0e4690baa4adea153f7db9fa80a0a9";
const std::string kAwsAuthorization =
    "AWS4-HMAC-SHA256 Credential=AKIAIOSFODNN7EXAMPLE/20130524/us-east-1/s3/aws4_request,SignedHeaders=content-"
    "encoding;content-length;host;x-amz-content-sha256;x-amz-date;x-amz-decoded-content-length;x-amz-storage-class,"
    "Signature=4f232c4386841ef735655705268965c44a0e4690baa4adea153f7db9fa80a0a9";
const std::string kAwsChunk1 = "ad80c730a21e5b8d04586a2213dd63b9a0e99e0e2307b0ade35a65485a288648";
const std::string kAwsChunk2 = "0055627c9e194cb4542bae2aa5492e3c1575bbb81b612b7d234b86a503ef5497";
const std::string kAwsChunk3 = "b6c6ea8a5354eaf15b3cb7646744f4275b71ea724fed81ceb9323e279d449df9";
const std::string kSha256Chunk1 = "bf718b6f653bebc184e1479f1935b8da974d701b893afcf49e701f3e2f9f9c5a";   // 65536 'a'
const std::string kSha256Chunk2 = "2edc986847e209b4016e141a6dc8716d3207350f416969382d431539bf292e4a";   // 1024 'a'

// --- AWS example: STREAMING-AWS4-HMAC-SHA256-PAYLOAD-TRAILER ------------------------------------------------------
// The page's Authorization header lists content-length among the SignedHeaders, but its canonical request (whose
// hash and seed signature it publishes) does not sign content-length; the canonical request is what is pinned here.

const std::string kTrailerCanonical =
    "PUT\n/examplebucket/chunkObject.txt\n\n"
    "content-encoding:aws-chunked\nhost:s3.amazonaws.com\n"
    "x-amz-content-sha256:STREAMING-AWS4-HMAC-SHA256-PAYLOAD-TRAILER\nx-amz-date:20130524T000000Z\n"
    "x-amz-decoded-content-length:66560\nx-amz-storage-class:REDUCED_REDUNDANCY\n"
    "x-amz-trailer:x-amz-checksum-crc32c\n\n"
    "content-encoding;host;x-amz-content-sha256;x-amz-date;x-amz-decoded-content-length;x-amz-storage-class;"
    "x-amz-trailer\n"
    "STREAMING-AWS4-HMAC-SHA256-PAYLOAD-TRAILER";
const std::string kTrailerCanonicalHash = "44d48b8c2f70eae815a0198cc73d7a546a73a93359c070abbaa5e6c7de112559";
const std::string kTrailerSeed = "106e2a8a18243abcf37539882f36619c00e2dfc72633413f02d3b74544bfeb8e";
const std::string kTrailerChunk1 = "b474d8862b1487a5145d686f57f013e54db672cee1c953b3010fb58501ef5aa2";
const std::string kTrailerChunk2 = "1c1344b170168f8e65b41376b44b20fe354e373826ccbbe2c1d40a8cae51e5c7";
const std::string kTrailerChunk3 = "2ca2aba2005185cf7159c6277faf83795951dd77a3a99e6e65d5c9f85863f992";
const std::string kTrailerHash = "1e376db7e1a34a8ef1c4bcee131a2d60a1cb62503747488624e10995f448d774";
const std::string kTrailerSignature = "d81f82fc3505edab99d459891051a732e8730629a2e4a59689829ca17fe2e435";
const sv::HeaderList kCrc32cTrailer{{"x-amz-checksum-crc32c", "sOO8/Q=="}};

std::string withoutSpaces(std::string value) {
    std::erase(value, ' ');
    return value;
}

// The aws-chunked body exactly as the AWS pages show it, written out from their published signatures.
std::string awsBody(const std::string& s1, const std::string& s2, const std::string& s3, const std::string& tail) {
    return "10000;chunk-signature=" + s1 + "\r\n" + std::string(65536, 'a') + "\r\n" + "400;chunk-signature=" + s2 +
           "\r\n" + std::string(1024, 'a') + "\r\n" + "0;chunk-signature=" + s3 + "\r\n" + tail;
}

sv::Request awsRequest(const bool trailer) {
    sv::Request request{.method = "PUT",
                        .host = "s3.amazonaws.com",
                        .path = "/examplebucket/chunkObject.txt",
                        .query = {},
                        .headers = {{"Content-Encoding", "aws-chunked"},
                                    {"x-amz-decoded-content-length", "66560"},
                                    {"x-amz-storage-class", "REDUCED_REDUNDANCY"}},
                        .payload_hash = std::string(trailer ? sv::kStreamingSignedPayloadTrailer
                                                            : sv::kStreamingSignedPayload)};
    if (trailer) request.headers.emplace_back("x-amz-trailer", "x-amz-checksum-crc32c");
    else request.headers.emplace_back("Content-Length", "66824");
    return request;
}

// Decoder options without a designated initializer (every field would have to be named).
sv::ChunkedDecoderOptions decoderOptions(const std::optional<std::uint64_t> decodedLength = std::nullopt,
                                         std::optional<std::vector<std::string>> declaredTrailers = std::nullopt,
                                         const std::size_t maxChunkSize = sv::kDefaultMaxChunkSize) {
    sv::ChunkedDecoderOptions options;
    options.max_chunk_size = maxChunkSize;
    options.decoded_length = decodedLength;
    options.declared_trailers = std::move(declaredTrailers);
    return options;
}

sv::VerifyOptions streamingOptions() {
    sv::VerifyOptions options;
    options.allow_streaming_signed_payload = true;
    return options;
}

struct Decoded {
    std::expected<void, sv::Error> result;
    std::string data;
    sv::HeaderList trailers;
};

// Feeds body in pieces of random size (1 .. maxPiece bytes; maxPiece 0 = in one piece), then finishes.
Decoded decode(sv::AwsChunkedDecoder decoder, const std::string_view body, std::mt19937_64* rng = nullptr,
               const std::size_t maxPiece = 0) {
    Decoded out;
    const sv::AwsChunkedDecoder::Sink sink = [&](const std::string_view data) { out.data.append(data); };
    std::size_t offset = 0;
    while (offset < body.size()) {
        std::size_t n = body.size() - offset;
        if (rng && maxPiece > 0) n = std::min(n, std::uniform_int_distribution<std::size_t>(1, maxPiece)(*rng));
        out.result = decoder.feed(body.substr(offset, n), sink);
        if (!out.result) return out;
        offset += n;
    }
    out.result = decoder.finish();
    out.trailers = decoder.trailers();
    return out;
}

// AWS's request as the server receives it (the published Authorization header, verbatim).
sv::VerificationInput awsReceived(const bool trailer, const std::string& authorization) {
    sv::VerificationInput input{.method = "PUT", .target = "/examplebucket/chunkObject.txt", .host = {},
                                .headers = {{"Host", "s3.amazonaws.com"},
                                            {"x-amz-date", "20130524T000000Z"},
                                            {"x-amz-storage-class", "REDUCED_REDUNDANCY"},
                                            {"Authorization", authorization},
                                            {"x-amz-content-sha256", trailer ? "STREAMING-AWS4-HMAC-SHA256-PAYLOAD-TRAILER"
                                                                             : "STREAMING-AWS4-HMAC-SHA256-PAYLOAD"},
                                            {"Content-Encoding", "aws-chunked"},
                                            {"x-amz-decoded-content-length", "66560"},
                                            {"Content-Length", trailer ? "66946" : "66824"}},
                                .body = {}, .body_sha256 = std::nullopt};
    if (trailer) input.headers.emplace_back("x-amz-trailer", "x-amz-checksum-crc32c");
    return input;
}

TEST(AwsStreamingExample, SignerReproducesSeedAndEveryChunkSignature) {
    const auto s = sv::sign(awsRequest(false), kS3Docs, "us-east-1", "s3", at(k20130524T000000Z));
    EXPECT_EQ(s.canonical_request, kAwsCanonical);
    EXPECT_EQ(s.string_to_sign, kAwsStringToSign);
    EXPECT_EQ(s.signature, kAwsSeed);
    EXPECT_EQ(withoutSpaces(s.authorization), withoutSpaces(kAwsAuthorization));

    auto signer = sv::ChunkSigner::forRequest(s, kS3Docs.secret_key);
    if (!signer) {
        FAIL() << signer.error().message;
    }
    EXPECT_FALSE(signer->trailer());
    EXPECT_EQ(sv::chunkStringToSign(kDate, kScope, kAwsSeed, sv::sha256Hex(std::string(65536, 'a'))),
              "AWS4-HMAC-SHA256-PAYLOAD\n20130524T000000Z\n20130524/us-east-1/s3/aws4_request\n" + kAwsSeed + "\n" +
                  std::string(sv::kEmptyPayloadSha256) + "\n" + kSha256Chunk1);
    EXPECT_EQ(sv::sha256Hex(std::string(1024, 'a')), kSha256Chunk2);

    const auto body = sv::encodeAwsChunked(*signer, kPayload, 65536);
    EXPECT_EQ(body, awsBody(kAwsChunk1, kAwsChunk2, kAwsChunk3, "\r\n"));
    EXPECT_EQ(body.size(), 66824u);
    EXPECT_EQ(sv::awsChunkedLength(kPayload.size(), 65536, PayloadMode::StreamingSigned), 66824u);
    EXPECT_EQ(signer->previousSignature(), kAwsChunk3);
}

TEST(AwsStreamingExample, ChunkSignaturesOneByOne) {
    sv::ChunkSigner signer({.seed_signature = kAwsSeed, .amz_date = kDate,
                            .scope = {.access_key = {}, .date = "20130524", .region = "us-east-1", .service = "s3"},
                            .trailer = false},
                           kS3Docs.secret_key);
    EXPECT_EQ(signer.signChunk(std::string(65536, 'a')), kAwsChunk1);
    EXPECT_EQ(signer.signChunk(std::string(1024, 'a')), kAwsChunk2);
    EXPECT_EQ(signer.signChunk({}), kAwsChunk3);
}

TEST(AwsStreamingExample, VerifierAcceptsThePublishedRequestAndBody) {
    const auto input = awsReceived(false, kAwsAuthorization);
    const auto result = sv::verify(input, kS3Docs.secret_key, at(k20130524T000000Z), streamingOptions());
    ASSERT_TRUE(result.ok()) << result.message;
    EXPECT_TRUE(result.body_pending);
    EXPECT_EQ(result.payload_mode, PayloadMode::StreamingSigned);
    EXPECT_EQ(result.canonical_request, kAwsCanonical);
    EXPECT_EQ(result.string_to_sign, kAwsStringToSign);

    auto verifier = sv::ChunkVerifier::forRequest(result, kS3Docs.secret_key);
    if (!verifier) {
        FAIL() << verifier.error().message;
    }
    EXPECT_EQ(verifier->previousSignature(), kAwsSeed);
    const auto out = decode(sv::AwsChunkedDecoder(std::move(*verifier), decoderOptions(66560)),
                            awsBody(kAwsChunk1, kAwsChunk2, kAwsChunk3, "\r\n"));
    ASSERT_TRUE(out.result.has_value()) << out.result.error().message;
    EXPECT_EQ(out.data, kPayload);
    EXPECT_TRUE(out.trailers.empty());
}

TEST(AwsStreamingExample, ChunkVerifierFedPieceByPiece) {
    auto verifier = sv::ChunkVerifier::fromSecret(
        {.seed_signature = kAwsSeed, .amz_date = kDate,
         .scope = {.access_key = {}, .date = "20130524", .region = "us-east-1", .service = "s3"}, .trailer = false},
        kS3Docs.secret_key);
    ASSERT_TRUE(verifier.beginChunk(kAwsChunk1, 65536).has_value());
    for (int i = 0; i < 64; ++i) {
        ASSERT_TRUE(verifier.update(std::string(1024, 'a')).has_value());
    }
    ASSERT_TRUE(verifier.endChunk().has_value());
    EXPECT_EQ(verifier.previousSignature(), kAwsChunk1);
    EXPECT_FALSE(verifier.finish().has_value());   // no final chunk yet
    // Signatures compare case-insensitively, like the request signature.
    std::string upper = kAwsChunk2;
    std::ranges::transform(upper, upper.begin(), [](const unsigned char c) { return static_cast<char>(std::toupper(c)); });
    ASSERT_TRUE(verifier.verifyChunk(upper, std::string(1024, 'a')).has_value());
    ASSERT_TRUE(verifier.verifyChunk(kAwsChunk3, {}).has_value());
    EXPECT_TRUE(verifier.finish().has_value());
    EXPECT_TRUE(verifier.complete());
    EXPECT_EQ(verifier.chunks(), 3u);
    EXPECT_EQ(verifier.decodedLength(), 66560u);
}

TEST(AwsStreamingExample, NotAcceptedWithoutTheOptIn) {
    const auto result = sv::verify(awsReceived(false, kAwsAuthorization), kS3Docs.secret_key, at(k20130524T000000Z));
    EXPECT_EQ(result.code, ErrorCode::UnsupportedPayloadHash);
    EXPECT_FALSE(result.body_pending);
    EXPECT_EQ(sv::awsErrorCode(result.code), "NotImplemented");
}

TEST(AwsTrailerExample, SignerReproducesSeedChunksAndTrailer) {
    const auto s = sv::sign(awsRequest(true), kS3Docs, "us-east-1", "s3", at(k20130524T000000Z));
    EXPECT_EQ(s.canonical_request, kTrailerCanonical);
    EXPECT_EQ(sv::sha256Hex(s.canonical_request), kTrailerCanonicalHash);
    EXPECT_EQ(s.signature, kTrailerSeed);

    auto signer = sv::ChunkSigner::forRequest(s, kS3Docs.secret_key);
    if (!signer) {
        FAIL() << signer.error().message;
    }
    EXPECT_TRUE(signer->trailer());
    EXPECT_EQ(sv::canonicalTrailers(kCrc32cTrailer), "x-amz-checksum-crc32c:sOO8/Q==\n");
    EXPECT_EQ(sv::sha256Hex(sv::canonicalTrailers(kCrc32cTrailer)), kTrailerHash);
    EXPECT_EQ(sv::trailerStringToSign(kDate, kScope, kTrailerChunk3, kTrailerHash),
              "AWS4-HMAC-SHA256-TRAILER\n20130524T000000Z\n20130524/us-east-1/s3/aws4_request\n" + kTrailerChunk3 +
                  "\n" + kTrailerHash);

    const auto body = sv::encodeAwsChunked(*signer, kPayload, 65536, kCrc32cTrailer);
    EXPECT_EQ(body, awsBody(kTrailerChunk1, kTrailerChunk2, kTrailerChunk3,
                            "x-amz-checksum-crc32c:sOO8/Q==\r\nx-amz-trailer-signature:" + kTrailerSignature +
                                "\r\n\r\n"));
    EXPECT_EQ(body.size(), 66946u);   // the example's Content-Length
    EXPECT_EQ(sv::awsChunkedLength(kPayload.size(), 65536, PayloadMode::StreamingSignedTrailer, kCrc32cTrailer),
              66946u);
}

TEST(AwsTrailerExample, VerifierAcceptsAwsAndMinioTrailerLayouts) {
    const auto authorization = sv::authorizationHeader(
        "AKIAIOSFODNN7EXAMPLE", kScope,
        "content-encoding;host;x-amz-content-sha256;x-amz-date;x-amz-decoded-content-length;x-amz-storage-class;"
        "x-amz-trailer",
        kTrailerSeed);
    const auto result = sv::verify(awsReceived(true, authorization), kS3Docs.secret_key, at(k20130524T000000Z),
                                   streamingOptions());
    ASSERT_TRUE(result.ok()) << result.message;
    EXPECT_TRUE(result.body_pending);
    EXPECT_EQ(result.payload_mode, PayloadMode::StreamingSignedTrailer);
    EXPECT_EQ(result.canonical_request, kTrailerCanonical);

    const auto options = decoderOptions(66560, sv::parseTrailerNames("x-amz-checksum-crc32c"));
    // AWS SDK layout (CRLF after each trailer) and MinIO's Go client layout (LF after each trailer, then CRLF).
    for (const std::string& tail : {"x-amz-checksum-crc32c:sOO8/Q==\r\nx-amz-trailer-signature:" + kTrailerSignature +
                                       "\r\n\r\n",
                                   "x-amz-checksum-crc32c:sOO8/Q==\n\r\nx-amz-trailer-signature:" + kTrailerSignature +
                                       "\r\n\r\n"}) {
        auto verifier = sv::ChunkVerifier::forRequest(result, kS3Docs.secret_key);
        if (!verifier) {
            FAIL() << verifier.error().message;
        }
        const auto out = decode(sv::AwsChunkedDecoder(std::move(*verifier), options),
                                awsBody(kTrailerChunk1, kTrailerChunk2, kTrailerChunk3, tail));
        ASSERT_TRUE(out.result.has_value()) << out.result.error().message;
        EXPECT_EQ(out.data, kPayload);
        EXPECT_EQ(out.trailers, kCrc32cTrailer);
    }
}

TEST(AwsTrailerExample, TamperedTrailerFails) {
    auto verifier = sv::ChunkVerifier::fromSecret(
        {.seed_signature = kTrailerSeed, .amz_date = kDate,
         .scope = {.access_key = {}, .date = "20130524", .region = "us-east-1", .service = "s3"}, .trailer = true},
        kS3Docs.secret_key);
    const auto out = decode(sv::AwsChunkedDecoder(std::move(verifier)),
                            awsBody(kTrailerChunk1, kTrailerChunk2, kTrailerChunk3,
                                    "x-amz-checksum-crc32c:AAAAAA==\r\nx-amz-trailer-signature:" + kTrailerSignature +
                                        "\r\n\r\n"));
    ASSERT_FALSE(out.result.has_value());
    EXPECT_EQ(out.result.error().code, ErrorCode::ChunkSignatureMismatch);
    EXPECT_EQ(out.result.error().message, "Trailer signature mismatch");
}

// --- round trips ---------------------------------------------------------------------------------------------------

const std::string kSecret = "wJalrXUtnFEMI/K7MDENG+bPxRfiCYEXAMPLEKEY";
const sv::Credentials kGateway{.access_key = "VHTESTACCESSKEY", .secret_key = kSecret, .session_token = {}};
const sv::TimePoint kNow = at(k20261102T000000Z) + std::chrono::hours{9};

std::string randomPayload(std::mt19937_64& rng, const std::size_t size) {
    std::uniform_int_distribution<int> byte(0, 255);
    std::string out(size, '\0');
    for (auto& c : out) c = static_cast<char>(byte(rng));
    return out;
}

struct Upload {
    sv::Signed request;
    sv::VerificationInput input;
    std::string body;
    std::string payload;
    sv::HeaderList trailers;
};

Upload makeUpload(const std::string& payload, const std::size_t chunkSize, const PayloadMode mode,
                  const sv::HeaderList& trailers = {}, const sv::Credentials& credentials = kGateway) {
    Upload out{.request = {}, .input = {}, .body = {}, .payload = payload, .trailers = trailers};
    const auto length = sv::awsChunkedLength(payload.size(), chunkSize, mode, trailers);
    sv::Request request{.method = "PUT", .host = "localhost:39000", .path = "/bucket/dir/object.bin", .query = {},
                        .headers = {{"Content-Encoding", "aws-chunked"},
                                    {"Content-Length", std::to_string(length)},
                                    {"x-amz-decoded-content-length", std::to_string(payload.size())}},
                        .payload_hash = {}};
    switch (mode) {
        case PayloadMode::StreamingSigned: request.payload_hash = sv::kStreamingSignedPayload; break;
        case PayloadMode::StreamingSignedTrailer: request.payload_hash = sv::kStreamingSignedPayloadTrailer; break;
        default: request.payload_hash = sv::kStreamingUnsignedPayloadTrailer; break;
    }
    if (!trailers.empty()) {
        std::string names;
        for (const auto& [name, value] : trailers) names += (names.empty() ? "" : ",") + name;
        request.headers.emplace_back("x-amz-trailer", names);
    }
    out.request = sv::sign(request, credentials, "us-east-1", "s3", kNow);
    out.input = {.method = "PUT", .target = out.request.target(), .host = {}, .headers = {}, .body = {},
                 .body_sha256 = std::nullopt};
    for (const auto& [name, value] : out.request.headers) out.input.headers.emplace_back(name, value);
    if (mode == PayloadMode::StreamingUnsignedTrailer) {
        out.body = sv::encodeAwsChunkedUnsigned(payload, chunkSize, trailers);
    } else {
        auto signer = sv::ChunkSigner::forRequest(out.request, credentials.secret_key);
        if (signer) out.body = sv::encodeAwsChunked(*signer, payload, chunkSize, trailers);
    }
    return out;
}

// The server side: verify the headers, then decode and verify the body.
sv::AwsChunkedDecoder serverDecoder(const Upload& upload, const std::string_view secret = kSecret) {
    const auto result = sv::verify(upload.input, secret, kNow, streamingOptions());
    const auto options = decoderOptions(upload.payload.size());
    if (!result.body_pending) return sv::AwsChunkedDecoder(options);
    auto verifier = sv::ChunkVerifier::forRequest(result, secret);
    if (!verifier) throw std::logic_error(verifier.error().message);
    return sv::AwsChunkedDecoder(std::move(*verifier), options);
}

TEST(StreamingRoundTrip, SignedBodiesOfManyShapes) {
    std::mt19937_64 rng(20261103);
    for (const std::size_t size : {std::size_t{0}, std::size_t{1}, std::size_t{8191}, std::size_t{8192},
                                   std::size_t{65536}, std::size_t{65537}, std::size_t{200000}}) {
        for (const std::size_t chunk : {std::size_t{7}, std::size_t{8192}, std::size_t{65536}}) {
            for (const auto mode : {PayloadMode::StreamingSigned, PayloadMode::StreamingSignedTrailer}) {
                const sv::HeaderList trailers =
                    mode == PayloadMode::StreamingSignedTrailer
                        ? sv::HeaderList{{"x-amz-checksum-sha256", "47DEQpj8HBSa+/TImW+5JCeuQeRkm5NMpJWZG3hSuFU="},
                                         {"X-Amz-Checksum-CRC32", " AAAAAA== "}}
                        : sv::HeaderList{};
                const auto upload = makeUpload(randomPayload(rng, size), chunk, mode, trailers);
                const auto verified = sv::verify(upload.input, kSecret, kNow, streamingOptions());
                ASSERT_TRUE(verified.ok()) << verified.message;
                ASSERT_TRUE(verified.body_pending);
                EXPECT_EQ(upload.body.size(), sv::awsChunkedLength(size, chunk, mode, trailers));
                const auto out = decode(serverDecoder(upload), upload.body, &rng, 3000);
                ASSERT_TRUE(out.result.has_value()) << size << "/" << chunk << ": " << out.result.error().message;
                EXPECT_EQ(out.data, upload.payload);
                if (mode == PayloadMode::StreamingSignedTrailer) {
                    EXPECT_EQ(out.trailers, (sv::HeaderList{{"x-amz-checksum-sha256",
                                                             "47DEQpj8HBSa+/TImW+5JCeuQeRkm5NMpJWZG3hSuFU="},
                                                            {"x-amz-checksum-crc32", "AAAAAA=="}}));
                }
            }
        }
    }
}

TEST(StreamingRoundTrip, ByteAtATime) {
    std::mt19937_64 rng(7);
    const auto upload = makeUpload(randomPayload(rng, 20000), 4096, PayloadMode::StreamingSignedTrailer,
                                   {{"x-amz-checksum-crc32c", "sOO8/Q=="}});
    const auto out = decode(serverDecoder(upload), upload.body, &rng, 1);
    ASSERT_TRUE(out.result.has_value()) << out.result.error().message;
    EXPECT_EQ(out.data, upload.payload);
}

TEST(StreamingRoundTrip, SecretLookupOverload) {
    std::mt19937_64 rng(11);
    const auto upload = makeUpload(randomPayload(rng, 70000), 65536, PayloadMode::StreamingSigned);
    std::optional<std::string> looked;
    const sv::SecretLookup lookup = [&](const std::string_view key) -> std::optional<std::string> {
        if (key != kGateway.access_key) return std::nullopt;
        looked = kSecret;
        return kSecret;
    };
    const auto result = sv::verify(upload.input, lookup, kNow, streamingOptions());
    ASSERT_TRUE(result.ok()) << result.message;
    ASSERT_TRUE(looked.has_value());
    auto verifier = sv::ChunkVerifier::forRequest(result, *looked);
    if (!verifier) {
        FAIL() << verifier.error().message;
    }
    const auto out = decode(sv::AwsChunkedDecoder(std::move(*verifier)), upload.body);
    ASSERT_TRUE(out.result.has_value()) << out.result.error().message;
    EXPECT_EQ(out.data, upload.payload);
}

TEST(StreamingRoundTrip, UnsignedTrailerFraming) {
    std::mt19937_64 rng(13);
    const sv::HeaderList trailers{{"x-amz-checksum-crc32", "AAAAAA=="}};
    const auto upload = makeUpload(randomPayload(rng, 100000), 65536, PayloadMode::StreamingUnsignedTrailer, trailers);
    const auto result = sv::verify(upload.input, kSecret, kNow);   // no opt-in needed: nothing is pending
    ASSERT_TRUE(result.ok()) << result.message;
    EXPECT_FALSE(result.body_pending);
    EXPECT_EQ(result.payload_mode, PayloadMode::StreamingUnsignedTrailer);
    EXPECT_EQ(upload.body.size(),
              sv::awsChunkedLength(100000, 65536, PayloadMode::StreamingUnsignedTrailer, trailers));
    const auto out = decode(sv::AwsChunkedDecoder(decoderOptions(100000)), upload.body, &rng, 5000);
    ASSERT_TRUE(out.result.has_value()) << out.result.error().message;
    EXPECT_EQ(out.data, upload.payload);
    EXPECT_EQ(out.trailers, trailers);

    // Chunk extensions are ignored in unsigned framing; a bare LF ends a trailer line, and the CRLF after it only
    // separates (MinIO's Go client: "name:value\n\r\n\r\n").
    const auto ext = decode(sv::AwsChunkedDecoder(), "3;foo=bar\r\nabc\r\n0\r\nx-amz-checksum-crc32:AAAAAA==\n\r\n\r\n");
    ASSERT_TRUE(ext.result.has_value()) << ext.result.error().message;
    EXPECT_EQ(ext.data, "abc");
    EXPECT_EQ(ext.trailers, (sv::HeaderList{{"x-amz-checksum-crc32", "AAAAAA=="}}));
    const auto open = decode(sv::AwsChunkedDecoder(), "3\r\nabc\r\n0\r\nx-amz-checksum-crc32:AAAAAA==\n\r\n");
    ASSERT_FALSE(open.result.has_value());
    EXPECT_EQ(open.result.error().code, ErrorCode::IncompleteBody);
    const auto extra = decode(sv::AwsChunkedDecoder(), "3\r\nabc\r\n0\r\nx-amz-checksum-crc32:AAAAAA==\n\r\n\r\n\r\n");
    ASSERT_FALSE(extra.result.has_value());
    EXPECT_EQ(extra.result.error().code, ErrorCode::MalformedChunkedEncoding);
}

// --- real clients ----------------------------------------------------------------------------------------------------
// Uploads mc (RELEASE.2025-08-13, minio-go v7.0.90) sent over plain HTTP to a capture server on 127.0.0.1, signed with
// the TEST-ONLY capture credential of Vaulthalla's tools/dev/sigv4-capture/ (capture_boto3_mc.sh,
// capture_mc_streaming.sh). Verified at the time they were signed.

const std::string kCaptureAccessKey = "VHCAPTUREFIXTUREKEY00000A";
const std::string kCaptureSecret = "VHcaptureSecretKey0123456789abcdefghijkl";

sv::VerificationInput mcPut(const std::string& target, const std::string& host, const std::string& date,
                            const std::string& contentLength, const std::string& decodedLength,
                            const std::string& authorization, const std::string& payloadHash,
                            const sv::HeaderList& extra = {}) {
    sv::VerificationInput input{.method = "PUT", .target = target, .host = {},
                                .headers = {{"Host", host},
                                            {"User-Agent", "MinIO (linux; amd64) minio-go/v7.0.90 mc/RELEASE.2025-08-13T08-35-41Z"},
                                            {"Content-Length", contentLength},
                                            {"Accept-Encoding", "zstd,gzip"},
                                            {"Authorization", authorization},
                                            {"Content-Type", "text/plain"},
                                            {"X-Amz-Content-Sha256", payloadHash},
                                            {"X-Amz-Date", date},
                                            {"X-Amz-Decoded-Content-Length", decodedLength}},
                                .body = {}, .body_sha256 = std::nullopt};
    for (const auto& header : extra) input.headers.push_back(header);
    return input;
}

sv::TimePoint signedAt(const std::string& date) { return *sv::parseAmzDate(date); }

TEST(MinioClientCaptures, SignedSingleChunk) {
    const auto input = mcPut(
        "/vh-bucket/mc%20dir/a%20b.txt", "127.0.0.1:47111", "20261103T035945Z", "190", "17",
        "AWS4-HMAC-SHA256 Credential=VHCAPTUREFIXTUREKEY00000A/20261103/us-east-1/s3/aws4_request,SignedHeaders=host;"
        "x-amz-content-sha256;x-amz-date;x-amz-decoded-content-length,"
        "Signature=c23ec103127a095e5160a03b025e801e20704cd5f323b9aba4731add63a79c47",
        "STREAMING-AWS4-HMAC-SHA256-PAYLOAD");
    const std::string body =
        "11;chunk-signature=2f6502fa824f44fd47c61c535a7c5994308720d5182f8dce870386e9aeb93799\r\nhello vaulthalla\n\r\n"
        "0;chunk-signature=1fd95ba3c1b35a5b87208698271d0553cde409c8837e13791e75af3100a738a8\r\n\r\n";
    ASSERT_EQ(body.size(), 190u);
    const auto result = sv::verify(input, kCaptureSecret, signedAt("20261103T035945Z"), streamingOptions());
    ASSERT_TRUE(result.ok()) << result.message;
    ASSERT_TRUE(result.body_pending);
    auto verifier = sv::ChunkVerifier::forRequest(result, kCaptureSecret);
    ASSERT_TRUE(verifier.has_value());
    const auto out = decode(sv::AwsChunkedDecoder(std::move(*verifier), decoderOptions(17)), body);
    ASSERT_TRUE(out.result.has_value()) << out.result.error().message;
    EXPECT_EQ(out.data, "hello vaulthalla\n");
}

TEST(MinioClientCaptures, SignedMultiChunk) {
    const auto input = mcPut(
        "/vh-bucket/mc%20dir/big.txt", "127.0.0.1:47121", "20261103T154915Z", "150355", "150000",
        "AWS4-HMAC-SHA256 Credential=VHCAPTUREFIXTUREKEY00000A/20261103/us-east-1/s3/aws4_request,SignedHeaders=host;"
        "x-amz-content-sha256;x-amz-date;x-amz-decoded-content-length,"
        "Signature=dab51fb7afeab44f062422f126789cdeb56f45c6457efd2213017f68c78e570f",
        "STREAMING-AWS4-HMAC-SHA256-PAYLOAD");
    const auto chunk = [](const std::size_t size, const std::string& signature) {
        return sv::test::hexString(size) + ";chunk-signature=" + signature + "\r\n" + std::string(size, 'v') + "\r\n";
    };
    const std::string body = chunk(65536, "048e1441e62ca546addba5172f8be765452c56ca2c72806a9f3fc443102da1e5") +
                             chunk(65536, "749812e4a35e879e92b9e92c90b6fdd3748b7cfb9a89479dfba1cad746b0ad2a") +
                             chunk(18928, "6aa62583cf64bad4854441ce5d9d649af6fa12bdb85132de9c94f94b9f6a6be1") +
                             "0;chunk-signature=23206a7f8562a2beab793c7293b2c7af0ce5b230906a9ec8f8ce431bf641928d\r\n\r\n";
    ASSERT_EQ(body.size(), 150355u);
    const auto result = sv::verify(input, kCaptureSecret, signedAt("20261103T154915Z"), streamingOptions());
    ASSERT_TRUE(result.ok()) << result.message;
    auto verifier = sv::ChunkVerifier::forRequest(result, kCaptureSecret);
    ASSERT_TRUE(verifier.has_value());
    std::mt19937_64 rng(1);
    const auto out = decode(sv::AwsChunkedDecoder(std::move(*verifier), decoderOptions(150000)), body, &rng, 9000);
    ASSERT_TRUE(out.result.has_value()) << out.result.error().message;
    EXPECT_EQ(out.data, std::string(150000, 'v'));
}

TEST(MinioClientCaptures, UnsignedTrailerLayout) {
    // mc cp --checksum CRC32C: STREAMING-UNSIGNED-PAYLOAD-TRAILER, trailer line ended by a bare LF, then CRLF CRLF.
    const auto input = mcPut(
        "/vh-bucket/mc%20dir/sum.txt", "127.0.0.1:47121", "20261103T154915Z", "61", "17",
        "AWS4-HMAC-SHA256 Credential=VHCAPTUREFIXTUREKEY00000A/20261103/us-east-1/s3/aws4_request, SignedHeaders="
        "content-encoding;content-type;host;x-amz-content-sha256;x-amz-date;x-amz-decoded-content-length;x-amz-trailer, "
        "Signature=37447a65e9d990dc62b820640b151f3971e960b3b420b42de0e94523ac935bea",
        "STREAMING-UNSIGNED-PAYLOAD-TRAILER",
        {{"Content-Encoding", "aws-chunked"}, {"X-Amz-Trailer", "x-amz-checksum-crc32c"}});
    const std::string body = "11\r\nhello vaulthalla\n\r\n0\r\nx-amz-checksum-crc32c:3HEteQ==\n\r\n\r\n";
    ASSERT_EQ(body.size(), 61u);
    const auto result = sv::verify(input, kCaptureSecret, signedAt("20261103T154915Z"));
    ASSERT_TRUE(result.ok()) << result.message;
    EXPECT_FALSE(result.body_pending);
    const auto out = decode(sv::AwsChunkedDecoder(decoderOptions(17, sv::parseTrailerNames("x-amz-checksum-crc32c"))),
                            body);
    ASSERT_TRUE(out.result.has_value()) << out.result.error().message;
    EXPECT_EQ(out.data, "hello vaulthalla\n");
    EXPECT_EQ(out.trailers, (sv::HeaderList{{"x-amz-checksum-crc32c", "3HEteQ=="}}));
}

// --- failures ------------------------------------------------------------------------------------------------------

// A signed body of three 8 KiB chunks and the final chunk, split into its chunk encodings.
Upload threeChunks(const PayloadMode mode = PayloadMode::StreamingSigned) {
    std::mt19937_64 rng(17);
    const sv::HeaderList trailers =
        mode == PayloadMode::StreamingSignedTrailer ? sv::HeaderList{{"x-amz-checksum-crc32c", "sOO8/Q=="}}
                                                    : sv::HeaderList{};
    return makeUpload(randomPayload(rng, 3 * 8192), 8192, mode, trailers);
}

std::vector<std::string> splitChunks(const std::string& body) {
    std::vector<std::string> out;
    std::size_t offset = 0;
    while (offset < body.size()) {
        const auto lineEnd = body.find("\r\n", offset);
        const auto size = std::stoull(body.substr(offset, body.find(';', offset) - offset), nullptr, 16);
        const auto end = size == 0 ? body.size() : lineEnd + 2 + size + 2;
        out.push_back(body.substr(offset, end - offset));
        offset = end;
    }
    return out;
}

std::string join(const std::vector<std::string>& parts) {
    std::string out;
    for (const auto& part : parts) out += part;
    return out;
}

ErrorCode decodeError(const Upload& upload, const std::string& body, std::string* message = nullptr) {
    const auto out = decode(serverDecoder(upload), body);
    if (out.result) return ErrorCode::None;
    if (message) *message = out.result.error().message;
    return out.result.error().code;
}

TEST(StreamingFailures, WrongChunkSignature) {
    const auto upload = threeChunks();
    auto chunks = splitChunks(upload.body);
    ASSERT_EQ(chunks.size(), 4u);
    auto badSignature = chunks;
    auto& sig = badSignature[1][std::string("2000;chunk-signature=").size() + 10];
    sig = sig == '0' ? '1' : '0';
    std::string message;
    EXPECT_EQ(decodeError(upload, join(badSignature), &message), ErrorCode::ChunkSignatureMismatch);
    EXPECT_EQ(message, "Chunk signature mismatch (chunk 2)");

    auto badData = chunks;
    badData[2][badData[2].size() - 10] ^= 0x01;
    EXPECT_EQ(decodeError(upload, join(badData)), ErrorCode::ChunkSignatureMismatch);

    auto badFinal = chunks;
    badFinal[3][25] = badFinal[3][25] == 'a' ? 'b' : 'a';
    EXPECT_EQ(decodeError(upload, join(badFinal)), ErrorCode::ChunkSignatureMismatch);

    EXPECT_EQ(decodeError(upload, upload.body), ErrorCode::None);
}

TEST(StreamingFailures, WrongSecret) {
    const auto upload = threeChunks();
    const auto result = sv::verify(upload.input, kSecret, kNow, streamingOptions());
    ASSERT_TRUE(result.ok());
    auto verifier = sv::ChunkVerifier::forRequest(result, "not-the-secret");
    ASSERT_TRUE(verifier.has_value());
    const auto out = decode(sv::AwsChunkedDecoder(std::move(*verifier)), upload.body);
    ASSERT_FALSE(out.result.has_value());
    EXPECT_EQ(out.result.error().code, ErrorCode::ChunkSignatureMismatch);
}

TEST(StreamingFailures, ReorderedChunks) {
    const auto upload = threeChunks();
    auto chunks = splitChunks(upload.body);
    std::swap(chunks[0], chunks[1]);
    EXPECT_EQ(decodeError(upload, join(chunks)), ErrorCode::ChunkSignatureMismatch);
}

TEST(StreamingFailures, DroppedChunk) {
    const auto upload = threeChunks();
    for (std::size_t drop = 0; drop < 3; ++drop) {
        auto chunks = splitChunks(upload.body);
        chunks.erase(chunks.begin() + static_cast<std::ptrdiff_t>(drop));
        // Without a decoded length the chain alone catches it.
        const auto result = sv::verify(upload.input, kSecret, kNow, streamingOptions());
        auto verifier = sv::ChunkVerifier::forRequest(result, kSecret);
        ASSERT_TRUE(verifier.has_value());
        const auto out = decode(sv::AwsChunkedDecoder(std::move(*verifier)), join(chunks));
        ASSERT_FALSE(out.result.has_value()) << drop;
        EXPECT_EQ(out.result.error().code, ErrorCode::ChunkSignatureMismatch) << drop;
    }
}

TEST(StreamingFailures, MissingFinalChunk) {
    const auto upload = threeChunks();
    auto chunks = splitChunks(upload.body);
    chunks.pop_back();
    std::string message;
    EXPECT_EQ(decodeError(upload, join(chunks), &message), ErrorCode::IncompleteBody);
    EXPECT_EQ(message, "aws-chunked body ended before the final chunk");

    // The chain alone, without the framing parser.
    auto verifier = sv::ChunkVerifier::fromSecret(*sv::streamingSeed(sv::verify(upload.input, kSecret, kNow,
                                                                                 streamingOptions())),
                                                  kSecret);
    const auto payload = std::string_view(upload.payload);
    sv::ChunkSigner signer(*sv::streamingSeed(upload.request), kSecret);
    for (std::size_t i = 0; i < 3; ++i) {
        const auto chunk = payload.substr(i * 8192, 8192);
        ASSERT_TRUE(verifier.verifyChunk(signer.signChunk(chunk), chunk).has_value());
    }
    const auto finished = verifier.finish();
    ASSERT_FALSE(finished.has_value());
    EXPECT_EQ(finished.error().code, ErrorCode::IncompleteBody);
    EXPECT_FALSE(verifier.complete());
}

TEST(StreamingFailures, TruncatedData) {
    const auto upload = threeChunks();
    for (const std::size_t cut : {std::size_t{1}, std::size_t{50}, std::size_t{120}, upload.body.size() / 2,
                                  upload.body.size() - 3, upload.body.size() - 1}) {
        EXPECT_EQ(decodeError(upload, upload.body.substr(0, cut)), ErrorCode::IncompleteBody) << cut;
    }
}

TEST(StreamingFailures, ChunkSizeMismatch) {
    const auto upload = threeChunks();
    for (const std::string size : {"1fff", "2001", "1000"}) {
        auto chunks = splitChunks(upload.body);
        chunks[1].replace(0, 4, size);
        std::string message;
        EXPECT_EQ(decodeError(upload, join(chunks), &message), ErrorCode::MalformedChunkedEncoding) << size;
        EXPECT_EQ(message, "Chunk data not followed by CRLF (chunk size mismatch)");
    }
}

TEST(StreamingFailures, OversizeAndMalformedChunkHeaders) {
    const auto upload = threeChunks();
    const auto tail = upload.body.substr(upload.body.find("\r\n"));
    std::string message;
    // An endless header line is refused once it passes the limit, however it is fed.
    const std::string longHeader = "2000;chunk-signature=" + std::string(100000, 'a');
    const auto out = decode(serverDecoder(upload), longHeader + tail, nullptr, 0);
    ASSERT_FALSE(out.result.has_value());
    EXPECT_EQ(out.result.error().code, ErrorCode::MalformedChunkedEncoding);
    EXPECT_EQ(out.result.error().message, "Chunk header too long");
    std::mt19937_64 rng(3);
    const auto pieces = decode(serverDecoder(upload), longHeader, &rng, 7);
    ASSERT_FALSE(pieces.result.has_value());
    EXPECT_EQ(pieces.result.error().message, "Chunk header too long");

    const auto signature = upload.body.substr(4, upload.body.find("\r\n") - 4);   // ";chunk-signature=<64>"
    EXPECT_EQ(decodeError(upload, "1000001" + signature + "\r\n"), ErrorCode::ChunkTooLarge);
    for (const std::string& bad : {std::string("+2000") + signature, std::string(" 2000") + signature,
                                  std::string("0x2000") + signature, std::string("2000 ") + signature,
                                  std::string("00000000000000002000") + signature, std::string(signature),
                                  std::string("2000"), std::string("2000;chunk-signature=abc"),
                                  std::string("2000;chunk-signature=") + std::string(64, 'g'),
                                  std::string("2000;x-other=1") + signature, std::string("2000") + signature + ";x=y"}) {
        EXPECT_EQ(decodeError(upload, bad + "\r\n", &message), ErrorCode::MalformedChunkedEncoding) << bad;
    }
    EXPECT_EQ(decodeError(upload, "2000" + signature + "\n", &message), ErrorCode::MalformedChunkedEncoding);
    EXPECT_EQ(message, "Chunk header not terminated by CRLF");
}

TEST(StreamingFailures, DecodedLengthMismatch) {
    const auto upload = threeChunks();
    auto decodeWith = [&](const std::uint64_t length) {
        const auto result = sv::verify(upload.input, kSecret, kNow, streamingOptions());
        auto verifier = sv::ChunkVerifier::forRequest(result, kSecret);
        return decode(sv::AwsChunkedDecoder(std::move(*verifier), decoderOptions(length)), upload.body);
    };
    const auto longer = decodeWith(upload.payload.size() - 1);
    ASSERT_FALSE(longer.result.has_value());
    EXPECT_EQ(longer.result.error().code, ErrorCode::DecodedLengthMismatch);
    EXPECT_EQ(longer.data.size(), 2u * 8192u);   // refused at the third chunk's header, before its data
    const auto shorter = decodeWith(upload.payload.size() + 1);
    ASSERT_FALSE(shorter.result.has_value());
    EXPECT_EQ(shorter.result.error().code, ErrorCode::DecodedLengthMismatch);
}

TEST(StreamingFailures, DataAfterTheEndAndTrailerMisuse) {
    const auto upload = threeChunks();
    std::string message;
    EXPECT_EQ(decodeError(upload, upload.body + "x", &message), ErrorCode::MalformedChunkedEncoding);
    EXPECT_EQ(message, "Data after the end of the aws-chunked body");

    // Trailers in a body signed without trailers.
    auto chunks = splitChunks(upload.body);
    chunks.back().insert(chunks.back().size() - 2, "x-amz-checksum-crc32:AAAAAA==\r\n");
    EXPECT_EQ(decodeError(upload, join(chunks), &message), ErrorCode::MalformedChunkedEncoding);
    EXPECT_EQ(message, "Trailers in a payload signed without trailers");

    const auto trailerUpload = threeChunks(PayloadMode::StreamingSignedTrailer);
    const auto finalChunk = trailerUpload.body.substr(trailerUpload.body.rfind("0;chunk-signature="));
    const auto withoutTrailers = trailerUpload.body.substr(0, trailerUpload.body.size() - finalChunk.size());
    const auto finalLine = finalChunk.substr(0, finalChunk.find("\r\n") + 2);
    const auto sigLine = finalChunk.substr(finalChunk.find("x-amz-trailer-signature"));
    // Signature missing: the body never ends.
    EXPECT_EQ(decodeError(trailerUpload, withoutTrailers + finalLine + "x-amz-checksum-crc32c:sOO8/Q==\r\n\r\n",
                          &message),
              ErrorCode::IncompleteBody);
    // Trailer dropped (the signature covers it).
    EXPECT_EQ(decodeError(trailerUpload, withoutTrailers + finalLine + sigLine), ErrorCode::ChunkSignatureMismatch);
    // Trailer after the signature, repeated trailers, malformed lines.
    EXPECT_EQ(decodeError(trailerUpload, withoutTrailers + finalLine + sigLine.substr(0, sigLine.size() - 2) +
                                             "x-amz-checksum-crc32c:sOO8/Q==\r\n\r\n",
                          &message),
              ErrorCode::MalformedChunkedEncoding);
    EXPECT_EQ(message, "Trailer after x-amz-trailer-signature");
    EXPECT_EQ(decodeError(trailerUpload, withoutTrailers + finalLine + "x-amz-checksum-crc32c:sOO8/Q==\r\n" +
                                             "X-Amz-Checksum-Crc32c:sOO8/Q==\r\n" + sigLine,
                          &message),
              ErrorCode::MalformedChunkedEncoding);
    EXPECT_EQ(message, "Repeated trailer: x-amz-checksum-crc32c");
    for (const std::string bad : {"no-colon\r\n", ":value\r\n", "bad name:v\r\n", "x-amz-trailer-signature:abc\r\n"}) {
        EXPECT_EQ(decodeError(trailerUpload, withoutTrailers + finalLine + bad + sigLine),
                  ErrorCode::MalformedChunkedEncoding)
            << bad;
    }
    // Declared trailers must match x-amz-trailer.
    const auto result = sv::verify(trailerUpload.input, kSecret, kNow, streamingOptions());
    auto verifier = sv::ChunkVerifier::forRequest(result, kSecret);
    const auto undeclared = decode(
        sv::AwsChunkedDecoder(std::move(*verifier),
                              decoderOptions(std::nullopt, std::vector<std::string>{"x-amz-checksum-sha256"})),
        trailerUpload.body);
    ASSERT_FALSE(undeclared.result.has_value());
    EXPECT_EQ(undeclared.result.error().message, "Trailers differ from x-amz-trailer");
    // A trailer signature in a body without signed trailers.
    const auto unsignedOut = decode(sv::AwsChunkedDecoder(),
                                    "0\r\nx-amz-trailer-signature:" + std::string(64, 'a') + "\r\n\r\n");
    ASSERT_FALSE(unsignedOut.result.has_value());
    EXPECT_EQ(unsignedOut.result.error().code, ErrorCode::MalformedChunkedEncoding);
}

TEST(StreamingFailures, TrailerSectionLimits) {
    const auto many = std::string("0\r\n") + [] {
        std::string lines;
        for (int i = 0; i < 1000; ++i) lines += "x-amz-meta-" + std::to_string(i) + ":" + std::string(20, 'v') + "\r\n";
        return lines;
    }() + "\r\n";
    const auto out = decode(sv::AwsChunkedDecoder(), many);
    ASSERT_FALSE(out.result.has_value());
    EXPECT_EQ(out.result.error().message, "Trailer section too large");
    const auto longLine = decode(sv::AwsChunkedDecoder(), "0\r\nx-a:" + std::string(5000, 'v') + "\r\n\r\n");
    ASSERT_FALSE(longLine.result.has_value());
    EXPECT_EQ(longLine.result.error().message, "Trailer line too long");
}

TEST(StreamingFailures, ErrorsStick) {
    const auto upload = threeChunks();
    auto decoder = serverDecoder(upload);
    const auto first = decoder.feed("zz\r\n");
    ASSERT_FALSE(first.has_value());
    const auto again = decoder.feed(upload.body);
    ASSERT_FALSE(again.has_value());
    EXPECT_EQ(again.error().message, first.error().message);
    const auto finished = decoder.finish();
    ASSERT_FALSE(finished.has_value());
    EXPECT_EQ(finished.error().message, first.error().message);
    EXPECT_FALSE(decoder.done());
}

TEST(StreamingFailures, ChunkVerifierMisuse) {
    const auto upload = threeChunks();
    const auto seed = sv::streamingSeed(sv::verify(upload.input, kSecret, kNow, streamingOptions()));
    ASSERT_TRUE(seed.has_value());
    {
        auto v = sv::ChunkVerifier::fromSecret(*seed, kSecret);
        EXPECT_EQ(v.update("x").error().code, ErrorCode::MalformedChunkedEncoding);
        EXPECT_EQ(v.beginChunk(std::string(64, 'a'), 1).error().code, ErrorCode::MalformedChunkedEncoding);   // sticks
    }
    {
        auto v = sv::ChunkVerifier::fromSecret(*seed, kSecret);
        ASSERT_TRUE(v.beginChunk(std::string(64, 'a'), 2).has_value());
        EXPECT_EQ(v.update("abc").error().message, "Chunk data exceeds its declared size");
    }
    {
        auto v = sv::ChunkVerifier::fromSecret(*seed, kSecret);
        ASSERT_TRUE(v.beginChunk(std::string(64, 'a'), 2).has_value());
        ASSERT_TRUE(v.update("a").has_value());
        EXPECT_EQ(v.endChunk().error().code, ErrorCode::IncompleteBody);
    }
    {
        auto v = sv::ChunkVerifier::fromSecret(*seed, kSecret);
        sv::ChunkSigner signer(*seed, kSecret);
        ASSERT_TRUE(v.verifyChunk(signer.signChunk({}), {}).has_value());
        EXPECT_TRUE(v.complete());
        EXPECT_EQ(v.verifyTrailer({}, std::string(64, 'a')).error().message,
                  "Trailer signature in a payload signed without trailers");
    }
    {
        auto v = sv::ChunkVerifier::fromSecret(*seed, kSecret);
        sv::ChunkSigner signer(*seed, kSecret);
        ASSERT_TRUE(v.verifyChunk(signer.signChunk({}), {}).has_value());
        EXPECT_EQ(v.beginChunk(signer.signChunk("x"), 1).error().message, "Chunk after the final chunk");
    }
}

TEST(StreamingVerify, ResultsAndOptIn) {
    const auto upload = threeChunks();
    // Off by default.
    const auto off = sv::verify(upload.input, kSecret, kNow);
    EXPECT_EQ(off.code, ErrorCode::UnsupportedPayloadHash);
    EXPECT_FALSE(off.body_pending);
    EXPECT_EQ(sv::streamingSeed(off).error().code, ErrorCode::UnsupportedPayloadHash);
    // A bad seed signature still fails, and nothing is pending.
    auto input = upload.input;
    for (auto& [name, value] : input.headers)
        if (name == "authorization") value.back() = value.back() == '0' ? '1' : '0';
    const auto bad = sv::verify(input, kSecret, kNow, streamingOptions());
    EXPECT_EQ(bad.code, ErrorCode::SignatureMismatch);
    EXPECT_FALSE(bad.body_pending);
    EXPECT_FALSE(sv::ChunkVerifier::forRequest(bad, kSecret).has_value());
    // SigV4a streaming stays unsupported.
    auto sigv4a = upload.input;
    for (auto& [name, value] : sigv4a.headers)
        if (name == "x-amz-content-sha256") value = "STREAMING-AWS4-ECDSA-P256-SHA256-PAYLOAD";
    EXPECT_EQ(sv::verify(sigv4a, kSecret, kNow, streamingOptions()).code, ErrorCode::UnsupportedPayloadHash);
    // An ordinary request is not pending, so it has no seed.
    const auto plain = sv::sign(sv::test::makeRequest("GET", "localhost:39000", "/bucket/key"), kGateway, "us-east-1",
                                "s3", kNow);
    sv::VerificationInput plainInput{.method = "GET", .target = plain.target(), .host = {}, .headers = {}, .body = {},
                                     .body_sha256 = std::nullopt};
    for (const auto& [name, value] : plain.headers) plainInput.headers.emplace_back(name, value);
    const auto plainResult = sv::verify(plainInput, kSecret, kNow, streamingOptions());
    ASSERT_TRUE(plainResult.ok()) << plainResult.message;
    EXPECT_FALSE(plainResult.body_pending);
    EXPECT_EQ(plainResult.payload_mode, PayloadMode::Hashed);
    EXPECT_EQ(sv::ChunkVerifier::forRequest(plainResult, kSecret).error().code, ErrorCode::UnsupportedPayloadHash);
    EXPECT_FALSE(sv::ChunkSigner::forRequest(plain, kSecret).has_value());
}

TEST(StreamingVerify, PayloadModesAndNames) {
    EXPECT_EQ(sv::payloadMode("UNSIGNED-PAYLOAD"), PayloadMode::Unsigned);
    EXPECT_EQ(sv::payloadMode("STREAMING-UNSIGNED-PAYLOAD-TRAILER"), PayloadMode::StreamingUnsignedTrailer);
    EXPECT_EQ(sv::payloadMode("STREAMING-AWS4-HMAC-SHA256-PAYLOAD"), PayloadMode::StreamingSigned);
    EXPECT_EQ(sv::payloadMode("STREAMING-AWS4-HMAC-SHA256-PAYLOAD-TRAILER"), PayloadMode::StreamingSignedTrailer);
    EXPECT_EQ(sv::payloadMode("STREAMING-AWS4-ECDSA-P256-SHA256-PAYLOAD"), PayloadMode::Unsupported);
    EXPECT_EQ(sv::payloadMode("streaming-aws4-hmac-sha256-payload"), PayloadMode::Hashed);
    EXPECT_EQ(sv::payloadMode(sv::kEmptyPayloadSha256), PayloadMode::Hashed);
    EXPECT_EQ(sv::parseTrailerNames(" X-Amz-Checksum-CRC32 ,, x-amz-checksum-sha256"),
              (std::vector<std::string>{"x-amz-checksum-crc32", "x-amz-checksum-sha256"}));
    EXPECT_EQ(sv::errorCodeName(ErrorCode::ChunkSignatureMismatch), "ChunkSignatureMismatch");
    EXPECT_EQ(sv::awsErrorCode(ErrorCode::ChunkSignatureMismatch), "SignatureDoesNotMatch");
    EXPECT_EQ(sv::awsErrorCode(ErrorCode::IncompleteBody), "IncompleteBody");
    EXPECT_EQ(sv::awsErrorCode(ErrorCode::DecodedLengthMismatch), "IncompleteBody");
    EXPECT_EQ(sv::awsErrorCode(ErrorCode::MalformedChunkedEncoding), "InvalidRequest");
    EXPECT_EQ(sv::awsErrorCode(ErrorCode::ChunkTooLarge), "InvalidRequest");
    EXPECT_THROW((void)sv::awsChunkedLength(1, 0, PayloadMode::StreamingSigned), std::invalid_argument);
    EXPECT_THROW((void)sv::awsChunkedLength(1, 1, PayloadMode::Hashed), std::invalid_argument);
    EXPECT_THROW((void)sv::encodeAwsChunkedUnsigned("x", 0), std::invalid_argument);
}

TEST(StreamingVerify, IncrementalSha256MatchesOneShot) {
    std::mt19937_64 rng(5);
    const auto data = randomPayload(rng, 100000);
    sv::Sha256 hash;
    for (std::size_t offset = 0; offset < data.size(); offset += 999) hash.update(std::string_view(data).substr(offset, 999));
    EXPECT_EQ(hash.finishHex(), sv::sha256Hex(data));
    EXPECT_EQ(hash.finishHex(), sv::kEmptyPayloadSha256);   // reset after finish
}

// --- robustness ------------------------------------------------------------------------------------------------------

std::size_t iterations() {
    if (const char* env = std::getenv("VL_SIGV4_FUZZ_ITERATIONS"); env && *env) return std::strtoull(env, nullptr, 10);
    return 3000;
}

const std::vector<std::string> kTokens{"\r\n", "\r", "\n", "0", "1", "f", "F", "10", ";", ";chunk-signature=",
                                       "chunk-signature=", ":", "x-amz-trailer-signature:", "x-amz-checksum-crc32c:",
                                       " ", "\t", std::string(1, '\0'), "\xff", "ffffffffffffffff", "0\r\n\r\n"};

std::string mutate(std::string value, std::mt19937_64& rng) {
    std::uniform_int_distribution<int> op(0, 5);
    std::uniform_int_distribution<int> byte(0, 255);
    const auto rounds = std::uniform_int_distribution<int>(1, 3)(rng);
    for (int r = 0; r < rounds && !value.empty(); ++r) {
        std::uniform_int_distribution<std::size_t> pos(0, value.size() - 1);
        switch (op(rng)) {
            case 0: value[pos(rng)] = static_cast<char>(byte(rng)); break;
            case 1: value[pos(rng)] ^= static_cast<char>(1 << (byte(rng) % 8)); break;
            case 2: value.erase(pos(rng), std::uniform_int_distribution<std::size_t>(1, 8)(rng)); break;
            case 3: value.insert(pos(rng), 1, static_cast<char>(byte(rng))); break;
            case 4: value.resize(pos(rng)); break;
            default: value.insert(pos(rng), kTokens[static_cast<std::size_t>(byte(rng)) % kTokens.size()]); break;
        }
    }
    return value;
}

// Mutated signed bodies must never crash, throw or trip the sanitizers, and whenever one still verifies it must
// decode to exactly the signed payload and trailers. Splitting the input differently never changes the outcome.
TEST(StreamingRobustness, MutatedSignedBodiesNeverVerifyAsSomethingElse) {
    std::mt19937_64 rng(0x5eed5eed);
    std::vector<Upload> bases;
    for (const auto mode : {PayloadMode::StreamingSigned, PayloadMode::StreamingSignedTrailer}) {
        const sv::HeaderList trailers = mode == PayloadMode::StreamingSignedTrailer
                                            ? sv::HeaderList{{"x-amz-checksum-crc32c", "sOO8/Q=="}}
                                            : sv::HeaderList{};
        bases.push_back(makeUpload(randomPayload(rng, 300), 64, mode, trailers));
        bases.push_back(makeUpload(randomPayload(rng, 5000), 2048, mode, trailers));
        bases.push_back(makeUpload({}, 64, mode, trailers));
    }
    std::size_t verified = 0;
    for (std::size_t i = 0; i < iterations(); ++i) {
        const auto& base = bases[i % bases.size()];
        const auto body = mutate(base.body, rng);
        const auto whole = decode(serverDecoder(base), body);
        const auto split = decode(serverDecoder(base), body, &rng, 17);
        ASSERT_EQ(whole.result.has_value(), split.result.has_value()) << i;
        if (!whole.result) {
            EXPECT_EQ(whole.result.error().code, split.result.error().code) << i;
            EXPECT_NE(whole.result.error().code, ErrorCode::None);
            continue;
        }
        ++verified;
        EXPECT_EQ(whole.data, base.payload) << i;
        EXPECT_EQ(split.data, base.payload) << i;
        EXPECT_EQ(whole.trailers, sv::HeaderList(base.trailers.begin(), base.trailers.end())) << i;
    }
    EXPECT_LT(verified, iterations());   // benign mutations (hex case, a CR dropped from a trailer line) are rare
}

TEST(StreamingRobustness, RandomInputNeverCrashes) {
    std::mt19937_64 rng(0xc0ffee);
    std::uniform_int_distribution<std::size_t> count(0, 40);
    std::uniform_int_distribution<std::size_t> pick(0, kTokens.size() - 1);
    std::uniform_int_distribution<int> byte(0, 255);
    const auto upload = threeChunks(PayloadMode::StreamingSignedTrailer);
    for (std::size_t i = 0; i < iterations(); ++i) {
        std::string body;
        const auto n = count(rng);
        for (std::size_t t = 0; t < n; ++t) {
            if (byte(rng) % 3 == 0) body.push_back(static_cast<char>(byte(rng)));
            else body += kTokens[pick(rng)];
        }
        const auto signedOut = decode(serverDecoder(upload), body, &rng, 5);
        EXPECT_FALSE(signedOut.result.has_value()) << i;
        const auto unsignedWhole = decode(sv::AwsChunkedDecoder(decoderOptions(std::nullopt, std::nullopt, 64)), body);
        const auto unsignedSplit = decode(sv::AwsChunkedDecoder(decoderOptions(std::nullopt, std::nullopt, 64)), body, &rng, 3);
        ASSERT_EQ(unsignedWhole.result.has_value(), unsignedSplit.result.has_value()) << i;
        EXPECT_EQ(unsignedWhole.data, unsignedSplit.data) << i;
    }
}

}
