# Compatibility notes: Vaulthalla's four SigV4 implementations and vl-sigv4

vl-sigv4 replaces four AWS Signature Version 4 implementations in Vaulthalla (vaulthalla-server, `core/`):

| Name | Code | Role |
| --- | --- | --- |
| **upstream** | `storage::s3::sigv4::sign` (`src/storage/s3/sigv4/Signer.cpp`) | general signer: upstream control plane, versioning, STS/SQS/R2 admin |
| **legacy** | `storage::s3::curl::buildAuthorizationHeader` + `canonicalQueryString` (`src/storage/s3/curl/helpers.cpp`) | vault data path |
| **ses** | `signAwsV4` (`src/email/providers/SesProvider.cpp`) | SES v2 SendEmail |
| **gateway** | `protocols::s3::sigv4` (`src/protocols/s3/SigV4.cpp`, used by `Auth.cpp`) | S3 gateway verifier |

The library follows the SigV4 specification, which is what **upstream** (signing) and **gateway** (verifying)
already do; where legacy or ses deviate, migrating them changes their output, and every such change is a fix.

Evidence: `tests/vectors/vaulthalla-goldens.txt` is Vaulthalla's characterization fixture (vaulthalla-server
PR #306, 233 records, 25 request shapes, all four implementations). `tests/test_vaulthalla_goldens.cpp` rebuilds
every case with this library and asserts that:

- `sign()` reproduces **every upstream record** byte for byte (authorization, canonical request, string to sign);
- the verifier reproduces **every gateway record** for S3 and accepts every case (the one non-S3 difference is
  item 3 below);
- legacy and ses differ from the library on exactly a pinned set of cases, all explained here
  (`VaulthallaGoldens.KnownDeviationsOfLegacyAndSes`).

`tests/test_s3_vectors.cpp` additionally pins goldens captured from upstream's `Signer.cpp` (Vaulthalla commit
`608aac48`) for ranges, `versionId` with `+ / =`, keys with spaces and UTF-8, `UNSIGNED-PAYLOAD`, session tokens,
multipart, copy, R2, STS, SQS and SES.

## Signing: where the four disagree

1. **Header values.** upstream trims and collapses runs of spaces/tabs; the gateway does the same for every
   `isspace()` character; **legacy and ses sign values verbatim**. The library trims and collapses (space, `\t`,
   `\n`, `\v`, `\f`, `\r`), per the spec. A legacy- or ses-signed request with a header value that has leading,
   trailing or repeated whitespace fails at AWS and at the gateway today (fixture case
   `s3/put-object-headers-case-and-space`: legacy signs `x-amz-meta-owner:  Cooper   Larson `). Migrating changes
   signatures only for such headers. Against upstream, the library differs only for values containing `\r \n \v \f`,
   which are not valid in HTTP field values.
2. **Query.** ses signs the query as written: unsorted, and a flag parameter stays bare (`lifecycle`). Everyone else
   sorts by name then value (byte order) and writes `lifecycle=`, as the spec says. The library sorts and writes
   `name=`. (SendEmail has no query, so ses's real request is unaffected.) Flavours the library offers:
   - `canonicalQuery(QueryParams)`: raw pairs, RFC 3986-encoded and sorted (upstream; what `sign()` uses).
   - `sortEncodedQuery(std::string_view)`: an already-encoded query sorted **without** re-encoding, empty parts
     dropped, bare names given `=` (exactly legacy's `canonicalQueryString`).
   - `canonicalQueryFromWire(query, omitSignature)`: decode, re-encode, sort (the gateway).
3. **Non-S3 path encoding.** The canonical URI for services other than S3 is the path *as sent on the wire* URI-encoded
   once more ("double encoding"); S3 uses the wire path itself. upstream takes raw paths, puts `uriEncode(path)` on the
   wire and double-encodes in the canonical request (`/ሴ` → wire `/%E1%88%B4` → canonical `/%25E1%2588%25B4`).
   legacy, ses and the gateway never double-encode. Arbiters:
   - the AWS suite's `get-utf8` and `get-space` put *unencoded* bytes on the wire (`GET /ሴ`), so their published
     signatures (`8318018e…`, `65248758…`) are the wire path encoded once. The library's verifier verifies those exact
     requests (`AwsSuiteVerify.RawWirePathsVerifyWithPublishedSignatures`);
   - botocore 1.34 `SigV4Auth` on the URL `/%E1%88%B4` signs canonical `/%25E1%2588%25B4` (signature `697b3484…`),
     which is what `sign()` produces for the raw path `/ሴ`.

   So the library keeps upstream's rule. For the gateway this matters only if it ever verifies a non-S3 service (it
   accepts `s3` only); for legacy (S3 only) and ses (`/v2/email/outbound-emails` has nothing to encode) it changes no
   real request. Paths are never normalized (`.`, `..`, `//` kept), like upstream.
4. **Service in the scope.** legacy hard-codes `s3`, ses hard-codes `ses`, the gateway accepts `s3` only. The library
   takes the service as a parameter (`sign`, `presign`) or option (`VerifyOptions::service`, default `s3`). S3 is the
   only service that single-encodes the path and gets `x-amz-content-sha256` added (`singleEncodesPath`).
5. **Time.** legacy takes `x-amz-date` from the caller's header map but the scope date from the system clock
   (`getDate()`), so a request signed across midnight UTC gets mismatched dates and fails. upstream and ses derive
   both from one `time_t`; the gateway reads `std::time(nullptr)` itself. The library never reads a clock: every
   call takes `TimePoint now` (`std::chrono::system_clock::time_point`), and both dates come from it
   (`Dates.ScopeDateAndAmzDateComeFromTheSameInstant`); the verifier rejects a scope date that differs from
   `x-amz-date` (`ScopeDateMismatch`, as AWS does).
6. **Header names and repeated headers.** upstream and the gateway lower-case names; legacy and ses use the map keys
   as given (callers lower-case them). Repeated names: upstream's `std::map` kept one value; the gateway kept the
   first value Beast emplaced. The library takes a `HeaderList` (vector of pairs) and combines repeated names with `,`
   in order, per the spec (AWS suite `get-header-key-duplicate`, `get-header-value-order`).
7. **Session tokens.** Only upstream signs them (`x-amz-security-token` header, or `X-Amz-Security-Token` for
   presign). legacy and ses cannot; the gateway refuses them (`Auth.cpp`). The library signs them and verifies them
   unless `VerifyOptions::reject_session_tokens` is set.
8. **Payload hash.** ses hashes the body itself and so cannot sign `UNSIGNED-PAYLOAD`; legacy and upstream take the
   caller's hash. With the library an empty `Request::payload_hash` means the empty body's hash (upstream signed an
   empty string there, which no caller did).
9. **Which headers are signed.** upstream signs every header of the request plus `host`, `x-amz-date`,
   `x-amz-content-sha256` (S3) and `x-amz-security-token`; `sign()` does the same and overrides caller-supplied
   copies of those four. legacy and ses sign exactly the map they are given; with the library they pass their extra
   headers in `Request::headers`. For hand-built requests the primitives (`canonicalHeaders`, `canonicalRequest`,
   `stringToSign`, `deriveSigningKey`, `signatureHex`, `authorizationHeader`) compose to the same bytes
   (`Primitives.ComposeToTheSameSignature`).

## Verifying: library vs the gateway

Kept from the gateway: the request shape (method, raw target, host, headers, body or a precomputed body hash), S3
path normalization (decode then re-encode), query normalization, `UNSIGNED-PAYLOAD` and
`STREAMING-UNSIGNED-PAYLOAD-TRAILER` skip the body check, ±15 min skew, presign window, X-Amz-Expires ≤ 604800,
constant-time signature comparison (now `CRYPTO_memcmp`), case-insensitive hex signatures, and the implied
`content-length: 0` for bodiless requests whose `Content-Length` a proxy dropped (`imply_zero_content_length`, on by
default). The messages of the shared failures are the gateway's ("Signature mismatch", "Payload hash mismatch",
"Signed header missing from request: <name>", "Invalid X-Amz-Expires", "Missing X-Amz-Expires", "X-Amz-Expires
exceeds maximum allowed value", "Signature date is outside allowed skew", "Missing Authorization header",
"Malformed Authorization header", "Invalid credential scope", "Unsupported SigV4 service", ...). Every result also has
an `ErrorCode`, and `awsErrorCode()` gives the S3 error code to answer with.

Deliberate differences (all rejections of requests AWS also rejects, unless noted):

| Gateway | Library |
| --- | --- |
| `verify(input, secret)`; clock read inside | `verify(input, secret, now, options)`, `verify(input, SecretLookup, now, options)` (lookup called once, only after the secret-free checks pass), `verify(input, ParsedAuth, secret, now, options)` |
| Percent-decoding through `strtoul`: `%+1`, `% 1`, `%-1` decoded as bytes | strict: only `%` + two hex digits |
| `X-Amz-Expires=0` meant "never expires" | rejected (`InvalidExpires`) |
| Expired presign reported as "Signature date is outside allowed skew" | `PresignExpired`, "Request has expired" |
| Lenient `x-amz-date` (`get_time`, ≥ 16 chars, trailing junk ignored) | exactly `YYYYMMDD'T'HHMMSS'Z'`, valid calendar date (`InvalidDate`) |
| Scope date not compared with `x-amz-date` | must match (`ScopeDateMismatch`; option `require_scope_date_match`) |
| Region not checked | optional `VerifyOptions::region` (`RegionMismatch`) |
| `host` need not be signed | must be signed (`HostNotSigned`; option `require_signed_host`) |
| Authorization header and presigned query both present: presigned wins | rejected (`AmbiguousAuthorization`) |
| Presigned when `X-Amz-Algorithm` is non-empty | presigned when the parameter is present |
| `AWS4-HMAC-SHA256X …` accepted (prefix match) | the algorithm must be followed by whitespace |
| Authorization parts without `=` ignored; repeated parameters: last wins | malformed |
| Credential split with `getline` (a trailing `/` accepted); date and access key not validated | exactly 5 parts, non-empty key and region, 8-digit date |
| Empty names in SignedHeaders skipped | empty or repeated names are malformed |
| Signed streaming payloads (`STREAMING-AWS4-HMAC-SHA256-PAYLOAD`) fail as "Payload hash mismatch" | `UnsupportedPayloadHash` by default; accepted with `allow_streaming_signed_payload`, body verified by `ChunkVerifier` (next section) |
| `X-Amz-Signature` dropped from the canonical query for header-signed requests too | dropped only for presigned requests (a header-signed request with that parameter now verifies) |
| Non-S3 canonical URI single-encoded | the wire path encoded once more (item 3) |
| Session tokens rejected in `Auth.cpp` before the secret lookup | `VerifyOptions::reject_session_tokens` (`SessionTokenNotSupported`, maps to `InvalidToken`) |
| Repeated request headers: first value | combined with `,` |
| Body copied into `VerificationInput` | `std::string_view body` (must outlive the call) or `body_sha256` |
| `inputFromRequest` (Boost.Beast) in the header | not in the library: keep it in Vaulthalla, filling `vl::sigv4::VerificationInput` |

## Signed streaming and aws-chunked framing: library vs the gateway's decoder

The gateway decodes aws-chunked bodies itself (`decodeAwsChunkedBody` in `src/protocols/s3/Session.cpp`): it spools
the raw body to a file, then decodes it into a second one, ignoring chunk signatures. It never accepted signed
streaming payloads (they failed as "Payload hash mismatch", and since vaulthalla-server #309 as `NotImplemented`).
The library owns the framing parser (`AwsChunkedDecoder`), so the gateway keeps one parser: the library's, for signed
and unsigned bodies alike. Its seed is the request `verify()` accepted (`VerifyResult::body_pending`); the signature
chain is AWS's ("Transferring Payload in Multiple Chunks", "Signature calculations for trailing headers"), pinned by
both published examples byte for byte (`tests/test_streaming.cpp`).

| Gateway decoder | Library (`AwsChunkedDecoder`) |
| --- | --- |
| Chunk signatures ignored; signed streaming refused before decoding | verified chunk by chunk (`ChunkVerifier`), final zero-length chunk and, with `-TRAILER`, `x-amz-trailer-signature` required |
| Chunk size through `strtoull`: leading whitespace, `+`/`-`, `0x` accepted, any number of digits | 1 to 16 hex digits, nothing else |
| No chunk size limit (only the request body limit) | `max_chunk_size`, 16 MiB by default (`ChunkTooLarge`), as MinIO |
| Header and trailer lines of any length (`getline`) | `max_line_length` 4096 per line, `max_trailer_bytes` 16 KiB for the trailers |
| A chunk header ended by a bare LF accepted | CRLF required; trailer lines may end in a bare LF, and a CRLF right after such a line separates rather than ends (MinIO's Go client: `name:value\n\r\n` then `x-amz-trailer-signature:…\r\n\r\n`, or unsigned the final `\r\n`) |
| Extensions after `;` ignored | ignored in unsigned framing; with signatures exactly `;chunk-signature=<64 hex>` |
| Trailer lines without `:` skipped; repeated names: last wins | malformed (`MalformedChunkedEncoding`); names must be tokens |
| Trailers not compared with `x-amz-trailer` | optional `declared_trailers` (exactly those names) |
| Bytes after the trailers ignored | `MalformedChunkedEncoding` |
| `x-amz-decoded-content-length` compared after decoding | optional `decoded_length`, refused at the first chunk header that would exceed it, and checked at the end (`DecodedLengthMismatch`) |
| Framing errors thrown as `std::runtime_error`: the connection closes without an S3 error | an `Error` (`MalformedChunkedEncoding`, `ChunkTooLarge` → `InvalidRequest`; `IncompleteBody`, `DecodedLengthMismatch` → `IncompleteBody`; `ChunkSignatureMismatch` → `SignatureDoesNotMatch`) |
| Whole raw body decoded from a file | push parser fed in pieces of any size; decoded data passed on as it arrives (unverified until `finish()`) |

Two details the AWS pages leave open, settled as the clients do:

- **Canonical trailers.** Each trailer as `<lower-case name>:<trimmed value>\n`, in the order received (AWS's example
  hashes `x-amz-checksum-crc32c:sOO8/Q==\n`; the SDKs send one checksum trailer; MinIO's Go client hashes its lines in
  the order it writes them). Not sorted.
- **The trailer example's Authorization header** lists `content-length` among the SignedHeaders while its canonical
  request (the one whose hash and seed signature the page publishes) does not sign it. The tests pin the canonical
  request.

## Migration checklist (Vaulthalla)

- **upstream callers** (`version.cpp`, `stream.cpp`, `provider/admin/Internal.cpp`, `AwsEvents.cpp`): replace
  `std::time(nullptr)` with `vl::sigv4::Clock::now()` (or keep `from_time_t`), and `headers["x"] = v` with
  `headers.emplace_back("x", v)`. Output is byte-identical.
- **legacy** (`buildAuthorizationHeader`): move to `sign()` with the raw key path and raw query pairs (drop the
  per-segment `curl_easy_escape`, which `sign()`'s encoding equals for S3). Signatures change only for headers with
  extra whitespace (item 1) and across midnight (item 5), both fixes. `sortEncodedQuery()` is there for any caller
  that must keep a pre-encoded query.
- **ses**: `sign()` with service `ses`, `Content-Type` and `X-Amz-Content-Sha256` in `Request::headers`; SendEmail
  is byte-identical (fixture case `ses/send-email`).
- **gateway** (`Auth.cpp`, `Router.cpp`): build `VerificationInput` from the Beast request; `parseAuthorization`
  (options: `service = "s3"`, `reject_session_tokens = true`) to get the access key, look the credential up, then
  `verify(input, parsed, secret, now, options)`; map failures with `awsErrorCode(code, parsed.presigned)` (today
  everything is `SignatureDoesNotMatch` / `InvalidToken`). Gateway tests that assert exact messages keep passing for
  the shared failures; `RejectsPresignedUrlsDatedTooFarInFuture` and `RejectsMalformedPresignedExpiresWithoutThrowing`
  are ported in `tests/test_verifier.cpp`.
- **signed streaming** (gateway): set `allow_streaming_signed_payload`; when `verify()` returns `body_pending`, decode
  the raw body with `AwsChunkedDecoder(ChunkVerifier::forRequest(result, secret), {decoded_length, declared_trailers})`
  in place of `decodeAwsChunkedBody` (unsigned aws-chunked bodies use `AwsChunkedDecoder()` too, before `verify()`, so
  a hashed payload can be compared with the decoded body), and touch no object until `finish()` succeeds. Map the new
  codes in `sigv4StatusFor` (`ChunkSignatureMismatch` 403; the framing codes 400).
