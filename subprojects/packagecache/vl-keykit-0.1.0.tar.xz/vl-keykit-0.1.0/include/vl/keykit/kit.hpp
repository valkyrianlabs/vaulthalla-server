// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Valkyrian Labs LLC
#pragma once

#include "vl/keykit/seed.hpp"
#include "vl/keykit/uid.hpp"

#include <nlohmann/json.hpp>

#include <cstdint>
#include <optional>
#include <span>
#include <stdexcept>
#include <string>
#include <string_view>
#include <vector>

// The recovery kit (Vaulthalla design/encryption/03-metadata-recovery.md §5.3): what a customer keeps (Desktop: in the
// vault's 1Password item; otherwise printed or on offline media) to recover vaults from their buckets. Generated on a
// customer device, never on a server; one kit can serve many vaults.
//
//   {"type": "vh.recovery-kit", "v": 1,
//    "recovery_seed": "<27 symbols>",
//    "vaults": [{"vault_uid": "<b32>", "origin": {"node_id": "…", "vault_id": 42},
//                "attestation_public_keys": [{"key_id": 3, "public_key": "<b64>"}],
//                "checkpoint": {"epoch": 812, "root_sha256": "<hex>", "at": "…"}}]}
//
// `attestation_public_keys` pin the original node's signing keys, the trust anchor a restore on another node uses
// (§6.2). `checkpoint` bounds rollback (§4.5). Members a reader doesn't know are ignored.
namespace vl::keykit {

inline constexpr std::string_view kKitType = "vh.recovery-kit";
inline constexpr unsigned kKitVersion = 1;
inline constexpr std::size_t kAttestationPublicKeySize = 32;  // Ed25519

// code(): "bad_kit" (not a kit, or a member of the wrong type), "unsupported_version", or a SeedError code.
class KitError : public std::runtime_error {
public:
    KitError(std::string code, const std::string& detail);
    [[nodiscard]] const std::string& code() const noexcept { return code_; }

private:
    std::string code_;
};

struct KitAttestationKey {
    unsigned key_id{};
    std::vector<uint8_t> public_key;  // Ed25519, 32 bytes
    [[nodiscard]] bool operator==(const KitAttestationKey&) const = default;
};

struct KitCheckpoint {
    uint64_t epoch{};
    std::string root_sha256;  // 64 lower-case hex digits
    std::optional<std::string> at;
    [[nodiscard]] bool operator==(const KitCheckpoint&) const = default;
};

struct KitVault {
    Uid vault_uid{};
    std::optional<std::string> origin_node_id;
    std::optional<uint64_t> origin_vault_id;
    std::vector<KitAttestationKey> attestation_public_keys;
    std::optional<KitCheckpoint> checkpoint;
    [[nodiscard]] bool operator==(const KitVault&) const = default;
};

struct Kit {
    RecoverySeed seed;
    std::vector<KitVault> vaults;

    [[nodiscard]] const KitVault* find(const Uid& vaultUid) const;
};

// Throws KitError. The seed text in `j` is left as it is (the caller wipes its copy).
[[nodiscard]] Kit parseKit(const nlohmann::json& j);
[[nodiscard]] nlohmann::json toJson(const Kit& kit);
[[nodiscard]] nlohmann::json toJson(const KitVault& vault);
[[nodiscard]] KitVault kitVaultFromJson(const nlohmann::json& j);  // KitError("bad_kit")

// Standard base64 with padding (RFC 4648 §4), as the kit writes public keys. The decoder is strict: no whitespace,
// padding only at the end, and zero trailing bits; nullopt otherwise.
[[nodiscard]] std::string base64Encode(std::span<const uint8_t> bytes);
[[nodiscard]] std::optional<std::vector<uint8_t>> base64Decode(std::string_view text);

}
