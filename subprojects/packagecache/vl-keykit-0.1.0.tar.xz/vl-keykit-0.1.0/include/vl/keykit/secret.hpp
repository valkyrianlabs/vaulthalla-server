// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Valkyrian Labs LLC
#pragma once

#include <cstddef>
#include <cstdint>
#include <span>
#include <string>
#include <vector>

namespace vl::keykit {

// A secret of any length (a vault key, a recovery seed, a derived private key) in memory that is locked where the
// platform allows it and zeroed before it is freed. Immutable and move-only, so the bytes live in one place: callers
// read them through bytes() and keep no copies of their own.
class SecretBytes {
public:
    SecretBytes() noexcept = default;
    explicit SecretBytes(std::span<const uint8_t> bytes);
    ~SecretBytes();

    SecretBytes(SecretBytes&& other) noexcept;
    SecretBytes& operator=(SecretBytes&& other) noexcept;
    SecretBytes(const SecretBytes&) = delete;
    SecretBytes& operator=(const SecretBytes&) = delete;

    [[nodiscard]] std::span<const uint8_t> bytes() const noexcept { return {data_, size_}; }
    [[nodiscard]] std::size_t size() const noexcept { return size_; }
    [[nodiscard]] bool empty() const noexcept { return size_ == 0; }

    // `n` bytes from OpenSSL's private CSPRNG (RAND_priv_bytes), written straight into locked memory. Throws
    // std::invalid_argument when n is 0 and std::runtime_error when the generator fails.
    [[nodiscard]] static SecretBytes random(std::size_t n);

private:
    explicit SecretBytes(std::size_t n);  // locked, zero-filled
    void release() noexcept;

    uint8_t* data_ = nullptr;
    std::size_t size_ = 0;
};

// Zero memory that held a secret (OPENSSL_cleanse: not optimized away).
void wipe(std::span<uint8_t> bytes) noexcept;
void wipe(std::vector<uint8_t>& bytes) noexcept;
void wipe(std::string& text) noexcept;

// Constant-time equality of two buffers of the same size (false for different sizes).
[[nodiscard]] bool equalConstantTime(std::span<const uint8_t> a, std::span<const uint8_t> b) noexcept;

// Tests only: called with each SecretBytes buffer right after it is zeroed and before it is freed (its address and its
// contents at that moment), so a test can prove a secret left no copy behind. A consumer with secret types of its own
// may report them through notifySecretWiped. nullptr (the default) turns it off; it is the library's only global.
using WipeObserver = void (*)(const void* where, std::span<const uint8_t> after);
void setWipeObserverForTesting(WipeObserver observer) noexcept;
void notifySecretWiped(const void* where, std::span<const uint8_t> after) noexcept;

}
