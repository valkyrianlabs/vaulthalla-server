// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Valkyrian Labs LLC
#pragma once

#include <array>
#include <cstdint>
#include <optional>
#include <string>
#include <string_view>

// Vault and object uids (Vaulthalla design/encryption/01-provider-blind-storage.md §4.1): 16 random bytes with no
// UUID version or variant bits. The text form in object keys, kits and documents is lower-case Crockford base32,
// 26 symbols. Vectors: vectors.json `object_ids`.
namespace vl::keykit {

using Uid = std::array<uint8_t, 16>;

inline constexpr std::string_view kBase32Alphabet = "0123456789abcdefghjkmnpqrstvwxyz";
inline constexpr std::size_t kUidTextSize = 26;

// 16 bytes from OpenSSL's CSPRNG.
[[nodiscard]] Uid newUid();

enum class Base32Error { BadLength, BadSymbol, NonCanonical };

[[nodiscard]] std::string_view to_string(Base32Error error);

// 26 lower-case symbols, big-endian bit order, the 2 trailing padding bits zero.
[[nodiscard]] std::string toBase32(const Uid& uid);

// Strict: one spelling per uid. Refuses upper case, symbols outside the alphabet (i, l, o, u), any other length and
// non-zero padding bits. Symbols are checked before the length.
[[nodiscard]] std::optional<Uid> fromBase32(std::string_view text, Base32Error* error = nullptr);

}
