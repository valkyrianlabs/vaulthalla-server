# CI container

vl-keykit's GitHub Actions run on the Valkyrian Labs VPS build pool (org runners labelled `vps-ci`). Every run step
executes in a disposable rootless Podman container:

```yaml
defaults:
  run:
    shell: bash ./ci/run-ci bash -euo pipefail {0}
```

- `ci/Containerfile`: Ubuntu 24.04 (pinned by digest, the same as the other Valkyrian Labs C++ repositories) with
  GCC 14, meson, ninja, pkg-config, OpenSSL 3 headers, nlohmann-json, GoogleTest, python3-cryptography (the vectors' reference check) and ccache. `sudo` works inside.
- `ci/run-ci`: copied verbatim from Vaulthalla (`ci/run-ci`); the same script every Valkyrian Labs repository uses.
  Keep it identical: fix it upstream and copy it again.
- Caches on the runner: `~/.cache/vl-keykit-ci/ccache` (`CCACHE_DIR=/cache/ccache`, enabled by `CI_CACHE_NAMES`).

Run any step locally the same way (needs Podman): `./ci/run-ci meson test -C build`.
