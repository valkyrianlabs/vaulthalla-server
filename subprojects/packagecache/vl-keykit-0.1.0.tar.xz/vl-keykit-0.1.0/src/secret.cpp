// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Valkyrian Labs LLC
#include "vl/keykit/secret.hpp"

#include "openssl.hpp"

#include <openssl/crypto.h>

#if defined(__unix__) || defined(__APPLE__)
#include <sys/mman.h>
#endif

#include <algorithm>
#include <atomic>
#include <stdexcept>
#include <utility>

namespace vl::keykit {

namespace {
std::atomic<WipeObserver> wipeObserver{nullptr};

void lockPages(void* p, const std::size_t n) noexcept {
#if defined(__unix__) || defined(__APPLE__)
    (void)mlock(p, n);  // keep it out of swap where the platform allows it; failure (RLIMIT_MEMLOCK) is not fatal
#else
    (void)p;
    (void)n;
#endif
}

void unlockPages(void* p, const std::size_t n) noexcept {
#if defined(__unix__) || defined(__APPLE__)
    (void)munlock(p, n);
#else
    (void)p;
    (void)n;
#endif
}
}

SecretBytes::SecretBytes(const std::size_t n) : data_(n ? new uint8_t[n]() : nullptr), size_(n) {
    if (data_) lockPages(data_, size_);  // before any secret byte is written
}

SecretBytes::SecretBytes(const std::span<const uint8_t> bytes) : SecretBytes(bytes.size()) {
    std::ranges::copy(bytes, data_);
}

SecretBytes::~SecretBytes() { release(); }

SecretBytes::SecretBytes(SecretBytes&& other) noexcept
    : data_(std::exchange(other.data_, nullptr)), size_(std::exchange(other.size_, 0)) {}

SecretBytes& SecretBytes::operator=(SecretBytes&& other) noexcept {
    if (this != &other) {
        release();
        data_ = std::exchange(other.data_, nullptr);
        size_ = std::exchange(other.size_, 0);
    }
    return *this;
}

void SecretBytes::release() noexcept {
    if (!data_) return;
    OPENSSL_cleanse(data_, size_);
    unlockPages(data_, size_);
    notifySecretWiped(data_, {data_, size_});
    delete[] data_;
    data_ = nullptr;
    size_ = 0;
}

SecretBytes SecretBytes::random(const std::size_t n) {
    if (n == 0) throw std::invalid_argument("a random secret needs at least one byte");
    SecretBytes out(n);
    detail::randomBytes({out.data_, out.size_}, true);
    return out;
}

void wipe(const std::span<uint8_t> bytes) noexcept {
    if (!bytes.empty()) OPENSSL_cleanse(bytes.data(), bytes.size());
}

void wipe(std::vector<uint8_t>& bytes) noexcept { wipe(std::span<uint8_t>(bytes)); }

void wipe(std::string& text) noexcept {
    if (!text.empty()) OPENSSL_cleanse(text.data(), text.size());
}

bool equalConstantTime(const std::span<const uint8_t> a, const std::span<const uint8_t> b) noexcept {
    if (a.size() != b.size()) return false;
    return a.empty() || CRYPTO_memcmp(a.data(), b.data(), a.size()) == 0;
}

void setWipeObserverForTesting(const WipeObserver observer) noexcept { wipeObserver.store(observer); }

void notifySecretWiped(const void* where, const std::span<const uint8_t> after) noexcept {
    if (const auto observer = wipeObserver.load(std::memory_order_relaxed)) observer(where, after);
}

}
