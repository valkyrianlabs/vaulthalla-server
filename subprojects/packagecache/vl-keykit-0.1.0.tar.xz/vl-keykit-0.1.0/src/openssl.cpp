// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Valkyrian Labs LLC
#include "openssl.hpp"

#include <openssl/core_names.h>
#include <openssl/kdf.h>
#include <openssl/params.h>
#include <openssl/rand.h>

#include <climits>
#include <stdexcept>
#include <vector>

namespace vl::keykit::detail {

namespace {

struct KdfDeleter {
    void operator()(EVP_KDF* p) const noexcept { EVP_KDF_free(p); }
};
struct KdfCtxDeleter {
    void operator()(EVP_KDF_CTX* p) const noexcept { EVP_KDF_CTX_free(p); }
};

// OSSL_PARAM octet strings take a mutable pointer they never write through; an empty span still needs a valid one.
void* octets(const std::span<const uint8_t> bytes) {
    static uint8_t empty = 0;
    return bytes.empty() ? &empty : const_cast<uint8_t*>(bytes.data());
}

}

std::array<uint8_t, 32> sha256(const std::span<const uint8_t> bytes) {
    std::array<uint8_t, 32> out{};
    unsigned len = 0;
    if (EVP_Digest(bytes.data(), bytes.size(), out.data(), &len, EVP_sha256(), nullptr) != 1 || len != out.size())
        throw std::runtime_error("SHA-256 failed");
    return out;
}

void hkdfSha256(const std::span<const uint8_t> ikm, const std::span<const uint8_t> salt,
                const std::span<const uint8_t> info, const std::span<uint8_t> out) {
    const std::unique_ptr<EVP_KDF, KdfDeleter> kdf(EVP_KDF_fetch(nullptr, "HKDF", nullptr));
    if (!kdf) throw std::runtime_error("OpenSSL HKDF is unavailable");
    const std::unique_ptr<EVP_KDF_CTX, KdfCtxDeleter> ctx(EVP_KDF_CTX_new(kdf.get()));
    if (!ctx) throw std::runtime_error("Failed to allocate an OpenSSL HKDF context");
    char digest[] = "SHA256";
    int mode = EVP_KDF_HKDF_MODE_EXTRACT_AND_EXPAND;
    std::array<OSSL_PARAM, 6> params{
        OSSL_PARAM_construct_utf8_string(OSSL_KDF_PARAM_DIGEST, digest, 0),
        OSSL_PARAM_construct_int(OSSL_KDF_PARAM_MODE, &mode),
        OSSL_PARAM_construct_octet_string(OSSL_KDF_PARAM_KEY, octets(ikm), ikm.size()),
        OSSL_PARAM_construct_octet_string(OSSL_KDF_PARAM_SALT, octets(salt), salt.size()),
        OSSL_PARAM_construct_octet_string(OSSL_KDF_PARAM_INFO, octets(info), info.size()),
        OSSL_PARAM_construct_end()};
    if (EVP_KDF_derive(ctx.get(), out.data(), out.size(), params.data()) != 1)
        throw std::runtime_error("HKDF-SHA-256 derivation failed");
}

void randomBytes(const std::span<uint8_t> out, const bool forSecret) {
    for (std::size_t done = 0; done < out.size();) {
        const auto n = static_cast<int>(std::min<std::size_t>(out.size() - done, INT_MAX));
        const int rc = forSecret ? RAND_priv_bytes(out.data() + done, n) : RAND_bytes(out.data() + done, n);
        if (rc != 1) throw std::runtime_error("the OpenSSL random generator failed");
        done += static_cast<std::size_t>(n);
    }
}

std::array<uint8_t, 32> rawPublicKey(const int type, const std::span<const uint8_t> secret) {
    if (secret.size() != 32) throw std::invalid_argument("an X25519 or Ed25519 secret key is 32 bytes");
    const Pkey key(EVP_PKEY_new_raw_private_key(type, nullptr, secret.data(), secret.size()));
    std::array<uint8_t, 32> out{};
    std::size_t len = out.size();
    if (!key || EVP_PKEY_get_raw_public_key(key.get(), out.data(), &len) != 1 || len != out.size())
        throw std::runtime_error("public key derivation failed");
    return out;
}

}
