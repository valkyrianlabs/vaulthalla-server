// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Valkyrian Labs LLC
#include "vl/keykit/seed.hpp"

#include "openssl.hpp"
#include "vl/keykit/uid.hpp"

#include <algorithm>
#include <cctype>

namespace vl::keykit {

namespace {

constexpr std::string_view kSalt = "vh.recovery.v1";

char checkSymbol(const std::span<const uint8_t> seed) { return kBase32Alphabet[detail::sha256(seed)[0] >> 3]; }

}

SeedError::SeedError(std::string code)
    : std::runtime_error("not a recovery seed (" + code + ")"), code_(std::move(code)) {}

RecoverySeed RecoverySeed::generate() { return RecoverySeed(SecretBytes::random(kSeedSize)); }

RecoverySeed RecoverySeed::fromBytes(const std::span<const uint8_t> bytes) {
    if (bytes.size() != kSeedSize) throw SeedError("bad_length");
    return RecoverySeed(SecretBytes(bytes));
}

RecoverySeed RecoverySeed::parse(const std::string_view text) {
    std::string clean;
    clean.reserve(kSeedTextSize);
    struct WipeText {
        std::string& s;
        ~WipeText() { wipe(s); }
    } wipeClean{clean};
    for (const char c : text) {
        if (std::isspace(static_cast<unsigned char>(c)) || c == '-') continue;
        clean.push_back(static_cast<char>(std::tolower(static_cast<unsigned char>(c))));
    }
    if (clean.size() != kSeedTextSize) throw SeedError("bad_length");
    auto raw = fromBase32(std::string_view(clean).substr(0, kSeedTextSize - 1));
    if (!raw) throw SeedError("bad_symbol");
    RecoverySeed seed{SecretBytes(std::span<const uint8_t>(*raw))};
    wipe(std::span<uint8_t>(*raw));
    if (clean.back() != checkSymbol(seed.bytes())) throw SeedError("bad_check");
    return seed;
}

std::string RecoverySeed::text() const {
    Uid raw{};
    std::ranges::copy(seed_.bytes(), raw.begin());
    auto out = toBase32(raw);
    wipe(std::span<uint8_t>(raw));
    out.push_back(checkSymbol(seed_.bytes()));
    return out;
}

SecretBytes RecoverySeed::expand(const std::string_view label) const {
    std::array<uint8_t, 32> out{};
    detail::hkdfSha256(seed_.bytes(), detail::viewBytes(kSalt), detail::viewBytes(label), out);
    SecretBytes key(out);
    wipe(std::span<uint8_t>(out));
    return key;
}

SecretBytes RecoverySeed::x25519SecretKey() const { return expand("x25519"); }

std::vector<uint8_t> RecoverySeed::x25519PublicKey() const {
    const auto sk = x25519SecretKey();
    const auto pk = detail::rawPublicKey(EVP_PKEY_X25519, sk.bytes());
    return {pk.begin(), pk.end()};
}

SecretBytes RecoverySeed::ed25519Seed() const { return expand("ed25519"); }

std::vector<uint8_t> RecoverySeed::ed25519PublicKey() const {
    const auto seed = ed25519Seed();
    const auto pk = detail::rawPublicKey(EVP_PKEY_ED25519, seed.bytes());
    return {pk.begin(), pk.end()};
}

}
