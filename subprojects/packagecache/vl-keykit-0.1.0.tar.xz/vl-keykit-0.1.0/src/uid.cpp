// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Valkyrian Labs LLC
#include "vl/keykit/uid.hpp"

#include "openssl.hpp"

namespace vl::keykit {

Uid newUid() {
    Uid uid{};
    detail::randomBytes(uid, false);
    return uid;
}

std::string_view to_string(const Base32Error error) {
    switch (error) {
    case Base32Error::BadLength: return "bad_length";
    case Base32Error::BadSymbol: return "bad_symbol";
    case Base32Error::NonCanonical: return "non_canonical";
    }
    return "bad_symbol";
}

std::string toBase32(const Uid& uid) {
    std::string out;
    out.reserve(kUidTextSize);
    uint32_t buffer = 0;
    int bits = 0;
    for (const auto b : uid) {
        buffer = buffer << 8 | b;
        bits += 8;
        while (bits >= 5) {
            bits -= 5;
            out.push_back(kBase32Alphabet[buffer >> bits & 0x1f]);
        }
    }
    if (bits > 0) out.push_back(kBase32Alphabet[buffer << (5 - bits) & 0x1f]);
    return out;
}

std::optional<Uid> fromBase32(const std::string_view text, Base32Error* error) {
    const auto fail = [&](const Base32Error e) -> std::optional<Uid> {
        if (error) *error = e;
        return std::nullopt;
    };
    // Symbols first: an upper-case or out-of-alphabet id of the wrong length is still a bad symbol.
    for (const auto c : text)
        if (kBase32Alphabet.find(c) == std::string_view::npos) return fail(Base32Error::BadSymbol);
    if (text.size() != kUidTextSize) return fail(Base32Error::BadLength);

    Uid uid{};
    uint32_t buffer = 0;
    int bits = 0;
    std::size_t byte = 0;
    for (const auto c : text) {
        buffer = buffer << 5 | static_cast<uint32_t>(kBase32Alphabet.find(c));
        bits += 5;
        if (bits >= 8) {
            bits -= 8;
            uid[byte++] = static_cast<uint8_t>(buffer >> bits & 0xff);
        }
    }
    if ((buffer & ((1u << bits) - 1)) != 0) return fail(Base32Error::NonCanonical);
    return uid;
}

}
