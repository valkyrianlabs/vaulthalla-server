// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Valkyrian Labs LLC
#pragma once

// Private helpers over OpenSSL 3 shared by the codecs. Not installed.

#include <openssl/evp.h>

#include <array>
#include <cstdint>
#include <memory>
#include <span>
#include <string_view>

namespace vl::keykit::detail {

struct PkeyDeleter {
    void operator()(EVP_PKEY* p) const noexcept { EVP_PKEY_free(p); }
};
using Pkey = std::unique_ptr<EVP_PKEY, PkeyDeleter>;

[[nodiscard]] std::array<uint8_t, 32> sha256(std::span<const uint8_t> bytes);

// HKDF-SHA-256 extract-and-expand into `out` (any length HKDF allows). Throws std::runtime_error.
void hkdfSha256(std::span<const uint8_t> ikm, std::span<const uint8_t> salt, std::span<const uint8_t> info,
                std::span<uint8_t> out);

// Fills `out` from OpenSSL's public (RAND_bytes) or private (RAND_priv_bytes) generator. Throws std::runtime_error.
void randomBytes(std::span<uint8_t> out, bool forSecret);

// The raw public key of an X25519 or Ed25519 private key (32 bytes each); `type` is EVP_PKEY_X25519 or
// EVP_PKEY_ED25519. Throws std::invalid_argument for a key that is not 32 bytes, std::runtime_error otherwise.
[[nodiscard]] std::array<uint8_t, 32> rawPublicKey(int type, std::span<const uint8_t> secret);

[[nodiscard]] inline std::span<const uint8_t> viewBytes(const std::string_view text) noexcept {
    return {reinterpret_cast<const uint8_t*>(text.data()), text.size()};
}

}
