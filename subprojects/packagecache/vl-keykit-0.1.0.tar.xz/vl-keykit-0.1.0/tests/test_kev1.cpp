// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Valkyrian Labs LLC
//
// KEV1 key envelopes against the golden vectors (vectors.json `kev1`): positives byte for byte, negatives by their
// first failing check. Ported from Vaulthalla core/tests/unit/test_kev1.cpp, plus P-256 round trips, tampering and
// the cases a cloud service relies on when it validates envelopes it cannot open.
#include "support.hpp"
#include "vl/keykit/kev1.hpp"
#include "vl/keykit/seed.hpp"

#include <gtest/gtest.h>

#include <set>

namespace vl::keykit::test {

namespace {

kev1::VaultUid uidOf(const Json& j) {
    const auto b = hex(j);
    kev1::VaultUid u{};
    if (b.size() != u.size()) throw std::invalid_argument("a vault uid is 16 bytes");
    std::copy(b.begin(), b.end(), u.begin());
    return u;
}

kev1::Suite suiteOf(const Json& j) { return static_cast<kev1::Suite>(j.get<uint16_t>()); }

Bytes randomKey() {
    const auto k = SecretBytes::random(32);
    return {k.bytes().begin(), k.bytes().end()};
}

kev1::ErrorCode unwrapError(const Bytes& env, const std::span<const uint8_t> sk, const kev1::Suite suite,
                            const kev1::VaultUid& uid) {
    try {
        (void)kev1::unwrap(env, sk, suite, uid);
    } catch (const kev1::Error& e) {
        return e.code();
    }
    throw std::logic_error("accepted");
}

}

TEST(Kev1Vectors, PositiveEnvelopesAreReproducedAndUnwrap) {
    const auto& positives = vectors().at("kev1").at("positive");
    ASSERT_GE(positives.size(), 3u);
    std::set<uint16_t> suites;
    for (const auto& v : positives) {
        SCOPED_TRACE(str(v.at("name")));
        const auto suite = suiteOf(v.at("suite"));
        suites.insert(static_cast<uint16_t>(suite));
        const auto key = hex(v.at("vault_key_hex"));
        const auto rpk = hex(v.at("recipient_pk_hex"));
        EXPECT_EQ(toHex(kev1::publicKeyOf(suite, hex(v.at("recipient_sk_hex")))), str(v.at("recipient_pk_hex")));
        EXPECT_EQ(toHex(kev1::recipientId(rpk)), str(v.at("recipient_id_hex")));

        const auto env = kev1::wrap(key, suite, v.at("key_version").get<uint32_t>(), uidOf(v.at("vault_uid_hex")), rpk,
                                    hex(v.at("ephemeral_sk_hex")));
        EXPECT_EQ(toHex(env), str(v.at("envelope_hex")));
        EXPECT_EQ(kev1::objectKey(kev1::kid(env)), str(v.at("object_key")));

        const auto out =
            kev1::unwrap(hex(v.at("envelope_hex")), hex(v.at("recipient_sk_hex")), suite, uidOf(v.at("vault_uid_hex")));
        EXPECT_EQ(out.key_version, v.at("key_version").get<uint32_t>());
        EXPECT_EQ(toHex(out.key.bytes()), str(v.at("vault_key_hex")));

        const auto h = kev1::inspect(env);
        EXPECT_EQ(h.suite, static_cast<uint16_t>(suite));
        EXPECT_EQ(h.purpose, kev1::kPurposeVaultKey);
        EXPECT_EQ(h.recipient_class, kev1::kClassCustomer);
        EXPECT_EQ(h.key_version, v.at("key_version").get<uint32_t>());
        EXPECT_EQ(h.vault_uid, uidOf(v.at("vault_uid_hex")));
        EXPECT_EQ(toHex(h.recipient_id), str(v.at("recipient_id_hex")));
    }
    EXPECT_EQ(suites, (std::set<uint16_t>{1, 2}));  // both suites are vectored
}

TEST(Kev1Vectors, NegativeEnvelopesFailAtTheirFirstCheck) {
    const auto& negatives = vectors().at("kev1").at("negative");
    ASSERT_GE(negatives.size(), 9u);
    for (const auto& n : negatives) {
        SCOPED_TRACE(str(n.at("name")));
        try {
            (void)kev1::unwrap(hex(n.at("envelope_hex")), hex(n.at("recipient_sk_hex")),
                               suiteOf(n.at("suite_expected")), uidOf(n.at("vault_uid_hex")));
            ADD_FAILURE() << "accepted";
        } catch (const kev1::Error& e) {
            EXPECT_EQ(kev1::errorCodeName(e.code()), str(n.at("expect").at("error")));
        }
    }
}

TEST(Kev1, FreshEnvelopesRoundTripAndNeverRepeat) {
    const auto key = randomKey();
    const auto seed = RecoverySeed::generate();
    const auto rpk = seed.x25519PublicKey();
    const auto sk = seed.x25519SecretKey();
    const auto uid = newUid();
    const auto a = kev1::wrap(key, kev1::Suite::X25519, 7, uid, rpk);
    const auto b = kev1::wrap(key, kev1::Suite::X25519, 7, uid, rpk);
    EXPECT_EQ(a.size(), 150u);
    EXPECT_NE(a, b);  // a fresh ephemeral key per envelope
    EXPECT_NE(kev1::kid(a), kev1::kid(b));
    const auto out = kev1::unwrap(a, sk.bytes(), kev1::Suite::X25519, uid);
    EXPECT_EQ(out.key_version, 7u);
    EXPECT_TRUE(equalConstantTime(out.key.bytes(), key));
    EXPECT_THROW((void)kev1::wrap(key, kev1::Suite::X25519, 0, uid, rpk), std::invalid_argument);
    EXPECT_THROW((void)kev1::wrap(key, kev1::Suite::X25519, 1, uid, Bytes(31, 1)), std::invalid_argument);
    EXPECT_THROW((void)kev1::wrap(Bytes(31, 1), kev1::Suite::X25519, 1, uid, rpk), std::invalid_argument);
    EXPECT_THROW((void)kev1::wrap(key, static_cast<kev1::Suite>(3), 1, uid, rpk), std::invalid_argument);
}

TEST(Kev1, P256EnvelopesRoundTrip) {
    const auto key = randomKey();
    // A P-256 scalar from the CSPRNG; a draw at or above the group order is astronomically unlikely.
    const auto sk = SecretBytes::random(kev1::kP256ScalarSize);
    const auto rpk = kev1::publicKeyOf(kev1::Suite::P256, sk.bytes());
    ASSERT_EQ(rpk.size(), kev1::kP256PointSize);
    const auto uid = newUid();
    const auto env = kev1::wrap(key, kev1::Suite::P256, 3, uid, rpk);
    EXPECT_EQ(env.size(), kev1::kFixedPrefixSize + kev1::kP256PointSize + kev1::kWrappedSize);
    const auto out = kev1::unwrap(env, sk.bytes(), kev1::Suite::P256, uid);
    EXPECT_EQ(out.key_version, 3u);
    EXPECT_TRUE(equalConstantTime(out.key.bytes(), key));
    // The suite the reader expects is part of the check: a P-256 envelope is never read as X25519.
    EXPECT_EQ(unwrapError(env, sk.bytes(), kev1::Suite::X25519, uid), kev1::ErrorCode::UnsupportedSuite);
    // Not a point on the curve.
    auto off = rpk;
    off[64] ^= 1;
    EXPECT_THROW((void)kev1::wrap(key, kev1::Suite::P256, 1, uid, off), std::invalid_argument);
    EXPECT_THROW((void)kev1::publicKeyOf(kev1::Suite::P256, Bytes(32, 0)), std::invalid_argument);
    EXPECT_THROW((void)kev1::publicKeyOf(kev1::Suite::P256, Bytes(32, 0xff)), std::invalid_argument);
}

TEST(Kev1, EveryAuthenticatedByteIsBound) {
    const auto key = randomKey();
    const auto seed = RecoverySeed::generate();
    const auto sk = seed.x25519SecretKey();
    const auto uid = newUid();
    const auto env = kev1::wrap(key, kev1::Suite::X25519, 2, uid, seed.x25519PublicKey());
    // Flipping any byte fails some check: structural ones before the key is touched, and the AEAD for the rest.
    for (std::size_t i = 0; i < env.size(); ++i) {
        auto bad = env;
        bad[i] ^= 0x01;
        try {
            (void)kev1::unwrap(bad, sk.bytes(), kev1::Suite::X25519, uid);
            ADD_FAILURE() << "byte " << i << " is not authenticated";
        } catch (const kev1::Error&) {
        }
    }
    auto wrongVault = uid;
    wrongVault[0] ^= 1;
    EXPECT_EQ(unwrapError(env, sk.bytes(), kev1::Suite::X25519, wrongVault), kev1::ErrorCode::VaultMismatch);
    const auto other = RecoverySeed::generate().x25519SecretKey();
    EXPECT_EQ(unwrapError(env, other.bytes(), kev1::Suite::X25519, uid), kev1::ErrorCode::RecipientMismatch);
    EXPECT_EQ(unwrapError(env, Bytes(7, 1), kev1::Suite::X25519, uid), kev1::ErrorCode::RecipientMismatch);
    auto shortEnv = env;
    shortEnv.pop_back();
    EXPECT_EQ(unwrapError(shortEnv, sk.bytes(), kev1::Suite::X25519, uid), kev1::ErrorCode::BadLength);
    EXPECT_EQ(unwrapError(Bytes(env.begin(), env.begin() + 69), sk.bytes(), kev1::Suite::X25519, uid),
              kev1::ErrorCode::BadMagic);
}

// Spec 03 §5.7: every envelope written now is class 0 / purpose 1; a reserved class or purpose is refused by the reader
// and reported as one a restore skips (never fatal), alongside envelopes addressed to someone else.
TEST(Kev1ReservedFields, ReservedClassesAndPurposesAreRefusedAndSkippable) {
    std::set<std::string> seen;
    for (const auto& n : vectors().at("kev1").at("negative")) {
        const auto name = str(n.at("name"));
        if (name != "reserved_recipient_class" && name != "reserved_purpose_threshold_share" &&
            name != "reserved_nonzero" && name != "wrong_recipient")
            continue;
        seen.insert(name);
        try {
            (void)kev1::inspect(hex(n.at("envelope_hex")));
            if (name != "wrong_recipient") ADD_FAILURE() << name << " passed inspect";
        } catch (const kev1::Error& e) {
            EXPECT_EQ(kev1::skippedByRestore(e.code()), name != "reserved_nonzero") << name;
        }
    }
    EXPECT_EQ(seen.size(), 4u);
    EXPECT_TRUE(kev1::skippedByRestore(kev1::ErrorCode::RecipientMismatch));
    EXPECT_FALSE(kev1::skippedByRestore(kev1::ErrorCode::WrapAuthFailed));
    EXPECT_FALSE(kev1::skippedByRestore(kev1::ErrorCode::VaultMismatch));

    const auto key = randomKey();
    const auto env = kev1::wrap(key, kev1::Suite::X25519, 1, newUid(), RecoverySeed::generate().x25519PublicKey());
    EXPECT_EQ(env[12], 1);  // purpose: a whole vault key version
    EXPECT_EQ(env[13], 0);  // recipient_class: customer-controlled
}

TEST(Kev1, ErrorNamesAreTheVectorsSpelling) {
    EXPECT_EQ(kev1::errorCodeName(kev1::ErrorCode::BadMagic), "bad_magic");
    EXPECT_EQ(kev1::errorCodeName(kev1::ErrorCode::BadKeyVersion), "bad_key_version");
    EXPECT_EQ(kev1::errorCodeName(static_cast<kev1::ErrorCode>(200)), "unknown");
    EXPECT_EQ(kev1::objectKey("abc"), ".vaulthalla/key/abc");
}

}
