// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Valkyrian Labs LLC
#pragma once

#include <nlohmann/json.hpp>

#include <cstdint>
#include <fstream>
#include <span>
#include <stdexcept>
#include <string>
#include <vector>

namespace vl::keykit::test {

using Json = nlohmann::json;
using Bytes = std::vector<uint8_t>;

// vectors/vectors.json, read once.
inline const Json& vectors() {
    static const Json j = [] {
        std::ifstream in(std::string(VL_KEYKIT_VECTORS_DIR) + "/vectors.json");
        if (!in) throw std::runtime_error("cannot open vectors/vectors.json");
        return Json::parse(in);
    }();
    return j;
}

inline Bytes fromHex(const std::string& text) {
    if (text.size() % 2 != 0) throw std::invalid_argument("odd hex length");
    const auto digit = [](const char c) -> int {
        if (c >= '0' && c <= '9') return c - '0';
        if (c >= 'a' && c <= 'f') return c - 'a' + 10;
        if (c >= 'A' && c <= 'F') return c - 'A' + 10;
        throw std::invalid_argument("not a hex digit");
    };
    Bytes out(text.size() / 2);
    for (std::size_t i = 0; i < out.size(); ++i)
        out[i] = static_cast<uint8_t>(digit(text[2 * i]) << 4 | digit(text[2 * i + 1]));
    return out;
}

inline Bytes hex(const Json& j) { return fromHex(j.get<std::string>()); }

inline std::string toHex(const std::span<const uint8_t> bytes) {
    static constexpr char kDigits[] = "0123456789abcdef";
    std::string out;
    out.reserve(bytes.size() * 2);
    for (const auto b : bytes) {
        out.push_back(kDigits[b >> 4]);
        out.push_back(kDigits[b & 0x0f]);
    }
    return out;
}

inline std::string str(const Json& j) { return j.get<std::string>(); }

}
