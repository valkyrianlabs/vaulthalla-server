// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Valkyrian Labs LLC
//
// Uids against the golden vectors (vectors.json `object_ids`), and SecretBytes' wiping.
#include "support.hpp"
#include "vl/keykit/kev1.hpp"
#include "vl/keykit/secret.hpp"
#include "vl/keykit/seed.hpp"
#include "vl/keykit/uid.hpp"

#include <gtest/gtest.h>

#include <algorithm>
#include <atomic>

namespace vl::keykit::test {

TEST(UidVectors, EncodeAndDecodeTheDocumentedIds) {
    const auto& ids = vectors().at("object_ids");
    EXPECT_EQ(str(ids.at("alphabet")), kBase32Alphabet);
    ASSERT_GE(ids.at("encode").size(), 4u);
    for (const auto& e : ids.at("encode")) {
        const auto raw = hex(e.at("uid_hex"));
        Uid uid{};
        std::ranges::copy(raw, uid.begin());
        EXPECT_EQ(toBase32(uid), str(e.at("b32")));
        EXPECT_EQ(fromBase32(str(e.at("b32"))), uid);
    }
    for (const auto& n : ids.at("decode_negative")) {
        SCOPED_TRACE(str(n.at("why")));
        Base32Error error{};
        EXPECT_FALSE(fromBase32(str(n.at("text")), &error));
        EXPECT_EQ(to_string(error), str(n.at("error")));
    }
    EXPECT_NE(newUid(), newUid());
}

namespace {
std::atomic<int> wiped{0};
std::atomic<bool> allZero{true};
void observe(const void*, const std::span<const uint8_t> after) {
    ++wiped;
    if (!std::ranges::all_of(after, [](const uint8_t b) { return b == 0; })) allZero = false;
}
}

TEST(SecretBytes, IsWipedBeforeItIsFreedAndMovesWithoutCopies) {
    wiped = 0;
    allZero = true;
    setWipeObserverForTesting(&observe);
    {
        auto a = SecretBytes::random(32);
        EXPECT_EQ(a.size(), 32u);
        EXPECT_FALSE(std::ranges::all_of(a.bytes(), [](const uint8_t b) { return b == 0; }));
        const auto* where = a.bytes().data();
        SecretBytes b(std::move(a));
        EXPECT_TRUE(a.empty());  // NOLINT(bugprone-use-after-move): moved-from is empty by contract
        EXPECT_EQ(b.bytes().data(), where);
        SecretBytes c;
        c = std::move(b);
        EXPECT_EQ(c.bytes().data(), where);
        EXPECT_EQ(wiped.load(), 0);
    }
    EXPECT_EQ(wiped.load(), 1);
    {
        // A seed's derivations and an unwrapped key are SecretBytes too.
        const auto seed = RecoverySeed::generate();
        (void)seed.x25519SecretKey();
        const auto key = SecretBytes::random(32);
        const auto uid = newUid();
        const auto env = kev1::wrap(key.bytes(), kev1::Suite::X25519, 1, uid, seed.x25519PublicKey());
        (void)kev1::unwrap(env, seed.x25519SecretKey().bytes(), kev1::Suite::X25519, uid);
    }
    setWipeObserverForTesting(nullptr);
    // 1 above, then: the seed, the discarded x25519 key, the vault key, the x25519 key x25519PublicKey() derives, the
    // one passed to unwrap, and the unwrapped key.
    EXPECT_EQ(wiped.load(), 7);
    EXPECT_TRUE(allZero.load());
    EXPECT_THROW((void)SecretBytes::random(0), std::invalid_argument);
}

TEST(SecretBytes, ComparesInConstantTimeAndWipesBuffers) {
    const Bytes a{1, 2, 3}, b{1, 2, 3}, c{1, 2, 4};
    EXPECT_TRUE(equalConstantTime(a, b));
    EXPECT_FALSE(equalConstantTime(a, c));
    EXPECT_FALSE(equalConstantTime(a, Bytes{1, 2}));
    EXPECT_TRUE(equalConstantTime(Bytes{}, Bytes{}));
    Bytes v{9, 9, 9};
    wipe(v);
    EXPECT_EQ(v, (Bytes{0, 0, 0}));
    std::string s = "secret";
    wipe(s);
    EXPECT_EQ(s, std::string(6, '\0'));
}

}
