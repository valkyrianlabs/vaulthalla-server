// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Valkyrian Labs LLC
//
// The recovery seed against the golden vectors (vectors.json `recovery_seed`) and the recovery kit codec. Ported from
// Vaulthalla core/tests/unit/test_kev1.cpp, plus the strict base64 the kit uses for public keys.
#include "support.hpp"
#include "vl/keykit/kev1.hpp"
#include "vl/keykit/kit.hpp"
#include "vl/keykit/seed.hpp"

#include <gtest/gtest.h>

#include <cctype>

namespace vl::keykit::test {

TEST(RecoverySeedVectors, SeedsDeriveTheDocumentedKeys) {
    const auto& positives = vectors().at("recovery_seed").at("positive");
    ASSERT_GE(positives.size(), 2u);
    for (const auto& s : positives) {
        SCOPED_TRACE(str(s.at("seed_text")));
        const auto seed = RecoverySeed::parse(str(s.at("seed_text")));
        EXPECT_EQ(toHex(seed.bytes()), str(s.at("seed_hex")));
        EXPECT_EQ(seed.text(), str(s.at("seed_text")));
        EXPECT_EQ(toHex(seed.x25519SecretKey().bytes()), str(s.at("x25519_sk_hex")));
        EXPECT_EQ(toHex(seed.x25519PublicKey()), str(s.at("x25519_pk_hex")));
        EXPECT_EQ(toHex(kev1::recipientId(seed.x25519PublicKey())), str(s.at("recipient_id_hex")));
        EXPECT_EQ(toHex(seed.ed25519Seed().bytes()), str(s.at("ed25519_seed_hex")));
        EXPECT_EQ(toHex(seed.ed25519PublicKey()), str(s.at("ed25519_pk_hex")));
        EXPECT_EQ(RecoverySeed::fromBytes(hex(s.at("seed_hex"))).text(), str(s.at("seed_text")));
    }
    // Display grouping is cosmetic.
    const auto text = str(positives.at(0).at("seed_text"));
    std::string grouped;
    for (std::size_t i = 0; i < text.size(); ++i)
        grouped += (i && i % 5 == 0 ? "-" : "") +
                   std::string(1, static_cast<char>(std::toupper(static_cast<unsigned char>(text[i]))));
    EXPECT_EQ(RecoverySeed::parse(grouped).text(), text);
    EXPECT_EQ(RecoverySeed::parse(" " + text.substr(0, 9) + "\t" + text.substr(9) + "\n").text(), text);
}

TEST(RecoverySeedVectors, NegativeSeedsAreRefused) {
    for (const auto& s : vectors().at("recovery_seed").at("negative")) {
        try {
            (void)RecoverySeed::parse(str(s.at("seed_text")));
            ADD_FAILURE() << "accepted " << s.at("seed_text");
        } catch (const SeedError& e) {
            EXPECT_EQ(e.code(), str(s.at("error")));
        }
    }
    EXPECT_THROW((void)RecoverySeed::parse("148hr6b6azfczjm7b2hs4x7hn0"), SeedError);
    EXPECT_THROW((void)RecoverySeed::parse("148hr6b6azfczjm7b2hs4x7hnuj"), SeedError);
    EXPECT_THROW((void)RecoverySeed::fromBytes(Bytes(15, 0)), SeedError);
}

TEST(RecoverySeed, GeneratedSeedsRoundTripThroughText) {
    const auto a = RecoverySeed::generate();
    const auto b = RecoverySeed::generate();
    EXPECT_EQ(a.bytes().size(), kSeedSize);
    EXPECT_NE(a.text(), b.text());
    EXPECT_EQ(a.text().size(), kSeedTextSize);
    EXPECT_EQ(RecoverySeed::parse(a.text()).text(), a.text());
    EXPECT_EQ(a.x25519PublicKey(), kev1::publicKeyOf(kev1::Suite::X25519, a.x25519SecretKey().bytes()));
}

TEST(RecoveryKit, RoundTripsAndRefusesWhatIsNotAKit) {
    const auto seedText = str(vectors().at("recovery_seed").at("positive").at(0).at("seed_text"));
    const auto uid = newUid();
    const Json doc = {{"type", "vh.recovery-kit"},
                      {"v", 1},
                      {"recovery_seed", seedText},
                      {"vaults",
                       {{{"vault_uid", toBase32(uid)},
                         {"origin", {{"node_id", "00000000-0000-4000-8000-000000000001"}, {"vault_id", 42}}},
                         {"attestation_public_keys",
                          {{{"key_id", 3}, {"public_key", "A6EHv/POEL4dcN0Y50vAmWfk1jCbpQ1fHd2GZBJVMbg="}}}},
                         {"checkpoint", {{"epoch", 812}, {"root_sha256", std::string(64, 'a')}}},
                         {"future_member", true}}}},
                      {"unknown", "ignored"}};
    const auto kit = parseKit(doc);
    EXPECT_EQ(kit.seed.text(), seedText);
    ASSERT_EQ(kit.vaults.size(), 1u);
    ASSERT_NE(kit.find(uid), nullptr);
    EXPECT_EQ(kit.vaults[0].origin_vault_id, 42u);
    ASSERT_EQ(kit.vaults[0].attestation_public_keys.size(), 1u);
    EXPECT_EQ(kit.vaults[0].attestation_public_keys[0].public_key.size(), 32u);
    const auto again = parseKit(toJson(kit));
    EXPECT_EQ(again.vaults, kit.vaults);
    EXPECT_EQ(again.seed.text(), seedText);
    EXPECT_EQ(toJson(kit).at("vaults").at(0).at("attestation_public_keys").at(0).at("public_key"),
              "A6EHv/POEL4dcN0Y50vAmWfk1jCbpQ1fHd2GZBJVMbg=");

    const auto refused = [&](const Json& j, const std::string& code) {
        try {
            (void)parseKit(j);
            ADD_FAILURE() << "accepted " << j.dump();
        } catch (const KitError& e) {
            EXPECT_EQ(e.code(), code) << j.dump();
        }
    };
    auto j = doc;
    j["type"] = "vh.manifest.root";
    refused(j, "bad_kit");
    j = doc;
    j["v"] = 2;
    refused(j, "unsupported_version");
    j = doc;
    j["recovery_seed"] = seedText.substr(0, 26) + (seedText[26] == 'j' ? "k" : "j");
    refused(j, "bad_check");
    j = doc;
    j["vaults"][0]["attestation_public_keys"][0]["public_key"] = "AAAA";
    refused(j, "bad_kit");
    j = doc;
    j["vaults"].push_back(j["vaults"][0]);
    refused(j, "bad_kit");
    j = doc;
    j["vaults"][0]["vault_uid"] = "KCEYPK9VFN5TV6YX5C6QPFEBDM";
    refused(j, "bad_kit");
    j = doc;
    j["vaults"][0]["checkpoint"]["root_sha256"] = std::string(64, 'A');
    refused(j, "bad_kit");
    refused(Json::array(), "bad_kit");
}

TEST(Base64, EncodesStandardPaddedAndDecodesStrictly) {
    const auto b = [](const std::string& s) { return Bytes(s.begin(), s.end()); };
    // RFC 4648 §10.
    EXPECT_EQ(base64Encode(b("")), "");
    EXPECT_EQ(base64Encode(b("f")), "Zg==");
    EXPECT_EQ(base64Encode(b("fo")), "Zm8=");
    EXPECT_EQ(base64Encode(b("foo")), "Zm9v");
    EXPECT_EQ(base64Encode(b("foobar")), "Zm9vYmFy");
    EXPECT_EQ(base64Encode(Bytes{0xfb, 0xff}), "+/8=");
    for (const auto* s : {"", "f", "fo", "foo", "foob", "fooba", "foobar"})
        EXPECT_EQ(base64Decode(base64Encode(b(s))), b(s)) << s;
    EXPECT_FALSE(base64Decode("Zg="));       // not a multiple of 4
    EXPECT_FALSE(base64Decode("Zh=="));      // non-zero trailing bits
    EXPECT_FALSE(base64Decode("Zm9=" ));     // non-zero trailing bits
    EXPECT_FALSE(base64Decode("Z==="));      // too much padding
    EXPECT_FALSE(base64Decode("Zg==Zm8=")); // padding before the end
    EXPECT_FALSE(base64Decode("Zm 9v"));
    EXPECT_FALSE(base64Decode("Zm9v\n"));
    EXPECT_FALSE(base64Decode("Zm-v"));      // the URL alphabet is not this one
    EXPECT_FALSE(base64Decode("Z=g="));
}

}
