# Changelog

All notable changes to vl-keykit are recorded here. The format follows [Keep a Changelog](https://keepachangelog.com/),
and versions follow [Semantic Versioning](https://semver.org/) (before 1.0, a minor version may break the API).

## [Unreleased]

## [0.1.0]

### Added

- First release, extracted from vaulthalla-server 1.22.2 (`core/{include,src}/crypto/recovery/`, `crypto/id/ObjectUid`
  and `crypto/SecretBytes`). Byte-compatible with it: every `kev1`, `recovery_seed` and `object_ids` golden vector
  is reproduced.
  - `kev1`: `wrap`, `unwrap`, `inspect`, `recipientId`, `publicKeyOf`, `kid`, `objectKey`, `skippedByRestore`, and
    the reader's ordered `ErrorCode`s.
  - `RecoverySeed`: `generate`, `parse`, `fromBytes`, `text`, and the X25519 and Ed25519 derivations.
  - The recovery kit codec (`parseKit`, `toJson`, `kitVaultFromJson`) and strict standard base64.
  - `Uid`, `newUid`, strict `toBase32` / `fromBase32`.
  - `SecretBytes` (locked, wiped, move-only), `wipe`, `equalConstantTime`, and the test wipe observer.
- `vectors/`: a verbatim copy of vaulthalla-server's golden vectors and their Python reference, checked by
  `meson test` (`vectors-reference`).

### Changed (from the vaulthalla-server code)

- OpenSSL 3 is the only crypto dependency: X25519 and Ed25519 public keys, SHA-256, the CSPRNG
  (`RAND_priv_bytes` for secrets), wiping (`OPENSSL_cleanse`) and constant-time comparison (`CRYPTO_memcmp`) no
  longer come from libsodium. Memory locking uses `mlock`.
- `kev1::wrap` takes the vault key as 32 bytes (`std::span`), and `kev1::Unwrapped::key` is `SecretBytes`, so the
  library has no key type of its own.
