# vl-keykit

Vaulthalla's key-recovery formats for C++23, in one library shared by Vaulthalla Server and Vaulthalla Cloud so the
formats cannot drift:

- **KEV1 key envelopes** (`vl/keykit/kev1.hpp`): one vault key version wrapped to one recipient public key, X25519 or
  P-256 ECDH + HKDF-SHA-256 + AES-256-GCM. Writer, reader with ordered error codes, and a keyless `inspect` for
  services that store envelopes they cannot open. Reserved purposes and recipient classes are refused and reported
  as skippable, so later recipient types fit without a format change.
- **Recovery seed** (`vl/keykit/seed.hpp`): 16 random bytes, 27-symbol Crockford base32 text with a check symbol,
  and the X25519 recovery recipient and Ed25519 signing key derived from it.
- **Recovery kit** (`vl/keykit/kit.hpp`): the `vh.recovery-kit` JSON document (seed, vault uids, pinned attestation
  public keys, checkpoints).
- **Uids** (`vl/keykit/uid.hpp`): 16-byte vault and object uids and their strict base32 form.
- **SecretBytes** (`vl/keykit/secret.hpp`): locked, wiped, move-only memory for every secret the library returns.

Specification: Vaulthalla `design/encryption/03-metadata-recovery.md` §5. Golden vectors: `vectors/` (shared with
vaulthalla-server and Vaulthalla Desktop).

Dependencies: OpenSSL 3 (libcrypto) and nlohmann_json; GoogleTest for the tests.

```bash
meson setup build -Db_sanitize=address,undefined && meson compile -C build && meson test -C build --print-errorlogs
```

Consume it as a meson subproject (`dependency('vl-keykit', fallback: ['vl-keykit', 'vl_keykit_dep'])`) or through
pkg-config (`vl-keykit`).

© 2026 Valkyrian Labs LLC. MIT License (see `LICENSE`).
