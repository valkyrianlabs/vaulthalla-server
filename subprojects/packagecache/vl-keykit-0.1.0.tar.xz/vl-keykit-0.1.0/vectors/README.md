# Golden vectors

`vectors.json` and `vh_crypto_vectors.py` are **verbatim copies** of Vaulthalla's
`design/encryption/vectors/` (vaulthalla-server 0bae6b39, v1.22.2). They stay byte-identical so
that every implementation of these formats is checked against one file:

- **this library** (C++): the `kev1`, `recovery_seed` and `object_ids` sections;
- **vaulthalla-server**: its own copy also carries `vhf1` and `manifest`, and its tests compare the shared sections
  with this copy through the `vectors_dir` variable of `vl_keykit_dep`;
- **Vaulthalla Desktop** (Swift, vaulthalla-desktop#49): the same file.

The normative text is Vaulthalla's `design/encryption/03-metadata-recovery.md` §5. A change to any vector needs the
spec change and an independent check (`python3 vh_crypto_vectors.py --check` regenerates the file, compares it byte
for byte and runs its separate reader). Change it upstream first and copy it again, never "regenerate to green" here.
`meson test` runs the `--check` as `vectors-reference` where Python's `cryptography` package is installed (CI always).
