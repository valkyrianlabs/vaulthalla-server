// SPDX-License-Identifier: AGPL-3.0-or-later
// Copyright (c) 2026 Valkyrian Labs LLC
//
// The reference binding of the vl-vaultfmt WebAssembly reader (vl-vaultfmt-reader.wasm, built by wasm/build.sh and
// checked against vl-vaultfmt-reader.wasm.sha256). It only moves bytes in and out of the module and supplies the few
// WASI calls libcrypto imports (randomness from crypto.getRandomValues, a clock; no files, no environment). Every rule
// (C1, the chain rules, VHF1, the manifest, KEV1) runs in the module; nothing here decides anything.
//
// Plain TypeScript with erasable syntax only, so Node 24 runs it as is and the portal copies it unchanged. Keys never
// cross this boundary out of the module: a Keyring and a Recipient are handles, wiped when freed. Inputs that are
// secrets (the recovery seed text) are zeroed in module memory after the call; the JavaScript string itself can't be.

const SIZE_T = 4;

export type Status = number;

/** A failed call: `code` is the library's stable status name ("vhf1_chunk_auth_failed", "chain_rollback"). */
export class VaultfmtError extends Error {
  readonly status: Status;
  readonly code: string;
  constructor(status: Status, code: string, call: string) {
    super(`${call}: ${code}`);
    this.name = "VaultfmtError";
    this.status = status;
    this.code = code;
  }
}

export interface ListedVersion {
  version_id: string;
  delete_marker?: boolean;
  is_latest?: boolean;
  size?: number;
  etag?: string | null;
}

export interface Anchor {
  epoch: number;
  root_sha256: string;
  version_id?: string | null;
}

export interface HeadDecision {
  epoch: number;
  root_sha256: string;
  version_id: string | null;
  freshness: "verified" | "unverified";
  gap: boolean;
  base_version_id: string | null;
  strays: string[];
  anchor: Anchor;
}

export interface RootInfo {
  epoch: bigint;
  root_sha256: string;
  gap: boolean;
  version_log: boolean;
  files: bigint;
  dirs: bigint;
  bytes: bigint;
}

export interface ObjectRef {
  sid: string;
  key: string;
  object_sha256: string;
  size: bigint;
  snapshot: boolean;
  range_lo: number;
  range_hi: number;
}

export interface HeaderInfo {
  kind: number;
  key_version: number;
  vault_uid: Uint8Array;
  object_uid: Uint8Array;
  salt: Uint8Array;
  chunk_log2: number;
  plaintext_size: bigint;
  chunk_count: bigint;
}

export interface Expectation {
  kind: number;
  vault_uid: Uint8Array;
  object_uid?: Uint8Array | null;
  generation?: Uint8Array | null;
}

/** A manifest entry as the library writes it (manifest/Document.hpp toJson): uid, kind, parent, name, size, ... */
export type Entry = Record<string, unknown> & { uid: string; kind: string; name: string; parent: string | null };

export const KIND_FILE_CONTENT = 1;
export const KIND_MANIFEST_SEGMENT = 2;
export const KIND_MANIFEST_ROOT = 3;
export const KEV1_SUITE_X25519 = 1;
export const KEV1_SUITE_P256 = 2;
export const HEADER_SIZE = 120;

const ERR_BUFFER_TOO_SMALL = 2;
const ERR_NEED_OBJECTS = 500;

type Fn = (...args: (number | bigint)[]) => number;
interface Exports extends Record<string, unknown> {
  memory: WebAssembly.Memory;
  _initialize(): void;
  malloc(n: number): number;
  free(p: number): void;
}

/** Function names the module must export; nothing that seals, publishes or deletes is among them. */
export const EXPORTED = [
  "vl_vaultfmt_version", "vl_vaultfmt_status_name", "vl_vaultfmt_keyring_new", "vl_vaultfmt_keyring_add",
  "vl_vaultfmt_keyring_add_envelope", "vl_vaultfmt_keyring_free", "vl_vaultfmt_recipient_from_seed",
  "vl_vaultfmt_recipient_from_secret", "vl_vaultfmt_recipient_id", "vl_vaultfmt_recipient_free",
  "vl_vaultfmt_content_key", "vl_vaultfmt_content_key_uid", "vl_vaultfmt_segment_key", "vl_vaultfmt_classify_key",
  "vl_vaultfmt_object_size", "vl_vaultfmt_buffer_new", "vl_vaultfmt_buffer_sink_fn", "vl_vaultfmt_buffer_data",
  "vl_vaultfmt_buffer_size", "vl_vaultfmt_buffer_clear", "vl_vaultfmt_buffer_free", "vl_vaultfmt_opener_new",
  "vl_vaultfmt_opener_info", "vl_vaultfmt_opener_update", "vl_vaultfmt_opener_finish", "vl_vaultfmt_range_plan",
  "vl_vaultfmt_range_read", "vl_vaultfmt_opener_free", "vl_vaultfmt_head_new", "vl_vaultfmt_head_needed",
  "vl_vaultfmt_head_supply", "vl_vaultfmt_head_gone", "vl_vaultfmt_head_decide", "vl_vaultfmt_head_json",
  "vl_vaultfmt_head_root", "vl_vaultfmt_head_free", "vl_vaultfmt_root_open", "vl_vaultfmt_root_info_get",
  "vl_vaultfmt_root_object_count", "vl_vaultfmt_root_object", "vl_vaultfmt_root_free", "vl_vaultfmt_tree_build",
  "vl_vaultfmt_tree_entry_count", "vl_vaultfmt_tree_find", "vl_vaultfmt_tree_json", "vl_vaultfmt_tree_list_json",
  "vl_vaultfmt_tree_stat_json", "vl_vaultfmt_tree_open_content", "vl_vaultfmt_tree_free",
] as const;

// WASI as libcrypto uses it: randomness, a clock, and calls it makes but that have nothing to reach here (files, the
// environment, user ids). Any other import makes instantiate fail.
function imports(memory: () => WebAssembly.Memory): WebAssembly.Imports {
  const view = () => new DataView(memory().buffer);
  const EBADF = 8;
  const ENOSYS = 52;
  return {
    wasi_snapshot_preview1: {
      random_get(ptr: number, len: number) {
        const bytes = new Uint8Array(memory().buffer, ptr, len);
        for (let at = 0; at < len; at += 65536) crypto.getRandomValues(bytes.subarray(at, Math.min(len, at + 65536)));
        return 0;
      },
      clock_time_get(_id: number, _precision: bigint, out: number) {
        view().setBigUint64(out, BigInt(Date.now()) * 1_000_000n, true);
        return 0;
      },
      environ_sizes_get(count: number, size: number) {
        view().setUint32(count, 0, true);
        view().setUint32(size, 0, true);
        return 0;
      },
      environ_get: () => 0,
      fd_write(_fd: number, iovs: number, iovsLen: number, written: number) {
        let n = 0;
        for (let i = 0; i < iovsLen; i++) n += view().getUint32(iovs + i * 8 + 4, true);
        view().setUint32(written, n, true);
        return 0;
      },
      fd_read: () => EBADF,
      fd_close: () => EBADF,
      fd_seek: () => EBADF,
      proc_exit(code: number) {
        throw new Error(`the vl-vaultfmt module stopped (${code})`);
      },
    },
    env: {
      emscripten_notify_memory_growth: () => {},
      __syscall_getuid32: () => 0,
      __syscall_geteuid32: () => 0,
      __syscall_getgid32: () => 0,
      __syscall_getegid32: () => 0,
      __syscall_getdents64: () => -ENOSYS,
    },
  };
}

/** One instance of the module; every handle belongs to it. */
export class Reader {
  /** @internal */ readonly x: Exports;
  private readonly sinkFn: number;
  private readonly enc = new TextEncoder();
  private readonly dec = new TextDecoder("utf-8", { fatal: true });

  private constructor(x: Exports) {
    this.x = x;
    this.sinkFn = this.fn("vl_vaultfmt_buffer_sink_fn")();
  }

  static async instantiate(source: BufferSource | WebAssembly.Module): Promise<Reader> {
    let memory: WebAssembly.Memory | null = null;
    const env = imports(() => {
      if (!memory) throw new Error("no memory yet");
      return memory;
    });
    const instance =
      source instanceof WebAssembly.Module
        ? await WebAssembly.instantiate(source, env)
        : (await WebAssembly.instantiate(source, env)).instance;
    const x = instance.exports as unknown as Exports;
    for (const name of [...EXPORTED, "memory", "malloc", "free", "_initialize"])
      if (!(name in instance.exports)) throw new Error(`the vl-vaultfmt module lacks ${name}`);
    memory = x.memory;
    x._initialize();
    return new Reader(x);
  }

  /** @internal */ fn(name: string): Fn {
    return this.x[name] as Fn;
  }

  /** @internal */ get u8(): Uint8Array {
    return new Uint8Array(this.x.memory.buffer);
  }

  /** @internal */ get dv(): DataView {
    return new DataView(this.x.memory.buffer);
  }

  /** @internal Copies bytes into module memory; free with release(). */
  put(bytes: Uint8Array): number {
    const p = this.x.malloc(Math.max(1, bytes.length));
    if (!p) throw new VaultfmtError(3, "out_of_memory", "malloc");
    this.u8.set(bytes, p);
    return p;
  }

  /** @internal Zeroes and frees what put() or alloc() returned. */
  release(p: number, len: number): void {
    if (!p) return;
    this.u8.fill(0, p, p + len);
    this.x.free(p);
  }

  /** @internal */ alloc(len: number): number {
    const p = this.x.malloc(Math.max(1, len));
    if (!p) throw new VaultfmtError(3, "out_of_memory", "malloc");
    this.u8.fill(0, p, p + len);
    return p;
  }

  /** @internal Runs `f` with each input copied in, then zeroes and frees them. */
  with<T>(inputs: (Uint8Array | null)[], f: (...ptrs: number[]) => T): T {
    const ptrs = inputs.map((b) => (b ? this.put(b) : 0));
    try {
      return f(...ptrs);
    } finally {
      inputs.forEach((b, i) => b && this.release(ptrs[i], b.length));
    }
  }

  /** @internal */ cstr(p: number): string {
    if (!p) return "";
    const u = this.u8;
    let end = p;
    while (u[end] !== 0) end++;
    return this.dec.decode(u.subarray(p, end));
  }

  /** @internal Calls a C function; throws VaultfmtError unless it returned OK. */
  call(name: string, ...args: (number | bigint)[]): void {
    const s = this.fn(name)(...args);
    if (s !== 0) throw new VaultfmtError(s, this.statusName(s), name);
  }

  /** @internal The buffer convention for text outputs: f(out, outLenPtr) asked twice. */
  text(name: string, f: (out: number, outLen: number) => Status): string {
    const lenp = this.alloc(SIZE_T);
    try {
      let s = f(0, lenp);
      const n = this.dv.getUint32(lenp, true);
      if (s === 0 && n === 0) return "";
      if (s !== ERR_BUFFER_TOO_SMALL) throw new VaultfmtError(s, this.statusName(s), name);
      const out = this.alloc(n);
      try {
        s = f(out, lenp);
        if (s !== 0) throw new VaultfmtError(s, this.statusName(s), name);
        return this.dec.decode(this.u8.subarray(out, out + this.dv.getUint32(lenp, true)));
      } finally {
        this.release(out, n);
      }
    } finally {
      this.x.free(lenp);
    }
  }

  /** @internal An out-pointer for a handle: f(outPtr), then the handle. */
  handle(name: string, f: (out: number) => Status): number {
    const out = this.alloc(4);
    try {
      const s = f(out);
      if (s !== 0) throw new VaultfmtError(s, this.statusName(s), name);
      return this.dv.getUint32(out, true);
    } finally {
      this.x.free(out);
    }
  }

  /** @internal A library buffer used as a sink: f(sinkFn, buffer), then its bytes copied out (and wiped inside). */
  sink(name: string, f: (sinkFn: number, buffer: number) => Status): Uint8Array {
    const b = this.handle("vl_vaultfmt_buffer_new", (out) => this.fn("vl_vaultfmt_buffer_new")(out));
    try {
      const s = f(this.sinkFn, b);
      if (s !== 0) throw new VaultfmtError(s, this.statusName(s), name);
      const p = this.fn("vl_vaultfmt_buffer_data")(b);
      const n = this.fn("vl_vaultfmt_buffer_size")(b);
      return p ? new Uint8Array(this.u8.subarray(p, p + n)) : new Uint8Array(0);
    } finally {
      this.fn("vl_vaultfmt_buffer_free")(b);
    }
  }

  /** @internal */ utf8(s: string): Uint8Array {
    return this.enc.encode(s);
  }

  /** @internal NUL-terminated. */ utf8z(s: string): Uint8Array {
    const b = this.enc.encode(s);
    const z = new Uint8Array(b.length + 1);
    z.set(b);
    return z;
  }

  version(): string {
    return this.cstr(this.fn("vl_vaultfmt_version")());
  }

  statusName(status: Status): string {
    return this.cstr(this.fn("vl_vaultfmt_status_name")(status));
  }

  keyring(): Keyring {
    return new Keyring(this, this.handle("vl_vaultfmt_keyring_new", (out) => this.fn("vl_vaultfmt_keyring_new")(out)));
  }

  /** The account recovery key from its text (KEV1 suite 1). The text is zeroed in module memory after the call. */
  recipientFromSeed(text: string): Recipient {
    const b = this.utf8(text);
    try {
      return new Recipient(this, this.with([b], (p) =>
        this.handle("vl_vaultfmt_recipient_from_seed", (out) => this.fn("vl_vaultfmt_recipient_from_seed")(p, b.length, out))));
    } finally {
      b.fill(0);
    }
  }

  /** A recipient from its raw 32-byte secret (suite 1 X25519, suite 2 P-256). */
  recipientFromSecret(suite: number, secret: Uint8Array): Recipient {
    return new Recipient(this, this.with([secret], (p) =>
      this.handle("vl_vaultfmt_recipient_from_secret", (out) =>
        this.fn("vl_vaultfmt_recipient_from_secret")(suite, p, secret.length, out))));
  }

  /** Starts choosing the canonical head of `.vaulthalla/root` from its version listing (newest first). */
  head(vaultUid: Uint8Array, listing: ListedVersion[] | string, anchor: Anchor | null = null): Head {
    const text = this.utf8(typeof listing === "string" ? listing : JSON.stringify(listing));
    const sha = anchor ? this.utf8z(anchor.root_sha256) : null;
    const vid = anchor?.version_id ? this.utf8z(anchor.version_id) : null;
    return this.with([vaultUid, text, sha, vid], (pv, pl, ps, pi) => {
      let pa = 0;
      if (anchor) {
        pa = this.alloc(16);
        this.dv.setBigUint64(pa, BigInt(anchor.epoch), true);
        this.dv.setUint32(pa + 8, ps, true);
        this.dv.setUint32(pa + 12, pi, true);
      }
      try {
        return new Head(this, this.handle("vl_vaultfmt_head_new", (out) =>
          this.fn("vl_vaultfmt_head_new")(pv, pl, text.length, pa, out)));
      } finally {
        if (pa) this.x.free(pa);
      }
    });
  }

  /** Authenticates a root object and applies the chain rules against `known` (null: nothing known). */
  openRoot(object: Uint8Array, vaultUid: Uint8Array, ring: Keyring, known: { epoch: number; root_sha256: string } | null = null): Root {
    const sha = known ? this.utf8z(known.root_sha256) : null;
    return this.with([object, vaultUid, sha], (po, pv, ps) => {
      let pk = 0;
      if (known) {
        pk = this.alloc(16);
        this.dv.setBigUint64(pk, BigInt(known.epoch), true);
        this.dv.setUint32(pk + 8, ps, true);
      }
      try {
        return new Root(this, this.handle("vl_vaultfmt_root_open", (out) =>
          this.fn("vl_vaultfmt_root_open")(po, object.length, pv, ring.h, pk, out)));
      } finally {
        if (pk) this.x.free(pk);
      }
    });
  }

  /** Authenticates a VHF1 header against `expect` (vectors, and callers without a tree). */
  openObject(header: Uint8Array, expect: Expectation, ring: Keyring, objectSize: bigint): Opener {
    return this.with([header, expect.vault_uid, expect.object_uid ?? null, expect.generation ?? null], (ph, pv, po, pg) => {
      const pe = this.alloc(16);
      this.dv.setInt32(pe, expect.kind, true);
      this.dv.setUint32(pe + 4, pv, true);
      this.dv.setUint32(pe + 8, po, true);
      this.dv.setUint32(pe + 12, pg, true);
      try {
        return new Opener(this, this.handle("vl_vaultfmt_opener_new", (out) =>
          this.fn("vl_vaultfmt_opener_new")(ph, header.length, pe, ring.h, objectSize, out)));
      } finally {
        this.x.free(pe);
      }
    });
  }

  /** o/<uid>, or the uid of such a key (null for any other key). */
  contentKey(uid: Uint8Array): string {
    return this.with([uid], (p) => this.text("vl_vaultfmt_content_key", (o, n) => this.fn("vl_vaultfmt_content_key")(p, o, n)));
  }

  contentKeyUid(key: string): Uint8Array | null {
    const b = this.utf8(key);
    const out = this.alloc(16);
    try {
      const s = this.with([b], (p) => this.fn("vl_vaultfmt_content_key_uid")(p, b.length, out));
      if (s === 6) return null;
      if (s !== 0) throw new VaultfmtError(s, this.statusName(s), "vl_vaultfmt_content_key_uid");
      return new Uint8Array(this.u8.subarray(out, out + 16));
    } finally {
      this.x.free(out);
    }
  }
}

abstract class Owned {
  protected readonly r: Reader;
  /** @internal */ h: number;
  private readonly freeName: string;
  constructor(r: Reader, h: number, freeName: string) {
    this.r = r;
    this.h = h;
    this.freeName = freeName;
  }
  /** @internal */ live(): number {
    if (!this.h) throw new VaultfmtError(7, "unusable", "freed handle");
    return this.h;
  }
  free(): void {
    if (this.h) this.r.fn(this.freeName)(this.h);
    this.h = 0;
  }
  [Symbol.dispose](): void {
    this.free();
  }
}

/** Vault keys, held in the module only; zeroed when freed. */
export class Keyring extends Owned {
  constructor(r: Reader, h: number) {
    super(r, h, "vl_vaultfmt_keyring_free");
  }
  /** Unwraps a KEV1 envelope with `recipient` and keeps the vault key; returns its key version. */
  addEnvelope(recipient: Recipient, vaultUid: Uint8Array, envelope: Uint8Array): number {
    const kv = this.r.alloc(4);
    try {
      this.r.with([vaultUid, envelope], (pv, pe) =>
        this.r.call("vl_vaultfmt_keyring_add_envelope", this.live(), recipient.live(), pv, pe, envelope.length, kv));
      return this.r.dv.getUint32(kv, true);
    } finally {
      this.r.x.free(kv);
    }
  }
  /** A raw vault key (the golden vectors). A page gets its keys through addEnvelope. */
  add(keyVersion: number, key: Uint8Array): void {
    this.r.with([key], (p) => this.r.call("vl_vaultfmt_keyring_add", this.live(), keyVersion, p, key.length));
  }
}

/** A KEV1 recipient's secret key (the account key), held in the module only; zeroed when freed. */
export class Recipient extends Owned {
  constructor(r: Reader, h: number) {
    super(r, h, "vl_vaultfmt_recipient_free");
  }
  /** SHA-256 of the recipient's public key. */
  id(): Uint8Array {
    const p = this.r.alloc(32);
    try {
      this.r.call("vl_vaultfmt_recipient_id", this.live(), p);
      return new Uint8Array(this.r.u8.subarray(p, p + 32));
    } finally {
      this.r.x.free(p);
    }
  }
}

/** The canonical head over a version listing (rule C1). */
export class Head extends Owned {
  constructor(r: Reader, h: number) {
    super(r, h, "vl_vaultfmt_head_free");
  }
  /** Version ids to GET (`.vaulthalla/root?versionId=`), then supply or report gone. */
  needed(): string[] {
    return JSON.parse(this.r.text("vl_vaultfmt_head_needed", (o, n) => this.r.fn("vl_vaultfmt_head_needed")(this.live(), o, n)));
  }
  supply(versionId: string, bytes: Uint8Array): void {
    const id = this.r.utf8(versionId);
    this.r.with([id, bytes], (pi, pb) =>
      this.r.call("vl_vaultfmt_head_supply", this.live(), pi, id.length, pb, bytes.length));
  }
  gone(versionId: string): void {
    const id = this.r.utf8(versionId);
    this.r.with([id], (pi) => this.r.call("vl_vaultfmt_head_gone", this.live(), pi, id.length));
  }
  /** true: decided; false: supply what needed() now names and decide again. Throws on a refusal. */
  decide(ring: Keyring): boolean {
    const s = this.r.fn("vl_vaultfmt_head_decide")(this.live(), ring.live());
    if (s === ERR_NEED_OBJECTS) return false;
    if (s !== 0) throw new VaultfmtError(s, this.r.statusName(s), "vl_vaultfmt_head_decide");
    return true;
  }
  decision(): HeadDecision {
    return JSON.parse(this.r.text("vl_vaultfmt_head_json", (o, n) => this.r.fn("vl_vaultfmt_head_json")(this.live(), o, n)));
  }
  root(ring: Keyring): Root {
    return new Root(this.r, this.r.handle("vl_vaultfmt_head_root", (out) =>
      this.r.fn("vl_vaultfmt_head_root")(this.live(), ring.live(), out)));
  }
}

export class Root extends Owned {
  constructor(r: Reader, h: number) {
    super(r, h, "vl_vaultfmt_root_free");
  }
  info(): RootInfo {
    const p = this.r.alloc(112);
    try {
      this.r.call("vl_vaultfmt_root_info_get", this.live(), p);
      const d = this.r.dv;
      return {
        epoch: d.getBigUint64(p, true),
        root_sha256: this.r.cstr(p + 8),
        gap: d.getInt32(p + 76, true) !== 0,
        version_log: d.getInt32(p + 80, true) !== 0,
        files: d.getBigUint64(p + 88, true),
        dirs: d.getBigUint64(p + 96, true),
        bytes: d.getBigUint64(p + 104, true),
      };
    } finally {
      this.r.x.free(p);
    }
  }
  /** The objects the root pins (tree segments, then snapshot segments): GET each `key`. */
  objects(): ObjectRef[] {
    const n = this.r.fn("vl_vaultfmt_root_object_count")(this.live());
    const out: ObjectRef[] = [];
    const p = this.r.alloc(32);
    try {
      for (let i = 0; i < n; i++) {
        this.r.call("vl_vaultfmt_root_object", this.h, i, p);
        const d = this.r.dv;
        out.push({
          sid: this.r.cstr(d.getUint32(p, true)),
          key: this.r.cstr(d.getUint32(p + 4, true)),
          object_sha256: this.r.cstr(d.getUint32(p + 8, true)),
          size: d.getBigUint64(p + 16, true),
          snapshot: d.getInt32(p + 24, true) !== 0,
          range_lo: d.getUint8(p + 28),
          range_hi: d.getUint8(p + 29),
        });
      }
    } finally {
      this.r.x.free(p);
    }
    return out;
  }
  /** Builds the tree from the pinned objects' bytes (by sid): each present, matching its pin, authentic. */
  tree(objects: Map<string, Uint8Array>, ring: Keyring): Tree {
    const entries = [...objects];
    const sids = entries.map(([sid]) => this.r.utf8z(sid));
    const bytes = entries.map(([, b]) => b);
    return this.r.with([...sids, ...bytes], (...ptrs) => {
      const arr = this.r.alloc(12 * Math.max(1, entries.length));
      try {
        for (let i = 0; i < entries.length; i++) {
          this.r.dv.setUint32(arr + 12 * i, ptrs[i], true);
          this.r.dv.setUint32(arr + 12 * i + 4, ptrs[entries.length + i], true);
          this.r.dv.setUint32(arr + 12 * i + 8, bytes[i].length, true);
        }
        return new Tree(this.r, this.r.handle("vl_vaultfmt_tree_build", (out) =>
          this.r.fn("vl_vaultfmt_tree_build")(this.live(), arr, entries.length, ring.live(), out)));
      } finally {
        this.r.x.free(arr);
      }
    });
  }
}

export class Tree extends Owned {
  constructor(r: Reader, h: number) {
    super(r, h, "vl_vaultfmt_tree_free");
  }
  /** Every entry, in uid order. */
  entries(): Entry[] {
    return JSON.parse(this.r.text("vl_vaultfmt_tree_json", (o, n) => this.r.fn("vl_vaultfmt_tree_json")(this.live(), o, n)));
  }
  /** The entries whose parent is `parent` (null: the vault root itself). */
  list(parent: string | null): Entry[] {
    const p = parent === null ? null : this.r.utf8(parent);
    return JSON.parse(this.r.with([p], (pp) => this.r.text("vl_vaultfmt_tree_list_json", (o, n) =>
      this.r.fn("vl_vaultfmt_tree_list_json")(this.live(), pp, p ? p.length : 0, o, n))));
  }
  /** One entry, or null. */
  stat(uid: string): Entry | null {
    const u = this.r.utf8(uid);
    try {
      return JSON.parse(this.r.with([u], (pu) => this.r.text("vl_vaultfmt_tree_stat_json", (o, n) =>
        this.r.fn("vl_vaultfmt_tree_stat_json")(this.live(), pu, u.length, o, n))));
    } catch (e) {
      if (e instanceof VaultfmtError && e.code === "not_found") return null;
      throw e;
    }
  }
  /** Opens a file's object header (bytes [0, HEADER_SIZE) of o/<uid>, or of `versionId`) bound to this entry. */
  openContent(vaultUid: Uint8Array, uid: string, header: Uint8Array, ring: Keyring, versionId: string | null = null): Opener {
    const u = this.r.utf8(uid);
    const v = versionId === null ? null : this.r.utf8(versionId);
    return new Opener(this.r, this.r.with([vaultUid, u, v, header], (pv, pu, pi, ph) =>
      this.r.handle("vl_vaultfmt_tree_open_content", (out) =>
        this.r.fn("vl_vaultfmt_tree_open_content")(this.live(), pv, pu, u.length, pi, v ? v.length : 0, ph, header.length,
                                                   ring.live(), out))));
  }
}

/** One VHF1 object: streamed (update/finish) or ranged (rangePlan/rangeRead). Only authenticated plaintext leaves. */
export class Opener extends Owned {
  constructor(r: Reader, h: number) {
    super(r, h, "vl_vaultfmt_opener_free");
  }
  info(): HeaderInfo {
    const p = this.r.alloc(96);
    try {
      this.r.call("vl_vaultfmt_opener_info", this.live(), p);
      const d = this.r.dv;
      const u8 = this.r.u8;
      return {
        kind: d.getInt32(p, true),
        key_version: d.getUint32(p + 4, true),
        vault_uid: new Uint8Array(u8.subarray(p + 8, p + 24)),
        object_uid: new Uint8Array(u8.subarray(p + 24, p + 40)),
        salt: new Uint8Array(u8.subarray(p + 40, p + 72)),
        chunk_log2: d.getUint8(p + 72),
        plaintext_size: d.getBigUint64(p + 80, true),
        chunk_count: d.getBigUint64(p + 88, true),
      };
    } finally {
      this.r.x.free(p);
    }
  }
  /** The object's bytes after the header, in order, in any split: the plaintext of the chunks that authenticated. */
  update(sealed: Uint8Array): Uint8Array {
    return this.r.with([sealed], (p) => this.r.sink("vl_vaultfmt_opener_update", (fn, b) =>
      this.r.fn("vl_vaultfmt_opener_update")(this.live(), p, sealed.length, fn, b)));
  }
  /** Throws unless the whole object arrived and authenticated. */
  finish(): void {
    this.r.call("vl_vaultfmt_opener_finish", this.live());
  }
  /** The object bytes [offset, offset + length) a read of plaintext [start, end) needs (one ranged GET). */
  rangePlan(start: bigint, end: bigint): { offset: bigint; length: bigint } {
    const p = this.r.alloc(16);
    try {
      this.r.call("vl_vaultfmt_range_plan", this.live(), start, end, p, p + 8);
      return { offset: this.r.dv.getBigUint64(p, true), length: this.r.dv.getBigUint64(p + 8, true) };
    } finally {
      this.r.x.free(p);
    }
  }
  /** Plaintext [start, end) from exactly the planned window; `providerSize` is the Content-Range total. */
  rangeRead(start: bigint, end: bigint, providerSize: bigint, window: Uint8Array): Uint8Array {
    return this.r.with([window], (p) => this.r.sink("vl_vaultfmt_range_read", (fn, b) =>
      this.r.fn("vl_vaultfmt_range_read")(this.live(), start, end, providerSize, p, window.length, fn, b)));
  }
}
