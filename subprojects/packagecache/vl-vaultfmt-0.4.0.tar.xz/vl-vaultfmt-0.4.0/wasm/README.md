# The WebAssembly reader

`vl-vaultfmt-reader.wasm` is this library built for the browser, read only: the Vaulthalla Cloud portal uses it to show
a Desktop-only vault (a vault a Mac keeps in a bucket, with no server). The page fetches the bucket's encrypted
objects; the module chooses the canonical root, decrypts names, folders and file contents, and hands back only bytes
that authenticated. The rules are the library's own code (vaulthalla-server `design/core/vault-format-library.md`,
decided items 4 and 5), not a second implementation.

| File | What |
| --- | --- |
| `vl-vaultfmt-reader.wasm` | the artifact (committed) |
| `vl-vaultfmt-reader.wasm.sha256` | its checksum: the portal checks the bytes against it before instantiating |
| `build.sh`, `build-in-container.sh` | the reproducible build (below) |
| `exports.txt` | the functions the module exports |
| `reader.ts` | the reference binding (typed wrappers, the WASI shims): the portal copies it unchanged |
| `tests/reader.test.ts`, `tests/fixture.json` | the Node tests; the fixture is a vault the native library built (`tests/reader_fixture.hpp`) |

## Build

```bash
wasm/build.sh            # rebuild in the pinned container; fails unless the bytes equal the committed artifact
wasm/build.sh --record   # after a deliberate change: rebuild, replace the artifact and its checksum
cd wasm && node --test tests/reader.test.ts   # Node 24 or later (runs reader.ts as is)
```

A change to anything the module compiles (`src/`, `include/`, the vl-keykit tarball, the pins below) needs
`--record` in the same change; the `wasm` CI job rebuilds and fails on a stale artifact. Regenerate the fixture after a
format change with `build/tests/make_reader_fixture wasm/tests/fixture.json` (the native suite reads the committed
copy too, so a stale one fails there first).

Pinned inputs (all in `build.sh`; the build itself runs with `--network=none`):

| Input | Pin |
| --- | --- |
| Emscripten 6.0.13 (clang 24, binaryen, Node 24.19), image `docker.io/emscripten/emsdk` | `sha256:fb7864e398acfda863dfcea78b8bc8adad359fa60c6a0bbeb845931de64aa68a` (multi-architecture list; amd64 and arm64 build the same bytes) |
| OpenSSL 3.5.9 (`openssl-3.5.9.tar.gz`), the 3.5 LTS line, supported to 2030-04-08 | `603f5602e2eef00d77fbd429d34dcd5822bb301757a1bc9cdb24c670f1eb859a`; release signature checked against the OpenSSL key `B146 647E 45A7 B339 47AB 226B 2A2C 87D1 6169 2D40` when pinned |
| nlohmann_json 3.11.3 (`json.tar.xz`), the version the native CI image carries | `d6c65aca6b1ed68e7a182f4757257b107ae403032760ed6ef121c9d55e81757d` |
| vl-keykit 0.2.0 | the committed `subprojects/packagecache/` tarball and its unity patch |

Why OpenSSL 3.5: it is the LTS line, so security fixes arrive as patch releases for years without API changes, and it
keeps the one API generation the native builds use (OpenSSL 3.x); 4.x is not LTS. Bump it with the pin and `--record`.

Choices, as measured (Emscripten 6.0.13, OpenSSL configured with only what the reader needs, `wasm/build-in-container.sh`):

| Variant | Raw bytes | gzip -9 |
| --- | ---: | ---: |
| **-Oz, LTO, emmalloc, standalone (WASI imports): the artifact** | **1,324,887** | **575,279** (brotli -q 11: 476,632) |
| -Oz, no LTO | 1,368,732 | 586,722 |
| -Os | 1,457,624 | 606,054 |
| -O2 | 1,653,404 | 658,973 |
| dlmalloc instead of emmalloc | 1,375,916 | 589,894 |
| Emscripten's minimal runtime (+ its JS glue) | 1,339,806 + 8,239 | 595,917 + 2,961 |

- **Standalone WebAssembly, not Emscripten's JS runtime:** smaller, no generated JavaScript to review or pin, and the
  same pattern as the portal's relay TLS module (`reader.ts` supplies the handful of WASI calls).
- **`-fwasm-exceptions` (legacy wasm exception handling):** the library reports errors as C++ exceptions, every C entry
  catches them; it is the only exception model standalone WebAssembly has, and every current browser supports it.
- **No threads, no filesystem, a plain C ABI, no embind:** the C API already exists and is what Desktop uses; embind
  would add generated glue and a second interface.
- **Size is acceptable, so there is no crypto backend seam.** The budget I hold it to: at most about 600 KB
  compressed for a module that only the vault browser route loads, once, cached immutably, compiled while it streams
  (it compiles in milliseconds). 575 KB gzip / 477 KB brotli is inside it. Two thirds of it is libcrypto (OpenSSL 3's
  default provider registers every algorithm it was built with, and its object identifier tables are large); a seam
  would need a second, smaller synchronous AES-GCM, HKDF, SHA-256, X25519 and P-256 implementation, which this
  repository does not import, and WebCrypto can't back it (it is asynchronous). If the portal's budget tightens, the
  next step is trimming libcrypto further, then the seam (design item 4).

Reproducibility: fixed paths (`/build`, mapped away with `-ffile-prefix-map`), `SOURCE_DATE_EPOCH`, sorted link order,
no network. Proven 2026-11-15: the Linux box (amd64, Ubuntu 24.04, rootless Podman) built it twice and a Linux VM
on the Mac Studio (Tart, Ubuntu 24.04 arm64, rootless Podman: the image's arm64 variant, so another clang binary) built it once, all `0c07c605ac413f3b53c9f385ab4a1d2d0763cdf235d394635013e6540b7dbc29`.
A build takes about 50 s with 6 jobs once the image is pulled (2.5 GB).

## The API

The C functions are in `include/vl/vaultfmt/vl_vaultfmt.h` ("The reader", plus the opener, ranged reads, root and
tree above it); `reader.ts` wraps them:

```ts
const r = await Reader.instantiate(bytes);              // after checking bytes against vl-vaultfmt-reader.wasm.sha256
const ring = r.keyring();
const account = r.recipientFromSeed(recoveryKeyText);   // or recipientFromSecret(2, p256Scalar) for a device grant
for (const env of envelopes) try { ring.addEnvelope(account, vaultUid, env); } catch {}   // kev1_recipient_mismatch: not ours
account.free();
const head = r.head(vaultUid, listing, anchor);         // listing: the root key's versions, newest first
do for (const id of head.needed()) head.supply(id, await getVersion(id)); while (!head.decide(ring));
const { epoch, freshness, gap, anchor: next } = head.decision();
const root = head.root(ring);
const tree = root.tree(new Map(await Promise.all(root.objects().map(async (o) => [o.sid, await get(o.key)]))), ring);
tree.list(null); tree.list(dirUid); tree.stat(uid);
const opener = tree.openContent(vaultUid, uid, await getRange(`o/${uid}`, 0, 120), ring);
const { offset, length } = opener.rangePlan(start, end);
const plain = opener.rangeRead(start, end, contentRangeTotal, await getRange(`o/${uid}`, offset, length));
```

- **Head (rule C1).** The page lists `.vaulthalla/root` with `ListObjectVersions` (prefix `.vaulthalla/root`, every
  page, versions and delete markers merged in the order listed, entries of other keys dropped) and passes it as JSON.
  The module names the versions it needs (with an anchor, those from the anchor on; otherwise all); the page GETs them
  by `versionId`, in parallel, and supplies them (a 404 is `gone`). `decide` runs C1 with the anchor, then the chain
  rules; it can ask once more (an incomplete chain from the anchor needs the older versions). Versions that don't
  authenticate as this vault's root are skipped, as the rule says.
- **Anchor and freshness.** With an anchor (the last head accepted, or a Desktop checkpoint) the head is that root or
  a later one on its chain: an older root is `chain_rollback` (a stale root), another root of the same history is
  `chain_fork`. Without one, `freshness` is `"unverified"`: the head is the newest valid state in this listing, and a
  bucket that hid newer versions or replays an old root can't be told from an honest one. `gap` means newer than the
  anchor with no chain to it in the listing, accepted with that warning, as the server does. Keep `decision().anchor`
  for the next visit.
- **Tree.** Every object the head pins must be supplied, match its pinned SHA-256 and size, and authenticate:
  `chain_segment_missing`, `chain_segment_mismatch`, `vhf1_*`. No fallbacks (the server's provider-version and
  older-root fallbacks are a restore's, not a viewer's).
- **Content.** `openContent` binds the object to its entry: kind, vault, the file's uid, its generation and its sealed
  size, so another file's object, another vault's, or an older or newer generation is refused at the header. Ranged
  reads return a range only when every chunk under it authenticated (`vhf1_chunk_auth_failed` otherwise, and the
  opener refuses further ranged reads); the provider's total size must equal the authenticated one.
- **Keys.** Vault keys enter the keyring only by unwrapping KEV1 envelopes (`.vaulthalla/key/<kid>`: list the prefix,
  or take the kids a root names) with a recipient handle; no function returns a key. Handles are wiped when freed:
  free the recipient once the envelopes are unwrapped, and the keyring when the vault view closes.
  (`Keyring.add` takes a raw key for the golden vectors; a page has no use for it.)

## Threat model, in plain words

The module protects the page against the **storage**: a bucket (or anything between it and the page) that returns
altered, swapped, truncated, replayed or foreign objects gets refusals, never wrong plaintext. It can still refuse to
serve, serve a consistent older state to a reader with no anchor, and see which objects and ranges are fetched and how
big they are.

It does not protect against the **page**. The portal's code is served by the service, and whatever runs on
`app.vaulthalla.cloud` can do what the page does: call the module with the keyring the user unlocked (and so decrypt
the whole vault while the tab is open), read the module's memory directly (keys included: WebAssembly memory is an
ordinary `ArrayBuffer` that can't be locked; wiping shortens how long a key sits there, nothing more), read the
recovery key as the user types it, or load a different module altogether. The protections there are the portal's: its
CSP (no inline script, no eval, `'wasm-unsafe-eval'` only), the checksum check of this module, keys held only for the
tab and never stored unwrapped, and the user's trust in the service that serves the page, as for any end to end
encrypted web application. A user who must not trust the service reads the vault with Desktop.

## Limits

| Input | Limit | Past it |
| --- | --- | --- |
| Listing JSON | 8 MiB, 10,000 versions, version ids of 1,024 bytes, nesting depth 4 | `reader_limit`, `reader_bad_listing` |
| One root version / all supplied to a head | 16 MiB / 256 MiB | `reader_limit` |
| A plaintext buffer (one sink call's output) | 1 GiB | `callback_failed` |
| Module memory | 4 MiB initial, grows to 2 GiB | `out_of_memory` |
| Stack | 1 MiB | |

Every allocation is bounded by the bytes supplied (sizes and counts inside objects are checked against them before
anything is allocated); the reader's fuzz target runs with `-malloc_limit_mb=64` (`fuzz/fuzz_reader.cpp`). Segments
and content objects have no limit of their own beyond memory: the page decides how much it fetches (ranged reads for
large files). `vhf1` `range_without_size` (a read with no authenticated size) can't arise here: an opener always has
one.

## What the portal does to use it

1. Copy `vl-vaultfmt-reader.wasm`, its `.sha256` and `reader.ts`; load the module as the relay does
   (`?url` import, fetch, compare SHA-256 with the recorded one, then `Reader.instantiate`). Serve it as
   `application/wasm`, immutable.
2. CSP: `script-src 'self' 'wasm-unsafe-eval'` is already there. Add the bucket's origin to `connect-src` (the managed
   storage endpoint the cloud issues access for). The bucket's CORS must allow `GET` and `HEAD` from
   `https://app.vaulthalla.cloud` with the `Range` header, and expose `ETag`, `Content-Range`, `Content-Length` and
   `x-amz-version-id`.
3. Fetch with the short-lived read access the cloud issues (workstream K): `ListObjectVersions` of `.vaulthalla/root`,
   GETs by `versionId`, GETs of `.vaulthalla/seg/<sid>`, `ListObjects` of `.vaulthalla/key/` and those envelopes, and
   ranged GETs of `o/<uid>` (with the entry's `object.version_id` when it names one). Only these keys are in an
   opaque_v1 bucket's allowlist. Read a pinned segment only up to its pinned `size` (the root names it before the
   GET): a longer body is refused anyway, so there is no reason to download it.
4. Keys: the account recovery key typed by the user (its X25519 key unwraps the vault keys' KEV1 envelopes), or later
   a device grant (P-256, suite 2). Never stored; free the recipient after unwrapping, the keyring when the view
   closes.
5. Keep the anchor per vault (the last `decision().anchor`) where the page can't be made to forget it silently, and
   show "freshness unverified" when there is none.
