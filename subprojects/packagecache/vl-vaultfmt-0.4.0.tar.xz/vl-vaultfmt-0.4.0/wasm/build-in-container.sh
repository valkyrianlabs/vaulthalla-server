#!/usr/bin/env bash
# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (c) 2026 Valkyrian Labs LLC
#
# The WebAssembly reader's build, inside the pinned Emscripten image (wasm/build.sh runs it; never run it on a host).
# Inputs, read only: /src (this repository), /cache (the pinned, checksum-verified source tarballs). Output: /out.
# No network (the container runs with --network=none). Every path is fixed (/build/...) and mapped away
# (-ffile-prefix-map), the clock is SOURCE_DATE_EPOCH, and objects link in sorted order, so two machines produce the
# same bytes.
#
# Measurement knobs (the committed artifact uses the defaults): VF_OPT (Oz), VF_LTO (1), VF_MALLOC (emmalloc),
# VF_RUNTIME (standalone | minimal: Emscripten's minimal JS runtime instead of WASI imports, for comparison only).
set -euo pipefail
export LC_ALL=C TZ=UTC SOURCE_DATE_EPOCH=1767225600
jobs=${VF_JOBS:-6}
opt=${VF_OPT:-Oz}
lto=${VF_LTO:-1}
malloc=${VF_MALLOC:-emmalloc}
runtime=${VF_RUNTIME:-standalone}
names=${VF_NAMES:-0}   # 1: keep function names (size attribution only)
openssl=openssl-${VF_OPENSSL_VERSION:?}
json_version=${VF_JSON_VERSION:?}
keykit=vl-keykit-0.2.0

B=/build
mkdir -p "$B" && cd "$B"
tar -xzf "/cache/$openssl.tar.gz"
mkdir json && tar -xJf "/cache/json-$json_version.tar.xz" -C json --strip-components=1
tar -xJf "/src/subprojects/packagecache/$keykit.tar.xz"
patch -s -d "$keykit" -p1 < "/src/subprojects/packagefiles/$keykit-unity.patch"
mkdir -p vl-vaultfmt/wasm && cp -r /src/include /src/src vl-vaultfmt/ && cp /src/wasm/exports.txt vl-vaultfmt/wasm/
version=$(sed -n "s/^  version: '\([0-9.]*\)',$/\1/p" /src/meson.build)
[[ -n "$version" ]] || { echo "no version in meson.build" >&2; exit 1; }

map="-ffile-prefix-map=$B/="
flto=$([[ "$lto" == 1 ]] && echo -flto || true)

# libcrypto: only what the reader uses (AES-256-GCM, SHA-256, HMAC, HKDF, X25519, P-256 ECDH, the DRBG) plus what the
# default provider always carries; no threads, sockets, engines, modules, error strings or file names.
(
  cd "$openssl"
  ./Configure linux-generic32 CC=emcc AR=emar RANLIB=emranlib \
    no-shared no-asm no-threads no-thread-pool no-default-thread-pool no-dso no-engine no-dynamic-engine no-module \
    no-legacy no-apps no-tests no-docs no-ui-console no-sock no-dgram no-ktls no-afalgeng no-devcryptoeng \
    no-padlockeng no-loadereng no-capieng no-autoload-config no-async no-secure-memory no-err no-filenames \
    no-http no-ocsp no-cms no-ts no-ct no-cmp no-srp no-srtp no-psk no-ssl no-tls no-dtls no-quic no-comp no-zlib \
    no-aria no-bf no-blake2 no-camellia no-cast no-chacha no-poly1305 no-des no-dh no-dsa no-ec2m no-gost no-idea \
    no-md2 no-md4 no-mdc2 no-ocb no-rc2 no-rc4 no-rc5 no-rmd160 no-scrypt no-seed no-siphash no-siv no-sm2 \
    no-sm2-precomp no-sm3 no-sm4 no-whirlpool no-argon2 no-ml-dsa no-ml-kem no-slh-dsa no-rfc3779 no-sslkeylog \
    no-trace no-deprecated no-weak-ssl-ciphers no-nextprotoneg no-multiblock no-ecdsa no-egd no-jitter no-uplink \
    no-atexit no-cmac \
    --with-rand-seed=getrandom --prefix="$B/openssl" --openssldir="$B/openssl/ssl" --libdir=lib \
    "-$opt" $flto "$map" > configure.log 2>&1 || { tail -30 configure.log >&2; exit 1; }
  make -s -j"$jobs" build_generated > make.log 2>&1 && make -s -j"$jobs" libcrypto.a >> make.log 2>&1 ||
    { tail -40 make.log >&2; exit 1; }
)

# The library and vl-keykit, C++23 with WebAssembly exceptions.
cxxflags=(-std=c++23 "-$opt" $flto -fwasm-exceptions -DNDEBUG "$map" "-DVL_VAULTFMT_VERSION=\"$version\""
          -I"$B/vl-vaultfmt/include" -I"$B/$keykit/include" -I"$B/json/include" -I"$B/$openssl/include")
sources=(
  vl-vaultfmt/src/ObjectKeys.cpp vl-vaultfmt/src/c_api.cpp vl-vaultfmt/src/c_api_reader.cpp
  vl-vaultfmt/src/manifest/Chain.cpp vl-vaultfmt/src/manifest/Content.cpp vl-vaultfmt/src/manifest/Document.cpp
  vl-vaultfmt/src/manifest/Objects.cpp vl-vaultfmt/src/manifest/Partition.cpp vl-vaultfmt/src/manifest/Reader.cpp
  vl-vaultfmt/src/manifest/Store.cpp vl-vaultfmt/src/manifest/VersionLog.cpp vl-vaultfmt/src/manifest/WriteCapability.cpp
  vl-vaultfmt/src/vhf1/Aead.cpp vl-vaultfmt/src/vhf1/Format.cpp vl-vaultfmt/src/vhf1/Key.cpp
  vl-vaultfmt/src/vhf1/Reader.cpp vl-vaultfmt/src/vhf1/Writer.cpp
  "$keykit/src/kev1.cpp" "$keykit/src/openssl.cpp" "$keykit/src/sealing.cpp" "$keykit/src/secret.cpp"
  "$keykit/src/seed.cpp" "$keykit/src/text.cpp" "$keykit/src/uid.cpp"
)
mkdir -p obj
printf '%s\n' "${sources[@]}" | xargs -P "$jobs" -I{} sh -c \
  'src=$1; shift; em++ "$@" -c "$src" -o "obj/$(echo "$src" | tr / _).o"' _ {} "${cxxflags[@]}" ||
  { echo "compile failed" >&2; exit 1; }

exports=$(grep -v '^#' vl-vaultfmt/wasm/exports.txt | sed '/^$/d; s/^/_/' | paste -sd, -)
ldflags=("-$opt" $flto -fwasm-exceptions --no-entry "-sEXPORTED_FUNCTIONS=$exports" -sFILESYSTEM=0
         -sALLOW_MEMORY_GROWTH=1 -sINITIAL_MEMORY=4MB -sMAXIMUM_MEMORY=2GB -sSTACK_SIZE=1MB "-sMALLOC=$malloc"
         -sERROR_ON_UNDEFINED_SYMBOLS=1)
[[ "$names" == 1 ]] && ldflags+=(--profiling-funcs)
objects=$(find obj -name '*.o' | sort)
if [[ "$runtime" == standalone ]]; then
  em++ $objects "$openssl/libcrypto.a" "${ldflags[@]}" -sSTANDALONE_WASM=1 -o /out/vl-vaultfmt-reader.wasm
else
  em++ $objects "$openssl/libcrypto.a" "${ldflags[@]}" -sMINIMAL_RUNTIME=1 -sENVIRONMENT=web,node -sMODULARIZE=1 \
    -sEXPORT_ES6=1 -o /out/vl-vaultfmt-reader.mjs
fi

cd /out
for f in *.wasm *.mjs; do
  [[ -f "$f" ]] || continue
  printf '%s raw %s gzip-9 %s\n' "$f" "$(wc -c < "$f")" "$(gzip -9n < "$f" | wc -c)"
done > sizes.txt
emcc --version | head -1 > toolchain.txt
echo "$openssl, nlohmann_json $json_version, $keykit, opt $opt, lto $lto, malloc $malloc, runtime $runtime" >> toolchain.txt
