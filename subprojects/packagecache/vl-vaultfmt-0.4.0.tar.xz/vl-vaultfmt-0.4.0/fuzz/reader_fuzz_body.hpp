// SPDX-License-Identifier: AGPL-3.0-or-later
// Copyright (c) 2026 Valkyrian Labs LLC
#pragma once

// One fuzz iteration over the reader's byte-facing entry points (vl_vaultfmt.h, "The reader"), which the portal feeds
// with whatever the bucket returned: version listings, root versions, segments, content objects, KEV1 envelopes and
// seed text. Shared by the libFuzzer target (fuzz_reader.cpp, -Dfuzz=true) and ReaderProperty in the unit tests, which
// replays a deterministic input set on every build. Violations call std::abort(): a crash, never an ignored result.
//
// Every status must have a name and none may be `internal`. Oracles where the answer is known:
//   - a segment set that differs from the fixture's in any pinned byte never builds a tree;
//   - a ranged read that returns plaintext returns the fixture file's bytes at that offset;
//   - an envelope that unwraps yields the fixture's vault key (the ring then opens the fixture's head root);
//   - a decided head opens as a root.
// The first input byte picks the mode (0 listing text, 1 structured listing and root versions, 2 segments, 3 content,
// 4 envelopes, 5 seed text).

#include "../tests/reader_fixture.hpp"

#include "vl/vaultfmt/vl_vaultfmt.h"

#include <algorithm>
#include <cstdint>
#include <cstdlib>
#include <cstring>
#include <map>
#include <optional>
#include <set>
#include <span>
#include <string>
#include <vector>

namespace vl::vaultfmt::reader_fuzz {

inline void require(const bool ok) {
    if (!ok) std::abort();
}

inline void requireStatus(const vl_vaultfmt_status s) {
    require(std::string(vl_vaultfmt_status_name(s)) != "unknown");
    require(s != VL_VAULTFMT_ERR_INTERNAL);
}

class Input {
public:
    explicit Input(std::span<const uint8_t> data) : data_(data) {}
    uint8_t u8() { return pos_ < data_.size() ? data_[pos_++] : 0; }
    uint16_t u16() { return static_cast<uint16_t>((u8() << 8) | u8()); }
    std::span<const uint8_t> rest() { return data_.subspan(std::min(pos_, data_.size())); }
    std::span<const uint8_t> take(std::size_t n) {
        const auto at = std::min(pos_, data_.size());
        const auto out = data_.subspan(at, std::min(n, data_.size() - at));
        pos_ += out.size();
        return out;
    }

private:
    std::span<const uint8_t> data_;
    std::size_t pos_{};
};

struct World {
    test::ReaderFixture f = test::buildReaderFixture();
    vl_vaultfmt_keyring* ring = nullptr;
    vl_vaultfmt_root* head = nullptr;
    vl_vaultfmt_tree* tree = nullptr;
    std::set<std::string> pinned;   // the sids the head names
    World() {
        require(vl_vaultfmt_keyring_new(&ring) == VL_VAULTFMT_OK);
        vl_vaultfmt_recipient* r = nullptr;
        require(vl_vaultfmt_recipient_from_seed(f.seed_text.data(), f.seed_text.size(), &r) == VL_VAULTFMT_OK);
        require(vl_vaultfmt_keyring_add_envelope(ring, r, f.vault.data(), f.envelope.data(), f.envelope.size(), nullptr) ==
                VL_VAULTFMT_OK);
        vl_vaultfmt_recipient_free(r);
        const auto& bytes = rootBytes(f.epoch_version.at(3));
        require(vl_vaultfmt_root_open(bytes.data(), bytes.size(), f.vault.data(), ring, nullptr, &head) == VL_VAULTFMT_OK);
        for (size_t i = 0; i < vl_vaultfmt_root_object_count(head); ++i) {
            vl_vaultfmt_object_ref ref{};
            require(vl_vaultfmt_root_object(head, i, &ref) == VL_VAULTFMT_OK);
            pinned.insert(ref.sid);
        }
        const auto objects = segmentInputs(f.segments);
        require(vl_vaultfmt_tree_build(head, objects.data(), objects.size(), ring, &tree) == VL_VAULTFMT_OK);
    }
    World(const World&) = delete;
    World& operator=(const World&) = delete;
    ~World() {
        vl_vaultfmt_tree_free(tree);
        vl_vaultfmt_root_free(head);
        vl_vaultfmt_keyring_free(ring);
    }
    [[nodiscard]] const test::Bytes& rootBytes(const std::string& id) const {
        for (const auto& r : f.roots)
            if (r.version_id == id) return r.bytes;
        std::abort();
    }
    static std::vector<vl_vaultfmt_object_bytes> segmentInputs(const std::map<std::string, test::Bytes>& segments) {
        std::vector<vl_vaultfmt_object_bytes> out;
        for (const auto& [sid, bytes] : segments) out.push_back({sid.c_str(), bytes.data(), bytes.size()});
        return out;
    }
};

inline World& world() {
    static World w;
    return w;
}

// Truncates, extends or flips bytes of `b` as the input says.
inline void mutate(test::Bytes& b, Input& in) {
    const unsigned n = in.u8() % 4u;
    for (unsigned i = 0; i < n; ++i) {
        switch (in.u8() % 3) {
        case 0: b.resize(b.empty() ? 0 : in.u16() % (b.size() + 1)); break;
        case 1: {
            const auto extra = in.take(in.u8());
            b.insert(b.end(), extra.begin(), extra.end());
            break;
        }
        default:
            if (!b.empty()) b[in.u16() % b.size()] ^= static_cast<uint8_t>(in.u8() | 1);
        }
    }
}

inline std::string textOf(vl_vaultfmt_status (*fn)(const vl_vaultfmt_head*, char*, size_t*), const vl_vaultfmt_head* h,
                          vl_vaultfmt_status* status) {
    size_t len = 0;
    *status = fn(h, nullptr, &len);
    if (*status != VL_VAULTFMT_ERR_BUFFER_TOO_SMALL && *status != VL_VAULTFMT_OK) return {};
    std::string s(len, '\0');
    *status = fn(h, s.data(), &len);
    return s;
}

// Decides `head` as a page would: supply what it names (bytes from `bytesOf`), decide, at most three rounds.
template <class BytesOf>
inline void decide(vl_vaultfmt_head* head, BytesOf&& bytesOf) {
    auto& w = world();
    for (int round = 0; round < 3; ++round) {
        vl_vaultfmt_status s{};
        const auto needed = textOf(vl_vaultfmt_head_needed, head, &s);
        require(s == VL_VAULTFMT_OK);
        const auto ids = nlohmann::json::parse(needed);
        for (const auto& id : ids) {
            const auto text = id.get<std::string>();
            const auto bytes = bytesOf(text);
            const auto status = bytes ? vl_vaultfmt_head_supply(head, text.data(), text.size(), bytes->data(), bytes->size())
                                      : vl_vaultfmt_head_gone(head, text.data(), text.size());
            requireStatus(status);
        }
        const auto status = vl_vaultfmt_head_decide(head, w.ring);
        requireStatus(status);
        if (status == VL_VAULTFMT_ERR_READER_NEED_OBJECTS) continue;
        if (status != VL_VAULTFMT_OK) return;
        const auto json = textOf(vl_vaultfmt_head_json, head, &s);
        require(s == VL_VAULTFMT_OK && nlohmann::json::accept(json));
        vl_vaultfmt_root* root = nullptr;
        require(vl_vaultfmt_head_root(head, w.ring, &root) == VL_VAULTFMT_OK);
        vl_vaultfmt_root_free(root);
        return;
    }
}

inline void listingText(Input& in) {
    auto& w = world();
    const auto text = in.rest();
    vl_vaultfmt_head* head = nullptr;
    const auto s = vl_vaultfmt_head_new(w.f.vault.data(), reinterpret_cast<const char*>(text.data()), text.size(),
                                        nullptr, &head);
    requireStatus(s);
    require((s == VL_VAULTFMT_OK) == (head != nullptr));
    if (head) decide(head, [&](const std::string&) { return std::optional<test::Bytes>(w.f.roots.front().bytes); });
    vl_vaultfmt_head_free(head);
}

inline void structuredListing(Input& in) {
    auto& w = world();
    const unsigned n = in.u8() % 9u;
    auto listing = nlohmann::json::array();
    std::map<std::string, std::optional<test::Bytes>> bytes;
    for (unsigned i = 0; i < n; ++i) {
        const auto id = "v" + std::to_string(in.u8() % 12);
        const bool marker = (in.u8() & 7) == 0;
        listing.push_back({{"version_id", id}, {"delete_marker", marker}});
        const auto pick = in.u8();
        if (pick % 5 == 0) {
            bytes[id] = std::nullopt;   // gone
        } else if (pick % 5 == 1) {
            const auto raw = in.take(in.u8());
            bytes[id] = test::Bytes(raw.begin(), raw.end());
        } else {
            auto b = pick % 5 == 2 ? w.f.other_root : w.f.roots[pick % w.f.roots.size()].bytes;
            if (pick & 0x80) mutate(b, in);
            bytes[id] = b;
        }
    }
    std::string anchorSha;
    std::string anchorId;
    vl_vaultfmt_anchor anchor{};
    const auto a = in.u8() % 4;
    if (a) {
        const uint64_t epoch = 1u + in.u8() % 3u;
        anchorSha = w.f.epoch_sha.at(epoch);
        if (a == 2) anchorSha[0] = anchorSha[0] == '0' ? '1' : '0';
        anchorId = a == 3 ? "v" + std::to_string(in.u8() % 12) : std::string();
        anchor = {epoch, anchorSha.c_str(), anchorId.empty() ? nullptr : anchorId.c_str()};
    }
    const auto text = listing.dump();
    vl_vaultfmt_head* head = nullptr;
    const auto s = vl_vaultfmt_head_new(w.f.vault.data(), text.data(), text.size(), a ? &anchor : nullptr, &head);
    requireStatus(s);
    if (head) decide(head, [&](const std::string& id) { return bytes.contains(id) ? bytes.at(id) : std::nullopt; });
    vl_vaultfmt_head_free(head);
}

inline void segments(Input& in) {
    auto& w = world();
    auto segs = w.f.segments;
    bool changed = false;
    for (auto& [sid, b] : segs) {
        const auto op = in.u8() % 8;
        if (op == 1) {
            const auto before = b;
            mutate(b, in);
            changed = changed || (b != before && w.pinned.contains(sid));
        } else if (op == 2) {
            const auto raw = in.take(in.u8());
            const test::Bytes next(raw.begin(), raw.end());
            changed = changed || (next != b && w.pinned.contains(sid));
            b = next;
        }
    }
    if (in.u8() % 4 == 0 && !segs.empty()) {
        const auto victim = std::next(segs.begin(), static_cast<std::ptrdiff_t>(in.u8() % segs.size()));
        changed = changed || w.pinned.contains(victim->first);
        segs.erase(victim);
    }
    const auto objects = World::segmentInputs(segs);
    vl_vaultfmt_tree* tree = nullptr;
    const auto s = vl_vaultfmt_tree_build(w.head, objects.data(), objects.size(), w.ring, &tree);
    requireStatus(s);
    require(!changed || s != VL_VAULTFMT_OK);   // the root pins every byte
    vl_vaultfmt_tree_free(tree);
}

inline void content(Input& in) {
    auto& w = world();
    const auto& file = w.f.files[in.u8() % w.f.files.size()];
    auto object = in.u8() % 3 == 0 ? w.f.tampered : file.object;
    mutate(object, in);
    vl_vaultfmt_opener* opener = nullptr;
    const auto s = vl_vaultfmt_tree_open_content(w.tree, w.f.vault.data(), file.uid.data(), file.uid.size(), nullptr, 0,
                                                 object.data(), std::min<size_t>(object.size(), VL_VAULTFMT_HEADER_SIZE),
                                                 w.ring, &opener);
    requireStatus(s);
    if (!opener) return;
    for (int i = 0; i < 3; ++i) {
        uint64_t start = in.u16() % (file.size + 2);
        uint64_t end = start + in.u16() % (file.size + 2);
        uint64_t offset = 0, length = 0;
        const auto p = vl_vaultfmt_range_plan(opener, start, end, &offset, &length);
        requireStatus(p);
        if (p != VL_VAULTFMT_OK) continue;
        test::Bytes window;
        if (offset < object.size()) window.assign(object.begin() + static_cast<std::ptrdiff_t>(offset),
                                                  object.begin() + static_cast<std::ptrdiff_t>(std::min<uint64_t>(object.size(), offset + length)));
        vl_vaultfmt_buffer* out = nullptr;
        require(vl_vaultfmt_buffer_new(&out) == VL_VAULTFMT_OK);
        const auto r = vl_vaultfmt_range_read(opener, start, end, object.size(), window.data(), window.size(),
                                              vl_vaultfmt_buffer_sink_fn(), out);
        requireStatus(r);
        if (r == VL_VAULTFMT_OK) {
            require(vl_vaultfmt_buffer_size(out) == end - start);
            const auto* got = vl_vaultfmt_buffer_data(out);
            for (uint64_t k = 0; k < end - start; ++k) require(got[k] == test::patternByte(file.pattern, start + k));
        }
        vl_vaultfmt_buffer_free(out);
    }
    vl_vaultfmt_opener_free(opener);
}

inline void envelopes(Input& in) {
    auto& w = world();
    auto env = in.u8() & 1 ? w.f.envelope : w.f.decoy_envelope;
    mutate(env, in);
    vl_vaultfmt_recipient* r = nullptr;
    require(vl_vaultfmt_recipient_from_seed(w.f.seed_text.data(), w.f.seed_text.size(), &r) == VL_VAULTFMT_OK);
    vl_vaultfmt_keyring* ring = nullptr;
    require(vl_vaultfmt_keyring_new(&ring) == VL_VAULTFMT_OK);
    uint32_t version = 0;
    const auto s = vl_vaultfmt_keyring_add_envelope(ring, r, w.f.vault.data(), env.data(), env.size(), &version);
    requireStatus(s);
    if (s == VL_VAULTFMT_OK) {
        // What unwrapped is the vault key, under its version.
        require(version == w.f.key_version);
        const auto& bytes = w.rootBytes(w.f.epoch_version.at(3));
        vl_vaultfmt_root* root = nullptr;
        require(vl_vaultfmt_root_open(bytes.data(), bytes.size(), w.f.vault.data(), ring, nullptr, &root) == VL_VAULTFMT_OK);
        vl_vaultfmt_root_free(root);
    }
    vl_vaultfmt_keyring_free(ring);
    vl_vaultfmt_recipient_free(r);
}

inline void seedText(Input& in) {
    const auto text = in.rest();
    vl_vaultfmt_recipient* r = nullptr;
    requireStatus(vl_vaultfmt_recipient_from_seed(reinterpret_cast<const char*>(text.data()), text.size(), &r));
    vl_vaultfmt_recipient_free(r);
}

inline void runOne(const std::span<const uint8_t> data) {
    Input in(data);
    switch (in.u8() % 6) {
    case 0: listingText(in); break;
    case 1: structuredListing(in); break;
    case 2: segments(in); break;
    case 3: content(in); break;
    case 4: envelopes(in); break;
    default: seedText(in); break;
    }
}

}
