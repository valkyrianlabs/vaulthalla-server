// SPDX-License-Identifier: AGPL-3.0-or-later
// Copyright (c) 2026 Valkyrian Labs LLC
// The writer floor (docs/engine.md "The writer floor"; vaulthalla-server design/core/vault-format-library.md decision 7)
// against vectors/writer_floor.json and on the memory store: the member round-trips, the decision table holds, a writer
// below the floor publishes nothing (before any PUT, rebuilt roots included), and a writer at or above it keeps it.

#include "support.hpp"

#include "vl/vaultfmt/manifest/Document.hpp"
#include "vl/vaultfmt/manifest/Objects.hpp"
#include "vl/vaultfmt/manifest/Publisher.hpp"
#include "vl/vaultfmt/manifest/Reader.hpp"
#include "vl/vaultfmt/testing/memory_store.hpp"
#include "vl/vaultfmt/vhf1/Key.hpp"

#include <gtest/gtest.h>

#include <filesystem>
#include <fstream>

namespace vl::vaultfmt::manifest::test_writer_floor {

namespace {

const nlohmann::json& floorVectors() {
    static const nlohmann::json doc = [] {
        std::ifstream in(std::filesystem::path(VL_VAULTFMT_VECTORS_DIR) / "writer_floor.json");
        if (!in) throw std::runtime_error("missing vectors/writer_floor.json");
        return nlohmann::json::parse(in);
    }();
    return doc;
}

Uid vaultUid() {
    const auto b = test::fromHex(floorVectors().at("vault_uid_hex").get<std::string>());
    Uid u{};
    std::copy(b.begin(), b.end(), u.begin());
    return u;
}

vhf1::KeyPtr keyTwo() {
    std::vector<uint8_t> k(32);
    for (std::size_t i = 0; i < k.size(); ++i) k[i] = static_cast<uint8_t>(32 + i);
    return std::make_shared<const vhf1::Key>(k);
}

vhf1::KeyLookup keys() {
    return [k = keyTwo()](const uint32_t v) { return v == 2 ? k : nullptr; };
}

const nlohmann::json& rootVector(const std::string& name) {
    for (const auto& r : floorVectors().at("roots"))
        if (r.at("name") == name) return r;
    throw std::out_of_range(name);
}

struct Bucket {
    std::shared_ptr<test_support::MemoryBucket> bucket = std::make_shared<test_support::MemoryBucket>();
    std::shared_ptr<test_support::MemoryStore> store =
        std::make_shared<test_support::MemoryStore>(bucket, WriteCapability::VersionLog);

    explicit Bucket(const std::string& root) {
        const auto& seg = floorVectors().at("segment");
        bucket->seed(seg.at("object_key").get<std::string>(), test::fromHex(seg.at("object_hex").get<std::string>()));
        bucket->seed(std::string(kRootKey), test::fromHex(rootVector(root).at("object_hex").get<std::string>()));
    }

    PublishReport publish(const uint32_t revision, const uint32_t needs, const std::optional<uint32_t> knownFloor = {}) {
        PublisherCache cache;
        PublishOptions o;
        o.now = "2026-11-15T13:00:00Z";
        o.self_node = "desktop-writer-floor";
        o.writer_revision = revision;
        o.writer_floor = needs;
        o.known_floor = knownFloor;
        o.sleep = [](std::chrono::milliseconds) {};
        Content c;
        c.producer = {"desktop-writer-floor", std::nullopt, "test"};
        c.keys = {KeyRecord{2, std::nullopt, std::nullopt, "2026-11-15T12:00:00Z", std::nullopt, std::nullopt,
                            std::nullopt}};
        Entry rootDir;
        rootDir.uid = uidText([] {
            Uid u{};
            u.fill(0x11);
            return u;
        }());
        rootDir.kind = EntryKind::Dir;
        rootDir.name = "";
        rootDir.mode = 0755;
        rootDir.mtime = "2026-11-15T12:00:00Z";
        c.entries = {rootDir};
        return manifest::publish(*store, vaultUid(), keys(), {2, keyTwo()}, c, std::nullopt, cache, o);
    }

    [[nodiscard]] std::size_t rootVersions() const { return bucket->history(std::string(kRootKey)).size(); }
    [[nodiscard]] RootDocument head() const {
        return openRoot(bucket->current(std::string(kRootKey))->body, vaultUid(), keys());
    }
};

}

TEST(WriterFloorVectors, EveryRootOpensWithItsFloorAndReencodesToItsBytes) {
    for (const auto& r : floorVectors().at("roots")) {
        SCOPED_TRACE(r.at("name").get<std::string>());
        const auto bytes = test::fromHex(r.at("object_hex").get<std::string>());
        EXPECT_EQ(sha256Hex(bytes), r.at("object_sha256").get<std::string>());
        const auto root = openRoot(bytes, vaultUid(), keys());
        EXPECT_EQ(writerFloorOf(root), r.at("writer_floor").get<uint32_t>());
        EXPECT_EQ(root.writer_floor.has_value(), r.at("writer_floor").get<uint32_t>() != 0);
        EXPECT_EQ(canonicalJson(toJson(root)), r.at("plaintext_utf8").get<std::string>());
    }
}

TEST(WriterFloorVectors, TheDecisionTable) {
    std::size_t refused = 0, invalid = 0, written = 0;
    for (const auto& d : floorVectors().at("decisions")) {
        SCOPED_TRACE(d.dump());
        const auto base = d.at("base_floor").get<uint32_t>(), recorded = d.at("recorded_floor").get<uint32_t>();
        const auto revision = d.at("revision").get<uint32_t>(), needs = d.at("needs").get<uint32_t>();
        const auto& expect = d.at("expect");
        if (expect.contains("error")) {
            if (expect.at("error") == "invalid_argument") {
                EXPECT_THROW((void)nextWriterFloor(std::max(base, recorded), revision, needs), std::invalid_argument);
                ++invalid;
            } else {
                EXPECT_THROW((void)nextWriterFloor(std::max(base, recorded), revision, needs), WriterFloorRefused);
                ++refused;
            }
            continue;
        }
        const auto floor = nextWriterFloor(std::max(base, recorded), revision, needs);
        if (expect.at("writer_floor").is_null()) EXPECT_EQ(floor, 0u);
        else EXPECT_EQ(floor, expect.at("writer_floor").get<uint32_t>());
        ++written;
    }
    EXPECT_GT(refused, 0u);
    EXPECT_GT(invalid, 0u);
    EXPECT_GT(written, 0u);
}

TEST(WriterFloor, AWriterBelowTheHeadsFloorPublishesNothing) {
    Bucket b("floor_2");
    const auto puts = [&] { return b.bucket->history(std::string(kRootKey)).size() + b.store->list(".vaulthalla/seg/").size(); };
    const auto before = puts();
    try {
        (void)b.publish(kBaselineWriterRevision, 0);
        FAIL() << "published over a floor above its revision";
    } catch (const WriterFloorRefused& e) {
        EXPECT_EQ(e.floor(), 2u);
        EXPECT_EQ(e.revision(), kBaselineWriterRevision);
    }
    EXPECT_EQ(puts(), before);   // no segment, no root: refused before any PUT
    EXPECT_EQ(writerFloorOf(b.head()), 2u);
}

TEST(WriterFloor, AWriterAtTheFloorKeepsItAndNeverLowersIt) {
    Bucket b("floor_2");
    const auto r = b.publish(2, 0);
    EXPECT_EQ(r.published.root.writer_floor, std::optional<uint32_t>(2));
    EXPECT_EQ(writerFloorOf(b.head()), 2u);
    EXPECT_EQ(b.head().epoch, 2u);
}

TEST(WriterFloor, NoFloorIsWrittenUntilAWriterNeedsOne) {
    Bucket b("no_floor");
    (void)b.publish(kBaselineWriterRevision, 0);
    EXPECT_FALSE(b.head().writer_floor.has_value());   // roots stay byte-compatible with every reader's output
    Bucket c("floor_1");
    (void)c.publish(2, 2);
    EXPECT_EQ(c.head().writer_floor, std::optional<uint32_t>(2));
    Bucket d("floor_1");
    EXPECT_THROW((void)d.publish(1, 2), std::invalid_argument);   // needs more than it round-trips
}

TEST(WriterFloor, TheRecordedRootsFloorBindsAsWellAsTheHeads) {
    // What a root rebuilt over a missing or unreadable head relies on: the floor of the root this writer recorded
    // (PublishOptions::known_floor, which the session reads from its base copy) binds even when the head names none.
    Bucket b("no_floor");
    EXPECT_THROW((void)b.publish(kBaselineWriterRevision, 0, 2), WriterFloorRefused);
    EXPECT_EQ(b.rootVersions(), 1u);
}

}
