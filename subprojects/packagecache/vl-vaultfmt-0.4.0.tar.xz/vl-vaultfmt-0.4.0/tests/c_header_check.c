/* SPDX-License-Identifier: AGPL-3.0-or-later */
/* Copyright (c) 2026 Valkyrian Labs LLC */
/* The C API's header compiled as C11, and a sealing and opening done from C (test_c_api.cpp runs this). */
#include "vl/vaultfmt/vl_vaultfmt.h"

#include <string.h>

int vl_vaultfmt_c_header_check(void);

struct buffer {
    uint8_t bytes[4096];
    size_t len;
};

static int32_t collect(void* ctx, const uint8_t* bytes, size_t len) {
    struct buffer* b = (struct buffer*)ctx;
    if (b->len + len > sizeof b->bytes) return 1;
    memcpy(b->bytes + b->len, bytes, len);
    b->len += len;
    return 0;
}

int vl_vaultfmt_c_header_check(void) {
    static const uint8_t key[VL_VAULTFMT_KEY_SIZE] = {1, 2, 3};
    static const uint8_t vault[VL_VAULTFMT_UID_SIZE] = {9};
    static const uint8_t object[VL_VAULTFMT_UID_SIZE] = {7};
    static const uint8_t text[] = "hello from C";
    static struct buffer sealed, opened;
    vl_vaultfmt_keyring* ring = NULL;
    vl_vaultfmt_sealer* sealer = NULL;
    vl_vaultfmt_opener* opener = NULL;
    vl_vaultfmt_expectation expect;
    uint64_t size = 0;
    int result = 0;

    if (vl_vaultfmt_keyring_new(&ring) != VL_VAULTFMT_OK || vl_vaultfmt_keyring_add(ring, 1, key, sizeof key) != VL_VAULTFMT_OK)
        result = 1;
    else if (vl_vaultfmt_sealer_new(ring, 1, vault, object, collect, &sealed, &sealer) != VL_VAULTFMT_OK ||
             vl_vaultfmt_sealer_write(sealer, text, sizeof text - 1) != VL_VAULTFMT_OK ||
             vl_vaultfmt_sealer_finish(sealer, &size) != VL_VAULTFMT_OK || size != sealed.len)
        result = 2;
    else {
        expect.kind = VL_VAULTFMT_KIND_FILE_CONTENT;
        expect.vault_uid = vault;
        expect.object_uid = object;
        expect.generation = NULL;
        if (vl_vaultfmt_opener_new(sealed.bytes, sealed.len, &expect, ring, sealed.len, &opener) != VL_VAULTFMT_OK ||
            vl_vaultfmt_opener_update(opener, sealed.bytes + VL_VAULTFMT_HEADER_SIZE, sealed.len - VL_VAULTFMT_HEADER_SIZE,
                                      collect, &opened) != VL_VAULTFMT_OK ||
            vl_vaultfmt_opener_finish(opener) != VL_VAULTFMT_OK)
            result = 3;
        else if (opened.len != sizeof text - 1 || memcmp(opened.bytes, text, opened.len) != 0)
            result = 4;
    }
    memset(opened.bytes, 0, sizeof opened.bytes);
    vl_vaultfmt_opener_free(opener);
    vl_vaultfmt_sealer_free(sealer);
    vl_vaultfmt_keyring_free(ring);
    if (result == 0 && strcmp(vl_vaultfmt_status_name(VL_VAULTFMT_ERR_VHF1_CHUNK_AUTH_FAILED), "vhf1_chunk_auth_failed") != 0)
        result = 5;
    return result;
}
