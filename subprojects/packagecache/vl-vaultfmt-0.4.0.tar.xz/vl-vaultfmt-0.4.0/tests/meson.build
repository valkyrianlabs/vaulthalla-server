# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (c) 2026 Valkyrian Labs LLC
# One C translation unit (c_header_check.c) proves the C API's header is valid C.
add_languages('c', native: false, required: true)

test_sources = files(
  'c_header_check.c',
  'test_c_api.cpp',
  'test_c_api_reader.cpp',
  'test_manifest.cpp',
  'test_manifest_interleavings.cpp',
  'test_manifest_protocol.cpp',
  'test_manifest_reconcile.cpp',
  'test_object_keys.cpp',
  'test_vhf1.cpp',
  'test_writer_floor.cpp',
)

vl_vaultfmt_tests = executable('vl-vaultfmt-tests', test_sources,
  dependencies: [vl_vaultfmt_dep, gtest_dep],
  cpp_args: ['-DVL_VAULTFMT_VECTORS_DIR="' + meson.project_source_root() / 'vectors' + '"',
              '-DVL_VAULTFMT_WASM_FIXTURE="' + meson.project_source_root() / 'wasm' / 'tests' / 'fixture.json' + '"'],
  build_by_default: true,
  install: false,
  override_options: ['c_std=c11'],
)

# The reader fixture for the WebAssembly tests (wasm/tests/fixture.json; wasm/README.md).
executable('make_reader_fixture', 'make_reader_fixture.cpp',
  dependencies: vl_vaultfmt_dep,
  cpp_args: ['-DVL_VAULTFMT_VECTORS_DIR="' + meson.project_source_root() / 'vectors' + '"'],
  build_by_default: true,
  install: false,
)

# The interleavings suites enumerate tens of thousands of schedules.
test('vl-vaultfmt', vl_vaultfmt_tests, timeout: 900)

# The database-free engine and its C API (a C translation unit drives a whole vault through the C API alone).
vl_vaultfmt_engine_tests = executable('vl-vaultfmt-engine-tests',
  files('c_engine_lifecycle.c', 'test_c_engine.cpp', 'test_engine.cpp', 'test_engine_state.cpp'),
  dependencies: [vl_vaultfmt_dep, gtest_dep],
  build_by_default: true,
  install: false,
  override_options: ['c_std=c11'],
)
test('vl-vaultfmt-engine', vl_vaultfmt_engine_tests, timeout: 600)

python = find_program('python3', required: false)
if python.found()
  # The independent Python reference: regenerates the vectors, compares them with vectors.json byte for byte, and
  # runs its own reader over every vector. Skipped (exit 77) where the `cryptography` package is missing.
  test('vectors-reference', python,
    args: ['-c', '''
import importlib.util, subprocess, sys
if importlib.util.find_spec("cryptography") is None:
    sys.exit(77)
sys.exit(subprocess.call([sys.executable, sys.argv[1], "--check"]))
''', meson.project_source_root() / 'vectors' / 'vh_crypto_vectors.py'],
  )

  # This library's own vectors of the writer floor (vectors/writer_floor.json), regenerated and checked the same way.
  test('writer-floor-reference', python,
    args: ['-c', '''
import importlib.util, subprocess, sys
if importlib.util.find_spec("cryptography") is None:
    sys.exit(77)
sys.exit(subprocess.call([sys.executable, sys.argv[1], "--check"]))
''', meson.project_source_root() / 'vectors' / 'writer_floor_vectors.py'],
  )

  # The vectors, the reference and the C++ suites mean the same thing (tests/vectors_contract.py).
  test('vectors-contract', python, args: [meson.current_source_dir() / 'vectors_contract.py'])
endif
