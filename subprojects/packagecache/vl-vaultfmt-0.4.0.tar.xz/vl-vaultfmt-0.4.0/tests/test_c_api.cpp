// SPDX-License-Identifier: AGPL-3.0-or-later
// Copyright (c) 2026 Valkyrian Labs LLC
//
// The C API (vl/vaultfmt/vl_vaultfmt.h) against the golden vectors and the C++ API it wraps: every VHF1 vector opened
// as a stream in arbitrary splits, every negative with its status, the range vectors, streamed sealing that opens to
// its plaintext, sinks that fail, the object keys, every manifest chain case through root_open and tree_build, and
// the status names (stable, one per code, the vectors' spellings).
#include "support.hpp"

#include "vl/vaultfmt/ObjectKeys.hpp"
#include "vl/vaultfmt/manifest/Chain.hpp"
#include "vl/vaultfmt/manifest/Content.hpp"
#include "vl/vaultfmt/manifest/Document.hpp"
#include "vl/vaultfmt/manifest/Objects.hpp"
#include "vl/vaultfmt/vaultfmt.hpp"
#include "vl/vaultfmt/vhf1/Format.hpp"
#include "vl/vaultfmt/vhf1/Reader.hpp"
#include "vl/vaultfmt/vl_vaultfmt.h"

#include <gtest/gtest.h>

#include <cstring>
#include <map>
#include <memory>
#include <random>
#include <set>
#include <string>
#include <vector>

namespace vl::vaultfmt::test_c_api {

namespace {

using Bytes = std::vector<uint8_t>;
using nlohmann::json;
using test::fromHex;

const json& vectors() { return test::goldenVectors(); }

struct RingFree {
    void operator()(vl_vaultfmt_keyring* r) const { vl_vaultfmt_keyring_free(r); }
};
using Ring = std::unique_ptr<vl_vaultfmt_keyring, RingFree>;
struct OpenerFree {
    void operator()(vl_vaultfmt_opener* o) const { vl_vaultfmt_opener_free(o); }
};
using Opener = std::unique_ptr<vl_vaultfmt_opener, OpenerFree>;
struct SealerFree {
    void operator()(vl_vaultfmt_sealer* s) const { vl_vaultfmt_sealer_free(s); }
};
using Sealer = std::unique_ptr<vl_vaultfmt_sealer, SealerFree>;
struct RootFree {
    void operator()(vl_vaultfmt_root* r) const { vl_vaultfmt_root_free(r); }
};
using Root = std::unique_ptr<vl_vaultfmt_root, RootFree>;
struct TreeFree {
    void operator()(vl_vaultfmt_tree* t) const { vl_vaultfmt_tree_free(t); }
};
using Tree = std::unique_ptr<vl_vaultfmt_tree, TreeFree>;

// The vectors' keys, or only `held` of them.
Ring ringOf(const std::set<uint32_t>& held = {}) {
    vl_vaultfmt_keyring* r = nullptr;
    EXPECT_EQ(vl_vaultfmt_keyring_new(&r), VL_VAULTFMT_OK);
    for (const auto& [version, hex] : vectors()["conventions"]["keys"].items()) {
        const auto v = static_cast<uint32_t>(std::stoul(version));
        if (!held.empty() && !held.contains(v)) continue;
        const auto key = fromHex(hex.get<std::string>());
        EXPECT_EQ(vl_vaultfmt_keyring_add(r, v, key.data(), key.size()), VL_VAULTFMT_OK);
    }
    return Ring(r);
}

int32_t append(void* ctx, const uint8_t* bytes, const size_t len) {
    auto* out = static_cast<Bytes*>(ctx);
    out->insert(out->end(), bytes, bytes + len);
    return 0;
}

int32_t refuse(void*, const uint8_t*, size_t) { return 1; }

std::string name(const vl_vaultfmt_status s) { return vl_vaultfmt_status_name(s); }

// pattern(n, seed), the vectors' plaintext generator.
Bytes pattern(const std::size_t n, const unsigned seed) {
    Bytes out(n);
    for (std::size_t i = 0; i < n; ++i) out[i] = static_cast<uint8_t>((i * 131 + seed * 17 + 7) & 0xFF);
    return out;
}

json positive(const std::string& n) {
    for (const auto& v : vectors()["vhf1"]["positive"])
        if (v["name"] == n) return v;
    throw std::out_of_range(n);
}

struct Expect {
    int32_t kind{};
    std::array<uint8_t, 16> vault{}, object{};
    std::set<uint32_t> held;
    [[nodiscard]] vl_vaultfmt_expectation c() const { return {kind, vault.data(), object.data(), nullptr}; }
};

template <std::size_t N>
std::array<uint8_t, N> fixed(const std::string& hex) {
    std::array<uint8_t, N> out{};
    const auto b = fromHex(hex);
    std::copy(b.begin(), b.end(), out.begin());
    return out;
}

Expect expectOf(const json& params, const json& override = json::object()) {
    Expect e;
    e.kind = override.value("kind", params.value("kind", 1));
    e.vault = fixed<16>(override.value("vault_uid_hex", params["vault_uid_hex"].get<std::string>()));
    e.object = fixed<16>(override.value("object_uid_hex", params["object_uid_hex"].get<std::string>()));
    if (override.contains("keys"))
        for (const auto& k : override["keys"]) e.held.insert(k.get<uint32_t>());
    return e;
}

// Opens `object` as a stream: the header, then the rest in random splits. The first failing status, and the
// plaintext the sink received.
struct Streamed {
    vl_vaultfmt_status status{VL_VAULTFMT_OK};
    Bytes plaintext;
};

Streamed stream(const Bytes& object, const Expect& e, const unsigned seed) {
    Streamed out;
    const auto ring = ringOf(e.held);
    const auto expect = e.c();
    vl_vaultfmt_opener* raw = nullptr;
    out.status = vl_vaultfmt_opener_new(object.data(), object.size(), &expect, ring.get(), object.size(), &raw);
    if (out.status != VL_VAULTFMT_OK) {
        EXPECT_EQ(raw, nullptr);
        return out;
    }
    Opener o(raw);
    std::mt19937 rng(seed);
    std::size_t at = VL_VAULTFMT_HEADER_SIZE;
    while (at < object.size()) {
        const auto n = std::min<std::size_t>(object.size() - at, 1 + rng() % 3000);
        out.status = vl_vaultfmt_opener_update(o.get(), object.data() + at, n, append, &out.plaintext);
        if (out.status != VL_VAULTFMT_OK) return out;
        at += n;
    }
    out.status = vl_vaultfmt_opener_finish(o.get());
    return out;
}

json manifestObject(const std::string& n) {
    for (const auto& o : vectors()["manifest"]["objects"])
        if (o["name"] == n) return o;
    throw std::out_of_range(n);
}

std::array<uint8_t, 16> vaultUid() { return fixed<16>(positive("empty")["params"]["vault_uid_hex"].get<std::string>()); }

}

TEST(VaultfmtCApi, EveryStatusHasOneStableNameAndTheVectorsSpellings) {
    std::set<std::string> names;
    std::size_t defined = 0;
    for (vl_vaultfmt_status s = 0; s < 1000; ++s) {
        const auto n = name(s);
        if (n == "unknown") continue;
        ++defined;
        EXPECT_TRUE(names.insert(n).second) << n;
    }
    EXPECT_EQ(defined, 8u + 17u + 3u + 8u + 12u + 3u + 4u + 25u);   // + the reader's blocks (kev1, seed, reader) and the engine's (vl_vaultfmt_engine.h)
    EXPECT_EQ(name(-1), "unknown");
    for (int c = 0; c <= static_cast<int>(vhf1::ErrorCode::ChunkAuthFailed); ++c)
        EXPECT_EQ(name(100 + c), "vhf1_" + std::string(vhf1::errorCodeName(static_cast<vhf1::ErrorCode>(c))));
    for (int c = 0; c <= static_cast<int>(manifest::ChainError::PublishModeMismatch); ++c)
        EXPECT_EQ(name(300 + c), "chain_" + std::string(manifest::chainErrorName(static_cast<manifest::ChainError>(c))));
    EXPECT_STREQ(vl_vaultfmt_version(), vl::vaultfmt::version());
    EXPECT_STREQ(vl_vaultfmt_version(), "0.4.0");
}

TEST(VaultfmtCApi, KeyringRefusesWhatIsNotAVaultKey) {
    vl_vaultfmt_keyring* r = nullptr;
    EXPECT_EQ(vl_vaultfmt_keyring_new(nullptr), VL_VAULTFMT_ERR_INVALID_ARGUMENT);
    ASSERT_EQ(vl_vaultfmt_keyring_new(&r), VL_VAULTFMT_OK);
    const Ring ring(r);
    const Bytes key(32, 7), short_(31, 7);
    EXPECT_EQ(vl_vaultfmt_keyring_add(r, 0, key.data(), key.size()), VL_VAULTFMT_ERR_INVALID_ARGUMENT);
    EXPECT_EQ(vl_vaultfmt_keyring_add(r, 1, short_.data(), short_.size()), VL_VAULTFMT_ERR_INVALID_ARGUMENT);
    EXPECT_EQ(vl_vaultfmt_keyring_add(r, 1, nullptr, 32), VL_VAULTFMT_ERR_INVALID_ARGUMENT);
    EXPECT_EQ(vl_vaultfmt_keyring_add(r, 1, key.data(), key.size()), VL_VAULTFMT_OK);
    vl_vaultfmt_keyring_free(nullptr);
}

TEST(VaultfmtCApi, ObjectKeysFollowTheBufferConvention) {
    std::array<uint8_t, 16> uid{};
    for (std::size_t i = 0; i < uid.size(); ++i) uid[i] = static_cast<uint8_t>(i * 29 + 3);
    size_t len = 0;
    EXPECT_EQ(vl_vaultfmt_content_key(uid.data(), nullptr, &len), VL_VAULTFMT_ERR_BUFFER_TOO_SMALL);
    EXPECT_EQ(len, static_cast<size_t>(VL_VAULTFMT_CONTENT_KEY_SIZE));
    std::string key(len, '\0');
    ASSERT_EQ(vl_vaultfmt_content_key(uid.data(), key.data(), &len), VL_VAULTFMT_OK);
    EXPECT_EQ(key, keys::contentKey(uid));
    std::array<uint8_t, 16> back{};
    ASSERT_EQ(vl_vaultfmt_content_key_uid(key.data(), key.size(), back.data()), VL_VAULTFMT_OK);
    EXPECT_EQ(back, uid);
    EXPECT_EQ(vl_vaultfmt_content_key_uid("o/OO", 4, back.data()), VL_VAULTFMT_ERR_NOT_FOUND);
    EXPECT_EQ(vl_vaultfmt_classify_key(key.data(), key.size()), VL_VAULTFMT_KEY_CONTENT);
    EXPECT_EQ(vl_vaultfmt_classify_key(VL_VAULTFMT_ROOT_KEY, std::strlen(VL_VAULTFMT_ROOT_KEY)), VL_VAULTFMT_KEY_METADATA);
    EXPECT_EQ(vl_vaultfmt_classify_key("Reports/x.pdf", 13), VL_VAULTFMT_KEY_FOREIGN);
    EXPECT_EQ(vl_vaultfmt_classify_key(nullptr, 3), VL_VAULTFMT_KEY_FOREIGN);

    char seg[VL_VAULTFMT_SEGMENT_KEY_SIZE];
    len = sizeof seg - 1;
    EXPECT_EQ(vl_vaultfmt_segment_key(uid.data(), seg, &len), VL_VAULTFMT_ERR_BUFFER_TOO_SMALL);
    EXPECT_EQ(len, sizeof seg);
    ASSERT_EQ(vl_vaultfmt_segment_key(uid.data(), seg, &len), VL_VAULTFMT_OK);
    EXPECT_EQ(std::string(seg, len), manifest::segmentKey(manifest::uidText(uid)));
    EXPECT_EQ(vl_vaultfmt_part_size(60ull << 30), keys::partSizeFor(60ull << 30));
    EXPECT_EQ(vl_vaultfmt_object_size(0, 10), 136u);
    EXPECT_EQ(vl_vaultfmt_object_size(1, 9), 0u);
}

TEST(VaultfmtCApi, EveryPositiveVectorOpensAsAStreamInAnySplit) {
    std::size_t opened = 0;
    for (const auto& v : vectors()["vhf1"]["positive"]) {
        if (!v.contains("object_hex")) continue;
        SCOPED_TRACE(v["name"].get<std::string>());
        const auto object = fromHex(v["object_hex"].get<std::string>());
        const auto plaintext = fromHex(v["plaintext_hex"].get<std::string>());
        for (unsigned seed = 0; seed < 5; ++seed) {
            const auto got = stream(object, expectOf(v["params"]), seed);
            ASSERT_EQ(got.status, VL_VAULTFMT_OK) << name(got.status);
            EXPECT_EQ(got.plaintext, plaintext);
        }
        ++opened;
    }
    EXPECT_GE(opened, 6u);
}

TEST(VaultfmtCApi, EveryNegativeVectorFailsWithItsStatus) {
    for (const auto& n : vectors()["vhf1"]["negative"]) {
        SCOPED_TRACE(n["name"].get<std::string>());
        const auto& base = positive(n["base"].get<std::string>());
        const auto got = stream(fromHex(n["object_hex"].get<std::string>()), expectOf(base["params"], n["expect_override"]),
                                1);
        EXPECT_EQ(name(got.status), "vhf1_" + n["expect"]["error"].get<std::string>());
    }
}

TEST(VaultfmtCApi, RangeVectorsPlanAndReadAuthenticatedChunks) {
    std::size_t read = 0;
    for (const auto& r : vectors()["vhf1"]["range_reads"]) {
        SCOPED_TRACE(r["description"].get<std::string>());
        const auto& v = positive(r["object"].get<std::string>());
        const auto object = fromHex(v["object_hex"].get<std::string>());
        const auto e = expectOf(v["params"]);
        const auto ring = ringOf();
        const auto expect = e.c();
        vl_vaultfmt_opener* raw = nullptr;
        ASSERT_EQ(vl_vaultfmt_opener_new(object.data(), object.size(), &expect, ring.get(), object.size(), &raw),
                  VL_VAULTFMT_OK);
        const Opener o(raw);
        const auto start = r["start"].get<uint64_t>(), end = r["end"].get<uint64_t>();
        uint64_t offset = 0, length = 0;
        ASSERT_EQ(vl_vaultfmt_range_plan(o.get(), start, end, &offset, &length), VL_VAULTFMT_OK);
        if (r["object_range"].is_null()) {
            EXPECT_EQ(length, 0u);
        } else {
            EXPECT_EQ(offset, r["object_range"][0].get<uint64_t>());
            EXPECT_EQ(offset + length, r["object_range"][1].get<uint64_t>());
        }
        Bytes got;
        ASSERT_EQ(vl_vaultfmt_range_read(o.get(), start, end, object.size(), object.data() + offset, length, append, &got),
                  VL_VAULTFMT_OK);
        EXPECT_EQ(got, fromHex(r["plaintext_hex"].get<std::string>()));
        EXPECT_EQ(vl_vaultfmt_range_read(o.get(), start, end, object.size() - 1, object.data() + offset, length, append,
                                         &got),
                  VL_VAULTFMT_ERR_VHF1_SIZE_MISMATCH)
            << "a provider size other than the authenticated one";
        ++read;
    }
    EXPECT_GE(read, 1u);

    // A tampered chunk never reaches the sink, and the failure is sticky.
    const auto& v = positive("multi_chunk");
    auto object = fromHex(v["object_hex"].get<std::string>());
    const auto ring = ringOf();
    const auto e = expectOf(v["params"]);
    const auto expect = e.c();
    vl_vaultfmt_opener* raw = nullptr;
    ASSERT_EQ(vl_vaultfmt_opener_new(object.data(), object.size(), &expect, ring.get(), object.size(), &raw),
              VL_VAULTFMT_OK);
    const Opener o(raw);
    uint64_t offset = 0, length = 0;
    ASSERT_EQ(vl_vaultfmt_range_plan(o.get(), 0, 10, &offset, &length), VL_VAULTFMT_OK);
    object[offset + 3] ^= 1;
    Bytes got;
    EXPECT_EQ(vl_vaultfmt_range_read(o.get(), 0, 10, object.size(), object.data() + offset, length, append, &got),
              VL_VAULTFMT_ERR_VHF1_CHUNK_AUTH_FAILED);
    EXPECT_TRUE(got.empty());
    object[offset + 3] ^= 1;
    EXPECT_EQ(vl_vaultfmt_range_read(o.get(), 0, 10, object.size(), object.data() + offset, length, append, &got),
              VL_VAULTFMT_ERR_VHF1_CHUNK_AUTH_FAILED);
    EXPECT_EQ(vl_vaultfmt_range_plan(o.get(), 0, 1u << 30, &offset, &length), VL_VAULTFMT_ERR_VHF1_RANGE_OUT_OF_BOUNDS);
}

TEST(VaultfmtCApi, StreamedSealingOpensToItsPlaintextWhateverTheSplit) {
    const auto ring = ringOf();
    const auto vault = vaultUid();
    std::array<uint8_t, 16> object{};
    object.fill(0x42);
    for (const std::size_t size : {std::size_t{0}, std::size_t{1}, std::size_t{65536}, std::size_t{65537}, std::size_t{300001}}) {
        SCOPED_TRACE(size);
        const auto plaintext = pattern(size, 9);
        Bytes sealed;
        vl_vaultfmt_sealer* raw = nullptr;
        ASSERT_EQ(vl_vaultfmt_sealer_new(ring.get(), 2, vault.data(), object.data(), append, &sealed, &raw), VL_VAULTFMT_OK);
        const Sealer s(raw);
        std::mt19937 rng(static_cast<unsigned>(size));
        for (std::size_t at = 0; at < size;) {
            const auto n = std::min<std::size_t>(size - at, 1 + rng() % 70000);
            ASSERT_EQ(vl_vaultfmt_sealer_write(s.get(), plaintext.data() + at, n), VL_VAULTFMT_OK);
            at += n;
        }
        uint64_t objectSize = 0;
        ASSERT_EQ(vl_vaultfmt_sealer_finish(s.get(), &objectSize), VL_VAULTFMT_OK);
        EXPECT_EQ(objectSize, sealed.size());
        EXPECT_EQ(objectSize, vl_vaultfmt_object_size(size, VL_VAULTFMT_CHUNK_LOG2));
        EXPECT_EQ(vl_vaultfmt_sealer_finish(s.get(), nullptr), VL_VAULTFMT_ERR_UNUSABLE);
        EXPECT_EQ(vl_vaultfmt_sealer_write(s.get(), plaintext.data(), 0), VL_VAULTFMT_ERR_UNUSABLE);

        std::array<uint8_t, 32> salt{};
        ASSERT_EQ(vl_vaultfmt_sealer_generation(s.get(), salt.data()), VL_VAULTFMT_OK);
        const vl_vaultfmt_expectation expect{VL_VAULTFMT_KIND_FILE_CONTENT, vault.data(), nullptr, salt.data()};
        vl_vaultfmt_opener* ro = nullptr;
        ASSERT_EQ(vl_vaultfmt_opener_new(sealed.data(), sealed.size(), &expect, ring.get(), sealed.size(), &ro),
                  VL_VAULTFMT_OK)
            << "a generation alone binds the object";
        const Opener o(ro);
        vl_vaultfmt_header_info info{};
        ASSERT_EQ(vl_vaultfmt_opener_info(o.get(), &info), VL_VAULTFMT_OK);
        EXPECT_EQ(info.key_version, 2u);
        EXPECT_EQ(info.plaintext_size, size);
        EXPECT_EQ(std::memcmp(info.object_uid, object.data(), 16), 0);
        EXPECT_EQ(std::memcmp(info.salt, salt.data(), 32), 0);
        Bytes back;
        ASSERT_EQ(vl_vaultfmt_opener_update(o.get(), sealed.data() + VL_VAULTFMT_HEADER_SIZE,
                                            sealed.size() - VL_VAULTFMT_HEADER_SIZE, append, &back),
                  VL_VAULTFMT_OK);
        ASSERT_EQ(vl_vaultfmt_opener_finish(o.get()), VL_VAULTFMT_OK);
        EXPECT_EQ(back, plaintext);
        // The C++ reader agrees.
        const auto key = std::make_shared<const vhf1::Key>(fromHex(vectors()["conventions"]["keys"]["2"].get<std::string>()));
        const auto opened = vhf1::open(sealed, {vhf1::Kind::FileContent, vault, object, salt},
                                       [&](uint32_t v) { return v == 2 ? key : nullptr; });
        EXPECT_EQ(Bytes(opened.span().begin(), opened.span().end()), plaintext);
    }
}

TEST(VaultfmtCApi, ASinkThatFailsStopsTheStreamForGood) {
    const auto ring = ringOf();
    const auto vault = vaultUid();
    std::array<uint8_t, 16> object{};
    vl_vaultfmt_sealer* raw = nullptr;
    EXPECT_EQ(vl_vaultfmt_sealer_new(ring.get(), 9, vault.data(), object.data(), refuse, nullptr, &raw),
              VL_VAULTFMT_ERR_VHF1_KEY_UNAVAILABLE);
    EXPECT_EQ(raw, nullptr);
    EXPECT_EQ(vl_vaultfmt_sealer_new(ring.get(), 1, vault.data(), object.data(), refuse, nullptr, &raw),
              VL_VAULTFMT_ERR_CALLBACK_FAILED)
        << "the header is written at once";
    EXPECT_EQ(raw, nullptr);
    int calls = 0;
    const auto onlyTheHeader = [](void* ctx, const uint8_t*, size_t) -> int32_t { return (*static_cast<int*>(ctx))++ > 0; };
    ASSERT_EQ(vl_vaultfmt_sealer_new(ring.get(), 1, vault.data(), object.data(), onlyTheHeader, &calls, &raw),
              VL_VAULTFMT_OK);
    const Sealer s(raw);
    const auto plaintext = pattern(200000, 1);
    EXPECT_EQ(vl_vaultfmt_sealer_write(s.get(), plaintext.data(), plaintext.size()), VL_VAULTFMT_ERR_CALLBACK_FAILED);
    EXPECT_EQ(vl_vaultfmt_sealer_write(s.get(), plaintext.data(), 1), VL_VAULTFMT_ERR_UNUSABLE);
    EXPECT_EQ(vl_vaultfmt_sealer_finish(s.get(), nullptr), VL_VAULTFMT_ERR_UNUSABLE);

    const auto& v = positive("multi_chunk");
    const auto bytes = fromHex(v["object_hex"].get<std::string>());
    const auto e = expectOf(v["params"]);
    const auto expect = e.c();
    vl_vaultfmt_opener* ro = nullptr;
    ASSERT_EQ(vl_vaultfmt_opener_new(bytes.data(), bytes.size(), &expect, ring.get(), bytes.size(), &ro), VL_VAULTFMT_OK);
    const Opener o(ro);
    EXPECT_EQ(vl_vaultfmt_opener_update(o.get(), bytes.data() + 120, bytes.size() - 120, refuse, nullptr),
              VL_VAULTFMT_ERR_CALLBACK_FAILED);
    EXPECT_EQ(vl_vaultfmt_opener_finish(o.get()), VL_VAULTFMT_ERR_UNUSABLE);
}

TEST(VaultfmtCApi, EveryManifestChainCaseThroughRootOpenAndTreeBuild) {
    const auto ring = ringOf();
    const auto vault = vaultUid();
    const auto& seg = manifestObject("segment_1");
    const auto segSid = *manifest::sidOfKey(seg["object_key"].get<std::string>());
    const auto segBytes = fromHex(seg["object_hex"].get<std::string>());
    std::size_t built = 0;
    for (const auto& c : vectors()["manifest"]["chain"]) {
        SCOPED_TRACE(c["name"].get<std::string>());
        const auto rootBytes = c.contains("root_hex") ? fromHex(c["root_hex"].get<std::string>())
                                                      : fromHex(manifestObject(c["root"].get<std::string>())["object_hex"].get<std::string>());
        std::string knownSha;
        vl_vaultfmt_known known{};
        if (!c["known"].is_null()) {
            knownSha = c["known"]["root_sha256"].get<std::string>();
            known = {c["known"]["epoch"].get<uint64_t>(), knownSha.c_str()};
        }
        vl_vaultfmt_root* raw = nullptr;
        const auto status = vl_vaultfmt_root_open(rootBytes.data(), rootBytes.size(), vault.data(), ring.get(),
                                                  c["known"].is_null() ? nullptr : &known, &raw);
        const Root root(raw);
        const auto& expect = c["expect"];
        if (status != VL_VAULTFMT_OK) {
            EXPECT_EQ(root, nullptr);
            EXPECT_EQ(name(status), "chain_" + expect.value("error", std::string("?")));
            continue;
        }
        std::map<std::string, Bytes> objects{{segSid, segBytes}};
        if (c.contains("segments_override")) {
            objects.clear();
            for (const auto& [sid, hex] : c["segments_override"].items()) objects[sid] = fromHex(hex.get<std::string>());
        }
        std::vector<vl_vaultfmt_object_bytes> in;
        for (const auto& [sid, bytes] : objects) in.push_back({sid.c_str(), bytes.data(), bytes.size()});
        for (size_t i = 0; i < vl_vaultfmt_root_object_count(root.get()); ++i) {
            vl_vaultfmt_object_ref ref{};
            ASSERT_EQ(vl_vaultfmt_root_object(root.get(), i, &ref), VL_VAULTFMT_OK);
            EXPECT_EQ(std::string(ref.key), manifest::segmentKey(ref.sid));
            EXPECT_EQ(std::strlen(ref.object_sha256), static_cast<size_t>(VL_VAULTFMT_SHA256_HEX_SIZE));
        }
        vl_vaultfmt_tree* rt = nullptr;
        const auto built_status = vl_vaultfmt_tree_build(root.get(), in.data(), in.size(), ring.get(), &rt);
        const Tree tree(rt);
        if (expect.contains("error")) {
            EXPECT_EQ(name(built_status), "chain_" + expect["error"].get<std::string>());
            continue;
        }
        ASSERT_EQ(built_status, VL_VAULTFMT_OK) << name(built_status);
        vl_vaultfmt_root_info info{};
        ASSERT_EQ(vl_vaultfmt_root_info_get(root.get(), &info), VL_VAULTFMT_OK);
        EXPECT_EQ(info.epoch, expect["epoch"].get<uint64_t>());
        EXPECT_EQ(std::string(info.root_sha256), expect["root_sha256"].get<std::string>());
        EXPECT_EQ(info.gap != 0, expect.contains("warning"));

        // The tree is the C++ reader's content of the same objects.
        const auto keyLookup = [&](uint32_t v) -> vhf1::KeyPtr {
            return std::make_shared<const vhf1::Key>(
                fromHex(vectors()["conventions"]["keys"][std::to_string(v)].get<std::string>()));
        };
        const auto doc = manifest::openRoot(rootBytes, vault, keyLookup);
        const auto content = manifest::contentOf(
            doc, {manifest::openSegment(segBytes, vault, manifest::parseUid(segSid, "x", "sid"), keyLookup)}, {});
        ASSERT_EQ(vl_vaultfmt_tree_entry_count(tree.get()), content.entries.size());
        for (size_t i = 0; i < content.entries.size(); ++i) {
            vl_vaultfmt_entry e{};
            ASSERT_EQ(vl_vaultfmt_tree_entry(tree.get(), i, &e), VL_VAULTFMT_OK);
            const auto& want = content.entries[i];
            EXPECT_EQ(e.uid, want.uid);
            EXPECT_EQ(std::string(e.name, e.name_len), want.name);
            EXPECT_EQ(e.kind, static_cast<int32_t>(want.kind));
            EXPECT_EQ(e.parent ? std::optional<std::string>(e.parent) : std::nullopt, want.parent);
            size_t index = 99;
            ASSERT_EQ(vl_vaultfmt_tree_find(tree.get(), e.uid, std::strlen(e.uid), &index), VL_VAULTFMT_OK);
            EXPECT_EQ(index, i);
            if (want.kind == manifest::EntryKind::Dir) {
                size_t n = 0;
                EXPECT_NE(vl_vaultfmt_tree_children(tree.get(), e.uid, std::strlen(e.uid), nullptr, &n),
                          VL_VAULTFMT_ERR_INVALID_ARGUMENT);
                std::vector<size_t> kids(n);
                ASSERT_EQ(vl_vaultfmt_tree_children(tree.get(), e.uid, std::strlen(e.uid), kids.data(), &n), VL_VAULTFMT_OK);
                for (const auto k : kids) EXPECT_EQ(content.entries[k].parent, want.uid);
            }
        }
        size_t index = 0;
        EXPECT_EQ(vl_vaultfmt_tree_find(tree.get(), "nope", 4, &index), VL_VAULTFMT_ERR_NOT_FOUND);
        vl_vaultfmt_entry none{};
        EXPECT_EQ(vl_vaultfmt_tree_entry(tree.get(), content.entries.size(), &none), VL_VAULTFMT_ERR_NOT_FOUND);
        size_t len = 0;
        ASSERT_EQ(vl_vaultfmt_tree_json(tree.get(), nullptr, &len), VL_VAULTFMT_ERR_BUFFER_TOO_SMALL);
        std::string text(len, '\0');
        ASSERT_EQ(vl_vaultfmt_tree_json(tree.get(), text.data(), &len), VL_VAULTFMT_OK);
        EXPECT_EQ(json::parse(text).size(), content.entries.size());
        ++built;
    }
    EXPECT_GE(built, 3u);
}

TEST(VaultfmtCApi, AManifestObjectOpensOnlyAsItsKindWithTheKeysItNeeds) {
    const auto vault = vaultUid();
    const auto root = fromHex(manifestObject("root_epoch_1")["object_hex"].get<std::string>());
    vl_vaultfmt_root* raw = nullptr;
    EXPECT_EQ(vl_vaultfmt_root_open(root.data(), root.size(), vault.data(), ringOf({999}).get(), nullptr, &raw),
              VL_VAULTFMT_ERR_VHF1_KEY_UNAVAILABLE);
    const auto seg = fromHex(manifestObject("segment_1")["object_hex"].get<std::string>());
    EXPECT_EQ(vl_vaultfmt_root_open(seg.data(), seg.size(), vault.data(), ringOf().get(), nullptr, &raw),
              VL_VAULTFMT_ERR_VHF1_KIND_MISMATCH);
    EXPECT_EQ(raw, nullptr);
    const vl_vaultfmt_known bad{1, "short"};
    EXPECT_EQ(vl_vaultfmt_root_open(root.data(), root.size(), vault.data(), ringOf().get(), &bad, &raw),
              VL_VAULTFMT_ERR_INVALID_ARGUMENT);
}

}

extern "C" int vl_vaultfmt_c_header_check(void);

TEST(VaultfmtCApi, TheHeaderIsCAndWorksFromC) { EXPECT_EQ(vl_vaultfmt_c_header_check(), 0); }
