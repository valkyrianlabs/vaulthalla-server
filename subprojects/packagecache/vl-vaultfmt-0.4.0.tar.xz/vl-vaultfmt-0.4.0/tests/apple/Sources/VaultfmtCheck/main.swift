// SPDX-License-Identifier: AGPL-3.0-or-later
// Copyright (c) 2026 Valkyrian Labs LLC
//
// Calls the engine's C API from Swift the way Vaulthalla Desktop will: the store callbacks over an in-memory bucket that
// answers as Backblaze B2 does (version_log), the keys callbacks over a dictionary standing in for the keychain, the
// library's own state file in a temporary directory, and a KEV1 envelope made with CryptoKit (X25519, HKDF-SHA-256,
// AES-256-GCM, spec 03 §5.2). A vault is created, a key added, a folder made, a file streamed in and read back, the
// vault published, then opened again by an installation without state (re-anchored from the bucket) that reads the
// same bytes.

import CryptoKit
import Foundation
import VLVaultfmt

func fail(_ what: String) -> Never {
    FileHandle.standardError.write(Data("FAIL: \(what)\n".utf8))
    exit(1)
}

func check(_ status: vl_vaultfmt_status, _ what: String) {
    guard status == Int32(VL_VAULTFMT_OK) else { fail("\(what): \(String(cString: vl_vaultfmt_status_name(status)))") }
}

func text(_ p: UnsafePointer<CChar>?, _ n: Int) -> String {
    guard let p else { return "" }
    return String(decoding: UnsafeRawBufferPointer(start: p, count: n), as: UTF8.self)
}

// ---- the bucket ------------------------------------------------------------------------------------------------------

final class Bucket {
    struct Version { let id: String; var body: [UInt8]; let marker: Bool; let at: Int64 }
    var objects: [String: [Version]] = [:]   // oldest first
    var seq = 0
    var uploads: [Int: (key: String, body: [UInt8])] = [:]
    var nextUpload = 1

    func write(_ key: String, _ body: [UInt8], marker: Bool = false) -> Version {
        seq += 1
        let v = Version(id: String(format: "v%06d", seq), body: body, marker: marker, at: 1_800_000_000 + Int64(seq))
        objects[key, default: []].append(v)
        return v
    }
    func find(_ key: String, _ id: String?) -> Version? {
        guard let stack = objects[key] else { return nil }
        let v = id.map { want in stack.last { $0.id == want } } ?? stack.last
        return (v?.marker ?? true) ? nil : v
    }
}

func reply(_ r: OpaquePointer?, _ v: Bucket.Version) {
    let etag = "\"e\(v.id)\""
    _ = vl_vaultfmt_reply_etag(r, etag, etag.utf8.count)
    _ = vl_vaultfmt_reply_version_id(r, v.id, v.id.utf8.count)
}

func bucket(_ ctx: UnsafeMutableRawPointer?) -> Bucket { Unmanaged<Bucket>.fromOpaque(ctx!).takeUnretainedValue() }

enum Status {
    static let ok = Int32(VL_VAULTFMT_OK), notFound = Int32(VL_VAULTFMT_ERR_NOT_FOUND)
}

func storeTable(_ b: Bucket) -> vl_vaultfmt_store_table {
    var t = vl_vaultfmt_store_table()
    t.ctx = Unmanaged.passUnretained(b).toOpaque()
    t.mode = VL_VAULTFMT_MODE_VERSION_LOG
    t.get = { ctx, key, keyLen, vid, vidLen, r in
        guard let v = bucket(ctx).find(text(key, keyLen), vid == nil ? nil : text(vid, vidLen)) else { return Status.notFound }
        _ = vl_vaultfmt_reply_body(r, v.body, v.body.count)
        reply(r, v)
        return Status.ok
    }
    t.get_range = { ctx, key, keyLen, vid, vidLen, offset, length, r in
        guard let v = bucket(ctx).find(text(key, keyLen), vid == nil ? nil : text(vid, vidLen)) else { return Status.notFound }
        if offset < UInt64(v.body.count) {
            let end = Int(min(UInt64(v.body.count), offset &+ length))
            let slice = Array(v.body[Int(offset)..<end])
            _ = vl_vaultfmt_reply_body(r, slice, slice.count)
        }
        _ = vl_vaultfmt_reply_total(r, UInt64(v.body.count))
        return Status.ok
    }
    t.head = { ctx, key, keyLen, r in
        guard let v = bucket(ctx).find(text(key, keyLen), nil) else { return Status.notFound }
        reply(r, v)
        return Status.ok
    }
    t.put = { ctx, key, keyLen, bytes, len, condition, _, _, r in
        // As B2 answers: conditional PUTs are not implemented.
        if condition != VL_VAULTFMT_PUT_PLAIN { return Int32(VL_VAULTFMT_ERR_STORE_CONDITIONS_UNSUPPORTED) }
        reply(r, bucket(ctx).write(text(key, keyLen), Array(UnsafeBufferPointer(start: bytes, count: len))))
        return Status.ok
    }
    t.list = { ctx, prefix, prefixLen, r in
        let p = text(prefix, prefixLen)
        for key in bucket(ctx).objects.keys.sorted() where key.hasPrefix(p) {
            guard let v = bucket(ctx).find(key, nil) else { continue }
            let etag = "\"e\(v.id)\""
            _ = vl_vaultfmt_reply_listed(r, key, key.utf8.count, UInt64(v.body.count), v.at, etag, etag.utf8.count)
        }
        return Status.ok
    }
    t.versions = { ctx, key, keyLen, _, _, under, r in
        let k = text(key, keyLen)
        for name in bucket(ctx).objects.keys.sorted() where under != 0 ? name.hasPrefix(k) : name == k {
            for (i, v) in bucket(ctx).objects[name]!.reversed().enumerated() {
                let etag = v.marker ? "" : "\"e\(v.id)\""
                _ = vl_vaultfmt_reply_version(r, name, name.utf8.count, v.id, v.id.utf8.count, UInt64(v.body.count), v.at,
                                              v.marker ? 1 : 0, etag, etag.utf8.count, i == 0 ? 1 : 0)
            }
        }
        return Status.ok
    }
    t.remove = { ctx, key, keyLen, vid, vidLen in
        let k = text(key, keyLen)
        if vid == nil { _ = bucket(ctx).write(k, [], marker: true) } else {
            let want = text(vid, vidLen)
            bucket(ctx).objects[k]?.removeAll { $0.id == want }
        }
        return Status.ok
    }
    t.content_begin = { ctx, key, keyLen, _, upload in
        let b = bucket(ctx)
        let id = b.nextUpload
        b.nextUpload += 1
        b.uploads[id] = (text(key, keyLen), [])
        upload?.pointee = UnsafeMutableRawPointer(bitPattern: id)
        return Status.ok
    }
    t.content_write = { ctx, upload, bytes, len in
        let id = Int(bitPattern: upload)
        bucket(ctx).uploads[id]?.body.append(contentsOf: UnsafeBufferPointer(start: bytes, count: len))
        return Status.ok
    }
    t.content_finish = { ctx, upload, r in
        let b = bucket(ctx)
        guard let u = b.uploads.removeValue(forKey: Int(bitPattern: upload)) else { return Int32(VL_VAULTFMT_ERR_STORE_FAILED) }
        reply(r, b.write(u.key, u.body))
        return Status.ok
    }
    t.content_abort = { ctx, upload in _ = bucket(ctx).uploads.removeValue(forKey: Int(bitPattern: upload)) }
    return t
}

// ---- keys --------------------------------------------------------------------------------------------------------------

final class Keychain { var keys: [UInt32: [UInt8]] = [:] }

func keysTable(_ k: Keychain) -> vl_vaultfmt_keys_table {
    var t = vl_vaultfmt_keys_table()
    t.ctx = Unmanaged.passUnretained(k).toOpaque()
    t.lookup = { ctx, version, out in
        guard let key = Unmanaged<Keychain>.fromOpaque(ctx!).takeUnretainedValue().keys[version], let out else { return Status.notFound }
        out.update(from: key, count: 32)
        return Status.ok
    }
    t.current = { _, version in
        version?.pointee = 1
        return Status.ok
    }
    return t
}

// KEV1, suite 1 (spec 03 §5.2): one vault key version for one X25519 recovery recipient.
func kev1(vaultKey: [UInt8], version: UInt32, vaultUid: [UInt8], recipient: Curve25519.KeyAgreement.PublicKey) throws -> [UInt8] {
    let ephemeral = Curve25519.KeyAgreement.PrivateKey()
    let epk = [UInt8](ephemeral.publicKey.rawRepresentation), rpk = [UInt8](recipient.rawRepresentation)
    var prefix: [UInt8] = [0x89, 0x56, 0x48, 0x4B, 0x0D, 0x0A, 0x1A, 0x0A, 0, 1, 0, 1, 1, 0, 0, 0]
    prefix += withUnsafeBytes(of: version.bigEndian, Array.init)
    prefix += vaultUid
    prefix += SHA256.hash(data: rpk)
    prefix += [0, 32] + epk
    let shared = try ephemeral.sharedSecretFromKeyAgreement(with: recipient)
    let wrap = shared.hkdfDerivedSymmetricKey(using: SHA256.self, salt: epk + rpk,
                                              sharedInfo: Array("vh.kev1.wrap".utf8) + prefix, outputByteCount: 32)
    let sealed = try AES.GCM.seal(vaultKey, using: wrap, nonce: AES.GCM.Nonce(data: Data(count: 12)), authenticating: prefix)
    return prefix + sealed.ciphertext + sealed.tag
}

// ---- the lifecycle ---------------------------------------------------------------------------------------------------

let vaultUid = (0..<16).map { UInt8(0x56 + $0) }
let vaultKey = (0..<32).map { UInt8(41 + $0) }
let store = Bucket(), keychain = Keychain()
keychain.keys[1] = vaultKey
let dir = FileManager.default.temporaryDirectory.appendingPathComponent("vl-vaultfmt-swift-\(getpid())")
try? FileManager.default.removeItem(at: dir)
try! FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
defer { try? FileManager.default.removeItem(at: dir) }

func openVault(_ store: Bucket, _ keychain: Keychain, statePath: String, create: String?)
    -> (OpaquePointer, vl_vaultfmt_open_info, OpaquePointer) {
    var fileState: OpaquePointer?
    check(vl_vaultfmt_file_state_new(statePath, statePath.utf8.count, &fileState), "file state")
    var stateTable = vl_vaultfmt_state_table()
    check(vl_vaultfmt_file_state_table(fileState, &stateTable), "state table")
    var storeT = storeTable(store), keysT = keysTable(keychain)
    var info = vl_vaultfmt_open_info()
    var vault: OpaquePointer?
    let node = "swift-check"
    let status = node.withCString { nodeP in
        (create ?? "").withCString { createP in
            var o = vl_vaultfmt_vault_options()
            o.node_id = nodeP
            o.node_id_len = node.utf8.count
            o.create_name = create == nil ? nil : createP
            o.create_name_len = create?.utf8.count ?? 0
            return vl_vaultfmt_vault_open(vaultUid, &storeT, &keysT, &stateTable, &o, &info, &vault)
        }
    }
    check(status, "open")
    return (vault!, info, fileState!)
}

func uid(of listing: OpaquePointer?) -> String {
    var e = vl_vaultfmt_entry()
    check(vl_vaultfmt_listing_entry(listing, 0, &e), "entry")
    return String(cString: e.uid)
}

final class Sink { var bytes: [UInt8] = [] }
func readAll(_ vault: OpaquePointer, _ file: String) -> [UInt8] {
    let sink = Sink()
    check(vl_vaultfmt_vault_read(vault, file, file.utf8.count, nil, 0, 0, UInt64.max, { ctx, bytes, len in
        Unmanaged<Sink>.fromOpaque(ctx!).takeUnretainedValue().bytes.append(contentsOf: UnsafeBufferPointer(start: bytes, count: len))
        return 0
    }, Unmanaged.passUnretained(sink).toOpaque()), "read")
    return sink.bytes
}

var (vault, info, fileState) = openVault(store, keychain, statePath: dir.appendingPathComponent("a.state").path, create: "Finance")
guard info.anchor == VL_VAULTFMT_ANCHOR_CREATED else { fail("anchor \(info.anchor)") }
let recipient = Curve25519.KeyAgreement.PrivateKey().publicKey
let envelope = try! kev1(vaultKey: vaultKey, version: 1, vaultUid: vaultUid, recipient: recipient)
envelope.withUnsafeBufferPointer { env in
    var bytes = vl_vaultfmt_bytes(bytes: env.baseAddress, len: env.count)
    check(vl_vaultfmt_vault_key_add(vault, 1, vaultKey, 32, &bytes, 1, nil, 0), "key add")
}
var rootBuf = [CChar](repeating: 0, count: 27)
var rootLen = 26
check(vl_vaultfmt_vault_root(vault, &rootBuf, &rootLen), "root")
let root = String(decoding: rootBuf[0..<rootLen].map { UInt8(bitPattern: $0) }, as: UTF8.self)
var listing: OpaquePointer?
check(vl_vaultfmt_vault_mkdir(vault, root, root.utf8.count, "Docs", 4, &listing), "mkdir")
let docs = uid(of: listing)
vl_vaultfmt_listing_free(listing)

let content = (0..<150_000).map { UInt8(truncatingIfNeeded: $0 &* 13) }
var write: OpaquePointer?
check(vl_vaultfmt_write_begin(vault, docs, docs.utf8.count, "report.pdf", 10, nil, 0, nil, 0, UInt64(content.count), &write),
      "write begin")
for start in stride(from: 0, to: content.count, by: 40_000) {
    let piece = Array(content[start..<min(content.count, start + 40_000)])
    check(vl_vaultfmt_write_chunk(write, piece, piece.count), "write chunk")
}
var conflict: Int32 = -1
check(vl_vaultfmt_write_finish(write, &conflict, &listing), "write finish")
vl_vaultfmt_write_free(write)
let file = uid(of: listing)
vl_vaultfmt_listing_free(listing)
guard conflict == 0, readAll(vault, file) == content else { fail("read back") }

var pub = vl_vaultfmt_publish_info()
check(vl_vaultfmt_vault_publish(vault, &pub), "publish")
guard pub.published == 1, pub.epoch == 1 else { fail("publish \(pub.published) \(pub.epoch)") }
vl_vaultfmt_vault_free(vault)
vl_vaultfmt_file_state_free(fileState)

// An installation without state: re-anchored from the bucket, freshness unverified, the same bytes.
(vault, info, fileState) = openVault(store, keychain, statePath: dir.appendingPathComponent("b.state").path, create: nil)
guard info.anchor == VL_VAULTFMT_ANCHOR_REANCHORED, info.freshness_verified == 0, info.epoch == 1 else { fail("re-anchor") }
guard readAll(vault, file) == content else { fail("read after re-anchor") }
vl_vaultfmt_vault_free(vault)
vl_vaultfmt_file_state_free(fileState)

print("OK: VLVaultfmt \(String(cString: vl_vaultfmt_version())): vault created, key added with a CryptoKit KEV1 envelope, "
      + "150000 bytes streamed and read back, published at epoch 1, re-anchored by a second installation")
