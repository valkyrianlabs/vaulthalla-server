#!/usr/bin/env bash
# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (c) 2026 Valkyrian Labs LLC
#
# Builds the XCFramework (scripts/build-xcframework.sh), copies it next to this package and runs the Swift check.
# macOS only; not part of the Linux CI.
set -euo pipefail
here="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
root="$(cd "$here/../.." && pwd)"
"$root/scripts/build-xcframework.sh" "$root/build-apple"
rm -rf "$here/Frameworks" && mkdir -p "$here/Frameworks"
cp -R "$root/build-apple/VLVaultfmt.xcframework" "$here/Frameworks/"
unset CPATH LIBRARY_PATH CPPFLAGS LDFLAGS
swift run --package-path "$here" --scratch-path "$root/build-apple/swift" -c release VaultfmtCheck
