// SPDX-License-Identifier: AGPL-3.0-or-later
// Copyright (c) 2026 Valkyrian Labs LLC
#pragma once

// The manifest suites' shared fixtures (test_manifest.cpp, test_manifest_protocol.cpp): keys, uids, entries, a vault
// with every kind of fact the manifest carries, and small vaults.

#include "vl/vaultfmt/manifest/Content.hpp"
#include "vl/vaultfmt/vhf1/Format.hpp"
#include "vl/vaultfmt/vhf1/Key.hpp"

#include <map>
#include <memory>
#include <optional>
#include <string>
#include <vector>

namespace vl::vaultfmt::manifest::test_fixtures {

using Bytes = std::vector<uint8_t>;

inline vhf1::KeyLookup lookupOf(std::map<uint32_t, vhf1::KeyPtr> keys) {
    return [keys = std::move(keys)](const uint32_t v) -> vhf1::KeyPtr {
        const auto it = keys.find(v);
        return it == keys.end() ? nullptr : it->second;
    };
}

// ---- fixtures ------------------------------------------------------------------------------------------------------

inline vhf1::KeyPtr keyOf(const uint8_t seed) {
    Bytes k(32);
    for (std::size_t i = 0; i < k.size(); ++i) k[i] = static_cast<uint8_t>(seed + i);
    return std::make_shared<const vhf1::Key>(k);
}

inline Uid uidOf(const uint8_t first, const uint8_t fill) {
    Uid u{};
    u.fill(fill);
    u[0] = first;
    return u;
}

inline std::string uidT(const uint8_t first, const uint8_t fill) { return uidText(uidOf(first, fill)); }

inline Entry dirEntry(const std::string& uid, std::optional<std::string> parent, std::string name) {
    Entry e;
    e.uid = uid;
    e.kind = EntryKind::Dir;
    e.parent = std::move(parent);
    e.name = std::move(name);
    e.mode = 0755;
    e.mtime = "2026-11-05T12:00:00Z";
    return e;
}

inline Entry fileEntry(const std::string& uid, const std::string& parent, std::string name, const uint64_t size) {
    Entry e;
    e.uid = uid;
    e.kind = EntryKind::File;
    e.parent = parent;
    e.name = std::move(name);
    e.mode = 0644;
    e.mtime = "2026-11-05T12:01:00Z";
    e.size = size;
    e.format = 1;
    e.key_version = 1;
    e.object = ObjectRef{"\"etag-" + e.uid.substr(0, 6) + "\"", size + 136, std::nullopt, std::nullopt};
    return e;
}

inline const std::string kRootUid = uidT(0x01, 0x11);
inline const std::string kReportsUid = uidT(0x80, 0x22);

// A vault with every kind of fact the manifest carries.
inline Content richContent() {
    Content c;
    c.producer = {"8f14e45f-ceea-467a-9575-0c6d2b6a1b8a", 42, "vaulthalla test"};
    c.vault = VaultInfo{"Finance", "2026-10-01T00:00:00Z", std::nullopt, "cache",
                        FileRecovery{"provider_versioning", 90}};
    c.keys = {KeyRecord{1, "72e4c8b7f8ab43b8ed8869a57cef1703",
                        KeyAttestation{3, "A6EHv/POEL4dcN0Y50vAmWfk1jCbpQ1fHdyGZBJVMbg=", std::string(86, 'A') + "=="},
                        "2026-10-01T00:00:00Z", "2026-11-01T00:00:00Z", std::nullopt, std::nullopt},
              KeyRecord{2, std::nullopt, std::nullopt, "2026-11-01T00:00:00Z", std::nullopt, std::nullopt, std::nullopt}};
    c.recovery_policy = RecoveryPolicy{};
    c.entries.push_back(dirEntry(kRootUid, std::nullopt, ""));
    c.entries.push_back(dirEntry(kReportsUid, kRootUid, "Reports"));
    auto pdf = fileEntry(uidT(0x40, 0x33), kReportsUid, "Q3 board pack.pdf", 3172);
    pdf.mime = "application/pdf";
    pdf.owner = Owner{1000, 1000};
    pdf.versions = {FileVersion{"v2", std::nullopt, 1, 3308, "\"e2\"", "2026-11-05T12:01:00Z", std::nullopt, false, std::nullopt},
                    FileVersion{"v1", std::nullopt, 1, 3300, "\"e1\"", "2026-11-04T12:00:00Z", "2026-11-05T12:01:00Z",
                                false, std::nullopt}};
    pdf.names = {PriorName{"2026-11-05T00:00:00Z", kRootUid, "draft.pdf"}};
    c.entries.push_back(pdf);
    Entry link;
    link.uid = uidT(0xc0, 0x44);
    link.kind = EntryKind::Symlink;
    link.parent = kReportsUid;
    link.name = "latest";
    link.target = "Reports/Q3 board pack.pdf";
    c.entries.push_back(link);
    auto trashed = fileEntry(uidT(0xd0, 0x55), kReportsUid, "old.txt", 12);
    trashed.trashed = Trashed{"2026-11-05T11:00:00Z", "admin", "/Reports/old.txt"};
    c.entries.push_back(trashed);
    Entry tomb;
    tomb.uid = uidT(0xe0, 0x66);
    tomb.kind = EntryKind::Tombstone;
    tomb.name = "purged.bin";
    tomb.versions = {FileVersion{"v9", std::nullopt, 1, 200, "\"e9\"", "2026-11-03T00:00:00Z", std::nullopt, false, std::nullopt}};
    c.entries.push_back(tomb);
    c.snapshots = {SnapshotRecord{uidT(0x70, 0x77), std::nullopt, "before audit", "2026-11-05T10:00:00Z", "/Reports",
                                  {SnapshotMember{uidT(0x40, 0x33), "/Reports/Q3 board pack.pdf", std::nullopt, 1, "v1", true},
                                   SnapshotMember{std::nullopt, "/Reports/gone.txt", std::nullopt, 1, std::nullopt, false}}}};
    normalize(c);
    return c;
}

inline Content smallVault(const std::size_t files, const uint8_t salt = 0) {
    Content c;
    c.producer = {"node", 1, "vaulthalla test"};
    c.recovery_policy = RecoveryPolicy{};
    c.keys = {KeyRecord{2, std::nullopt, std::nullopt, "2026-11-01T00:00:00Z", std::nullopt, std::nullopt, std::nullopt}};
    c.entries.push_back(dirEntry(kRootUid, std::nullopt, ""));
    for (std::size_t i = 0; i < files; ++i) {
        Uid u{};
        u.fill(static_cast<uint8_t>(i * 7 + salt));
        u[0] = static_cast<uint8_t>((i * 37) & 0xff);
        u[1] = static_cast<uint8_t>(i >> 8);
        u[2] = static_cast<uint8_t>(i);
        c.entries.push_back(fileEntry(uidText(u), kRootUid, "file-" + std::to_string(i), 100 + i));
    }
    normalize(c);
    return c;
}

}
