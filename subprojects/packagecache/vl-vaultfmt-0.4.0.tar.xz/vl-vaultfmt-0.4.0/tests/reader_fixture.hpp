// SPDX-License-Identifier: AGPL-3.0-or-later
// Copyright (c) 2026 Valkyrian Labs LLC
#pragma once

// A small Desktop-only vault as a bucket holds it, built with the native library: three epochs published in
// version_log mode on the in-memory versioned store (MemoryBucket), a sibling root above the head, every segment, the
// sealed content of three files (one with 4 KiB chunks, so a ranged read crosses chunks), the vault key wrapped as a
// KEV1 envelope to an account recovery key, an envelope for someone else, a tampered copy of one file's object and a
// root sealed for another vault. test_c_api_reader.cpp reads it through the C API (built fresh, and from the committed
// copy); make_reader_fixture writes it as JSON for the WebAssembly tests (wasm/tests/fixture.json), which read it
// through the wasm build alone. Sealing takes fresh salts and ephemeral keys, so each build differs in bytes, never in
// what it holds.

#include "support.hpp"

#include "vl/vaultfmt/manifest/Content.hpp"
#include "vl/vaultfmt/manifest/Document.hpp"
#include "vl/vaultfmt/manifest/Objects.hpp"
#include "vl/vaultfmt/manifest/Publisher.hpp"
#include "vl/vaultfmt/testing/memory_store.hpp"
#include "vl/vaultfmt/vhf1/Format.hpp"
#include "vl/vaultfmt/vhf1/Key.hpp"
#include "vl/vaultfmt/vhf1/Writer.hpp"

#include <vl/keykit/kev1.hpp>
#include <vl/keykit/seed.hpp>

#include <nlohmann/json.hpp>

#include <cstdint>
#include <map>
#include <memory>
#include <string>
#include <vector>

namespace vl::vaultfmt::test {

using Bytes = std::vector<uint8_t>;

// The plaintext of fixture file `seed`, byte i (the JavaScript tests compute the same).
inline uint8_t patternByte(const uint32_t seed, const uint64_t i) {
    return static_cast<uint8_t>((i * 31u + seed * 7u + (i >> 8)) & 0xffu);
}

inline Bytes patternBytes(const uint32_t seed, const uint64_t size) {
    Bytes b(size);
    for (uint64_t i = 0; i < size; ++i) b[i] = patternByte(seed, i);
    return b;
}

struct ReaderFixture {
    struct RootVersion {
        std::string version_id;
        bool delete_marker{false};
        Bytes bytes;
    };
    struct File {
        std::string uid;
        std::string name;
        uint32_t pattern{};
        uint64_t size{};
        uint8_t chunk_log2{};
        Bytes object;
    };
    manifest::Uid vault{};
    manifest::Uid other_vault{};
    std::string seed_text;
    uint32_t key_version{1};
    Bytes envelope;           // the vault key, to the account key of seed_text
    Bytes decoy_envelope;     // the same key to another recipient
    std::vector<RootVersion> roots;   // newest first, as ListObjectVersions lists them
    std::map<uint64_t, std::string> epoch_version;   // canonical epoch -> version id
    std::map<uint64_t, std::string> epoch_sha;       // canonical epoch -> root object hash
    std::string sibling_version;      // a sibling of the head (epoch 3, prev = epoch 2), newer than it
    std::map<std::string, Bytes> segments;           // sid -> sealed segment (every epoch's)
    std::vector<File> files;
    Bytes tampered;           // files[0].object with one byte flipped in its second chunk
    Bytes other_root;         // a valid root of other_vault, sealed under the same key

    [[nodiscard]] std::string listingJson() const {
        auto a = nlohmann::json::array();
        for (const auto& r : roots)
            a.push_back({{"version_id", r.version_id},
                         {"delete_marker", r.delete_marker},
                         {"key", ".vaulthalla/root"},
                         {"size", r.bytes.size()}});
        return a.dump();
    }
};

inline ReaderFixture buildReaderFixture() {
    using namespace manifest;
    ReaderFixture f;
    for (std::size_t i = 0; i < 16; ++i) {
        f.vault[i] = static_cast<uint8_t>(0xa0 + i);
        f.other_vault[i] = static_cast<uint8_t>(0x30 + i);
    }
    Bytes keyBytes(32);
    for (std::size_t i = 0; i < keyBytes.size(); ++i) keyBytes[i] = static_cast<uint8_t>(0x40 + 3 * i);
    const auto key = std::make_shared<const vhf1::Key>(keyBytes);
    const vhf1::KeyLookup lookup = [&](const uint32_t v) -> vhf1::KeyPtr { return v == 1 ? key : nullptr; };
    const SealingKey sealing{1, key};

    Bytes seedBytes(16), decoyBytes(16);
    for (std::size_t i = 0; i < 16; ++i) {
        seedBytes[i] = static_cast<uint8_t>(0x11 * (i + 1));
        decoyBytes[i] = static_cast<uint8_t>(0x5a ^ i);
    }
    const auto seed = keykit::RecoverySeed::fromBytes(seedBytes);
    const auto decoy = keykit::RecoverySeed::fromBytes(decoyBytes);
    f.seed_text = seed.text();
    f.envelope = keykit::kev1::wrap(keyBytes, keykit::kev1::Suite::X25519, 1, f.vault, seed.x25519PublicKey());
    f.decoy_envelope = keykit::kev1::wrap(keyBytes, keykit::kev1::Suite::X25519, 1, f.vault, decoy.x25519PublicKey());

    const auto uidAt = [](const uint8_t first, const uint8_t fill) {
        Uid u{};
        u.fill(fill);
        u[0] = first;
        return u;
    };
    const auto rootDir = uidAt(0x08, 0x01);
    const auto docsDir = uidAt(0x48, 0x02);
    Content c;
    c.producer = {"desktop-0001", std::nullopt, "vl-vaultfmt reader fixture"};
    c.recovery_policy = RecoveryPolicy{};
    c.keys = {KeyRecord{1, std::nullopt, std::nullopt, "2026-11-15T00:00:00Z", std::nullopt,
                        std::vector<std::string>{keykit::kev1::kid(f.envelope)}, std::nullopt}};
    const auto dir = [](const Uid& uid, std::optional<std::string> parent, std::string name) {
        Entry e;
        e.uid = uidText(uid);
        e.kind = EntryKind::Dir;
        e.parent = std::move(parent);
        e.name = std::move(name);
        e.mode = 0755;
        e.mtime = "2026-11-15T10:00:00Z";
        return e;
    };
    c.entries.push_back(dir(rootDir, std::nullopt, ""));
    c.entries.push_back(dir(docsDir, uidText(rootDir), "docs"));
    struct Spec {
        Uid uid;
        Uid parent;
        std::string name;
        uint32_t pattern;
        uint64_t size;
        uint8_t chunkLog2;
    };
    const std::vector<Spec> specs{{uidAt(0x90, 0x03), docsDir, "report.bin", 1, 10000, 12},
                                  {uidAt(0xc4, 0x04), rootDir, "note.txt", 2, 3, 16},
                                  {uidAt(0xe2, 0x05), docsDir, "photo.raw", 3, 70000, 16}};
    std::map<std::string, Entry> fileEntries;
    for (const auto& s : specs) {
        vhf1::HeaderParams p;
        p.kind = vhf1::Kind::FileContent;
        p.keyVersion = 1;
        p.vaultUid = f.vault;
        p.objectUid = s.uid;
        p.salt = vhf1::freshSalt();
        p.chunkLog2 = s.chunkLog2;
        const auto plaintext = patternBytes(s.pattern, s.size);
        auto object = vhf1::seal(plaintext, p, *key);
        Entry e;
        e.uid = uidText(s.uid);
        e.kind = EntryKind::File;
        e.parent = uidText(s.parent);
        e.name = s.name;
        e.mode = 0644;
        e.mtime = "2026-11-15T10:05:00Z";
        e.size = s.size;
        e.format = 1;
        e.key_version = 1;
        e.generation = toHex(p.salt);
        e.object = ObjectRef{"\"etag-" + e.uid.substr(0, 6) + "\"", object.size(), std::string("ov-") + e.uid.substr(0, 8),
                             std::nullopt};
        fileEntries[e.uid] = e;
        f.files.push_back({e.uid, s.name, s.pattern, s.size, s.chunkLog2, std::move(object)});
    }
    f.tampered = f.files[0].object;
    f.tampered[vhf1::kHeaderSize + (1u << 12) + vhf1::kTagSize + 5] ^= 0x20;

    auto bucket = std::make_shared<test_support::MemoryBucket>(true);
    bucket->setNow(1794744000);
    test_support::MemoryStore store(bucket, WriteCapability::VersionLog);
    PublisherCache cache;
    PublishOptions o;
    o.now = "2026-11-15T10:10:00Z";
    o.self_node = "desktop-0001";
    o.limits = PartitionLimits{2, 4u << 20, 1};   // a few entries per segment: several segments
    o.sleep = [](std::chrono::milliseconds) {};
    std::optional<Known> known;
    const auto publishNow = [&](Content content) {
        normalize(content);
        const auto r = publish(store, f.vault, lookup, sealing, content, known, cache, o);
        known = r.published.known;
        o.own_epoch = known->epoch;
        f.epoch_version[known->epoch] = *r.published.settled.version_id;
        f.epoch_sha[known->epoch] = known->root_sha256;
        return r.published.root;
    };
    // Epoch 1: the tree and report.bin; 2: note.txt and photo.raw; 3: note.txt renamed.
    c.entries.push_back(fileEntries[uidText(specs[0].uid)]);
    publishNow(c);
    c.entries.push_back(fileEntries[uidText(specs[1].uid)]);
    c.entries.push_back(fileEntries[uidText(specs[2].uid)]);
    publishNow(c);
    for (auto& e : c.entries)
        if (e.uid == uidText(specs[1].uid)) e.name = "notes.txt";
    auto head = publishNow(c);

    // A sibling of the head: another writer's epoch 3 on the same base that lost (here: written after it).
    head.published_at = "2026-11-15T10:11:00Z";
    head.producer.node_id = "desktop-0002";
    const auto sibling = sealRoot(head, f.vault, sealing);
    f.sibling_version = *store.put(std::string(kRootKey), sibling).version_id;

    for (const auto& v : store.versions(std::string(kRootKey))) {
        ReaderFixture::RootVersion r{v.version_id, v.delete_marker, {}};
        if (!v.delete_marker) r.bytes = store.get(std::string(kRootKey), v.version_id)->bytes;
        f.roots.push_back(std::move(r));
    }
    for (const auto& listed : store.list(std::string(kSegmentPrefix)))
        f.segments[*sidOfKey(listed.key)] = store.get(listed.key, std::nullopt)->bytes;

    auto other = head;
    other.vault_uid = uidText(f.other_vault);
    other.epoch = 1;
    other.prev.reset();
    f.other_root = sealRoot(other, f.other_vault, sealing);
    return f;
}

inline nlohmann::json toJson(const ReaderFixture& f) {
    nlohmann::json j;
    j["about"] = "vl-vaultfmt reader fixture: tests/reader_fixture.hpp, written by make_reader_fixture "
                 "(scripts in wasm/README.md). Generated; do not edit.";
    j["vault_uid_hex"] = toHex(f.vault);
    j["other_vault_uid_hex"] = toHex(f.other_vault);
    j["seed_text"] = f.seed_text;
    j["key_version"] = f.key_version;
    j["envelope_hex"] = toHex(f.envelope);
    j["decoy_envelope_hex"] = toHex(f.decoy_envelope);
    j["listing"] = nlohmann::json::parse(f.listingJson());
    auto roots = nlohmann::json::array();
    for (const auto& r : f.roots) roots.push_back({{"version_id", r.version_id}, {"delete_marker", r.delete_marker}, {"hex", toHex(r.bytes)}});
    j["roots"] = roots;
    for (const auto& [epoch, id] : f.epoch_version)
        j["epochs"][std::to_string(epoch)] = {{"version_id", id}, {"root_sha256", f.epoch_sha.at(epoch)}};
    j["sibling_version"] = f.sibling_version;
    for (const auto& [sid, bytes] : f.segments) j["segments"][sid] = toHex(bytes);
    auto files = nlohmann::json::array();
    for (const auto& file : f.files)
        files.push_back({{"uid", file.uid}, {"name", file.name}, {"pattern", file.pattern}, {"size", file.size},
                         {"chunk_log2", file.chunk_log2}, {"object_hex", toHex(file.object)}});
    j["files"] = files;
    j["tampered_hex"] = toHex(f.tampered);
    j["other_root_hex"] = toHex(f.other_root);
    return j;
}

inline ReaderFixture fixtureFromJson(const nlohmann::json& j) {
    ReaderFixture f;
    const auto uid = [](const std::string& hex) {
        manifest::Uid u{};
        const auto b = fromHex(hex);
        std::copy(b.begin(), b.end(), u.begin());
        return u;
    };
    f.vault = uid(j["vault_uid_hex"]);
    f.other_vault = uid(j["other_vault_uid_hex"]);
    f.seed_text = j["seed_text"];
    f.key_version = j["key_version"];
    f.envelope = fromHex(j["envelope_hex"]);
    f.decoy_envelope = fromHex(j["decoy_envelope_hex"]);
    for (const auto& r : j["roots"]) f.roots.push_back({r["version_id"], r["delete_marker"], fromHex(r["hex"])});
    for (const auto& [epoch, e] : j["epochs"].items()) {
        f.epoch_version[std::stoull(epoch)] = e["version_id"];
        f.epoch_sha[std::stoull(epoch)] = e["root_sha256"];
    }
    f.sibling_version = j["sibling_version"];
    for (const auto& [sid, hex] : j["segments"].items()) f.segments[sid] = fromHex(hex.get<std::string>());
    for (const auto& file : j["files"])
        f.files.push_back({file["uid"], file["name"], file["pattern"], file["size"], file["chunk_log2"],
                           fromHex(file["object_hex"])});
    f.tampered = fromHex(j["tampered_hex"]);
    f.other_root = fromHex(j["other_root_hex"]);
    return f;
}

}
