// SPDX-License-Identifier: AGPL-3.0-or-later
// Copyright (c) 2026 Valkyrian Labs LLC
// Encrypted manifest v2 (vaulthalla-server #368; design/encryption/03-metadata-recovery.md §3-§4, §8), DB-free.
//
// ManifestVectors   every manifest vector of vectors.json (objects, chain, negative): the C++ reader agrees with the
//                   reference, and the documents re-encode to the vectors' bytes.
// ManifestDocument  the root/segment/snapshot schema: round trips, unknown members, the extensible recovery_policy,
//                   structural refusals.
// ManifestPartition segment split/merge rules.
// ManifestContent   merging pending changes keeps every writer's snapshots.
//
// The publish protocol's own suites (ManifestPublish*, ManifestChain*, ManifestReplay*, ManifestStore*,
// ManifestBaseCopy) are in test_manifest_protocol.cpp, the version_log interleavings in test_manifest_interleavings.cpp,
// both on the in-memory store; the fixtures they share with this file are manifest_fixtures.hpp.

#include "manifest_fixtures.hpp"
#include "support.hpp"
#include "vl/vaultfmt/vhf1/Key.hpp"
#include "vl/vaultfmt/vhf1/Format.hpp"
#include "vl/vaultfmt/vhf1/Writer.hpp"
#include "vl/vaultfmt/manifest/Chain.hpp"
#include "vl/vaultfmt/manifest/Content.hpp"
#include "vl/vaultfmt/manifest/Document.hpp"
#include "vl/vaultfmt/manifest/Objects.hpp"
#include "vl/vaultfmt/manifest/Partition.hpp"
#include "vl/vaultfmt/manifest/Publisher.hpp"
#include "vl/vaultfmt/manifest/Reader.hpp"
#include "vl/vaultfmt/manifest/Store.hpp"

#include <gtest/gtest.h>

#include <functional>
#include <future>
#include <set>
#include <thread>

namespace vl::vaultfmt::manifest::test_manifest_suite {

namespace {

using namespace test_fixtures;

using Bytes = std::vector<uint8_t>;
using vhf1::Key;
using vhf1::KeyPtr;

// ---- vectors -------------------------------------------------------------------------------------------------------

const Json& vectors() { return vl::vaultfmt::test::goldenVectors(); }

using vl::vaultfmt::test::fromHex;

Uid uidFromHex(const std::string& hex) {
    const auto raw = fromHex(hex);
    Uid out{};
    std::copy(raw.begin(), raw.end(), out.begin());
    return out;
}


std::map<uint32_t, vhf1::KeyPtr> vectorKeys() {
    std::map<uint32_t, vhf1::KeyPtr> keys;
    for (const auto& [version, hex] : vectors()["conventions"]["keys"].items())
        keys[static_cast<uint32_t>(std::stoul(version))] = std::make_shared<const vhf1::Key>(fromHex(hex.get<std::string>()));
    return keys;
}

const Uid& vectorVaultUid() {
    static const Uid uid = uidFromHex(vectors()["vhf1"]["positive"][0]["params"]["vault_uid_hex"].get<std::string>());
    return uid;
}

const Json& vectorObject(const std::string& name) {
    for (const auto& o : vectors()["manifest"]["objects"])
        if (o["name"] == name) return o;
    throw std::runtime_error("no manifest object " + name);
}



}

// ── ManifestVectors ──────────────────────────────────────────────────────────────────────────────────────────────

TEST(ManifestVectors, ObjectsOpenAndReencodeToTheirPlaintext) {
    const auto keys = lookupOf(vectorKeys());
    for (const auto& o : vectors()["manifest"]["objects"]) {
        SCOPED_TRACE(o["name"].get<std::string>());
        const auto object = fromHex(o["object_hex"].get<std::string>());
        const auto objectUid = uidFromHex(o["object_uid_hex"].get<std::string>());
        if (o.contains("object_sha256")) { EXPECT_EQ(sha256Hex(object), o["object_sha256"].get<std::string>()); }
        const auto plaintext = o["plaintext_utf8"].get<std::string>();
        if (o["kind"].get<int>() == 3) {
            EXPECT_EQ(o["object_key"].get<std::string>(), kRootKey);
            EXPECT_EQ(objectUid, vectorVaultUid());
            const auto root = openRoot(object, vectorVaultUid(), keys);
            EXPECT_EQ(canonicalJson(toJson(root)), plaintext);
            EXPECT_EQ(rootFromJson(Json::parse(plaintext), vectorVaultUid()), root);
        } else {
            ASSERT_EQ(o["kind"].get<int>(), 2);
            const auto key = o["object_key"].get<std::string>();
            const auto sid = sidOfKey(key);
            ASSERT_TRUE(sid);
            EXPECT_EQ(parseUid(*sid, "bad_root", "sid"), objectUid);
            const auto seg = openSegment(object, vectorVaultUid(), objectUid, keys);
            EXPECT_EQ(canonicalJson(toJson(seg)), plaintext);
        }
    }
}

TEST(ManifestVectors, ChainCasesMatchTheReference) {
    const auto keys = lookupOf(vectorKeys());
    const Json seg = vectorObject("segment_1");
    const auto segSid = *sidOfKey(seg["object_key"].get<std::string>());
    std::size_t warnings = 0;
    for (const auto& c : vectors()["manifest"]["chain"]) {
        SCOPED_TRACE(c["name"].get<std::string>());
        const Bytes rootObject = c.contains("root_hex") ? fromHex(c["root_hex"].get<std::string>())
                                                        : fromHex(vectorObject(c["root"].get<std::string>())["object_hex"].get<std::string>());
        const auto root = openRoot(rootObject, vectorVaultUid(), keys);
        if (c.contains("root_plaintext_utf8")) { EXPECT_EQ(canonicalJson(toJson(root)), c["root_plaintext_utf8"].get<std::string>()); }
        std::map<std::string, Bytes> segments{{segSid, fromHex(seg["object_hex"].get<std::string>())}};
        if (c.contains("segments_override")) {
            segments.clear();
            for (const auto& [sid, hex] : c["segments_override"].items()) segments[sid] = fromHex(hex.get<std::string>());
        }
        std::optional<Known> known;
        if (!c["known"].is_null())
            known = Known{c["known"]["epoch"].get<uint64_t>(), c["known"]["root_sha256"].get<std::string>()};

        Json got;
        try {
            const auto a = acceptRoot(root, rootObject, known, segments);
            got = {{"epoch", a.epoch}, {"root_sha256", a.root_sha256}};
            if (a.gap) {
                got["warning"] = "gap";
                ++warnings;
            }
        } catch (const ChainRejected& e) {
            got = {{"error", std::string(chainErrorName(e.code()))}};
        }
        EXPECT_EQ(got, c["expect"]);
    }
    EXPECT_GE(warnings, 1u) << "the vectors carry a gap case";
}

TEST(ManifestVectors, NegativesFailClosed) {
    const auto keys = lookupOf(vectorKeys());
    for (const auto& n : vectors()["manifest"]["negative"]) {
        SCOPED_TRACE(n["name"].get<std::string>());
        const auto object = fromHex(n["object_hex"].get<std::string>());
        const auto kind = static_cast<vhf1::Kind>(n["expect_kind"].get<int>());
        const auto uid = uidFromHex(n["expect_object_uid_hex"].get<std::string>());
        std::optional<std::string> error;
        try {
            if (kind == vhf1::Kind::ManifestRoot) (void)openRoot(object, vectorVaultUid(), keys);
            else (void)openSegment(object, vectorVaultUid(), uid, keys);
        } catch (const vhf1::Error& e) {
            error = std::string(vhf1::errorCodeName(e.code()));
        }
        ASSERT_TRUE(error) << "accepted";
        EXPECT_EQ(*error, n["expect"]["error"].get<std::string>());
    }
}

TEST(ManifestVectors, EveryChainErrorNameIsKnown) {
    for (const auto& c : vectors()["manifest"]["chain"])
        if (c["expect"].contains("error")) {
            EXPECT_TRUE(chainErrorFromName(c["expect"]["error"].get<std::string>()))
                << c["expect"]["error"].get<std::string>();
        }
}

// ── ManifestDocument ─────────────────────────────────────────────────────────────────────────────────────────────

TEST(ManifestDocument, IsoTimeIsTheUtcCalendarTimeToTheSecond) {
    // The documents' timestamps (isoTime, <chrono>): what gmtime gives, leap days and times before 1970 included.
    EXPECT_EQ(isoTime(0), "1970-01-01T00:00:00Z");
    EXPECT_EQ(isoTime(-1), "1969-12-31T23:59:59Z");
    EXPECT_EQ(isoTime(951782399), "2000-02-28T23:59:59Z");
    EXPECT_EQ(isoTime(951782400), "2000-02-29T00:00:00Z");
    EXPECT_EQ(isoTime(1709251199), "2024-02-29T23:59:59Z");
    EXPECT_EQ(isoTime(1793880000), "2026-11-05T12:00:00Z");
    EXPECT_EQ(isoTime(4102444799), "2099-12-31T23:59:59Z");
}

TEST(ManifestDocument, RichRootSegmentAndSnapshotRoundTrip) {
    const auto content = richContent();
    const Uid vault = uidOf(0x56, 0x48);
    RootDocument root;
    root.vault_uid = uidText(vault);
    root.epoch = 2;
    root.prev = std::string(64, 'a');
    root.published_at = "2026-11-05T12:02:00Z";
    root.producer = content.producer;
    root.vault = content.vault;
    root.keys = content.keys;
    root.keys[1].envelopes = std::vector<std::string>{"abcdefghjkmnpqrstvwxyz0123"};
    root.recovery_policy = RecoveryPolicy{1, true, {Grant{"g1", std::string(64, 'b'), "customer", 1, "Recovery kit",
                                                           "2026-11-01T00:00:00Z", "device-3", std::nullopt, std::nullopt, 1u}}};
    // The account's signed recovery policy travels in the root, byte for byte (design/cloud/key-manager.md).
    root.recovery_policy->account_policy = AccountPolicyBytes{.policy = "vhc-recovery-policy-v1\n…", .signature = "c2ln"};
    root.segments = {SegmentRef{uidT(0x10, 0x01), {0x00, 0x7f}, 3, std::string(64, 'c'), 900},
                     SegmentRef{uidT(0x10, 0x02), {0x80, 0xff}, 4, std::string(64, 'd'), 1200}};
    root.snapshots = {SnapshotRef{uidT(0x10, 0x03), std::string(64, 'e'), 400}};
    root.stats = statsOf(content);
    const auto text = canonicalJson(toJson(root));
    EXPECT_EQ(rootFromJson(Json::parse(text), vault), root);
    EXPECT_EQ(canonicalJson(toJson(rootFromJson(Json::parse(text), vault))), text);

    SegmentDocument seg{uidText(vault), {0x00, 0xff}, content.entries};
    const auto segText = canonicalJson(toJson(seg));
    EXPECT_EQ(segmentFromJson(Json::parse(segText), vault), seg);

    SnapshotDocument snap{uidText(vault), content.snapshots[0]};
    EXPECT_EQ(snapshotFromJson(Json::parse(canonicalJson(toJson(snap))), vault), snap);

    EXPECT_EQ(root.stats, (Stats{1, 2, 3172}));  // the trashed file and the tombstone are not live files
}

TEST(ManifestDocument, ReadersIgnoreUnknownMembersAndKeepUnknownGrantsUnusable) {
    const Uid vault = uidOf(0x56, 0x48);
    auto j = toJson(RootDocument{uidText(vault), std::string(kLayoutOpaqueV1), 1, std::nullopt, "t", {"n", 1, "s"},
                                 std::nullopt, {}, RecoveryPolicy{}, {SegmentRef{uidT(1, 1), {0, 255}, 0, std::string(64, 'f'), 1}},
                                 {}, {}});
    j["future_member"] = {{"anything", true}};
    j["recovery_policy"]["grants"] = Json::array(
        {{{"grant_id", "g-cust"}, {"recipient_id", std::string(64, '1')}, {"class", "customer"}, {"suite", 1},
          {"revoked_at", nullptr}},
         {{"grant_id", "g-cust-revoked"}, {"recipient_id", std::string(64, '2')}, {"class", "customer"}, {"suite", 1},
          {"revoked_at", "2026-11-04T00:00:00Z"}},
         {{"grant_id", "g-future"}, {"recipient_id", std::string(64, '3')}, {"class", "custodian"}, {"suite", 3},
          {"revoked_at", nullptr}, {"participant_share", 2}}});
    const auto root = rootFromJson(j, vault);
    ASSERT_TRUE(root.recovery_policy);
    ASSERT_EQ(root.recovery_policy->grants.size(), 3u);
    EXPECT_TRUE(root.recovery_policy->grants[0].usableForDecryption());
    EXPECT_FALSE(root.recovery_policy->grants[1].usableForDecryption());  // revoked
    EXPECT_FALSE(root.recovery_policy->grants[2].usableForDecryption());  // a class this reader doesn't know

    // A later policy version, or the reserved threshold in use: not understood, nothing usable, the root still loads.
    for (const auto& [v, threshold] : {std::pair{Json(2), Json(nullptr)}, std::pair{Json(1), Json(2)}}) {
        auto k = j;
        k["recovery_policy"]["v"] = v;
        k["recovery_policy"]["threshold"] = threshold;
        const auto r = rootFromJson(k, vault);
        ASSERT_TRUE(r.recovery_policy);
        EXPECT_FALSE(r.recovery_policy->understood);
        EXPECT_TRUE(r.recovery_policy->grants.empty());
    }
}

TEST(ManifestDocument, StructuralRefusals) {
    const Uid vault = uidOf(0x56, 0x48);
    RootDocument good{uidText(vault), std::string(kLayoutOpaqueV1), 2, std::string(64, 'a'), "t", {"n", 1, "s"},
                      std::nullopt, {}, std::nullopt,
                      {SegmentRef{uidT(1, 1), {0x00, 0x7f}, 0, std::string(64, 'f'), 1},
                       SegmentRef{uidT(1, 2), {0x80, 0xff}, 0, std::string(64, 'f'), 1}},
                      {}, {}};
    ASSERT_NO_THROW((void)rootFromJson(toJson(good), vault));
    const auto refuses = [&](const std::function<void(Json&)>& mutate, const std::string& why) {
        auto j = toJson(good);
        mutate(j);
        try {
            (void)rootFromJson(j, vault);
            ADD_FAILURE() << "accepted: " << why;
        } catch (const FormatError& e) {
            EXPECT_EQ(e.code(), "bad_root") << why;
        }
    };
    refuses([](Json& j) { j["type"] = "vh.manifest.segment"; }, "another document type");
    refuses([](Json& j) { j["v"] = 2; }, "an unknown version");
    refuses([](Json& j) { j["epoch"] = 0; }, "epoch 0");
    refuses([](Json& j) { j["prev"] = nullptr; }, "no prev after epoch 1");
    refuses([](Json& j) { j["epoch"] = 1; }, "a prev at epoch 1");
    refuses([&](Json& j) { j["vault_uid"] = uidT(9, 9); }, "another vault");
    refuses([](Json& j) { j["segments"][1]["range"] = Json::array({"7f", "ff"}); }, "overlapping ranges");
    refuses([](Json& j) { j["segments"][1]["range"] = Json::array({"81", "ff"}); }, "a gap in the ranges");
    refuses([](Json& j) { j["segments"].erase(1); }, "ranges that don't reach ff");
    refuses([](Json& j) { j["segments"][1]["sid"] = j["segments"][0]["sid"]; }, "a sid named twice");
    refuses([](Json& j) { j["segments"][0]["sid"] = "NOT-BASE32"; }, "a malformed sid");
    refuses([](Json& j) { j["layout"] = "PathV0"; }, "another layout");

    SegmentDocument seg{uidText(vault), {0x00, 0x7f}, {dirEntry(uidT(0x90, 1), std::nullopt, "")}};
    try {
        (void)segmentFromJson(toJson(seg), vault);
        ADD_FAILURE() << "an entry outside the segment's range was accepted";
    } catch (const FormatError& e) {
        EXPECT_EQ(e.code(), "bad_segment");
    }
}

TEST(ManifestDocument, SealedObjectsBindKindVaultAndObjectUid) {
    const Uid vault = uidOf(0x56, 0x48);
    const auto keys = lookupOf({{2, keyOf(40)}});
    SegmentDocument seg{uidText(vault), {0x00, 0xff}, {}};
    const auto sid = uidOf(0x20, 0x20);
    const auto bytes = sealSegment(seg, vault, sid, {2, keyOf(40)});
    EXPECT_EQ(openSegment(bytes, vault, sid, keys), seg);
    const auto codeOf = [&](auto&& f) -> std::string {
        try {
            f();
        } catch (const vhf1::Error& e) {
            return std::string(vhf1::errorCodeName(e.code()));
        }
        return "accepted";
    };
    EXPECT_EQ(codeOf([&] { (void)openRoot(bytes, vault, keys); }), "kind_mismatch");
    EXPECT_EQ(codeOf([&] { (void)openSegment(bytes, vault, uidOf(0x20, 0x21), keys); }), "object_mismatch");
    EXPECT_EQ(codeOf([&] { (void)openSegment(bytes, uidOf(0x57, 0x48), sid, keys); }), "vault_mismatch");
    EXPECT_EQ(codeOf([&] { (void)openSegment(bytes, vault, sid, lookupOf({})); }), "key_unavailable");
}

// ── ManifestPartition ────────────────────────────────────────────────────────────────────────────────────────────

TEST(ManifestPartition, SplitsAboveTheLimitsAndMergesBelowWithinThem) {
    const PartitionLimits limits{8, 1u << 20, 2};
    const auto c = smallVault(30);
    const auto plan = partition(c.entries, {}, "v", limits);
    ASSERT_GT(plan.size(), 1u);
    int next = 0;
    std::size_t total = 0;
    for (const auto& p : plan) {
        EXPECT_EQ(p.doc.range.lo, next);
        next = p.doc.range.hi + 1;
        EXPECT_LE(p.doc.entries.size(), limits.split_entries);
        total += p.doc.entries.size();
        for (const auto& e : p.doc.entries) { EXPECT_TRUE(p.doc.range.contains(parseUid(e.uid, "x", "uid"))); }
    }
    EXPECT_EQ(next, 0x100);
    EXPECT_EQ(total, c.entries.size());

    // Shrunk to a few entries, the same ranges merge back (each merge stays within the split limits).
    const auto shrunk = smallVault(3);
    std::vector<Range> ranges;
    for (const auto& p : plan) ranges.push_back(p.doc.range);
    const auto merged = partition(shrunk.entries, ranges, "v", limits);
    EXPECT_LT(merged.size(), plan.size());
    for (const auto& p : merged) { EXPECT_LE(p.doc.entries.size(), limits.split_entries); }

    // Bytes count too: one big entry over the byte limit splits its range.
    const auto bytesPlan = partition(c.entries, {}, "v", PartitionLimits{100000, 2000, 1});
    EXPECT_GT(bytesPlan.size(), 1u);
    EXPECT_EQ(partition({}, {}, "v").size(), 1u) << "an empty vault is one empty segment";
}

TEST(ManifestDocument, SnapshotRecordsAreNamedByUidAndNoLongerByAServersId) {
    const Uid vault = uidOf(0x56, 0x48);
    SnapshotDocument doc{uidText(vault), richContent().snapshots[0]};
    const auto j = toJson(doc);
    EXPECT_TRUE(j["snapshot"].contains("uid"));
    EXPECT_FALSE(j["snapshot"].contains("id")) << "a per-server sequence is no identity across servers";
    EXPECT_EQ(snapshotFromJson(Json::parse(canonicalJson(j)), vault), doc);
    EXPECT_EQ(snapshotKey(doc.snapshot), doc.snapshot.uid);
}

TEST(ManifestContent, TwoServersSnapshotsWithOneLocalIdAreBothKept) {
    auto theirs = richContent(), ours = richContent();
    theirs.snapshots[0].uid = uidT(0x71, 0x01);
    ours.snapshots[0].uid = uidT(0x72, 0x02);
    Content before = theirs;   // the base of our pending changes: their snapshot not yet, ours not yet
    before.snapshots.clear();
    const auto both = mergePending(theirs, before, ours);
    EXPECT_EQ(both.snapshots.size(), 2u);
}


}
