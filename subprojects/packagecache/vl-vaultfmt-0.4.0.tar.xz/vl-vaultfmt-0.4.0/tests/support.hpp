// SPDX-License-Identifier: AGPL-3.0-or-later
// Copyright (c) 2026 Valkyrian Labs LLC
#pragma once

// What the suites share: hex <-> bytes and the golden vectors (vectors/vectors.json, VL_VAULTFMT_VECTORS_DIR).

#include <nlohmann/json.hpp>

#include <cstdint>
#include <filesystem>
#include <fstream>
#include <iterator>
#include <span>
#include <stdexcept>
#include <string>
#include <vector>

namespace vl::vaultfmt::test {

inline std::vector<uint8_t> fromHex(const std::string& hex) {
    if (hex.size() % 2 != 0) throw std::invalid_argument("odd hex length");
    std::vector<uint8_t> out(hex.size() / 2);
    for (std::size_t i = 0; i < out.size(); ++i) out[i] = static_cast<uint8_t>(std::stoul(hex.substr(2 * i, 2), nullptr, 16));
    return out;
}

inline std::string toHex(const std::span<const uint8_t> bytes) {
    static constexpr char kDigits[] = "0123456789abcdef";
    std::string out;
    out.reserve(bytes.size() * 2);
    for (const auto b : bytes) {
        out += kDigits[b >> 4];
        out += kDigits[b & 0xF];
    }
    return out;
}

inline const nlohmann::json& goldenVectors() {
    static const nlohmann::json doc = [] {
        const auto path = std::filesystem::path(VL_VAULTFMT_VECTORS_DIR) / "vectors.json";
        std::ifstream in(path);
        if (!in) throw std::runtime_error("missing golden vectors: " + path.string());
        return nlohmann::json::parse(in);
    }();
    return doc;
}

}
