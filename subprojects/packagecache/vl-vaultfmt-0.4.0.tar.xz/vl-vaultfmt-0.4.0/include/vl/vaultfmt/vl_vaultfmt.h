/* SPDX-License-Identifier: AGPL-3.0-or-later */
/* Copyright (c) 2026 Valkyrian Labs LLC */
#ifndef VL_VAULTFMT_H
#define VL_VAULTFMT_H

/*
 * vl-vaultfmt's C API: the vault format operations a consumer that can't use C++ needs first (Vaulthalla Desktop
 * through Swift, the portal's WebAssembly reader): sealing and opening VHF1 objects as streams, ranged reads, the
 * object keys of an opaque_v1 bucket, and reading a manifest root and its segments into a tree it can iterate. Plain
 * C11; every function is extern "C". The formats are specified in the C++ headers beside this one (vhf1/Format.hpp,
 * ObjectKeys.hpp, manifest/Document.hpp, manifest/Chain.hpp) and in vaulthalla-server design/encryption/; this API adds
 * no format. Not here yet: publishing, the chain walk over a version listing, blind rebuild and the engine session
 * (vaulthalla-server design/core/vault-format-library.md, work item 9).
 *
 * Status codes. Every function except those that return a value of their own (vl_vaultfmt_version,
 * vl_vaultfmt_status_name, vl_vaultfmt_classify_key, vl_vaultfmt_part_size, vl_vaultfmt_object_size,
 * vl_vaultfmt_root_object_count, vl_vaultfmt_tree_entry_count and the frees) returns a vl_vaultfmt_status. Values are
 * stable: never renumbered or reused, only added. Each block is a base plus the C++ enum's value (VHF1 errors 100 +
 * vhf1::ErrorCode, chain rules 300 + manifest::ChainError), so a C++ code is only ever appended, with its name here in
 * the same change. vl_vaultfmt_status_name gives each a stable lower-case name: the block's prefix and the error's
 * spelling in the golden vectors ("vhf1_chunk_auth_failed", "chain_rollback"). No C++ exception crosses this boundary;
 * an unexpected failure is VL_VAULTFMT_ERR_INTERNAL.
 *
 * Inputs. Pointers are borrowed for the duration of the call; the library keeps no reference to them unless a function
 * says so. Text is UTF-8 passed as pointer and length (no terminating NUL is read). A NULL pointer with length 0 is the
 * empty string or buffer; a required pointer that is NULL is VL_VAULTFMT_ERR_INVALID_ARGUMENT. Fixed-size arrays in
 * the signatures (uint8_t vault_uid[16]) must hold that many bytes.
 *
 * Outputs. Variable-length outputs are caller-provided buffers with the length in and out: `*out_len` is the capacity
 * on entry and the length written on VL_VAULTFMT_OK. When the capacity is too small nothing is written to the buffer,
 * `*out_len` is set to the length needed and the status is VL_VAULTFMT_ERR_BUFFER_TOO_SMALL (pass `out` NULL with
 * `*out_len` 0 to ask). Text outputs carry no terminating NUL. Streams leave through a sink callback instead.
 *
 * Sinks. A vl_vaultfmt_sink_fn receives bytes during the call that produces them and returns 0 to go on; any other
 * value stops the call with VL_VAULTFMT_ERR_CALLBACK_FAILED, and the handle that called it is then unusable (a sealer
 * can't resume a sealing: start a new one, which takes a fresh salt). The bytes are valid only during the callback.
 * An opener's sink receives plaintext only after the chunk that holds it authenticated; a chunk that fails is never
 * passed on. Plaintext handed to a sink is the caller's to wipe.
 *
 * Secrets. Vault keys exist only inside a vl_vaultfmt_keyring, in locked memory that is zeroed when the ring is freed;
 * the bytes a caller adds are copied during the call, and wiping the caller's copy stays the caller's job. No key, and
 * no derived key, is ever returned, logged or put in a status name.
 *
 * Ownership. Handles returned through an `out` pointer belong to the caller and are released with their own free
 * function; freeing NULL does nothing. On failure `*out` is set to NULL. Strings inside a vl_vaultfmt_entry or
 * vl_vaultfmt_object_ref are NUL-terminated, point into the handle they came from and live until it is freed.
 *
 * Thread safety. The library has no mutable global state. A keyring may be read by several threads at once (sealers,
 * openers and roots read it) but not while vl_vaultfmt_keyring_add runs. A sealer or opener is one stream: one thread
 * at a time. Roots and trees are immutable and may be read concurrently. Freeing a handle must not race with any other
 * use of it.
 */

#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

/* ---- Sizes and names --------------------------------------------------------------------------------------------- */

#define VL_VAULTFMT_UID_SIZE 16            /* a vault, object or segment uid's bytes */
#define VL_VAULTFMT_UID_TEXT_SIZE 26       /* its lower-case Crockford base32 text */
#define VL_VAULTFMT_KEY_SIZE 32            /* AES-256: a vault key */
#define VL_VAULTFMT_SALT_SIZE 32           /* a VHF1 generation (the header's salt) */
#define VL_VAULTFMT_SHA256_HEX_SIZE 64
#define VL_VAULTFMT_HEADER_SIZE 120        /* a VHF1 object's header: the first bytes of every object */
#define VL_VAULTFMT_TAG_SIZE 16            /* per chunk */
#define VL_VAULTFMT_CHUNK_LOG2 16          /* the chunk size writers use: 64 KiB */
#define VL_VAULTFMT_CONTENT_KEY_SIZE 28    /* o/<uid> */
#define VL_VAULTFMT_SEGMENT_KEY_SIZE 42    /* .vaulthalla/seg/<sid> */
#define VL_VAULTFMT_ROOT_KEY ".vaulthalla/root"
#define VL_VAULTFMT_LAYOUT_KEY ".vaulthalla/layout.json"

/* VHF1 object kinds (vhf1::Kind). */
#define VL_VAULTFMT_KIND_FILE_CONTENT 1
#define VL_VAULTFMT_KIND_MANIFEST_SEGMENT 2
#define VL_VAULTFMT_KIND_MANIFEST_ROOT 3

/* Object key classes (keys::KeyClass). */
#define VL_VAULTFMT_KEY_CONTENT 0
#define VL_VAULTFMT_KEY_METADATA 1
#define VL_VAULTFMT_KEY_FOREIGN 2

/* Manifest entry kinds (manifest::EntryKind). */
#define VL_VAULTFMT_ENTRY_DIR 0
#define VL_VAULTFMT_ENTRY_FILE 1
#define VL_VAULTFMT_ENTRY_SYMLINK 2
#define VL_VAULTFMT_ENTRY_TOMBSTONE 3

/* ---- Status codes ------------------------------------------------------------------------------------------------ */

typedef int32_t vl_vaultfmt_status;

enum {
    VL_VAULTFMT_OK = 0,
    VL_VAULTFMT_ERR_INVALID_ARGUMENT = 1, /* a NULL or ill-sized argument, or an input the writer refuses */
    VL_VAULTFMT_ERR_BUFFER_TOO_SMALL = 2, /* `*out_len` holds the length needed */
    VL_VAULTFMT_ERR_OUT_OF_MEMORY = 3,
    VL_VAULTFMT_ERR_INTERNAL = 4,         /* an unexpected failure (OpenSSL, the CSPRNG) */
    VL_VAULTFMT_ERR_CALLBACK_FAILED = 5,  /* a sink returned non-zero */
    VL_VAULTFMT_ERR_NOT_FOUND = 6,        /* no such entry, or not a key of that kind */
    VL_VAULTFMT_ERR_UNUSABLE = 7,         /* the handle is finished, or failed earlier (its failure is sticky) */

    /* VHF1 (vhf1/Format.hpp): 100 + vhf1::ErrorCode, in the reader's check order */
    VL_VAULTFMT_ERR_VHF1_BAD_MAGIC = 100,
    VL_VAULTFMT_ERR_VHF1_UNSUPPORTED_VERSION = 101,
    VL_VAULTFMT_ERR_VHF1_BAD_HEADER_LENGTH = 102,
    VL_VAULTFMT_ERR_VHF1_UNSUPPORTED_SUITE = 103,
    VL_VAULTFMT_ERR_VHF1_BAD_CHUNK_SIZE = 104,
    VL_VAULTFMT_ERR_VHF1_RESERVED_NONZERO = 105,
    VL_VAULTFMT_ERR_VHF1_KIND_MISMATCH = 106,
    VL_VAULTFMT_ERR_VHF1_VAULT_MISMATCH = 107,
    VL_VAULTFMT_ERR_VHF1_OBJECT_MISMATCH = 108,
    VL_VAULTFMT_ERR_VHF1_GENERATION_MISMATCH = 109,
    VL_VAULTFMT_ERR_VHF1_KEY_UNAVAILABLE = 110,
    VL_VAULTFMT_ERR_VHF1_HEADER_AUTH_FAILED = 111,
    VL_VAULTFMT_ERR_VHF1_SIZE_UNKNOWN = 112,
    VL_VAULTFMT_ERR_VHF1_SIZE_MISMATCH = 113,
    VL_VAULTFMT_ERR_VHF1_BAD_SIZE = 114,
    VL_VAULTFMT_ERR_VHF1_RANGE_OUT_OF_BOUNDS = 115,
    VL_VAULTFMT_ERR_VHF1_CHUNK_AUTH_FAILED = 116,

    /* Manifest documents (manifest/Document.hpp FormatError): an authentic object that is not the document expected */
    VL_VAULTFMT_ERR_MANIFEST_BAD_ROOT = 200,
    VL_VAULTFMT_ERR_MANIFEST_BAD_SEGMENT = 201,
    VL_VAULTFMT_ERR_MANIFEST_BAD_SNAPSHOT = 202,

    /* The reader's chain rules (manifest/Chain.hpp): 300 + manifest::ChainError */
    VL_VAULTFMT_ERR_CHAIN_BAD_ROOT = 300,
    VL_VAULTFMT_ERR_CHAIN_ROLLBACK = 301,
    VL_VAULTFMT_ERR_CHAIN_FORK = 302,
    VL_VAULTFMT_ERR_CHAIN_SEGMENT_MISSING = 303,
    VL_VAULTFMT_ERR_CHAIN_SEGMENT_MISMATCH = 304,
    VL_VAULTFMT_ERR_CHAIN_ORDER_VIOLATION = 305,
    VL_VAULTFMT_ERR_CHAIN_SUPERSEDED = 306,
    VL_VAULTFMT_ERR_CHAIN_PUBLISH_MODE_MISMATCH = 307
};

/* The library version ("0.1.0"), a static NUL-terminated string. */
const char* vl_vaultfmt_version(void);

/* The status's stable name ("ok", "vhf1_chunk_auth_failed"), a static NUL-terminated string; "unknown" for a value
   this version doesn't define. */
const char* vl_vaultfmt_status_name(vl_vaultfmt_status status);

/* Receives streamed bytes (sealed object bytes, or authenticated plaintext). Returns 0 to go on. */
typedef int32_t (*vl_vaultfmt_sink_fn)(void* ctx, const uint8_t* bytes, size_t len);

/* ---- Vault keys -------------------------------------------------------------------------------------------------- */

typedef struct vl_vaultfmt_keyring vl_vaultfmt_keyring;

vl_vaultfmt_status vl_vaultfmt_keyring_new(vl_vaultfmt_keyring** out);

/* Adds (or replaces) the vault key of `key_version` (>= 1); `key_len` must be VL_VAULTFMT_KEY_SIZE. The bytes are
   copied into locked memory. A sealer or opener made before keeps the key it was made with. */
vl_vaultfmt_status vl_vaultfmt_keyring_add(vl_vaultfmt_keyring* ring, uint32_t key_version, const uint8_t* key,
                                           size_t key_len);

/* Zeroes every key the ring alone holds and frees it. */
void vl_vaultfmt_keyring_free(vl_vaultfmt_keyring* ring);

/* ---- Object keys (ObjectKeys.hpp) -------------------------------------------------------------------------------- */

/* o/<uid> (VL_VAULTFMT_CONTENT_KEY_SIZE characters). */
vl_vaultfmt_status vl_vaultfmt_content_key(const uint8_t uid[16], char* out, size_t* out_len);

/* The uid of an o/<uid> key (strict base32; a leading '/' is accepted); VL_VAULTFMT_ERR_NOT_FOUND for any other key. */
vl_vaultfmt_status vl_vaultfmt_content_key_uid(const char* key, size_t key_len, uint8_t uid[16]);

/* .vaulthalla/seg/<sid> (VL_VAULTFMT_SEGMENT_KEY_SIZE characters). */
vl_vaultfmt_status vl_vaultfmt_segment_key(const uint8_t sid[16], char* out, size_t* out_len);

/* VL_VAULTFMT_KEY_CONTENT, _METADATA or _FOREIGN (anything an opaque_v1 bucket must not hold); _FOREIGN for NULL. */
int32_t vl_vaultfmt_classify_key(const char* key, size_t key_len);

/* The multipart part size for an object of `object_size` bytes: max(5 MiB, ceil(size / 10,000)) in whole MiB. */
uint64_t vl_vaultfmt_part_size(uint64_t object_size);

/* ---- VHF1: sealing (vhf1/Writer.hpp) ----------------------------------------------------------------------------- */

/* The sealed size of `plaintext_size` bytes at chunk size 2^chunk_log2 (VL_VAULTFMT_CHUNK_LOG2); 0 when it would not
   fit in 64 bits or chunk_log2 is outside 10..22. */
uint64_t vl_vaultfmt_object_size(uint64_t plaintext_size, uint8_t chunk_log2);

typedef struct vl_vaultfmt_sealer vl_vaultfmt_sealer;

/* Starts sealing a file's content (kind 1) for o/<object_uid> under the vault key `key_version` of `ring`, with a
   fresh salt from OpenSSL's CSPRNG and 64 KiB chunks. The header reaches `sink` during this call; the output is byte
   for byte what a one-shot sealing of the same plaintext gives, whatever the split. VL_VAULTFMT_ERR_VHF1_KEY_UNAVAILABLE
   when the ring has no such key. `sink` and `ctx` are kept until the sealer is freed. */
vl_vaultfmt_status vl_vaultfmt_sealer_new(const vl_vaultfmt_keyring* ring, uint32_t key_version,
                                          const uint8_t vault_uid[16], const uint8_t object_uid[16],
                                          vl_vaultfmt_sink_fn sink, void* ctx, vl_vaultfmt_sealer** out);

/* Seals more plaintext; full chunks reach the sink, the last one is held back until more arrives or finish. */
vl_vaultfmt_status vl_vaultfmt_sealer_write(vl_vaultfmt_sealer* sealer, const uint8_t* plaintext, size_t len);

/* Seals the final chunk. `object_size` (may be NULL) receives the bytes given to the sink in all. */
vl_vaultfmt_status vl_vaultfmt_sealer_finish(vl_vaultfmt_sealer* sealer, uint64_t* object_size);

/* The sealing's generation (its salt), which a manifest entry records as hex. */
vl_vaultfmt_status vl_vaultfmt_sealer_generation(const vl_vaultfmt_sealer* sealer, uint8_t salt[32]);

/* Wipes the held-back plaintext and frees the sealer. */
void vl_vaultfmt_sealer_free(vl_vaultfmt_sealer* sealer);

/* ---- VHF1: opening (vhf1/Reader.hpp) ----------------------------------------------------------------------------- */

typedef struct vl_vaultfmt_expectation {
    int32_t kind;                 /* VL_VAULTFMT_KIND_* */
    const uint8_t* vault_uid;     /* 16 bytes, required */
    const uint8_t* object_uid;    /* 16 bytes, or NULL when not held (then `generation` is required) */
    const uint8_t* generation;    /* 32 bytes (the salt the caller expects), or NULL */
} vl_vaultfmt_expectation;

typedef struct vl_vaultfmt_header_info {
    int32_t kind;
    uint32_t key_version;
    uint8_t vault_uid[16];
    uint8_t object_uid[16];
    uint8_t salt[32];
    uint8_t chunk_log2;
    uint64_t plaintext_size;      /* from the object size the opener was given */
    uint64_t chunk_count;
} vl_vaultfmt_header_info;

typedef struct vl_vaultfmt_opener vl_vaultfmt_opener;

/* Authenticates the header (`header` holds at least the object's first VL_VAULTFMT_HEADER_SIZE bytes; only those are
   read) against `expect` and a key of `ring`, for an object of `object_size` bytes (from authenticated metadata, or
   the provider's size for a whole read). Statuses: the vhf1_* checks of the header, in the reader's order, and
   vhf1_bad_size when `object_size` has no layout. */
vl_vaultfmt_status vl_vaultfmt_opener_new(const uint8_t* header, size_t header_len,
                                          const vl_vaultfmt_expectation* expect, const vl_vaultfmt_keyring* ring,
                                          uint64_t object_size, vl_vaultfmt_opener** out);

vl_vaultfmt_status vl_vaultfmt_opener_info(const vl_vaultfmt_opener* opener, vl_vaultfmt_header_info* out);

/* Streams the object's bytes after the header, in order and in any split; each chunk's plaintext reaches `sink` once
   its tag verified. VL_VAULTFMT_ERR_VHF1_CHUNK_AUTH_FAILED or _SIZE_MISMATCH (more bytes than the object) stop it for
   good. */
vl_vaultfmt_status vl_vaultfmt_opener_update(vl_vaultfmt_opener* opener, const uint8_t* sealed, size_t len,
                                             vl_vaultfmt_sink_fn sink, void* ctx);

/* VL_VAULTFMT_OK only when the whole object arrived and authenticated: until then the plaintext passed on is authentic
   but possibly truncated. VL_VAULTFMT_ERR_VHF1_SIZE_MISMATCH when the stream ended early. */
vl_vaultfmt_status vl_vaultfmt_opener_finish(vl_vaultfmt_opener* opener);

/* The object bytes [offset, offset + length) a ranged read of plaintext [start, end) needs (one ranged GET); both 0
   for an empty range. VL_VAULTFMT_ERR_VHF1_RANGE_OUT_OF_BOUNDS unless start <= end <= the plaintext size. */
vl_vaultfmt_status vl_vaultfmt_range_plan(const vl_vaultfmt_opener* opener, uint64_t start, uint64_t end,
                                          uint64_t* offset, uint64_t* length);

/* Reads plaintext [start, end) from `window` (exactly the bytes vl_vaultfmt_range_plan named), authenticating each
   covering chunk whole before any byte of it reaches `sink` (one call with the whole range). `provider_size` is the
   object size the provider reports (the Content-Range total); it must equal the opener's size
   (VL_VAULTFMT_ERR_VHF1_SIZE_MISMATCH), so a truncated object can't pass for a short file. A chunk that fails
   authentication is sticky for ranged reads of this opener. Independent of update and finish. */
vl_vaultfmt_status vl_vaultfmt_range_read(vl_vaultfmt_opener* opener, uint64_t start, uint64_t end,
                                          uint64_t provider_size, const uint8_t* window, size_t window_len,
                                          vl_vaultfmt_sink_fn sink, void* ctx);

/* Wipes the opener's scratch plaintext and its derived key, and frees it. */
void vl_vaultfmt_opener_free(vl_vaultfmt_opener* opener);

/* ---- Manifest: a root and the objects it pins (manifest/Objects.hpp, Chain.hpp) ---------------------------------- */

typedef struct vl_vaultfmt_known {
    uint64_t epoch;
    const char* root_sha256;      /* VL_VAULTFMT_SHA256_HEX_SIZE lower-case hex characters */
} vl_vaultfmt_known;

typedef struct vl_vaultfmt_root_info {
    uint64_t epoch;
    char root_sha256[65];         /* hex of the root object's SHA-256, NUL-terminated: with `epoch`, the next known */
    int32_t gap;                  /* 1: newer than `known` by more than one epoch, and no chain was walked to it */
    int32_t version_log;          /* 1: the root names the version_log publish mode */
    uint64_t files;               /* the root's stats */
    uint64_t dirs;
    uint64_t bytes;
} vl_vaultfmt_root_info;

typedef struct vl_vaultfmt_object_ref {
    const char* sid;              /* VL_VAULTFMT_UID_TEXT_SIZE characters */
    const char* key;              /* .vaulthalla/seg/<sid> */
    const char* object_sha256;    /* VL_VAULTFMT_SHA256_HEX_SIZE characters: the pin */
    uint64_t size;                /* the pinned object size */
    int32_t snapshot;             /* 1: a snapshot segment; 0: a segment of the tree */
    uint8_t range_lo;             /* a tree segment's uid range (first uid byte, inclusive) */
    uint8_t range_hi;
} vl_vaultfmt_object_ref;

typedef struct vl_vaultfmt_root vl_vaultfmt_root;

/* Authenticates the root object (kind 3, object uid = vault uid, a key of `ring`), parses it and applies the chain
   rules against `known` (NULL: nothing known, accepted as is). Statuses: vhf1_*, manifest_bad_root, chain_rollback,
   chain_fork. A root newer than `known` by more than one epoch is accepted with `gap` set: this call has no retained
   roots to walk. The ring is read only during the call. */
vl_vaultfmt_status vl_vaultfmt_root_open(const uint8_t* object, size_t object_len, const uint8_t vault_uid[16],
                                         const vl_vaultfmt_keyring* ring, const vl_vaultfmt_known* known,
                                         vl_vaultfmt_root** out);

vl_vaultfmt_status vl_vaultfmt_root_info_get(const vl_vaultfmt_root* root, vl_vaultfmt_root_info* out);

/* The objects the root pins: its tree segments in range order, then its snapshot segments. Fetch each by its key. */
size_t vl_vaultfmt_root_object_count(const vl_vaultfmt_root* root);
vl_vaultfmt_status vl_vaultfmt_root_object(const vl_vaultfmt_root* root, size_t index, vl_vaultfmt_object_ref* out);

void vl_vaultfmt_root_free(vl_vaultfmt_root* root);

/* ---- Manifest: the tree (manifest/Content.hpp) ------------------------------------------------------------------- */

typedef struct vl_vaultfmt_object_bytes {
    const char* sid;              /* VL_VAULTFMT_UID_TEXT_SIZE characters */
    const uint8_t* bytes;
    size_t len;
} vl_vaultfmt_object_bytes;

typedef struct vl_vaultfmt_entry {
    const char* uid;              /* VL_VAULTFMT_UID_TEXT_SIZE characters */
    int32_t kind;                 /* VL_VAULTFMT_ENTRY_* */
    const char* parent;           /* uid text, or NULL for the vault root (and tombstones without one) */
    const char* name;             /* "" for the vault root; `name_len` bytes before the NUL */
    size_t name_len;
    int32_t trashed;              /* 1: in the vault trash */
    int32_t has_size;
    uint64_t size;                /* plaintext bytes (files) */
    uint32_t mode;                /* 0 when the entry carries none */
    uint32_t key_version;         /* 0 when none: the key the current object is sealed under */
    const char* mtime;            /* ISO 8601 UTC, or NULL */
    const char* generation;       /* hex salt of the current object, or NULL */
    const char* target;           /* a symlink's target, or NULL */
    int32_t has_object;
    uint64_t object_size;         /* sealed bytes of o/<uid> */
    const char* version_id;       /* its provider version, or NULL */
} vl_vaultfmt_entry;

typedef struct vl_vaultfmt_tree vl_vaultfmt_tree;

/* Opens every object `root` pins from `objects` (any order; extra ones are ignored) and builds the vault's content:
   each must be present (chain_segment_missing), match its pinned SHA-256 and size (chain_segment_mismatch) and
   authenticate (vhf1_*, manifest_bad_segment, manifest_bad_snapshot). The ring is read only during the call. */
vl_vaultfmt_status vl_vaultfmt_tree_build(const vl_vaultfmt_root* root, const vl_vaultfmt_object_bytes* objects,
                                          size_t count, const vl_vaultfmt_keyring* ring, vl_vaultfmt_tree** out);

/* Entries are in uid order. */
size_t vl_vaultfmt_tree_entry_count(const vl_vaultfmt_tree* tree);
vl_vaultfmt_status vl_vaultfmt_tree_entry(const vl_vaultfmt_tree* tree, size_t index, vl_vaultfmt_entry* out);

/* The index of the entry with `uid` (base32 text); VL_VAULTFMT_ERR_NOT_FOUND when there is none. */
vl_vaultfmt_status vl_vaultfmt_tree_find(const vl_vaultfmt_tree* tree, const char* uid, size_t uid_len, size_t* index);

/* The indexes of the entries whose parent is `parent` (uid text), in uid order, into `out` (`*out_len` entries in and
   out; the buffer convention counts entries, not bytes). */
vl_vaultfmt_status vl_vaultfmt_tree_children(const vl_vaultfmt_tree* tree, const char* parent, size_t parent_len,
                                             size_t* out, size_t* out_len);

/* The entries as the manifest's own JSON: an array of segment entries in uid order, canonical member order. */
vl_vaultfmt_status vl_vaultfmt_tree_json(const vl_vaultfmt_tree* tree, char* out, size_t* out_len);

void vl_vaultfmt_tree_free(vl_vaultfmt_tree* tree);

/* ---- The reader (src/c_api_reader.cpp): what the portal's WebAssembly build exports --------------------------------
 *
 * Read only, and only over bytes the caller fetched: nothing here performs I/O, blocks, seals, publishes or deletes.
 * A page lists the versions of .vaulthalla/root, chooses the canonical head with vl_vaultfmt_head_* (rule C1 of
 * vaulthalla-server design/encryption/06-publish-without-preconditions.md §5.1, from the anchor it holds or from none),
 * fetches the objects the head pins (vl_vaultfmt_root_object), builds the tree (vl_vaultfmt_tree_build), lists and
 * stats entries as JSON, and reads a file's object through vl_vaultfmt_tree_open_content and the ranged reads above.
 * Vault keys reach the keyring by unwrapping KEV1 envelopes (vl-keykit) with the account key, never as bytes.
 * Limits: VL_VAULTFMT_READER_MAX_* below; past them, VL_VAULTFMT_ERR_READER_LIMIT. Status blocks: 400 + vl-keykit's
 * kev1::ErrorCode, 450-452 recovery seed text, 500-503 the reader.
 */

enum {
    /* KEV1 envelopes (vl-keykit kev1.hpp): 400 + kev1::ErrorCode, in the reader's check order */
    VL_VAULTFMT_ERR_KEV1_BAD_MAGIC = 400,
    VL_VAULTFMT_ERR_KEV1_UNSUPPORTED_VERSION = 401,
    VL_VAULTFMT_ERR_KEV1_UNSUPPORTED_SUITE = 402,
    VL_VAULTFMT_ERR_KEV1_BAD_PURPOSE = 403,
    VL_VAULTFMT_ERR_KEV1_UNSUPPORTED_RECIPIENT_CLASS = 404,
    VL_VAULTFMT_ERR_KEV1_RESERVED_NONZERO = 405,
    VL_VAULTFMT_ERR_KEV1_VAULT_MISMATCH = 406,
    VL_VAULTFMT_ERR_KEV1_RECIPIENT_MISMATCH = 407, /* addressed to another recipient: try the next envelope */
    VL_VAULTFMT_ERR_KEV1_BAD_LENGTH = 408,
    VL_VAULTFMT_ERR_KEV1_BAD_EPHEMERAL = 409,
    VL_VAULTFMT_ERR_KEV1_WRAP_AUTH_FAILED = 410,
    VL_VAULTFMT_ERR_KEV1_BAD_KEY_VERSION = 411,

    /* Recovery seed text (vl-keykit seed.hpp SeedError) */
    VL_VAULTFMT_ERR_SEED_BAD_LENGTH = 450,
    VL_VAULTFMT_ERR_SEED_BAD_SYMBOL = 451,
    VL_VAULTFMT_ERR_SEED_BAD_CHECK = 452,

    /* The reader */
    VL_VAULTFMT_ERR_READER_NEED_OBJECTS = 500,   /* supply what vl_vaultfmt_head_needed names, then decide again */
    VL_VAULTFMT_ERR_READER_NO_USABLE_ROOT = 501, /* no version of the root authenticates (or the listing is empty) */
    VL_VAULTFMT_ERR_READER_LIMIT = 502,          /* an input past a VL_VAULTFMT_READER_MAX_* limit */
    VL_VAULTFMT_ERR_READER_BAD_LISTING = 503     /* the listing is not the JSON described at vl_vaultfmt_head_new */
};

#define VL_VAULTFMT_READER_MAX_LISTING_BYTES (8u << 20)    /* the listing's JSON text */
#define VL_VAULTFMT_READER_MAX_VERSIONS 10000u             /* versions in a listing (delete markers included) */
#define VL_VAULTFMT_READER_MAX_VERSION_ID 1024u            /* bytes of one version id */
#define VL_VAULTFMT_READER_MAX_ROOT_BYTES (16u << 20)      /* one root version's object */
#define VL_VAULTFMT_READER_MAX_SUPPLIED_BYTES (256u << 20) /* all root versions supplied to one head */
#define VL_VAULTFMT_READER_MAX_BUFFER_BYTES (1u << 30)     /* one vl_vaultfmt_buffer */

/* KEV1 suites (vl-keykit kev1::Suite). */
#define VL_VAULTFMT_KEV1_SUITE_X25519 1     /* recovery recipients: the account key */
#define VL_VAULTFMT_KEV1_SUITE_P256 2       /* device grants */

/* -- Plaintext buffers: a sink that keeps what it receives in library memory, zeroed when cleared or freed. In the
   WebAssembly build a page passes vl_vaultfmt_buffer_sink_fn() and the buffer as the sink of any call above, then
   reads the bytes in place (no callback into JavaScript). */

typedef struct vl_vaultfmt_buffer vl_vaultfmt_buffer;

vl_vaultfmt_status vl_vaultfmt_buffer_new(vl_vaultfmt_buffer** out);
/* A vl_vaultfmt_sink_fn whose ctx is a vl_vaultfmt_buffer: appends; refuses (non-zero) past
   VL_VAULTFMT_READER_MAX_BUFFER_BYTES or when out of memory. */
int32_t vl_vaultfmt_buffer_sink(void* buffer, const uint8_t* bytes, size_t len);
/* &vl_vaultfmt_buffer_sink, for callers (WebAssembly) that need its function pointer as a value. */
vl_vaultfmt_sink_fn vl_vaultfmt_buffer_sink_fn(void);
/* The bytes held (valid until the next append, clear or free); NULL when empty. */
const uint8_t* vl_vaultfmt_buffer_data(const vl_vaultfmt_buffer* buffer);
size_t vl_vaultfmt_buffer_size(const vl_vaultfmt_buffer* buffer);
/* Zeroes and empties it. */
void vl_vaultfmt_buffer_clear(vl_vaultfmt_buffer* buffer);
void vl_vaultfmt_buffer_free(vl_vaultfmt_buffer* buffer);

/* -- KEV1: vault keys from envelopes (.vaulthalla/key/<kid>), unwrapped with a recipient key held in a handle */

typedef struct vl_vaultfmt_recipient vl_vaultfmt_recipient;

/* The account recovery key from its text (the recovery seed: 27 base32 symbols, spaces and '-' ignored, any case):
   its X25519 key, suite 1. Statuses: seed_bad_length, seed_bad_symbol, seed_bad_check. */
vl_vaultfmt_status vl_vaultfmt_recipient_from_seed(const char* text, size_t text_len, vl_vaultfmt_recipient** out);
/* A recipient from its raw secret key: suite 1 an X25519 key (32 bytes), suite 2 a P-256 scalar (32 bytes). */
vl_vaultfmt_status vl_vaultfmt_recipient_from_secret(int32_t suite, const uint8_t* secret, size_t secret_len,
                                                     vl_vaultfmt_recipient** out);
/* SHA-256 of the recipient's public key: the envelope's recipient_id and a root grant's. */
vl_vaultfmt_status vl_vaultfmt_recipient_id(const vl_vaultfmt_recipient* recipient, uint8_t out[32]);
/* Zeroes the secret key and frees the handle. */
void vl_vaultfmt_recipient_free(vl_vaultfmt_recipient* recipient);

/* Unwraps `envelope` (addressed to `recipient`, for `vault_uid`) and adds the vault key to `ring` under the envelope's
   key version, which `*key_version` (may be NULL) receives. The key never leaves the library. Statuses: kev1_* in the
   reader's order (kev1_recipient_mismatch: another recipient's envelope, try the next). */
vl_vaultfmt_status vl_vaultfmt_keyring_add_envelope(vl_vaultfmt_keyring* ring, const vl_vaultfmt_recipient* recipient,
                                                    const uint8_t vault_uid[16], const uint8_t* envelope,
                                                    size_t envelope_len, uint32_t* key_version);

/* -- The canonical head over a version listing of .vaulthalla/root (rule C1) */

typedef struct vl_vaultfmt_anchor {
    uint64_t epoch;
    const char* root_sha256;      /* VL_VAULTFMT_SHA256_HEX_SIZE lower-case hex characters */
    const char* version_id;       /* NUL-terminated provider version id of that root, or NULL */
} vl_vaultfmt_anchor;

typedef struct vl_vaultfmt_head vl_vaultfmt_head;

/* Starts choosing the head of `vault_uid`'s root from `listing`, a JSON array of the root key's provider versions,
   newest first, as ListObjectVersions returns them (every page, concatenated):
     [{"version_id": "...", "delete_marker": false, "is_latest": true, "size": 123, "etag": "\"...\""}, ...]
   Only "version_id" is required; "key", when present, must be ".vaulthalla/root"; other members are ignored.
   `anchor` is what the caller knows (the last head it accepted, or a customer checkpoint), or NULL. No key is needed
   yet. Statuses: reader_bad_listing (not that JSON, or a duplicate id), reader_limit. */
vl_vaultfmt_status vl_vaultfmt_head_new(const uint8_t vault_uid[16], const char* listing, size_t listing_len,
                                        const vl_vaultfmt_anchor* anchor, vl_vaultfmt_head** out);

/* The version ids whose bytes the decision needs and that were neither supplied nor reported gone, as a JSON array of
   strings, newest first: GET .vaulthalla/root?versionId=<id> for each (in parallel), then supply them. Before the
   first decide: every version from the anchor's on (every version without an anchor, or when the anchor's id is not
   listed); after a decide that returned reader_need_objects: every version. Buffer convention. */
vl_vaultfmt_status vl_vaultfmt_head_needed(const vl_vaultfmt_head* head, char* out, size_t* out_len);

/* The bytes of one version (copied). Statuses: not_found (no such id in the listing, or a delete marker),
   reader_limit (VL_VAULTFMT_READER_MAX_ROOT_BYTES, _SUPPLIED_BYTES). */
vl_vaultfmt_status vl_vaultfmt_head_supply(vl_vaultfmt_head* head, const char* version_id, size_t version_id_len,
                                           const uint8_t* bytes, size_t len);
/* That version is gone (its GET answered 404 after the listing): the decision skips it. */
vl_vaultfmt_status vl_vaultfmt_head_gone(vl_vaultfmt_head* head, const char* version_id, size_t version_id_len);

/* Applies C1 over the supplied versions with the keys of `ring` (a version that doesn't authenticate as this vault's
   root under these keys is skipped, as the rule says), then the chain rules against the anchor. Statuses:
   reader_need_objects (supply what vl_vaultfmt_head_needed now names, and decide again), reader_no_usable_root,
   chain_rollback (the head is older than the anchor: a stale root), chain_fork. Once decided, the head is final and
   later calls return VL_VAULTFMT_OK. */
vl_vaultfmt_status vl_vaultfmt_head_decide(vl_vaultfmt_head* head, const vl_vaultfmt_keyring* ring);

/* The decision as JSON (after an OK decide; VL_VAULTFMT_ERR_UNUSABLE before):
     {"anchor": {"epoch": 7, "root_sha256": "...", "version_id": "..."}, "base_version_id": "..." | null,
      "epoch": 7, "freshness": "verified" | "unverified", "gap": false, "root_sha256": "...", "strays": ["..."],
      "version_id": "..."}
   "anchor": what to keep for the next read. "gap": newer than the anchor by more than one epoch with no chain from it
   in the listing (accepted with this warning, as the server does). "freshness": "verified" when an anchor was given
   (the head is it or newer, never older or a fork of it); "unverified" without one: the head is the newest state in
   this listing, but a bucket that dropped or hid newer versions, or replays an old root, can't be told apart from an
   honest one. "strays": non-canonical versions newer than the head, ignored. */
vl_vaultfmt_status vl_vaultfmt_head_json(const vl_vaultfmt_head* head, char* out, size_t* out_len);

/* The head as a root handle (vl_vaultfmt_root_object, vl_vaultfmt_tree_build). The chain rules were applied by decide,
   so its vl_vaultfmt_root_info has gap 0: the head's own "gap" is in vl_vaultfmt_head_json. */
vl_vaultfmt_status vl_vaultfmt_head_root(const vl_vaultfmt_head* head, const vl_vaultfmt_keyring* ring,
                                         vl_vaultfmt_root** out);

void vl_vaultfmt_head_free(vl_vaultfmt_head* head);

/* -- The tree as JSON, and a file's content */

/* The entries whose parent is `parent` (uid text; NULL with length 0: the entries without one, i.e. the vault root),
   as a JSON array of the manifest's entry objects in uid order. */
vl_vaultfmt_status vl_vaultfmt_tree_list_json(const vl_vaultfmt_tree* tree, const char* parent, size_t parent_len,
                                              char* out, size_t* out_len);
/* One entry as the manifest's JSON; not_found when there is none. */
vl_vaultfmt_status vl_vaultfmt_tree_stat_json(const vl_vaultfmt_tree* tree, const char* uid, size_t uid_len, char* out,
                                              size_t* out_len);

/* Opens the header of the object o/<uid> holds for that file, bound to what the tree says: kind 1, `vault_uid`, the
   entry's uid and generation, and its sealed size (the entry's object size, or the version's). `version_id` NULL with
   length 0 is the current object; otherwise one of the entry's `versions`. The header is the first
   VL_VAULTFMT_HEADER_SIZE bytes of that object (a ranged GET); the rest is read through vl_vaultfmt_range_plan and
   vl_vaultfmt_range_read. An object of another file, vault or generation is refused (vhf1_*). not_found: no such
   entry or version, or no object, generation or size recorded for it. */
vl_vaultfmt_status vl_vaultfmt_tree_open_content(const vl_vaultfmt_tree* tree, const uint8_t vault_uid[16],
                                                 const char* uid, size_t uid_len, const char* version_id,
                                                 size_t version_id_len, const uint8_t* header, size_t header_len,
                                                 const vl_vaultfmt_keyring* ring, vl_vaultfmt_opener** out);

#ifdef __cplusplus
}
#endif

#endif
