// SPDX-License-Identifier: AGPL-3.0-or-later
// Copyright (c) 2026 Valkyrian Labs LLC
#pragma once

// An in-memory versioned bucket and the manifest ObjectStore over it: what the manifest's own tests need from a
// provider, with no HTTP, no XML and nothing of the server (it includes the Store seam, OpenSSL for MD5 ETags and the
// standard library; tools/contracts/test_format_library_contract.py). It answers as the versioned fake bucket
// (versioned_bucket.hpp) does behind storage::s3::ManifestStore, so a suite can run on either:
//
//   - versions per key, listed newest first; a DELETE adds a delete marker, a DELETE by version id removes exactly
//     that version (never adds a marker); a GET of a marker by id, or of a key whose newest version is one, finds
//     nothing;
//   - ETags are the quoted MD5 of the body, as S3 answers a single PUT;
//   - conditional PUTs are evaluated (412: PreconditionFailed), refused unevaluated as Backblaze B2 does
//     (ConditionsUnsupported, nothing written) or ignored;
//   - the bucket's clock is the test's: every write stamps `now` and, with autoTick, advances it by a second;
//   - the provider assumptions of design/encryption/06-publish-without-preconditions.md §4 can be broken on purpose:
//     listingLag (A3) and orderBy(Start) with holdPut (A4);
//   - provider(Provider::Backblaze) is Backblaze B2 as measured live on 2026-11-16 (misc/s3_version_checks.py in
//     vaulthalla-server): conditional PUTs refused (501, nothing written) and a key's versions ordered by when their
//     upload *started* (A4 false). A version is listed only once its upload completed (A3 held: 2,000 of 2,000
//     trials), and once listed it keeps its place; an upload that started earlier and completes later is inserted
//     below versions already listed. Every suite that runs version_log uses it;
//   - a lost reply: loseNextPut(key) makes the next plain PUT of that key start (its place in the order is taken)
//     and throw PutOutcomeUnknown without committing; land(key) commits it later, as a provider that received the
//     whole body and stalled does. Under Order::Start it lands at its start, below everything written since.
//
// MemoryBucket is the provider's state (thread-safe); MemoryStore is one client of it with its bucket mode.

#include "vl/vaultfmt/manifest/Store.hpp"

#include <openssl/evp.h>

#include <algorithm>
#include <array>
#include <cstdint>
#include <ctime>
#include <format>
#include <map>
#include <memory>
#include <mutex>
#include <optional>
#include <stdexcept>
#include <string>
#include <thread>
#include <utility>
#include <vector>

namespace vl::vaultfmt::test_support {

class MemoryBucket {
public:
    struct Version {
        std::string version_id;
        std::vector<uint8_t> body;
        std::string etag;   // quoted; empty for a delete marker
        std::time_t last_modified{};
        bool delete_marker{};
        uint64_t started{};   // when its upload started (the bucket's request sequence); Order::Start sorts by it
    };

    enum class ConditionalPuts { Supported, Reject, Ignore };
    enum class Order { Commit, Start };
    enum class Provider { Aws, Backblaze };

    // false: an unversioned bucket (one version "null" per key, a DELETE removes the key).
    explicit MemoryBucket(const bool versioned = true) : versioned_(versioned) {}

    // ---- the provider's behaviour --------------------------------------------------------------------------------------

    void conditionalPuts(const ConditionalPuts how) {
        std::scoped_lock lock(mutex_);
        conditional_ = how;
    }
    // A provider's measured behaviour in one call. Aws: conditional writes evaluated, versions in commit order.
    // Backblaze (live, 2026-11-16): conditional writes refused with 501, versions ordered by upload start.
    void provider(const Provider p) {
        std::scoped_lock lock(mutex_);
        conditional_ = p == Provider::Backblaze ? ConditionalPuts::Reject : ConditionalPuts::Supported;
        order_ = p == Provider::Backblaze ? Order::Start : Order::Commit;
    }
    void autoTick(const bool on) {
        std::scoped_lock lock(mutex_);
        autoTick_ = on;
    }
    void setNow(const std::time_t now) {
        std::scoped_lock lock(mutex_);
        now_ = now;
    }
    void advance(const std::time_t seconds) {
        std::scoped_lock lock(mutex_);
        now_ += seconds;
    }
    [[nodiscard]] std::time_t now() const {
        std::scoped_lock lock(mutex_);
        return now_;
    }
    // Version listings omit versions written less than `seconds` ago (bucket clock): breaks A3.
    void listingLag(const std::time_t seconds) {
        std::scoped_lock lock(mutex_);
        listingLag_ = seconds;
    }
    // orderBy(Start) + holdPut(key): the next PUT of `key` from this thread is ordered as if it had started now
    // although it commits later: its version is inserted below every version of that key written in between (by
    // other threads). Breaks A4.
    void orderBy(const Order order) {
        std::scoped_lock lock(mutex_);
        order_ = order;
    }
    void holdPut(const std::string& key) {
        std::scoped_lock lock(mutex_);
        heldAt_[{key, std::this_thread::get_id()}] = ++seq_;
    }
    // The next plain PUT of `key` (any thread) starts and loses its reply: PutOutcomeUnknown, nothing listed yet.
    void loseNextPut(const std::string& key) {
        std::scoped_lock lock(mutex_);
        ++loseNext_[key];
    }
    // How many lost PUTs of `key` have not landed.
    [[nodiscard]] std::size_t inFlight(const std::string& key) const {
        std::scoped_lock lock(mutex_);
        const auto it = inFlight_.find(key);
        return it == inFlight_.end() ? 0 : it->second.size();
    }
    // The oldest lost PUT of `key` commits now (stamped now), ordered by its start under Order::Start. Its version id.
    std::string land(const std::string& key) {
        std::scoped_lock lock(mutex_);
        auto& queue = inFlight_[key];
        if (queue.empty()) throw std::logic_error("no lost PUT of " + key + " to land (test)");
        auto v = std::move(queue.front());
        queue.erase(queue.begin());
        v.version_id = newVersionIdLocked();
        v.last_modified = stampLocked();
        return placeLocked(key, std::move(v)).version_id;
    }
    // The body of the oldest lost PUT of `key` (to recognise it), without landing it.
    [[nodiscard]] std::vector<uint8_t> inFlightBody(const std::string& key) const {
        std::scoped_lock lock(mutex_);
        const auto it = inFlight_.find(key);
        if (it == inFlight_.end() || it->second.empty()) throw std::logic_error("no lost PUT of " + key + " (test)");
        return it->second.front().body;
    }

    // ---- seeding and inspection ------------------------------------------------------------------------------------------

    // Writes a version as a PUT would. Returns its version id.
    std::string seed(const std::string& key, std::vector<uint8_t> body) {
        std::scoped_lock lock(mutex_);
        return writeLocked(key, std::move(body)).version_id;
    }
    // A request start, for seedStarted: a version seeded with it is ordered (Order::Start) as an upload that started
    // then and completed now.
    uint64_t startNow() {
        std::scoped_lock lock(mutex_);
        return ++seq_;
    }
    std::string seedStarted(const std::string& key, std::vector<uint8_t> body, const uint64_t started) {
        std::scoped_lock lock(mutex_);
        Version v;
        v.etag = md5Etag(body);
        v.body = std::move(body);
        v.last_modified = stampLocked();
        v.started = started;
        v.version_id = versioned_ ? newVersionIdLocked() : "null";
        return placeLocked(key, std::move(v)).version_id;
    }
    // Newest first; empty when the key has no versions.
    [[nodiscard]] std::vector<Version> history(const std::string& key) const {
        std::scoped_lock lock(mutex_);
        const auto it = objects_.find(key);
        if (it == objects_.end()) return {};
        return {it->second.rbegin(), it->second.rend()};
    }
    // The newest version unless it is a delete marker.
    [[nodiscard]] std::optional<Version> current(const std::string& key) const {
        std::scoped_lock lock(mutex_);
        const auto* v = latestLocked(key);
        if (!v || v->delete_marker) return std::nullopt;
        return *v;
    }

    // ---- requests (MemoryStore) ------------------------------------------------------------------------------------------

    [[nodiscard]] std::optional<Version> read(const std::string& key, const std::optional<std::string>& versionId) const {
        std::scoped_lock lock(mutex_);
        const Version* v = nullptr;
        if (versionId) {
            const auto it = objects_.find(key);
            if (it != objects_.end())
                for (const auto& x : it->second)
                    if (x.version_id == *versionId) v = &x;
        } else {
            v = latestLocked(key);
        }
        if (!v || v->delete_marker) return std::nullopt;
        return *v;
    }

    // A PUT with its conditions. Throws PreconditionFailed / ConditionsUnsupported as the bucket answers them.
    manifest::PutResult write(const std::string& key, const std::vector<uint8_t>& body,
                                    const std::optional<std::string>& ifMatch, const bool ifNoneMatch) {
        std::scoped_lock lock(mutex_);
        const auto* latest = latestLocked(key);
        const bool exists = latest && !latest->delete_marker;
        if ((ifMatch || ifNoneMatch) && conditional_ == ConditionalPuts::Reject)
            throw manifest::ConditionsUnsupported("the bucket does not support conditional writes (501 "
                                                        "NotImplemented, test)");
        if (conditional_ == ConditionalPuts::Supported) {
            if (ifMatch && (!exists || latest->etag != *ifMatch))
                throw manifest::PreconditionFailed("conditional PUT failed (412, test)");
            if (ifNoneMatch && exists) throw manifest::PreconditionFailed("conditional PUT failed (412, test)");
        }
        if (!ifMatch && !ifNoneMatch && versioned_)
            if (const auto lose = loseNext_.find(key); lose != loseNext_.end() && lose->second > 0) {
                --lose->second;
                Version v;
                v.etag = md5Etag(body);
                v.body = body;
                v.started = ++seq_;
                inFlight_[key].push_back(std::move(v));
                throw manifest::PutOutcomeUnknown("the PUT's reply was lost; its upload is still in flight (test)");
            }
        const auto& written = writeLocked(key, body);
        return {written.etag, versioned_ ? std::make_optional(written.version_id) : std::nullopt};
    }

    [[nodiscard]] std::vector<manifest::ListedObject> list(const std::string& prefix) const {
        std::scoped_lock lock(mutex_);
        std::vector<manifest::ListedObject> out;
        for (const auto& [key, stack] : objects_) {
            if (!key.starts_with(prefix) || stack.back().delete_marker) continue;
            const auto& v = stack.back();
            out.push_back({key, v.body.size(), v.last_modified, v.etag});
        }
        return out;
    }

    // Every version and delete marker of every key under `prefix` (of exactly `key` when exact), keys ascending, each
    // key's newest first, without those the listing lag hides.
    [[nodiscard]] std::vector<manifest::StoredVersion> versions(const std::string& prefix, const bool exact) const {
        std::scoped_lock lock(mutex_);
        std::vector<manifest::StoredVersion> out;
        for (const auto& [key, stack] : objects_) {
            if (exact ? key != prefix : !key.starts_with(prefix)) continue;
            for (auto v = stack.rbegin(); v != stack.rend(); ++v) {
                if (listingLag_ && now_ - v->last_modified < listingLag_) continue;   // A3 broken on purpose
                out.push_back({key, v->version_id, v->delete_marker ? 0 : v->body.size(), v->last_modified,
                               v->delete_marker, v->etag, v == stack.rbegin()});
            }
        }
        return out;
    }

    // DELETE: a delete marker on a versioned bucket, the key's removal on an unversioned one.
    void remove(const std::string& key) {
        std::scoped_lock lock(mutex_);
        if (!versioned_) {
            objects_.erase(key);
            return;
        }
        Version marker;
        marker.version_id = newVersionIdLocked();
        marker.delete_marker = true;
        marker.last_modified = stampLocked();
        marker.started = ++seq_;
        objects_[key].push_back(std::move(marker));
    }

    // DELETE ?versionId=: exactly that version or marker; one that is gone is not an error.
    void removeVersion(const std::string& key, const std::string& versionId) {
        std::scoped_lock lock(mutex_);
        const auto it = objects_.find(key);
        if (it == objects_.end()) return;
        std::erase_if(it->second, [&](const Version& v) { return v.version_id == versionId; });
        if (it->second.empty()) objects_.erase(it);
    }

private:
    [[nodiscard]] static std::string md5Etag(const std::vector<uint8_t>& body) {
        std::array<unsigned char, 16> digest{};
        unsigned int n = 0;
        if (EVP_Digest(body.data(), body.size(), digest.data(), &n, EVP_md5(), nullptr) != 1 || n != digest.size())
            throw std::runtime_error("MD5 failed (test)");
        std::string out = "\"";
        for (const auto b : digest) out += std::format("{:02x}", b);
        return out + "\"";
    }

    [[nodiscard]] const Version* latestLocked(const std::string& key) const {
        const auto it = objects_.find(key);
        if (it == objects_.end() || it->second.empty()) return nullptr;
        return &it->second.back();
    }

    std::string newVersionIdLocked() { return std::format("mem-{:06}", ++versionSeq_); }

    std::time_t stampLocked() {
        const auto t = now_;
        if (autoTick_) ++now_;
        return t;
    }

    const Version& writeLocked(const std::string& key, std::vector<uint8_t> body) {
        Version v;
        v.etag = md5Etag(body);
        v.body = std::move(body);
        v.last_modified = stampLocked();
        v.started = ++seq_;
        if (!versioned_) {
            objects_[key].clear();
            v.version_id = "null";
        } else {
            v.version_id = newVersionIdLocked();
        }
        if (const auto held = heldAt_.find({key, std::this_thread::get_id()}); held != heldAt_.end()) {
            v.started = held->second;
            heldAt_.erase(held);
        }
        return placeLocked(key, std::move(v));
    }

    // Commit order: on top. Start order: above every version that started before it (A4 as Backblaze breaks it).
    const Version& placeLocked(const std::string& key, Version v) {
        auto& stack = objects_[key];
        if (order_ == Order::Start) {
            const auto at = std::ranges::upper_bound(stack, v.started, {}, &Version::started);
            return *stack.insert(at, std::move(v));
        }
        stack.push_back(std::move(v));
        return stack.back();
    }

    mutable std::mutex mutex_;
    bool versioned_;
    ConditionalPuts conditional_{ConditionalPuts::Supported};
    bool autoTick_{true};
    std::time_t now_{1'700'000'000};
    std::time_t listingLag_{0};
    Order order_{Order::Commit};
    std::map<std::pair<std::string, std::thread::id>, uint64_t> heldAt_;   // the held PUT's start
    std::map<std::string, unsigned> loseNext_;
    std::map<std::string, std::vector<Version>> inFlight_;   // lost PUTs not landed, oldest first
    std::map<std::string, std::vector<Version>> objects_;    // oldest first (in the bucket's order)
    uint64_t versionSeq_{0};
    uint64_t seq_{0};   // request starts
};

class MemoryStore final : public manifest::ObjectStore {
public:
    explicit MemoryStore(std::shared_ptr<MemoryBucket> bucket,
                         const manifest::WriteCapability mode = manifest::WriteCapability::Unknown)
        : bucket_(std::move(bucket)), mode_(mode) {
        if (!bucket_) throw std::invalid_argument("MemoryStore needs a bucket");
    }

    std::optional<manifest::StoredObject> get(const std::string& key,
                                                    const std::optional<std::string>& versionId) override {
        auto v = bucket_->read(key, versionId);
        if (!v) return std::nullopt;
        if (v->body.size() > manifest::kMaxManifestObjectBytes)
            throw std::runtime_error("the object is larger than a manifest object may be (test)");
        // As storage::s3::ManifestStore answers: the version id asked for, none for the current object.
        return manifest::StoredObject{std::move(v->body), std::move(v->etag), versionId};
    }
    std::optional<std::vector<uint8_t>> getRange(const std::string& key, const uint64_t offset,
                                                 const uint64_t length) override {
        if (length == 0) return std::vector<uint8_t>{};
        const auto v = bucket_->read(key, std::nullopt);
        if (!v) return std::nullopt;
        if (offset >= v->body.size()) throw std::runtime_error("range not satisfiable (416, test)");
        const auto end = std::min<uint64_t>(v->body.size(), offset + length);
        return std::vector<uint8_t>(v->body.begin() + static_cast<std::ptrdiff_t>(offset),
                                    v->body.begin() + static_cast<std::ptrdiff_t>(end));
    }
    std::optional<std::string> headEtag(const std::string& key) override {
        const auto v = bucket_->read(key, std::nullopt);
        if (!v) return std::nullopt;
        return v->etag;
    }
    std::string putIfAbsent(const std::string& key, const std::vector<uint8_t>& bytes) override {
        return bucket_->write(key, bytes, std::nullopt, true).etag;
    }
    std::string putIfMatch(const std::string& key, const std::vector<uint8_t>& bytes, const std::string& etag) override {
        return bucket_->write(key, bytes, etag, false).etag;
    }
    manifest::PutResult put(const std::string& key, const std::vector<uint8_t>& bytes) override {
        return bucket_->write(key, bytes, std::nullopt, false);
    }
    std::vector<manifest::ListedObject> list(const std::string& prefix) override { return bucket_->list(prefix); }
    std::vector<manifest::StoredVersion> versions(const std::string& key) override {
        return bucket_->versions(key, true);
    }
    std::vector<manifest::StoredVersion> versionsUnder(const std::string& prefix) override {
        return bucket_->versions(prefix, false);
    }
    void remove(const std::string& key) override { bucket_->remove(key); }
    void removeVersion(const std::string& key, const std::string& versionId) override {
        bucket_->removeVersion(key, versionId);
    }
    [[nodiscard]] manifest::WriteCapability mode() const override { return mode_; }

private:
    std::shared_ptr<MemoryBucket> bucket_;
    manifest::WriteCapability mode_;
};

}
