// SPDX-License-Identifier: AGPL-3.0-or-later
// Copyright (c) 2026 Valkyrian Labs LLC
#pragma once

// Every public C++ header of vl-vaultfmt (the C API is vl_vaultfmt.h; the test doubles are under testing/).

#include "vl/vaultfmt/Fwd.hpp"
#include "vl/vaultfmt/ObjectKeys.hpp"
#include "vl/vaultfmt/manifest/Chain.hpp"
#include "vl/vaultfmt/manifest/Content.hpp"
#include "vl/vaultfmt/manifest/Document.hpp"
#include "vl/vaultfmt/manifest/Objects.hpp"
#include "vl/vaultfmt/manifest/Partition.hpp"
#include "vl/vaultfmt/manifest/Publisher.hpp"
#include "vl/vaultfmt/manifest/Reader.hpp"
#include "vl/vaultfmt/manifest/Reconcile.hpp"
#include "vl/vaultfmt/manifest/Session.hpp"
#include "vl/vaultfmt/manifest/Store.hpp"
#include "vl/vaultfmt/manifest/VersionLog.hpp"
#include "vl/vaultfmt/manifest/WriteCapability.hpp"
#include "vl/vaultfmt/vhf1/Aead.hpp"
#include "vl/vaultfmt/vhf1/Format.hpp"
#include "vl/vaultfmt/vhf1/Key.hpp"
#include "vl/vaultfmt/vhf1/Reader.hpp"
#include "vl/vaultfmt/vhf1/Writer.hpp"

namespace vl::vaultfmt {

// The library's version (meson project version), e.g. "0.1.0".
[[nodiscard]] const char* version() noexcept;

}
