// SPDX-License-Identifier: AGPL-3.0-or-later
// Copyright (c) 2026 Valkyrian Labs LLC
#pragma once

// Forward declarations of the library's types, for headers that only name them. Include the defining header to use one.

namespace vl::vaultfmt::vhf1 {
    struct Expectation;
    struct HeaderParams;
    struct Layout;
    struct RangePlan;
    class ChunkWalker;
    class Error;
    class Key;
    class OpenedHeader;
    class RangeReader;
    class SecureBytes;
    class Writer;
}

namespace vl::vaultfmt::manifest {
    class ObjectStore;
    class Session;
    class StateStore;
    struct Content;
}
