#!/usr/bin/env bash
# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (c) 2026 Valkyrian Labs LLC
#
# Builds VLVaultfmt.xcframework for macOS: one static library (vl-vaultfmt with its vl-keykit and Homebrew's openssl@3
# libcrypto linked in, so the app never loads OpenSSL from Homebrew at run time), the C API headers (vl_vaultfmt.h and
# vl_vaultfmt_engine.h) and a module map for `import VLVaultfmt` from Swift. Modelled on vl-keykit's script of the same
# name. macOS only; nothing here is signed.
#
#   scripts/build-xcframework.sh [OUT_DIR]          default OUT_DIR: build-apple (git-ignored)
#
# Environment:
#   ARCHS                       architectures to build (default: arm64, Vaulthalla Desktop's; x86_64 is built where a
#                               libcrypto.a of that architecture is found, else skipped with a note)
#   MACOSX_DEPLOYMENT_TARGET    default 27.0 (Vaulthalla Desktop's platform)
#   OPENSSL_PREFIX_arm64        default: Apple-silicon Homebrew's openssl@3 (brew --prefix openssl@3)
#   OPENSSL_PREFIX_x86_64       default: Intel Homebrew's /usr/local/opt/openssl@3
#   BUILD_JOBS                  compile jobs (default: meson's)
set -euo pipefail

if [[ "$(uname -s)" != Darwin ]]; then
    echo "build-xcframework.sh: macOS only" >&2
    exit 1
fi

root="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
out="$(mkdir -p "${1:-$root/build-apple}" && cd "${1:-$root/build-apple}" && pwd)"
target="${MACOSX_DEPLOYMENT_TARGET:-27.0}"
archs="${ARCHS:-arm64}"
jobs=()
if [[ -n "${BUILD_JOBS:-}" ]]; then jobs=(-j "$BUILD_JOBS"); fi

# A hermetic build: no stray include or library paths from the shell.
unset CPATH LIBRARY_PATH CPPFLAGS CFLAGS CXXFLAGS LDFLAGS PKG_CONFIG_PATH CC CXX

for tool in meson ninja xcodebuild libtool lipo pkg-config; do
    command -v "$tool" > /dev/null || { echo "build-xcframework.sh: $tool is missing" >&2; exit 1; }
done

json_pc="$(brew --prefix nlohmann-json 2> /dev/null || true)/share/pkgconfig"

openssl_prefix() {
    case "$1" in
        arm64) echo "${OPENSSL_PREFIX_arm64:-$(brew --prefix openssl@3 2> /dev/null || true)}" ;;
        x86_64) echo "${OPENSSL_PREFIX_x86_64:-/usr/local/opt/openssl@3}" ;;
        *) echo "" ;;
    esac
}

built=()
for arch in $archs; do
    prefix="$(openssl_prefix "$arch")"
    crypto="$prefix/lib/libcrypto.a"
    if [[ -z "$prefix" || ! -f "$crypto" ]] || ! lipo -archs "$crypto" | tr ' ' '\n' | grep -qx "$arch"; then
        echo "note: skipping $arch: no $arch libcrypto.a (looked in ${prefix:-nowhere}; set OPENSSL_PREFIX_$arch)" >&2
        continue
    fi
    case "$arch" in arm64) family=aarch64 ;; x86_64) family=x86_64 ;; *) echo "unknown arch $arch" >&2; exit 1 ;; esac

    dir="$out/$arch"
    rm -rf "$dir" && mkdir -p "$dir"
    cat > "$dir/cross.ini" << EOF
[binaries]
c = 'clang'
cpp = 'clang++'
ar = 'ar'
strip = 'strip'
pkg-config = 'pkg-config'

[built-in options]
c_args = ['-arch', '$arch', '-mmacosx-version-min=$target']
cpp_args = ['-arch', '$arch', '-mmacosx-version-min=$target']
c_link_args = ['-arch', '$arch', '-mmacosx-version-min=$target']
cpp_link_args = ['-arch', '$arch', '-mmacosx-version-min=$target']

[host_machine]
system = 'darwin'
subsystem = 'macos'
kernel = 'xnu'
cpu_family = '$family'
cpu = '$arch'
endian = 'little'
EOF
    meson setup "$dir/build" "$root" --cross-file "$dir/cross.ini" --buildtype=release -Db_ndebug=true \
        --unity=on -Dunity_size=1000 -Dtests=disabled -Dpkg_config_path="$prefix/lib/pkgconfig:$json_pc" > "$dir/setup.log"
    meson compile -C "$dir/build" "${jobs[@]}" > "$dir/compile.log"
    if grep -nE "warning:|WARNING:" "$dir/setup.log" "$dir/compile.log"; then
        echo "build-xcframework.sh: the build must be silent" >&2
        exit 1
    fi
    keykit="$(find "$dir/build/subprojects" -name 'libvl-keykit.a' -print -quit)"
    if [[ -z "$keykit" ]]; then
        echo "build-xcframework.sh: vl-keykit's static library was not built" >&2
        exit 1
    fi
    # vl-vaultfmt, vl-keykit and libcrypto in one archive, so the app links one library and no dylib from Homebrew.
    libtool -static -no_warning_for_no_symbols -o "$dir/libVLVaultfmt.a" "$dir/build/libvl-vaultfmt.a" "$keykit" \
        "$crypto" 2> "$dir/libtool.log" || {
        cat "$dir/libtool.log" >&2
        exit 1
    }
    built+=("$dir/libVLVaultfmt.a")
    echo "built $arch against $(basename "$(readlink -f "$prefix")") at $prefix"
done

if [[ ${#built[@]} -eq 0 ]]; then
    echo "build-xcframework.sh: nothing was built" >&2
    exit 1
fi

# One macOS slice: a universal archive when there are several architectures.
rm -rf "$out/universal" && mkdir -p "$out/universal"
lipo -create "${built[@]}" -output "$out/universal/libVLVaultfmt.a"

# The headers sit in a directory named after the module, so its module map can't collide with another framework's
# (VLKeykit's sits beside it in the same app).
headers="$out/headers"
rm -rf "$headers" && mkdir -p "$headers/VLVaultfmt"
cp "$root/include/vl/vaultfmt/vl_vaultfmt.h" "$root/include/vl/vaultfmt/vl_vaultfmt_engine.h" "$headers/VLVaultfmt/"
cat > "$headers/VLVaultfmt/module.modulemap" << 'EOF'
module VLVaultfmt {
    header "vl_vaultfmt.h"
    header "vl_vaultfmt_engine.h"
    link "c++"
    export *
}
EOF

rm -rf "$out/VLVaultfmt.xcframework"
xcodebuild -create-xcframework -library "$out/universal/libVLVaultfmt.a" -headers "$headers" \
    -output "$out/VLVaultfmt.xcframework" > /dev/null
echo "$out/VLVaultfmt.xcframework ($(lipo -archs "$out/universal/libVLVaultfmt.a"), macOS $target)"
