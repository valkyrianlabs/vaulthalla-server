// SPDX-License-Identifier: AGPL-3.0-or-later
// Copyright (c) 2026 Valkyrian Labs LLC
#include "vl/vaultfmt/engine/State.hpp"

#include "vl/vaultfmt/manifest/Objects.hpp"

#include <vl/keykit/uid.hpp>

#include <openssl/evp.h>

#include <algorithm>
#include <array>
#include <cstring>
#include <format>
#include <set>
#include <utility>

namespace vl::vaultfmt::engine {

namespace mf = manifest;

struct StateFile::Data {
    uint32_t writer_revision{mf::kBaselineWriterRevision};
    std::string node_id;
    mf::ChainState chain;
    std::optional<std::vector<uint8_t>> base_root;
    std::map<std::string, std::vector<uint8_t>> objects;   // sid → sealed bytes: the base copy's and pending roots'
    std::map<std::string, std::vector<uint8_t>> pending;   // root sha → sealed root, PUT and not recorded
    struct Root {
        uint64_t epoch{};
        std::string sha;
        std::vector<std::string> sids;
    };
    std::vector<Root> roots;                               // the retained roots, newest first (at most three)
    std::map<std::string, std::time_t> gc;                 // sid → first seen unreferenced
    uint64_t generation{};
    uint64_t revision{};
    uint64_t published_revision{};
    uint64_t changes_floor{};
    uint64_t seq{};                                        // the last journal record folded into this state
    std::map<std::string, std::pair<uint64_t, bool>> changes;   // uid → (revision, gone)
    std::vector<Purge> purges;
};

namespace state_file_detail {

using Json = nlohmann::json;
using Bytes = std::vector<uint8_t>;

constexpr std::array<uint8_t, 8> kMagic{'V', 'L', 'V', 'F', 'S', 'T', 'A', 'T'};
constexpr uint8_t kSnapshot = 1;
constexpr uint8_t kJournal = 2;
constexpr std::size_t kHashSize = 32;
constexpr std::size_t kRetainedRoots = 3;
constexpr std::size_t kMaxPublishing = 256;

std::array<uint8_t, kHashSize> sha256(std::span<const uint8_t> a, std::span<const uint8_t> b) {
    std::array<uint8_t, kHashSize> out{};
    EVP_MD_CTX* ctx = EVP_MD_CTX_new();
    unsigned int n = 0;
    const bool ok = ctx && EVP_DigestInit_ex(ctx, EVP_sha256(), nullptr) == 1 &&
                    EVP_DigestUpdate(ctx, a.data(), a.size()) == 1 && EVP_DigestUpdate(ctx, b.data(), b.size()) == 1 &&
                    EVP_DigestFinal_ex(ctx, out.data(), &n) == 1 && n == kHashSize;
    EVP_MD_CTX_free(ctx);
    if (!ok) throw std::runtime_error("SHA-256 failed");
    return out;
}

void putU32(Bytes& out, const uint32_t v) {
    for (int s = 24; s >= 0; s -= 8) out.push_back(static_cast<uint8_t>(v >> s));
}

uint32_t getU32(const uint8_t* p) {
    return (uint32_t{p[0]} << 24) | (uint32_t{p[1]} << 16) | (uint32_t{p[2]} << 8) | uint32_t{p[3]};
}

// One record: u32 BE payload length, u8 type, payload (CBOR), SHA-256 of everything before it.
Bytes record(const uint8_t type, const Json& payload) {
    const auto body = Json::to_cbor(payload);
    if (body.size() > UINT32_MAX) throw std::length_error("a state record is larger than 4 GiB");
    Bytes out;
    out.reserve(5 + body.size() + kHashSize);
    putU32(out, static_cast<uint32_t>(body.size()));
    out.push_back(type);
    out.insert(out.end(), body.begin(), body.end());
    const auto h = sha256(out, {});
    out.insert(out.end(), h.begin(), h.end());
    return out;
}

Bytes header() {
    Bytes out(kMagic.begin(), kMagic.end());
    putU32(out, StateFile::kFormatVersion);
    return out;
}

template <class T>
Json opt(const std::optional<T>& v) {
    return v ? Json(*v) : Json(nullptr);
}

template <class T>
std::optional<T> optOf(const Json& j, const char* key) {
    if (!j.contains(key) || j.at(key).is_null()) return std::nullopt;
    return j.at(key).get<T>();
}

Json bin(const Bytes& b) { return Json::binary(b); }
Bytes binOf(const Json& j) {
    const auto& b = j.get_binary();
    return Bytes(b.begin(), b.end());
}

// ---- the working content: the manifest's own codec (a root for vault, keys and policy; segment entries; snapshots) ---

Json contentJson(const mf::Content& c, const std::string& vaultUidText) {
    mf::RootDocument r;
    r.vault_uid = vaultUidText;
    r.epoch = 1;
    r.producer = c.producer;
    r.vault = c.vault;
    r.keys = c.keys;
    r.recovery_policy = c.recovery_policy;
    // A root needs a segment list covering 00..ff; this one only carries the members above.
    r.segments.push_back(mf::SegmentRef{vaultUidText, mf::Range{0x00, 0xff}, 0, std::string(64, '0'), 0});
    Json entries = Json::array();
    for (const auto& e : c.entries) entries.push_back(mf::toJson(e));
    Json snapshots = Json::array();
    for (const auto& s : c.snapshots) snapshots.push_back(mf::toJson(mf::SnapshotDocument{vaultUidText, s}));
    return {{"root", mf::toJson(r)}, {"entries", std::move(entries)}, {"snapshots", std::move(snapshots)}};
}

mf::Content contentOf(const Json& j, const mf::Uid& vaultUid) {
    const auto r = mf::rootFromJson(j.at("root"), vaultUid);
    mf::Content c;
    c.producer = r.producer;
    c.vault = r.vault;
    c.keys = r.keys;
    c.recovery_policy = r.recovery_policy;
    for (const auto& e : j.at("entries")) c.entries.push_back(mf::entryFromJson(e));
    for (const auto& s : j.at("snapshots")) c.snapshots.push_back(mf::snapshotFromJson(s, vaultUid).snapshot);
    mf::normalize(c);
    return c;
}

Json purgeJson(const Purge& p) {
    return {{"uid", p.uid}, {"key", p.key}, {"versions", p.version_ids}, {"revision", p.revision}};
}

Purge purgeOf(const Json& j) {
    return {j.at("uid").get<std::string>(), j.at("key").get<std::string>(),
            j.at("versions").get<std::vector<std::string>>(), j.at("revision").get<uint64_t>()};
}

Json changeJson(const Change& c, const uint64_t seq, const std::string& vaultUidText) {
    Json put = Json::array();
    for (const auto& e : c.put) put.push_back(mf::toJson(e));
    Json purges = Json::array();
    for (const auto& p : c.purges) purges.push_back(purgeJson(p));
    Json j = {{"seq", seq}, {"put", std::move(put)}, {"remove", c.remove}, {"purges", std::move(purges)}};
    if (c.keys || c.vault) {
        mf::Content meta;
        if (c.keys) meta.keys = *c.keys;
        meta.vault = c.vault;
        j["meta"] = contentJson(meta, vaultUidText).at("root");
        j["has_keys"] = c.keys.has_value();
        j["has_vault"] = c.vault.has_value();
    }
    return j;
}

Change changeOf(const Json& j, const mf::Uid& vaultUid) {
    Change c;
    for (const auto& e : j.at("put")) c.put.push_back(mf::entryFromJson(e));
    c.remove = j.at("remove").get<std::vector<std::string>>();
    for (const auto& p : j.at("purges")) c.purges.push_back(purgeOf(p));
    if (j.contains("meta")) {
        const auto r = mf::rootFromJson(j.at("meta"), vaultUid);
        if (j.at("has_keys").get<bool>()) c.keys = r.keys;
        if (j.at("has_vault").get<bool>()) c.vault = r.vault;
    }
    return c;
}

Json chainJson(const mf::ChainState& s) {
    Json j = {{"epoch", opt(s.epoch)},
              {"root_sha256", opt(s.root_sha256)},
              {"etag", opt(s.etag)},
              {"refused_reason", opt(s.refused_reason)},
              {"refused_epoch", opt(s.refused_epoch)},
              {"refused_root_sha256", opt(s.refused_root_sha256)},
              {"refused_at", opt(s.refused_at)},
              {"gc_at", opt(s.gc_at)},
              {"root_version_id", opt(s.root_version_id)},
              {"base_version_id", opt(s.base_version_id)},
              {"settle_window", s.settle_window},
              {"own_epoch", opt(s.own_epoch)},
              {"applying_epoch", opt(s.applying_epoch)},
              {"applying_root_sha256", opt(s.applying_root_sha256)},
              {"publishing_roots", s.publishing_roots},
              {"writers", s.writers},
              {"writers_change", nullptr}};
    if (s.writers_change)
        j["writers_change"] = {{"add", s.writers_change->kind == mf::WritersChange::Kind::Add},
                               {"node", s.writers_change->node}};
    return j;
}

mf::ChainState chainOf(const Json& j) {
    mf::ChainState s;
    s.epoch = optOf<uint64_t>(j, "epoch");
    s.root_sha256 = optOf<std::string>(j, "root_sha256");
    s.etag = optOf<std::string>(j, "etag");
    s.refused_reason = optOf<std::string>(j, "refused_reason");
    s.refused_epoch = optOf<uint64_t>(j, "refused_epoch");
    s.refused_root_sha256 = optOf<std::string>(j, "refused_root_sha256");
    s.refused_at = optOf<std::time_t>(j, "refused_at");
    s.gc_at = optOf<std::time_t>(j, "gc_at");
    s.root_version_id = optOf<std::string>(j, "root_version_id");
    s.base_version_id = optOf<std::string>(j, "base_version_id");
    s.settle_window = j.at("settle_window").get<std::vector<std::string>>();
    s.own_epoch = optOf<uint64_t>(j, "own_epoch");
    s.applying_epoch = optOf<uint64_t>(j, "applying_epoch");
    s.applying_root_sha256 = optOf<std::string>(j, "applying_root_sha256");
    s.publishing_roots = j.at("publishing_roots").get<std::vector<std::string>>();
    s.writers = j.at("writers").get<std::vector<std::string>>();
    if (const auto& c = j.at("writers_change"); !c.is_null())
        s.writers_change = mf::WritersChange{c.at("add").get<bool>() ? mf::WritersChange::Kind::Add
                                                                      : mf::WritersChange::Kind::Remove,
                                             c.at("node").get<std::string>()};
    return s;
}

Json snapshotJson(const StateFile::Data& d, const mf::Content& working, const std::string& vaultUidText) {
    Json objects = Json::object();
    for (const auto& [sid, b] : d.objects) objects[sid] = bin(b);
    Json pending = Json::object();
    for (const auto& [sha, b] : d.pending) pending[sha] = bin(b);
    Json roots = Json::array();
    for (const auto& r : d.roots) roots.push_back({{"epoch", r.epoch}, {"sha", r.sha}, {"sids", r.sids}});
    Json gc = Json::object();
    for (const auto& [sid, t] : d.gc) gc[sid] = t;
    Json changes = Json::object();
    for (const auto& [uid, c] : d.changes) changes[uid] = Json::array({c.first, c.second});
    Json purges = Json::array();
    for (const auto& p : d.purges) purges.push_back(purgeJson(p));
    return {{"v", StateFile::kFormatVersion},
            {"writer_revision", d.writer_revision},
            {"vault_uid", vaultUidText},
            {"node_id", d.node_id},
            {"chain", chainJson(d.chain)},
            {"base_root", d.base_root ? bin(*d.base_root) : Json(nullptr)},
            {"objects", std::move(objects)},
            {"pending", std::move(pending)},
            {"roots", std::move(roots)},
            {"gc", std::move(gc)},
            {"generation", d.generation},
            {"revision", d.revision},
            {"published_revision", d.published_revision},
            {"changes_floor", d.changes_floor},
            {"seq", d.seq},
            {"changes", std::move(changes)},
            {"purges", std::move(purges)},
            {"working", contentJson(working, vaultUidText)}};
}

StateFile::Data snapshotOf(const Json& j, const mf::Uid& vaultUid, mf::Content& working) {
    StateFile::Data d;
    d.writer_revision = j.at("writer_revision").get<uint32_t>();
    d.node_id = j.at("node_id").get<std::string>();
    d.chain = chainOf(j.at("chain"));
    if (!j.at("base_root").is_null()) d.base_root = binOf(j.at("base_root"));
    for (const auto& [sid, b] : j.at("objects").items()) d.objects[sid] = binOf(b);
    for (const auto& [sha, b] : j.at("pending").items()) d.pending[sha] = binOf(b);
    for (const auto& r : j.at("roots"))
        d.roots.push_back({r.at("epoch").get<uint64_t>(), r.at("sha").get<std::string>(),
                           r.at("sids").get<std::vector<std::string>>()});
    for (const auto& [sid, t] : j.at("gc").items()) d.gc[sid] = t.get<std::time_t>();
    d.generation = j.at("generation").get<uint64_t>();
    d.revision = j.at("revision").get<uint64_t>();
    d.published_revision = j.at("published_revision").get<uint64_t>();
    d.changes_floor = j.at("changes_floor").get<uint64_t>();
    d.seq = j.at("seq").get<uint64_t>();
    for (const auto& [uid, c] : j.at("changes").items()) d.changes[uid] = {c.at(0).get<uint64_t>(), c.at(1).get<bool>()};
    for (const auto& p : j.at("purges")) d.purges.push_back(purgeOf(p));
    working = contentOf(j.at("working"), vaultUid);
    return d;
}

// ---- in-memory rules ------------------------------------------------------------------------------------------------

void markChanged(StateFile::Data& d, const std::string& uid, const bool gone) { d.changes[uid] = {d.revision, gone}; }

// The change log keeps one row per live entry and at most kMaxRemovedInLog removals; anchors older than the oldest
// removal it dropped expire.
void pruneChanges(StateFile::Data& d) {
    std::vector<std::pair<uint64_t, std::string>> gone;
    for (const auto& [uid, c] : d.changes)
        if (c.second) gone.emplace_back(c.first, uid);
    if (gone.size() <= StateFile::kMaxRemovedInLog) return;
    std::ranges::sort(gone);
    const auto drop = gone.size() - StateFile::kMaxRemovedInLog;
    for (std::size_t i = 0; i < drop; ++i) {
        d.changes_floor = std::max(d.changes_floor, gone[i].first);
        d.changes.erase(gone[i].second);
    }
}

void putEntry(mf::Content& c, mf::Entry e) {
    const auto it = std::ranges::lower_bound(c.entries, e.uid, {}, &mf::Entry::uid);
    if (it != c.entries.end() && it->uid == e.uid) *it = std::move(e);
    else c.entries.insert(it, std::move(e));
}

void removeEntry(mf::Content& c, const std::string& uid) {
    const auto it = std::ranges::lower_bound(c.entries, uid, {}, &mf::Entry::uid);
    if (it != c.entries.end() && it->uid == uid) c.entries.erase(it);
}

void applyChange(StateFile::Data& d, mf::Content& working, const Change& c) {
    ++d.revision;
    for (const auto& e : c.put) {
        markChanged(d, e.uid, false);
        putEntry(working, e);
    }
    for (const auto& uid : c.remove) {
        markChanged(d, uid, true);
        removeEntry(working, uid);
    }
    if (c.keys) working.keys = *c.keys;
    if (c.vault) working.vault = *c.vault;
    for (const auto& p : c.purges) {
        std::erase_if(d.purges, [&](const Purge& q) { return q.uid == p.uid; });
        d.purges.push_back(p);
    }
    pruneChanges(d);
}

// What recordRoot keeps (the server's db::query::sync::Manifest::recordRoot, the same rules without SQL).
void recordInto(StateFile::Data& d, const mf::RootRecord& rec) {
    auto& s = d.chain;
    s.epoch = rec.epoch;
    s.root_sha256 = rec.root_sha256;
    s.etag = rec.etag;
    s.root_version_id = rec.version_id;
    s.base_version_id = rec.base_version_id;
    s.settle_window = rec.settle_window;
    if (rec.own) s.own_epoch = rec.epoch;
    s.publishing_roots = {rec.root_sha256};
    s.writers = rec.writers;
    if (s.applying_root_sha256 == rec.root_sha256) {
        s.applying_epoch.reset();
        s.applying_root_sha256.reset();
    }
    s.refused_reason.reset();
    s.refused_epoch.reset();
    s.refused_root_sha256.reset();
    s.refused_at.reset();
    if (s.writers_change && s.writers_change->satisfiedBy(rec.writers)) s.writers_change.reset();
    d.pending.clear();

    std::erase_if(d.roots, [&](const StateFile::Data::Root& r) { return r.epoch == rec.epoch; });
    d.roots.push_back({rec.epoch, rec.root_sha256, rec.sids});
    std::ranges::sort(d.roots, std::greater<>{}, &StateFile::Data::Root::epoch);
    if (d.roots.size() > kRetainedRoots) d.roots.resize(kRetainedRoots);

    if (!rec.base) {
        d.base_root.reset();
        d.objects.clear();
        return;
    }
    d.base_root = rec.base->root;
    const std::set<std::string> named(rec.sids.begin(), rec.sids.end());
    std::erase_if(d.objects, [&](const auto& kv) { return !named.contains(kv.first); });
    for (const auto& [sid, bytes] : rec.base->objects)
        if (named.contains(sid)) d.objects.try_emplace(sid, bytes);
}

uint64_t freshGeneration() {
    const auto u = vl::keykit::newUid();
    uint64_t g = 0;
    std::memcpy(&g, u.data(), sizeof g);
    return g == 0 ? 1 : g;
}

}

using namespace state_file_detail;

StateFile::StateFile(std::shared_ptr<StateBlob> blob, const mf::Uid& vaultUid, std::function<std::time_t()> now,
                     const std::size_t compactAfter)
    : blob_(std::move(blob)), vaultUid_(vaultUid), now_(std::move(now)), compactAfter_(std::max<std::size_t>(1, compactAfter)),
      data_(std::make_unique<Data>()) {
    if (!blob_) throw std::invalid_argument("engine::StateFile needs a blob");
    if (!now_) throw std::invalid_argument("engine::StateFile needs a clock");
}

StateFile::~StateFile() = default;

void StateFile::saveLocked(const Data& data, const mf::Content& working) {
    auto bytes = header();
    const auto snap = record(kSnapshot, snapshotJson(data, working, mf::uidText(vaultUid_)));
    bytes.insert(bytes.end(), snap.begin(), snap.end());
    try {
        blob_->save(bytes);
    } catch (const StateFailed&) {
        throw;
    } catch (const std::exception& e) {
        throw StateFailed(std::string("the engine's state could not be saved: ") + e.what());
    }
    journalRecords_ = 0;
}

template <class F>
void StateFile::mutate(F&& f) {
    std::scoped_lock lock(mutex_);
    auto next = std::make_unique<Data>(*data_);
    f(*next);
    saveLocked(*next, working_);
    data_ = std::move(next);
}

StateLoad StateFile::load(const uint32_t writerRevision) {
    std::scoped_lock lock(mutex_);
    std::optional<Bytes> blob;
    try {
        blob = blob_->load();
    } catch (const std::exception& e) {
        throw StateFailed(std::string("the engine's state could not be read: ") + e.what());
    }
    StateLoad out;
    if (!blob) return out;
    const auto damaged = [&](std::string why) {
        out.condition = StateCondition::Damaged;
        out.damage = std::move(why);
        return out;
    };
    const auto& b = *blob;
    if (b.size() < 12 || !std::equal(kMagic.begin(), kMagic.end(), b.begin())) return damaged("not an engine state");
    const auto version = getU32(b.data() + 8);
    if (version > kFormatVersion)
        throw StateTooNew(std::format("the engine's state has format {}; this engine reads {}", version, kFormatVersion));
    if (version != kFormatVersion) return damaged(std::format("unknown state format {}", version));

    // Records from offset 12. Each: length, type, payload, hash.
    struct Rec {
        uint8_t type;
        std::span<const uint8_t> payload;
    };
    std::vector<Rec> recs;
    std::size_t at = 12;
    while (at < b.size()) {
        if (b.size() - at < 5) {
            out.torn_tail = true;
            break;
        }
        const auto len = getU32(b.data() + at);
        if (b.size() - at - 5 < static_cast<std::size_t>(len) + kHashSize) {
            out.torn_tail = true;
            break;
        }
        const std::span<const uint8_t> covered(b.data() + at, 5 + len);
        const auto h = sha256(covered, {});
        if (!std::equal(h.begin(), h.end(), b.data() + at + 5 + len)) {
            if (at + 5 + len + kHashSize < b.size()) out.journal_truncated = true;
            else out.torn_tail = true;
            break;
        }
        recs.push_back({b[at + 4], covered.subspan(5)});
        at += 5 + len + kHashSize;
    }
    if (recs.empty() || recs.front().type != kSnapshot) return damaged("no readable snapshot");
    Json snap;
    try {
        snap = Json::from_cbor(recs.front().payload.begin(), recs.front().payload.end());
    } catch (const std::exception& e) {
        return damaged(std::string("the snapshot does not decode: ") + e.what());
    }
    try {
        if (snap.at("vault_uid").get<std::string>() != mf::uidText(vaultUid_))
            throw StateOfAnotherVault("the engine's state belongs to vault " + snap.at("vault_uid").get<std::string>());
        if (const auto r = snap.at("writer_revision").get<uint32_t>(); r > writerRevision)
            throw StateTooNew(std::format("the engine's state was written by writer revision {}; this engine is {}", r,
                                          writerRevision));
    } catch (const StateOfAnotherVault&) {
        throw;
    } catch (const StateTooNew&) {
        throw;
    } catch (const std::exception& e) {
        return damaged(std::string("the snapshot is incomplete: ") + e.what());
    }
    std::unique_ptr<Data> data;
    mf::Content working;
    try {
        data = std::make_unique<Data>(snapshotOf(snap, vaultUid_, working));
    } catch (const std::exception& e) {
        return damaged(std::string("the snapshot does not decode: ") + e.what());
    }
    for (std::size_t i = 1; i < recs.size(); ++i) {
        try {
            if (recs[i].type != kJournal) throw std::runtime_error("a record that is not a journal record");
            const auto j = Json::from_cbor(recs[i].payload.begin(), recs[i].payload.end());
            const auto seq = j.at("seq").get<uint64_t>();
            if (seq != data->seq + 1) throw std::runtime_error(std::format("journal record {} after {}", seq, data->seq));
            applyChange(*data, working, changeOf(j, vaultUid_));
            data->seq = seq;
            ++out.journal_records;
        } catch (const std::exception& e) {
            out.journal_truncated = true;
            out.damage = std::string("a journal record does not decode: ") + e.what();
            break;
        }
    }
    if (out.torn_tail && out.damage.empty()) out.damage = "the last journal record is incomplete (a crash during an append)";
    if (out.journal_truncated && out.damage.empty()) out.damage = "a journal record failed its checksum";
    out.condition = StateCondition::Loaded;
    data_ = std::move(data);
    working_ = std::move(working);
    journalRecords_ = out.journal_records;
    // Appends must land after valid bytes: a torn or truncated tail is rewritten away first.
    if (out.torn_tail || out.journal_truncated) saveLocked(*data_, working_);
    return out;
}

void StateFile::reset(mf::Content working, const std::optional<mf::RootRecord>& root, const std::string& nodeId,
                      const uint32_t writerRevision, const bool settled) {
    std::scoped_lock lock(mutex_);
    auto next = std::make_unique<Data>();
    next->writer_revision = writerRevision;
    next->node_id = nodeId;
    next->generation = freshGeneration();
    next->revision = 1;
    mf::normalize(working);
    for (const auto& e : working.entries) markChanged(*next, e.uid, false);
    if (root) recordInto(*next, *root);
    if (root && settled) next->published_revision = next->revision;
    saveLocked(*next, working);
    data_ = std::move(next);
    working_ = std::move(working);
}

const mf::Content& StateFile::working() const { return working_; }

uint64_t StateFile::commit(const Change& change) {
    std::scoped_lock lock(mutex_);
    Change stamped = change;
    for (auto& p : stamped.purges) p.revision = data_->revision + 1;
    if (appendable_ && journalRecords_ < compactAfter_) {
        const auto rec = record(kJournal, changeJson(stamped, data_->seq + 1, mf::uidText(vaultUid_)));
        bool appended = false;
        try {
            appended = blob_->append(rec);
        } catch (const std::exception& e) {
            throw StateFailed(std::string("the engine's journal could not be written: ") + e.what());
        }
        if (appended) {
            applyChange(*data_, working_, stamped);
            ++data_->seq;
            ++journalRecords_;
            return data_->revision;
        }
        appendable_ = false;   // the blob has no append: every change is a save
    }
    auto next = std::make_unique<Data>(*data_);
    auto working = working_;
    applyChange(*next, working, stamped);
    next->seq = 0;
    saveLocked(*next, working);
    data_ = std::move(next);
    working_ = std::move(working);
    return data_->revision;
}

void StateFile::applyAndRecord(mf::Content result, const mf::RootRecord& root, const bool settled) {
    std::scoped_lock lock(mutex_);
    auto next = std::make_unique<Data>(*data_);
    ++next->revision;
    mf::normalize(result);
    // The change log: every uid whose entry the apply added, changed or removed.
    const auto& before = working_.entries;
    std::size_t i = 0, j = 0;
    while (i < before.size() || j < result.entries.size()) {
        if (j == result.entries.size() || (i < before.size() && before[i].uid < result.entries[j].uid)) {
            markChanged(*next, before[i++].uid, true);
        } else if (i == before.size() || result.entries[j].uid < before[i].uid) {
            markChanged(*next, result.entries[j++].uid, false);
        } else {
            if (!(before[i] == result.entries[j])) markChanged(*next, result.entries[j].uid, false);
            ++i;
            ++j;
        }
    }
    pruneChanges(*next);
    recordInto(*next, root);
    if (settled) next->published_revision = next->revision;
    next->seq = 0;
    saveLocked(*next, result);
    data_ = std::move(next);
    working_ = std::move(result);
}

uint64_t StateFile::revision() const {
    std::scoped_lock lock(mutex_);
    return data_->revision;
}

uint64_t StateFile::publishedRevision() const {
    std::scoped_lock lock(mutex_);
    return data_->published_revision;
}

ChangeLog StateFile::changesSince(const uint64_t generation, const uint64_t after) const {
    std::scoped_lock lock(mutex_);
    ChangeLog out;
    out.generation = data_->generation;
    out.revision = data_->revision;
    if (generation != data_->generation || after < data_->changes_floor || after > data_->revision) {
        out.expired = true;
        return out;
    }
    for (const auto& [uid, c] : data_->changes)
        if (c.first > after) (c.second ? out.removed : out.changed).push_back(uid);
    return out;
}

std::vector<Purge> StateFile::purges() const {
    std::scoped_lock lock(mutex_);
    return data_->purges;
}

void StateFile::dropPurges(const std::vector<std::string>& uids) {
    if (uids.empty()) return;
    mutate([&](Data& d) {
        std::erase_if(d.purges, [&](const Purge& p) { return std::ranges::find(uids, p.uid) != uids.end(); });
    });
}

void StateFile::noteCollected(const uint64_t revision) {
    std::scoped_lock lock(mutex_);
    collected_ = revision;
}

void StateFile::settleCollected() {
    std::optional<uint64_t> collected;
    {
        std::scoped_lock lock(mutex_);
        collected = std::exchange(collected_, std::nullopt);
        if (!collected || *collected <= data_->published_revision) return;
    }
    mutate([&](Data& d) { d.published_revision = std::max(d.published_revision, *collected); });
}

std::string StateFile::nodeId() const {
    std::scoped_lock lock(mutex_);
    return data_->node_id;
}

void StateFile::setWritersChange(const std::optional<mf::WritersChange>& change) {
    mutate([&](Data& d) { d.chain.writers_change = change; });
}

// ---- manifest::StateStore -------------------------------------------------------------------------------------------

mf::ChainState StateFile::state() {
    std::scoped_lock lock(mutex_);
    return data_->chain;
}

void StateFile::recordRoot(const mf::RootRecord& record) {
    std::optional<uint64_t> collected;
    {
        std::scoped_lock lock(mutex_);
        if (record.own) collected = std::exchange(collected_, std::nullopt);
    }
    mutate([&](Data& d) {
        recordInto(d, record);
        // A publish of ours settled: everything its collect saw is in the bucket now.
        if (collected) d.published_revision = std::max(d.published_revision, *collected);
    });
}

std::optional<mf::BaseCopy> StateFile::base() {
    std::scoped_lock lock(mutex_);
    if (!data_->base_root) return std::nullopt;
    return mf::BaseCopy{*data_->base_root, data_->objects};
}

void StateFile::markApplying(const uint64_t epoch, const std::string& rootSha256) {
    mutate([&](Data& d) {
        d.chain.applying_epoch = epoch;
        d.chain.applying_root_sha256 = rootSha256;
    });
}

void StateFile::notePublishing(const std::string& rootSha256, const mf::BaseCopy& pending) {
    mutate([&](Data& d) {
        for (const auto& [sid, bytes] : pending.objects) d.objects.try_emplace(sid, bytes);
        if (!pending.root.empty()) d.pending.try_emplace(rootSha256, pending.root);
        auto& p = d.chain.publishing_roots;
        if (p.size() >= kMaxPublishing) p.erase(p.begin(), p.begin() + static_cast<std::ptrdiff_t>(p.size() - kMaxPublishing + 1));
        p.push_back(rootSha256);
        std::erase_if(d.pending, [&](const auto& kv) { return std::ranges::find(p, kv.first) == p.end(); });
    });
}

std::optional<mf::BaseCopy> StateFile::pendingBase(const std::string& rootSha256) {
    std::scoped_lock lock(mutex_);
    const auto it = data_->pending.find(rootSha256);
    if (it == data_->pending.end()) return std::nullopt;
    return mf::BaseCopy{it->second, data_->objects};
}

bool StateFile::recordRefused(const std::string& reason, const uint64_t epoch, const std::string& rootSha256) {
    {
        std::scoped_lock lock(mutex_);
        if (data_->chain.refused_root_sha256 == rootSha256 && data_->chain.refused_reason == reason) return false;
    }
    mutate([&](Data& d) {
        d.chain.refused_reason = reason;
        d.chain.refused_epoch = epoch;
        d.chain.refused_root_sha256 = rootSha256;
        d.chain.refused_at = now_();
    });
    return true;
}

std::set<std::string> StateFile::retainedSids() {
    std::scoped_lock lock(mutex_);
    std::set<std::string> out;
    for (const auto& r : data_->roots) out.insert(r.sids.begin(), r.sids.end());
    return out;
}

void StateFile::markCollected() {
    mutate([&](Data& d) { d.chain.gc_at = now_(); });
}

std::time_t StateFile::firstUnreferenced(const std::string& sid) {
    {
        std::scoped_lock lock(mutex_);
        if (const auto it = data_->gc.find(sid); it != data_->gc.end()) return it->second;
    }
    const auto t = now_();
    mutate([&](Data& d) { d.gc.try_emplace(sid, t); });
    std::scoped_lock lock(mutex_);
    return data_->gc.at(sid);
}

void StateFile::forgetUnreferenced(const std::string& sid) {
    {
        std::scoped_lock lock(mutex_);
        if (!data_->gc.contains(sid)) return;
    }
    mutate([&](Data& d) { d.gc.erase(sid); });
}

}
