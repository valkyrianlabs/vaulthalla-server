// SPDX-License-Identifier: AGPL-3.0-or-later
// Copyright (c) 2026 Valkyrian Labs LLC
//
// The reference file blob for the engine's state (State.hpp): the library's only POSIX file I/O (CLAUDE.md, Scope).
#include "vl/vaultfmt/engine/State.hpp"

#include <cerrno>
#include <cstring>
#include <string>
#include <system_error>

#include <fcntl.h>
#include <sys/stat.h>
#include <unistd.h>

namespace vl::vaultfmt::engine {

namespace file_blob_detail {

[[noreturn]] void fail(const std::string& what, const std::string& path) {
    const int e = errno;
    throw StateFailed(what + " " + path + ": " + std::generic_category().message(e));
}

class Fd {
public:
    explicit Fd(const int fd) : fd_(fd) {}
    ~Fd() {
        if (fd_ >= 0) (void)::close(fd_);
    }
    Fd(const Fd&) = delete;
    Fd& operator=(const Fd&) = delete;
    [[nodiscard]] int get() const { return fd_; }
    // Closes and reports the error (a close can be where a write's error shows).
    void close(const std::string& path) {
        const int fd = fd_;
        fd_ = -1;
        if (::close(fd) != 0) fail("could not close", path);
    }

private:
    int fd_;
};

// Durable on the device: F_FULLFSYNC on Apple platforms (fsync there only reaches the drive's cache), fsync elsewhere
// or where the file system refuses F_FULLFSYNC.
void flush(const int fd, const std::string& path) {
#ifdef F_FULLFSYNC
    if (::fcntl(fd, F_FULLFSYNC) == 0) return;
#endif
    if (::fsync(fd) != 0) fail("could not flush", path);
}

void writeAll(const int fd, std::span<const uint8_t> bytes, const std::string& path) {
    while (!bytes.empty()) {
        const auto n = ::write(fd, bytes.data(), bytes.size());
        if (n < 0) {
            if (errno == EINTR) continue;
            fail("could not write", path);
        }
        bytes = bytes.subspan(static_cast<std::size_t>(n));
    }
}

std::string dirOf(const std::string& path) {
    const auto slash = path.find_last_of('/');
    if (slash == std::string::npos) return ".";
    return slash == 0 ? "/" : path.substr(0, slash);
}

}

using namespace file_blob_detail;

FileStateBlob::FileStateBlob(std::string path) : path_(std::move(path)) {
    if (path_.empty()) throw std::invalid_argument("engine::FileStateBlob needs a path");
}

std::optional<std::vector<uint8_t>> FileStateBlob::load() {
    Fd fd(::open(path_.c_str(), O_RDONLY | O_CLOEXEC));
    if (fd.get() < 0) {
        if (errno == ENOENT) return std::nullopt;
        fail("could not open", path_);
    }
    std::vector<uint8_t> out;
    uint8_t buffer[1 << 16];
    for (;;) {
        const auto n = ::read(fd.get(), buffer, sizeof buffer);
        if (n < 0) {
            if (errno == EINTR) continue;
            fail("could not read", path_);
        }
        if (n == 0) break;
        out.insert(out.end(), buffer, buffer + n);
    }
    return out;
}

void FileStateBlob::save(const std::span<const uint8_t> bytes) {
    const auto tmp = path_ + ".tmp";
    {
        Fd fd(::open(tmp.c_str(), O_WRONLY | O_CREAT | O_TRUNC | O_CLOEXEC, S_IRUSR | S_IWUSR));
        if (fd.get() < 0) fail("could not create", tmp);
        writeAll(fd.get(), bytes, tmp);
        flush(fd.get(), tmp);
        fd.close(tmp);
    }
    if (::rename(tmp.c_str(), path_.c_str()) != 0) fail("could not replace", path_);
    // The rename itself is durable once the directory is.
    const auto dir = dirOf(path_);
    Fd d(::open(dir.c_str(), O_RDONLY | O_CLOEXEC));
    if (d.get() < 0) fail("could not open the directory of", path_);
    if (::fsync(d.get()) != 0) fail("could not flush the directory of", path_);
}

bool FileStateBlob::append(const std::span<const uint8_t> bytes) {
    Fd fd(::open(path_.c_str(), O_WRONLY | O_APPEND | O_CLOEXEC));
    if (fd.get() < 0) fail("could not open", path_);
    writeAll(fd.get(), bytes, path_);
    flush(fd.get(), path_);
    fd.close(path_);
    return true;
}

}
