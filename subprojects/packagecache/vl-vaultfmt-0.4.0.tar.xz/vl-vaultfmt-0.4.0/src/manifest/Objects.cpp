// SPDX-License-Identifier: AGPL-3.0-or-later
// Copyright (c) 2026 Valkyrian Labs LLC
#include "vl/vaultfmt/manifest/Objects.hpp"

#include "vl/vaultfmt/vhf1/Reader.hpp"
#include "vl/vaultfmt/vhf1/Writer.hpp"

#include <openssl/evp.h>

#include <array>
#include <format>
#include <stdexcept>

namespace vl::vaultfmt::manifest {

std::string segmentKey(const std::string_view sid) { return std::string(kSegmentPrefix) + std::string(sid); }

std::optional<std::string> sidOfKey(const std::string_view key) {
    if (!key.starts_with(kSegmentPrefix)) return std::nullopt;
    const auto sid = key.substr(kSegmentPrefix.size());
    if (!vl::keykit::fromBase32(sid)) return std::nullopt;
    return std::string(sid);
}

std::optional<Uid> uidOfObjectKey(const std::string_view key) {
    if (!key.starts_with(kObjectPrefix)) return std::nullopt;
    return vl::keykit::fromBase32(key.substr(kObjectPrefix.size()));
}

std::string layoutHint(const Uid& vaultUid) {
    return canonicalJson({{"format", 1}, {"layout", std::string(kLayoutOpaqueV1)}, {"vault_uid", uidText(vaultUid)}});
}

std::string sha256Hex(const std::span<const uint8_t> bytes) {
    std::array<unsigned char, 32> digest{};
    unsigned int size = 0;
    if (EVP_Digest(bytes.data(), bytes.size(), digest.data(), &size, EVP_sha256(), nullptr) != 1 ||
        size != digest.size())
        throw std::runtime_error("SHA-256 failed");
    std::string out;
    out.reserve(digest.size() * 2);
    for (const auto b : digest) out += std::format("{:02x}", b);
    return out;
}

std::vector<uint8_t> sealDocument(const Json& doc, const vhf1::Kind kind, const Uid& vaultUid,
                                  const Uid& objectUid, const SealingKey& key) {
    if (!key.key || key.version == 0) throw std::invalid_argument("manifest: sealing needs a vault key version");
    const auto text = canonicalJson(doc);
    vhf1::HeaderParams params;
    params.kind = kind;
    params.keyVersion = key.version;
    params.vaultUid = vaultUid;
    params.objectUid = objectUid;
    params.salt = vhf1::freshSalt();
    return vhf1::seal({reinterpret_cast<const uint8_t*>(text.data()), text.size()}, params, *key.key);
}

std::vector<uint8_t> sealRoot(const RootDocument& root, const Uid& vaultUid, const SealingKey& key) {
    return sealDocument(toJson(root), vhf1::Kind::ManifestRoot, vaultUid, vaultUid, key);
}

std::vector<uint8_t> sealSegment(const SegmentDocument& doc, const Uid& vaultUid, const Uid& sid, const SealingKey& key) {
    return sealDocument(toJson(doc), vhf1::Kind::ManifestSegment, vaultUid, sid, key);
}

std::vector<uint8_t> sealSnapshot(const SnapshotDocument& doc, const Uid& vaultUid, const Uid& sid,
                                  const SealingKey& key) {
    return sealDocument(toJson(doc), vhf1::Kind::ManifestSegment, vaultUid, sid, key);
}

Json openDocument(const std::span<const uint8_t> object, const vhf1::Kind kind, const Uid& vaultUid,
                  const Uid& objectUid, const vhf1::KeyLookup& keys, const std::string& code) {
    const vhf1::Expectation expect{kind, vaultUid, objectUid, std::nullopt};
    const auto plaintext = vhf1::open(object, expect, keys);
    const auto bytes = plaintext.span();
    auto parsed = Json::parse(bytes.begin(), bytes.end(), nullptr, false);
    if (parsed.is_discarded()) throw FormatError(code, "the authenticated plaintext is not JSON");
    return parsed;
}

RootDocument openRoot(const std::span<const uint8_t> object, const Uid& vaultUid, const vhf1::KeyLookup& keys) {
    return rootFromJson(openDocument(object, vhf1::Kind::ManifestRoot, vaultUid, vaultUid, keys, "bad_root"),
                        vaultUid);
}

SegmentDocument openSegment(const std::span<const uint8_t> object, const Uid& vaultUid, const Uid& sid,
                            const vhf1::KeyLookup& keys) {
    return segmentFromJson(
        openDocument(object, vhf1::Kind::ManifestSegment, vaultUid, sid, keys, "bad_segment"), vaultUid);
}

SnapshotDocument openSnapshot(const std::span<const uint8_t> object, const Uid& vaultUid, const Uid& sid,
                              const vhf1::KeyLookup& keys) {
    return snapshotFromJson(
        openDocument(object, vhf1::Kind::ManifestSegment, vaultUid, sid, keys, "bad_snapshot"), vaultUid);
}

}
