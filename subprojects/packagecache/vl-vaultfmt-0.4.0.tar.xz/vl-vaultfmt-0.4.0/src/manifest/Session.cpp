// SPDX-License-Identifier: AGPL-3.0-or-later
// Copyright (c) 2026 Valkyrian Labs LLC
#include "vl/vaultfmt/manifest/Session.hpp"

#include <algorithm>
#include <format>
#include <stdexcept>
#include <utility>

namespace vl::vaultfmt::manifest {

namespace session_detail {

bool versionLog(const ObjectStore& store) { return store.mode() == WriteCapability::VersionLog; }

}

std::string_view differsFromRecorded(const Content& produced, const Content& recorded) {
    // Producer-specific values: the producer itself, and when the recorded root is another server's (another node, or
    // another vault id: replicas may well share an id), its key records' check, attestation and origin (over its vault
    // id and its own TPM; the apply checked the keys are ours).
    const bool otherServer = recorded.producer.node_id != produced.producer.node_id ||
                             recorded.producer.vault_id != produced.producer.vault_id;
    const auto keysDiffer = [&] {
        if (produced.keys.size() != recorded.keys.size()) return true;
        for (std::size_t i = 0; i < produced.keys.size(); ++i) {
            auto a = produced.keys[i], b = recorded.keys[i];
            if (otherServer) {
                a.key_check = b.key_check;
                a.attestation = b.attestation;
                a.origin = b.origin;
            }
            if (a != b) return true;
        }
        return false;
    };
    if (produced.vault != recorded.vault) {
        if (!produced.vault || !recorded.vault) return "vault";
        if (produced.vault->name != recorded.vault->name) return "vault.name";
        if (produced.vault->created_at != recorded.vault->created_at) return "vault.created_at";
        if (produced.vault->quota_bytes != recorded.vault->quota_bytes) return "vault.quota_bytes";
        if (produced.vault->sync_strategy != recorded.vault->sync_strategy) return "vault.sync_strategy";
        return "vault.recovery_policy";
    }
    if (keysDiffer()) return "keys";
    if (produced.recovery_policy != recorded.recovery_policy) return "recovery_policy";
    // Each writer's own observations: when a provider version became noncurrent (whether it did is the fact), and a
    // directory's mtime (when this server's tree last changed in it: an apply stamps its own time). Neither is a
    // reason for a root; the next real change carries this server's values.
    const auto entries = [](std::vector<Entry> es) {
        for (auto& e : es) {
            if (e.kind == EntryKind::Dir) e.mtime.reset();
            for (auto& v : e.versions)
                if (v.noncurrent_at) v.noncurrent_at = "";
        }
        return es;
    };
    if (entries(produced.entries) != entries(recorded.entries)) return "entries";
    if (produced.snapshots != recorded.snapshots) return "snapshots";
    return {};
}

namespace session_detail {

std::optional<SettledWindow> settledOf(const ChainState& state) {
    if (!state.root_version_id || !state.base_version_id) return std::nullopt;
    return SettledWindow{*state.base_version_id, *state.root_version_id, state.settle_window};
}

bool refusal(const ChainError code) {
    return code == ChainError::Rollback || code == ChainError::Fork || code == ChainError::OrderViolation ||
           code == ChainError::Superseded || code == ChainError::PublishModeMismatch;
}

// What a cached base holds once its root is recorded: the sealed bytes went into the base copy, so the cache drops them
// (a large vault would otherwise keep its segments twice in memory).
void dropSealed(PublisherCache& cache) {
    if (!cache.base) return;
    for (auto& [_, s] : cache.base->segments) std::vector<uint8_t>().swap(s.sealed);
    for (auto& [_, s] : cache.base->snapshots) std::vector<uint8_t>().swap(s.sealed);
    std::vector<uint8_t>().swap(cache.base->root_bytes);
}

std::vector<std::string> sidsOf(const RootDocument& root) {
    std::vector<std::string> sids;
    for (const auto& s : root.segments) sids.push_back(s.sid);
    for (const auto& s : root.snapshots) sids.push_back(s.sid);
    return sids;
}

}

Session::Session(const Uid& vaultUid, std::shared_ptr<ObjectStore> store, std::shared_ptr<StateStore> state,
                 SessionHost host)
    : vaultUid_(vaultUid), store_(std::move(store)), state_(std::move(state)), host_(std::move(host)) {
    if (!store_ || !state_) throw std::invalid_argument("manifest::Session needs a store and a state store");
    if (!host_.collect || !host_.currentKey || !host_.keys || !host_.nodeId || !host_.now)
        throw std::invalid_argument("manifest::Session needs the vault's content and keys, a node id and a clock");
}

void Session::note(const Notice level, const std::string& message) const {
    if (host_.note) host_.note(level, message);
}

std::optional<Known> Session::known() const {
    const auto state = state_->state();
    if (!state.epoch || !state.root_sha256) return std::nullopt;
    return Known{*state.epoch, *state.root_sha256, state.root_version_id};
}

void Session::refused(const ChainRejected& e, const uint64_t epoch, const std::string& rootSha256) {
    const auto reason = std::string(chainErrorName(e.code()));
    note(Notice::Error, std::format("refused the bucket's manifest root ({}); the database keeps its state and nothing "
                                    "is published over it",
                                    e.what()));
    if (state_->recordRefused(reason, epoch, rootSha256) && host_.alert)
        host_.alert(Refusal{e.code(), epoch, rootSha256, known()});
}

PublishReport Session::publish() {
    std::scoped_lock lock(mutex_);
    return publishLocked(host_.collect());
}

std::optional<PublishReport> Session::publishIfChanged() {
    std::scoped_lock lock(mutex_);
    auto produced = host_.collect();
    const auto knownState = known();
    // A join, leave or replica removal the recorded root doesn't show yet is always published.
    const auto pending = state_->state();
    const bool changeDue = pending.writers_change && !pending.writers_change->satisfiedBy(pending.writers);
    if (!changeDue && cache_.base && cache_.last_produced && knownState && cache_.base->known == *knownState &&
        *cache_.last_produced == produced)
        return std::nullopt;
    if (!changeDue && knownState && unchanged_ && unchanged_->first == *knownState && unchanged_->second == produced)
        return std::nullopt;
    unchanged_.reset();
    // Another writer's root, applied, that already says what this server holds: publishing would only restamp it, and
    // the other writer would restamp that (two writers alternating roots every pass). Kept until either side changes.
    if (const auto state = state_->state(); knownState && !(cache_.base && cache_.base->known == *knownState) &&
                                            state.own_epoch != knownState->epoch && !state.applying_epoch) {
        const bool named = std::ranges::find(state.writers, produced.producer.node_id) != state.writers.end() &&
                           (!state.writers_change || state.writers_change->satisfiedBy(state.writers));
        if (const auto copy = named ? state_->base() : std::nullopt) {
            std::string why;
            if (const auto recorded = openBaseCopy(*copy, vaultUid_, host_.keys, *knownState, &why)) {
                // What a publish would write: ours merged on it, with the history the database doesn't hold.
                auto next = mergePending(*recorded, *recorded, produced);
                carryHistory(*recorded, next, isoTime(host_.now()));
                const auto differs = differsFromRecorded(next, *recorded);
                if (differs.empty()) {
                    unchanged_.emplace(*knownState, produced);
                    return std::nullopt;
                }
            }
        }
    }
    return publishLocked(produced);
}

PublishReport Session::publishLocked(const Content& produced) {
    namespace d = session_detail;
    const auto state = state_->state();
    if (state.applying_epoch)
        throw ApplyIncomplete(std::format("an apply of the root of epoch {} is incomplete: the database is between two "
                                          "roots, and a partial state is never published",
                                          *state.applying_epoch));
    const auto current = host_.currentKey();
    const auto knownState = known();
    PublishOptions options;
    if (!cache_.last_produced && knownState) {
        // A cold start: the base of our pending changes is the content of `known`, from the local copy.
        if (const auto copy = state_->base()) {
            std::string why;
            options.pending_base = openBaseCopy(*copy, vaultUid_, host_.keys, *knownState, &why);
            if (!options.pending_base)
                note(Notice::Warning, std::format("the local base copy of epoch {} is not usable ({}); merging on the "
                                                  "bucket's head",
                                                  knownState->epoch, why));
        }
    }
    options.now = isoTime(host_.now());
    options.self_node = produced.producer.node_id;
    options.own_epoch = state.own_epoch;
    options.settled = d::settledOf(state);
    options.apply_on_lost = true;
    options.writers_change = state.writers_change;
    options.writer_revision = host_.writerRevision;
    options.writer_floor = host_.writerFloor;
    if (knownState)
        if (const auto copy = state_->base()) try {
                options.known_floor = writerFloorOf(openRoot(copy->root, vaultUid_, host_.keys));
            } catch (const std::exception&) {
                // an unreadable copy: the head's floor is still checked
            }
    options.self_vault_id = host_.vaultId;
    bool rootPutSent = false;
    options.before_root_put = [this, &rootPutSent](const std::string& sha, const BaseCopy& pending) {
        state_->notePublishing(sha, pending);
        rootPutSent = true;
    };
    try {
        auto report = manifest::publish(*store_, vaultUid_, host_.keys, current, produced, knownState, cache_, options);
        if (host_.afterRootPut) host_.afterRootPut();
        state_->recordRoot({.epoch = report.published.known.epoch,
                            .root_sha256 = report.published.known.root_sha256,
                            .etag = report.published.etag,
                            .sids = report.published.sids(),
                            .version_id = report.settled.version_id,
                            .base_version_id = report.settled.base_version_id,
                            .settle_window = report.settled.window,
                            .own = true,
                            .base = baseCopyOf(report.published.root, report.published.root_bytes,
                                               report.published.segments, report.published.snapshots),
                            .writers = report.published.root.writers.value_or(std::vector<std::string>{}),
                            .producer = report.published.root.producer.node_id,
                            .published_at = report.published.root.published_at});
        d::dropSealed(cache_);
        if (report.lost)
            note(Notice::Info, std::format("another writer's root won {} round(s) of this publish; merged onto it "
                                           "(spec 06 §5.2)",
                                           report.lost));
        if (!report.repaired.empty())
            note(Notice::Info, std::format("deleted {} stray root version(s) above the head", report.repaired.size()));
        if (!report.ahead.empty())
            note(Notice::Warning, std::format("{} authentic root version(s) of a higher epoch sit above the root just "
                                              "published; left in place, the next read judges them",
                                              report.ahead.size()));
        if (report.gap)
            note(Notice::Warning, std::format("another writer published several roots since epoch {} (gap); merged and "
                                              "continued at epoch {}",
                                              knownState ? knownState->epoch : 0, report.published.known.epoch));
        if (report.root_rebuilt)
            note(Notice::Warning, std::format("the bucket's manifest root was missing or unreadable; rebuilt from the "
                                              "database at epoch {}",
                                              report.published.known.epoch));
        return report;
    } catch (const ChainRejected& e) {
        if (d::refusal(e.code())) refused(e, e.epoch(), e.rootSha256());
        cache_ = {};
        throw;
    } catch (...) {
        // A root PUT may have been sent and its reply lost: it can still land, below the current root on a bucket
        // that orders versions by upload start. Read by listing for a while (verifyRemoteVersionLog).
        if (rootPutSent && d::versionLog(*store_)) relistUntil_ = host_.now() + kLateRootWatchSeconds;
        throw;
    }
}

void Session::settleMoved(RemoteHead& out, Loaded&& loaded, const ChainState& state,
                          const std::optional<Known>& knownState) {
    switch (originOf(loaded.root, loaded.acceptance.root_sha256, loaded.base_version_id, knownState, host_.nodeId(),
                     host_.vaultId, state.publishing_roots)) {
    case HeadOrigin::OwnPast:
        // Our own root, PUT and not recorded: the database is at it or past it. Recorded, never reconciled.
        state_->recordRoot({.epoch = loaded.acceptance.epoch,
                            .root_sha256 = loaded.acceptance.root_sha256,
                            .etag = loaded.etag,
                            .sids = session_detail::sidsOf(loaded.root),
                            .version_id = loaded.version_id,
                            .base_version_id = loaded.base_version_id,
                            .settle_window = loaded.settle_window,
                            .own = true,
                            .base = baseCopyOf(loaded.root, loaded.root_bytes, loaded.segments, loaded.snapshots),
                                .writers = loaded.root.writers.value_or(std::vector<std::string>{})});
        if (cache_.base && cache_.base->known != loaded.known()) cache_.base.reset();
        out.adopted = true;
        note(Notice::Info, std::format("recorded this server's own root of epoch {}, which was published but not "
                                       "recorded",
                                       loaded.acceptance.epoch));
        return;
    case HeadOrigin::OwnUnexplained:
        out.own_unexplained = true;
        out.head = std::move(loaded);
        return;
    case HeadOrigin::Foreign:
        if (knownState) adoptBuiltOn(loaded, state, *knownState);
        out.above_floor = writerFloorOf(loaded.root) > host_.writerRevision;
        out.head = std::move(loaded);   // recorded by the apply, not here
        return;
    }
}

void Session::adoptBuiltOn(const Loaded& head, const ChainState& state, const Known& knownState) {
    // Another writer may have built on a root of ours that is PUT and not recorded (noted, its pending base copy kept):
    // then that root, not `known`, is what our database was at, and it must be the apply's base. It is adopted first.
    for (const auto& sha : state.publishing_roots) {
        if (sha == knownState.root_sha256 || sha == head.acceptance.root_sha256) continue;
        const auto copy = state_->pendingBase(sha);
        if (!copy) continue;
        std::optional<RootDocument> root;
        try {
            root = openRoot(copy->root, vaultUid_, host_.keys);
        } catch (const std::exception&) {
            continue;
        }
        if (originOf(*root, sha, std::nullopt, knownState, host_.nodeId(), host_.vaultId, state.publishing_roots) !=
            HeadOrigin::OwnPast)
            continue;
        bool descends = head.root.prev == sha && head.root.epoch == root->epoch + 1;
        if (!descends) {
            try {   // the chain rules from that root: the head must continue it without a gap
                LoadOptions o;
                o.known = Known{root->epoch, sha, std::nullopt};
                o.root_cache = &cache_.roots;
                const auto from = load(*store_, vaultUid_, host_.keys, o);
                descends = !from.acceptance.gap && from.acceptance.root_sha256 == head.acceptance.root_sha256;
            } catch (const std::exception&) {
                descends = false;
            }
        }
        if (!descends) continue;
        if (!openBaseCopy(*copy, vaultUid_, host_.keys, Known{root->epoch, sha, std::nullopt})) continue;
        std::vector<std::string> sids;
        for (const auto& s : root->segments) sids.push_back(s.sid);
        for (const auto& s : root->snapshots) sids.push_back(s.sid);
        state_->recordRoot({.epoch = root->epoch,
                            .root_sha256 = sha,
                            .etag = std::nullopt,
                            .sids = sids,
                            .version_id = std::nullopt,
                            .base_version_id = std::nullopt,
                            .settle_window = {},
                            .own = true,
                            .base = copy,
                            .writers = root->writers.value_or(std::vector<std::string>{})});
        cache_.base.reset();
        note(Notice::Info, std::format("another writer built on this server's own unrecorded root of epoch {}: recorded "
                                       "first, the base of the apply",
                                       root->epoch));
        return;
    }
}

void Session::applied() {
    std::scoped_lock lock(mutex_);
    cache_.base.reset();
    cache_.last_produced.reset();   // the base copy is the recorded head now
    unchanged_.reset();
}

std::optional<RemoteHead> Session::verifyRemoteVersionLog() {
    namespace d = session_detail;
    const auto state = state_->state();
    // A pass that changed nothing still costs one HEAD: the settled head is the current version until someone writes.
    // Not while a root PUT of ours may still land (relistUntil_): it would land below the current version.
    const bool watching = relistUntil_ != 0 && host_.now() < relistUntil_;
    if (!watching) relistUntil_ = 0;
    if (!watching && state.etag && state.epoch && state.root_sha256)
        if (const auto etag = store_->headEtag(std::string(kRootKey)); etag && *etag == *state.etag)
            return RemoteHead{{*state.epoch, *state.root_sha256, false}, std::nullopt};
    const std::optional<Known> knownState = state.epoch && state.root_sha256
        ? std::make_optional(Known{*state.epoch, *state.root_sha256, state.root_version_id})
        : std::nullopt;
    LoadOptions options;
    options.known = knownState;
    options.root_cache = &cache_.roots;
    options.settled = d::settledOf(state);
    options.self_node = host_.nodeId();
    options.self_vault_id = host_.vaultId;
    try {
        auto loaded = load(*store_, vaultUid_, host_.keys, options);
        const auto sids = d::sidsOf(loaded.root);
        RemoteHead out{loaded.acceptance, std::nullopt};
        const bool moved = !knownState || loaded.known() != *knownState;
        if (moved) {
            checkHeadForWriter(loaded.root, loaded.acceptance.root_sha256, *store_, host_.nodeId(), state.own_epoch);
        } else if (loaded.version_id && loaded.version_id != state.root_version_id) {
            // The same root, found by its hash (a state from before version ids were recorded, or recorded by a
            // restore).
            state_->recordRoot({.epoch = loaded.acceptance.epoch,
                                .root_sha256 = loaded.acceptance.root_sha256,
                                .etag = loaded.etag,
                                .sids = sids,
                                .version_id = loaded.version_id,
                                .base_version_id = loaded.base_version_id,
                                .settle_window = loaded.settle_window,
                                .own = false,
                                .base = baseCopyOf(loaded.root, loaded.root_bytes, loaded.segments, loaded.snapshots),
                                .writers = loaded.root.writers.value_or(std::vector<std::string>{})});
        }
        // Repair (spec 06 §5.4): versions newer than the head that aren't on the chain.
        for (const auto& id : loaded.strays) {
            try {
                store_->removeVersion(std::string(kRootKey), id);
            } catch (const std::exception& e) {
                note(Notice::Warning, std::format("a stray root version was not deleted: {}", e.what()));
            }
        }
        if (!loaded.strays.empty())
            note(Notice::Info, std::format("deleted {} stray root version(s) (above the head, or this server's own "
                                           "superseded attempts that landed late below it)",
                                           loaded.strays.size()));
        if (moved) settleMoved(out, std::move(loaded), state, knownState);
        return out;
    } catch (const ChainRejected& e) {
        if (d::refusal(e.code())) refused(e, e.epoch(), e.rootSha256());
        cache_ = {};
        throw;
    } catch (const NoUsableRoot&) {
        return std::nullopt;
    }
}

std::optional<RemoteHead> Session::verifyRemote() {
    namespace d = session_detail;
    std::scoped_lock lock(mutex_);
    const auto state = state_->state();
    if (d::versionLog(*store_)) return verifyRemoteVersionLog();
    // A pass that changed nothing costs one HEAD of the root (spec 01 §5): its ETag still the one we recorded.
    if (state.etag && state.epoch && state.root_sha256)
        if (const auto etag = store_->headEtag(std::string(kRootKey)); etag && *etag == *state.etag)
            return RemoteHead{{*state.epoch, *state.root_sha256, false}, std::nullopt};
    auto obj = store_->get(std::string(kRootKey));
    if (!obj) return std::nullopt;
    if (state.etag && obj->etag && *state.etag == *obj->etag && state.epoch && state.root_sha256)
        return RemoteHead{{*state.epoch, *state.root_sha256, false}, std::nullopt};
    const std::optional<Known> knownState =
        state.epoch && state.root_sha256 ? std::make_optional(Known{*state.epoch, *state.root_sha256}) : std::nullopt;
    try {
        // A full load: it authenticates the segments the new root pins and walks a gap through retained roots.
        auto loaded = load(*store_, vaultUid_, host_.keys, {knownState, true, std::move(obj)});
        RemoteHead out{loaded.acceptance, std::nullopt};
        if (!knownState || loaded.known() != *knownState) {
            // spec 06 §5.5, both modes: a head that excludes this writer after its last own root stops it here.
            checkHeadForWriter(loaded.root, loaded.acceptance.root_sha256, *store_, host_.nodeId(), state.own_epoch);
            settleMoved(out, std::move(loaded), state, knownState);
        }
        return out;
    } catch (const ChainRejected& e) {
        if (d::refusal(e.code())) refused(e, e.epoch(), e.rootSha256());
        cache_ = {};
        throw;
    } catch (const NoUsableRoot&) {
        return std::nullopt;
    }
}

std::optional<GcReport> Session::collectGarbageIfDue(const std::time_t now) {
    namespace d = session_detail;
    std::scoped_lock lock(mutex_);
    const auto state = state_->state();
    if (!state.epoch) return std::nullopt;  // nothing published yet
    if (state.gc_at && now - *state.gc_at < 24 * 60 * 60) return std::nullopt;
    GcReport report;
    if (d::versionLog(*store_)) {
        const UnreferencedClock clock{
            .first = [&](const std::string& sid) { return state_->firstUnreferenced(sid); },
            .forget = [&](const std::string& sid) { state_->forgetUnreferenced(sid); }};
        report = collectGarbageVersionLog(*store_, state_->retainedSids(), now, clock);
        if (state.root_version_id) {
            const auto janitor = collectRootVersions(*store_, vaultUid_, host_.keys, cache_.roots,
                                                     *state.root_version_id, now);
            if (!janitor.deleted.empty())
                note(Notice::Info, std::format("deleted {} superseded root version(s)", janitor.deleted.size()));
        }
    } else {
        report = collectGarbage(*store_, state_->retainedSids(), now);
    }
    state_->markCollected();
    if (!report.deleted.empty())
        note(Notice::Info, std::format("collected {} superseded segment(s)", report.deleted.size()));
    return report;
}

}
