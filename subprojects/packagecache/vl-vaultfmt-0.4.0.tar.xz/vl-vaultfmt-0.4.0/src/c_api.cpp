// SPDX-License-Identifier: AGPL-3.0-or-later
// Copyright (c) 2026 Valkyrian Labs LLC
//
// The C API (include/vl/vaultfmt/vl_vaultfmt.h) over the C++ library: argument checks, the buffer convention, handles,
// sinks and the mapping of every exception to a status. No exception leaves an extern "C" function.
#include "vl/vaultfmt/vl_vaultfmt.h"
#include "vl/vaultfmt/vl_vaultfmt_engine.h"   // its status block (plain C: no engine code here)

#include "c_api_internal.hpp"

#include "vl/vaultfmt/ObjectKeys.hpp"
#include "vl/vaultfmt/manifest/Chain.hpp"
#include "vl/vaultfmt/manifest/Content.hpp"
#include "vl/vaultfmt/manifest/Document.hpp"
#include "vl/vaultfmt/manifest/Objects.hpp"
#include "vl/vaultfmt/manifest/Reader.hpp"
#include "vl/vaultfmt/vaultfmt.hpp"
#include "vl/vaultfmt/vhf1/Format.hpp"
#include "vl/vaultfmt/vhf1/Key.hpp"
#include "vl/vaultfmt/vhf1/Reader.hpp"
#include "vl/vaultfmt/vhf1/Writer.hpp"

#include <vl/keykit/uid.hpp>

#include <nlohmann/json.hpp>

#include <algorithm>
#include <cstring>
#include <map>
#include <memory>
#include <new>
#include <optional>
#include <span>
#include <stdexcept>
#include <string>
#include <string_view>
#include <utility>
#include <vector>

#ifndef VL_VAULTFMT_VERSION
#error "VL_VAULTFMT_VERSION is set by meson.build"
#endif

namespace vf = vl::vaultfmt;

struct vl_vaultfmt_keyring {
    std::map<uint32_t, vf::vhf1::KeyPtr> keys;

    [[nodiscard]] vf::vhf1::KeyLookup lookup() const {
        return [this](const uint32_t version) -> vf::vhf1::KeyPtr {
            const auto it = keys.find(version);
            return it == keys.end() ? nullptr : it->second;
        };
    }
};

struct vl_vaultfmt_sealer {
    vf::vhf1::Salt salt{};
    std::unique_ptr<vf::vhf1::Writer> writer;
    bool broken{false};
};

struct vl_vaultfmt_opener {
    vf::vhf1::OpenedHeader header;
    uint64_t object_size{};
    vf::vhf1::ChunkWalker walker;
    vf::vhf1::RangeReader ranged;
    bool walk_broken{false};
    bool finished{false};
};

struct vl_vaultfmt_root {
    vf::manifest::RootDocument doc;
    vf::manifest::Acceptance acceptance;
    // Per pinned object, the strings its vl_vaultfmt_object_ref points at.
    struct Pin {
        std::string sid, key, sha256;
        uint64_t size{};
        bool snapshot{};
        vf::manifest::Range range{};
    };
    std::vector<Pin> pins;
};

struct vl_vaultfmt_tree {
    vf::manifest::Content content;
};

namespace vl::vaultfmt::capi {

namespace {

static_assert(VL_VAULTFMT_UID_SIZE == vhf1::kUidSize && VL_VAULTFMT_KEY_SIZE == vhf1::kKeySize &&
              VL_VAULTFMT_SALT_SIZE == vhf1::kSaltSize && VL_VAULTFMT_HEADER_SIZE == vhf1::kHeaderSize &&
              VL_VAULTFMT_TAG_SIZE == vhf1::kTagSize && VL_VAULTFMT_CHUNK_LOG2 == vhf1::kWriterChunkLog2);
static_assert(VL_VAULTFMT_KIND_FILE_CONTENT == static_cast<int>(vhf1::Kind::FileContent) &&
              VL_VAULTFMT_KIND_MANIFEST_SEGMENT == static_cast<int>(vhf1::Kind::ManifestSegment) &&
              VL_VAULTFMT_KIND_MANIFEST_ROOT == static_cast<int>(vhf1::Kind::ManifestRoot));
static_assert(VL_VAULTFMT_KEY_CONTENT == static_cast<int>(keys::KeyClass::Content) &&
              VL_VAULTFMT_KEY_METADATA == static_cast<int>(keys::KeyClass::Metadata) &&
              VL_VAULTFMT_KEY_FOREIGN == static_cast<int>(keys::KeyClass::Foreign));
static_assert(VL_VAULTFMT_ENTRY_DIR == static_cast<int>(manifest::EntryKind::Dir) &&
              VL_VAULTFMT_ENTRY_FILE == static_cast<int>(manifest::EntryKind::File) &&
              VL_VAULTFMT_ENTRY_SYMLINK == static_cast<int>(manifest::EntryKind::Symlink) &&
              VL_VAULTFMT_ENTRY_TOMBSTONE == static_cast<int>(manifest::EntryKind::Tombstone));
// The last code of each block: a code added to a C++ enum must be added to the header too (the tests check names).
static_assert(VL_VAULTFMT_ERR_VHF1_CHUNK_AUTH_FAILED == 100 + static_cast<int>(vhf1::ErrorCode::ChunkAuthFailed));
static_assert(VL_VAULTFMT_ERR_CHAIN_PUBLISH_MODE_MISMATCH ==
              300 + static_cast<int>(manifest::ChainError::PublishModeMismatch));

constexpr std::pair<vl_vaultfmt_status, const char*> kStatusNames[] = {
    {VL_VAULTFMT_OK, "ok"},
    {VL_VAULTFMT_ERR_INVALID_ARGUMENT, "invalid_argument"},
    {VL_VAULTFMT_ERR_BUFFER_TOO_SMALL, "buffer_too_small"},
    {VL_VAULTFMT_ERR_OUT_OF_MEMORY, "out_of_memory"},
    {VL_VAULTFMT_ERR_INTERNAL, "internal"},
    {VL_VAULTFMT_ERR_CALLBACK_FAILED, "callback_failed"},
    {VL_VAULTFMT_ERR_NOT_FOUND, "not_found"},
    {VL_VAULTFMT_ERR_UNUSABLE, "unusable"},
    {VL_VAULTFMT_ERR_VHF1_BAD_MAGIC, "vhf1_bad_magic"},
    {VL_VAULTFMT_ERR_VHF1_UNSUPPORTED_VERSION, "vhf1_unsupported_version"},
    {VL_VAULTFMT_ERR_VHF1_BAD_HEADER_LENGTH, "vhf1_bad_header_length"},
    {VL_VAULTFMT_ERR_VHF1_UNSUPPORTED_SUITE, "vhf1_unsupported_suite"},
    {VL_VAULTFMT_ERR_VHF1_BAD_CHUNK_SIZE, "vhf1_bad_chunk_size"},
    {VL_VAULTFMT_ERR_VHF1_RESERVED_NONZERO, "vhf1_reserved_nonzero"},
    {VL_VAULTFMT_ERR_VHF1_KIND_MISMATCH, "vhf1_kind_mismatch"},
    {VL_VAULTFMT_ERR_VHF1_VAULT_MISMATCH, "vhf1_vault_mismatch"},
    {VL_VAULTFMT_ERR_VHF1_OBJECT_MISMATCH, "vhf1_object_mismatch"},
    {VL_VAULTFMT_ERR_VHF1_GENERATION_MISMATCH, "vhf1_generation_mismatch"},
    {VL_VAULTFMT_ERR_VHF1_KEY_UNAVAILABLE, "vhf1_key_unavailable"},
    {VL_VAULTFMT_ERR_VHF1_HEADER_AUTH_FAILED, "vhf1_header_auth_failed"},
    {VL_VAULTFMT_ERR_VHF1_SIZE_UNKNOWN, "vhf1_size_unknown"},
    {VL_VAULTFMT_ERR_VHF1_SIZE_MISMATCH, "vhf1_size_mismatch"},
    {VL_VAULTFMT_ERR_VHF1_BAD_SIZE, "vhf1_bad_size"},
    {VL_VAULTFMT_ERR_VHF1_RANGE_OUT_OF_BOUNDS, "vhf1_range_out_of_bounds"},
    {VL_VAULTFMT_ERR_VHF1_CHUNK_AUTH_FAILED, "vhf1_chunk_auth_failed"},
    {VL_VAULTFMT_ERR_MANIFEST_BAD_ROOT, "manifest_bad_root"},
    {VL_VAULTFMT_ERR_MANIFEST_BAD_SEGMENT, "manifest_bad_segment"},
    {VL_VAULTFMT_ERR_MANIFEST_BAD_SNAPSHOT, "manifest_bad_snapshot"},
    {VL_VAULTFMT_ERR_CHAIN_BAD_ROOT, "chain_bad_root"},
    {VL_VAULTFMT_ERR_CHAIN_ROLLBACK, "chain_rollback"},
    {VL_VAULTFMT_ERR_CHAIN_FORK, "chain_fork"},
    {VL_VAULTFMT_ERR_CHAIN_SEGMENT_MISSING, "chain_segment_missing"},
    {VL_VAULTFMT_ERR_CHAIN_SEGMENT_MISMATCH, "chain_segment_mismatch"},
    {VL_VAULTFMT_ERR_CHAIN_ORDER_VIOLATION, "chain_order_violation"},
    {VL_VAULTFMT_ERR_CHAIN_SUPERSEDED, "chain_superseded"},
    {VL_VAULTFMT_ERR_CHAIN_PUBLISH_MODE_MISMATCH, "chain_publish_mode_mismatch"},
    {VL_VAULTFMT_ERR_KEV1_BAD_MAGIC, "kev1_bad_magic"},
    {VL_VAULTFMT_ERR_KEV1_UNSUPPORTED_VERSION, "kev1_unsupported_version"},
    {VL_VAULTFMT_ERR_KEV1_UNSUPPORTED_SUITE, "kev1_unsupported_suite"},
    {VL_VAULTFMT_ERR_KEV1_BAD_PURPOSE, "kev1_bad_purpose"},
    {VL_VAULTFMT_ERR_KEV1_UNSUPPORTED_RECIPIENT_CLASS, "kev1_unsupported_recipient_class"},
    {VL_VAULTFMT_ERR_KEV1_RESERVED_NONZERO, "kev1_reserved_nonzero"},
    {VL_VAULTFMT_ERR_KEV1_VAULT_MISMATCH, "kev1_vault_mismatch"},
    {VL_VAULTFMT_ERR_KEV1_RECIPIENT_MISMATCH, "kev1_recipient_mismatch"},
    {VL_VAULTFMT_ERR_KEV1_BAD_LENGTH, "kev1_bad_length"},
    {VL_VAULTFMT_ERR_KEV1_BAD_EPHEMERAL, "kev1_bad_ephemeral"},
    {VL_VAULTFMT_ERR_KEV1_WRAP_AUTH_FAILED, "kev1_wrap_auth_failed"},
    {VL_VAULTFMT_ERR_KEV1_BAD_KEY_VERSION, "kev1_bad_key_version"},
    {VL_VAULTFMT_ERR_SEED_BAD_LENGTH, "seed_bad_length"},
    {VL_VAULTFMT_ERR_SEED_BAD_SYMBOL, "seed_bad_symbol"},
    {VL_VAULTFMT_ERR_SEED_BAD_CHECK, "seed_bad_check"},
    {VL_VAULTFMT_ERR_READER_NEED_OBJECTS, "reader_need_objects"},
    {VL_VAULTFMT_ERR_READER_NO_USABLE_ROOT, "reader_no_usable_root"},
    {VL_VAULTFMT_ERR_READER_LIMIT, "reader_limit"},
    {VL_VAULTFMT_ERR_READER_BAD_LISTING, "reader_bad_listing"},
    // The engine's (vl_vaultfmt_engine.h): named here so every build that has the C API, the wasm reader's too, names
    // every code.
    {VL_VAULTFMT_ERR_STORE_FAILED, "store_failed"},
    {VL_VAULTFMT_ERR_STORE_PRECONDITION_FAILED, "store_precondition_failed"},
    {VL_VAULTFMT_ERR_STORE_CONDITIONS_UNSUPPORTED, "store_conditions_unsupported"},
    {VL_VAULTFMT_ERR_STORE_OUTCOME_UNKNOWN, "store_outcome_unknown"},
    {VL_VAULTFMT_ERR_STATE_FAILED, "state_failed"},
    {VL_VAULTFMT_ERR_STATE_TOO_NEW, "state_too_new"},
    {VL_VAULTFMT_ERR_STATE_OTHER_VAULT, "state_other_vault"},
    {VL_VAULTFMT_ERR_PUBLISH_CONFLICT, "publish_conflict"},
    {VL_VAULTFMT_ERR_PUBLISH_UNSETTLED, "publish_unsettled"},
    {VL_VAULTFMT_ERR_PUBLISH_UNSUPPORTED, "publish_unsupported"},
    {VL_VAULTFMT_ERR_NO_USABLE_ROOT, "no_usable_root"},
    {VL_VAULTFMT_ERR_WRITER_FLOOR, "writer_floor"},
    {VL_VAULTFMT_ERR_APPLY_STOPPED, "apply_stopped"},
    {VL_VAULTFMT_ERR_NOT_A_DIRECTORY, "not_a_directory"},
    {VL_VAULTFMT_ERR_NAME_EXISTS, "name_exists"},
    {VL_VAULTFMT_ERR_INVALID_NAME, "invalid_name"},
    {VL_VAULTFMT_ERR_INVALID_MOVE, "invalid_move"},
    {VL_VAULTFMT_ERR_KEY_NOT_ADDED, "key_not_added"},
    {VL_VAULTFMT_ERR_RECIPIENT_REQUIRED, "recipient_required"},
    {VL_VAULTFMT_ERR_KEY_MISMATCH, "key_mismatch"},
    {VL_VAULTFMT_ERR_KEY_VERSION, "key_version"},
    {VL_VAULTFMT_ERR_BAD_ENVELOPE, "bad_envelope"},
    {VL_VAULTFMT_ERR_NO_VAULT, "no_vault"},
    {VL_VAULTFMT_ERR_BUSY, "busy"},
    {VL_VAULTFMT_ERR_WRITERS_REFUSED, "writers_refused"},
};

// A sink that returned non-zero; never leaves this file.
struct SinkFailed {};

struct InvalidArgument {};

vl_vaultfmt_status formatStatus(const std::string& code) {
    if (code == "bad_segment") return VL_VAULTFMT_ERR_MANIFEST_BAD_SEGMENT;
    if (code == "bad_snapshot") return VL_VAULTFMT_ERR_MANIFEST_BAD_SNAPSHOT;
    return VL_VAULTFMT_ERR_MANIFEST_BAD_ROOT;
}

// Runs `f`, mapping every exception to its status. Library exceptions carry their code; std::invalid_argument is what
// the C++ API throws for arguments it refuses.
template <class F>
vl_vaultfmt_status guarded(F&& f) noexcept {
    try {
        return f();
    } catch (const SinkFailed&) {
        return VL_VAULTFMT_ERR_CALLBACK_FAILED;
    } catch (const InvalidArgument&) {
        return VL_VAULTFMT_ERR_INVALID_ARGUMENT;
    } catch (const vhf1::Error& e) {
        return 100 + static_cast<vl_vaultfmt_status>(e.code());
    } catch (const manifest::ChainRejected& e) {
        return 300 + static_cast<vl_vaultfmt_status>(e.code());
    } catch (const manifest::FormatError& e) {
        return formatStatus(e.code());
    } catch (const std::invalid_argument&) {
        return VL_VAULTFMT_ERR_INVALID_ARGUMENT;
    } catch (const std::bad_alloc&) {
        return VL_VAULTFMT_ERR_OUT_OF_MEMORY;
    } catch (...) {
        return VL_VAULTFMT_ERR_INTERNAL;
    }
}

vl_vaultfmt_status writeOut(const std::string_view bytes, char* out, size_t* outLen) {
    if (!outLen) return VL_VAULTFMT_ERR_INVALID_ARGUMENT;
    if (*outLen < bytes.size() || (!out && !bytes.empty())) {
        *outLen = bytes.size();
        return VL_VAULTFMT_ERR_BUFFER_TOO_SMALL;
    }
    if (!bytes.empty()) std::memcpy(out, bytes.data(), bytes.size());
    *outLen = bytes.size();
    return VL_VAULTFMT_OK;
}

std::span<const uint8_t> bytesOf(const uint8_t* p, const size_t n) {
    if (!p && n) throw InvalidArgument{};
    return {p, n};
}

std::string_view textOf(const char* p, const size_t n) {
    if (!p && n) throw InvalidArgument{};
    return {p ? p : "", n};
}

vhf1::Uid uidOf(const uint8_t* p) {
    if (!p) throw InvalidArgument{};
    vhf1::Uid u{};
    std::memcpy(u.data(), p, u.size());
    return u;
}

// The C++ sink over a C one: a non-zero return becomes SinkFailed.
auto adapt(const vl_vaultfmt_sink_fn sink, void* ctx) {
    return [sink, ctx](const std::span<const uint8_t> bytes) {
        if (sink(ctx, bytes.data(), bytes.size()) != 0) throw SinkFailed{};
    };
}

const char* cstrOr(const std::optional<std::string>& s) { return s ? s->c_str() : nullptr; }

}

// For the reader's entry points (src/c_api_reader.cpp, through src/c_api_internal.hpp).
vhf1::KeyLookup keyLookupOf(const vl_vaultfmt_keyring& ring) { return ring.lookup(); }
const manifest::Content& treeContent(const vl_vaultfmt_tree& tree) { return tree.content; }

}

namespace capi = vl::vaultfmt::capi;

extern "C" {

const char* vl_vaultfmt_version(void) { return VL_VAULTFMT_VERSION; }

const char* vl_vaultfmt_status_name(const vl_vaultfmt_status status) {
    for (const auto& [code, name] : capi::kStatusNames)
        if (code == status) return name;
    return "unknown";
}

// ---- keys ---------------------------------------------------------------------------------------------------------

vl_vaultfmt_status vl_vaultfmt_keyring_new(vl_vaultfmt_keyring** out) {
    if (!out) return VL_VAULTFMT_ERR_INVALID_ARGUMENT;
    *out = nullptr;
    return capi::guarded([&] {
        *out = new vl_vaultfmt_keyring{};
        return VL_VAULTFMT_OK;
    });
}

vl_vaultfmt_status vl_vaultfmt_keyring_add(vl_vaultfmt_keyring* ring, const uint32_t key_version, const uint8_t* key,
                                           const size_t key_len) {
    if (!ring || !key || key_len != VL_VAULTFMT_KEY_SIZE || key_version == 0) return VL_VAULTFMT_ERR_INVALID_ARGUMENT;
    return capi::guarded([&] {
        ring->keys[key_version] = std::make_shared<const vf::vhf1::Key>(std::span(key, key_len));
        return VL_VAULTFMT_OK;
    });
}

void vl_vaultfmt_keyring_free(vl_vaultfmt_keyring* ring) { delete ring; }

// ---- object keys --------------------------------------------------------------------------------------------------

vl_vaultfmt_status vl_vaultfmt_content_key(const uint8_t uid[16], char* out, size_t* out_len) {
    return capi::guarded([&] { return capi::writeOut(vf::keys::contentKey(capi::uidOf(uid)), out, out_len); });
}

vl_vaultfmt_status vl_vaultfmt_content_key_uid(const char* key, const size_t key_len, uint8_t uid[16]) {
    if (!uid) return VL_VAULTFMT_ERR_INVALID_ARGUMENT;
    return capi::guarded([&] {
        const auto u = vf::keys::uidOfContentKey(capi::textOf(key, key_len));
        if (!u) return VL_VAULTFMT_ERR_NOT_FOUND;
        std::memcpy(uid, u->data(), u->size());
        return VL_VAULTFMT_OK;
    });
}

vl_vaultfmt_status vl_vaultfmt_segment_key(const uint8_t sid[16], char* out, size_t* out_len) {
    return capi::guarded([&] { return capi::writeOut(vf::manifest::segmentKey(vf::manifest::uidText(capi::uidOf(sid))), out, out_len); });
}

int32_t vl_vaultfmt_classify_key(const char* key, const size_t key_len) {
    if (!key && key_len) return VL_VAULTFMT_KEY_FOREIGN;
    try {
        return static_cast<int32_t>(vf::keys::classify({key ? key : "", key_len}));
    } catch (...) {
        return VL_VAULTFMT_KEY_FOREIGN;
    }
}

uint64_t vl_vaultfmt_part_size(const uint64_t object_size) {
    try {
        return vf::keys::partSizeFor(object_size);
    } catch (...) {
        return 0;
    }
}

// ---- VHF1: sealing ------------------------------------------------------------------------------------------------

uint64_t vl_vaultfmt_object_size(const uint64_t plaintext_size, const uint8_t chunk_log2) {
    if (chunk_log2 < vf::vhf1::kMinChunkLog2 || chunk_log2 > vf::vhf1::kMaxChunkLog2) return 0;
    try {
        return vf::vhf1::objectSizeFor(plaintext_size, chunk_log2);
    } catch (...) {
        return 0;
    }
}

vl_vaultfmt_status vl_vaultfmt_sealer_new(const vl_vaultfmt_keyring* ring, const uint32_t key_version,
                                          const uint8_t vault_uid[16], const uint8_t object_uid[16],
                                          const vl_vaultfmt_sink_fn sink, void* ctx, vl_vaultfmt_sealer** out) {
    if (!out) return VL_VAULTFMT_ERR_INVALID_ARGUMENT;
    *out = nullptr;
    if (!ring || !sink || !vault_uid || !object_uid || key_version == 0) return VL_VAULTFMT_ERR_INVALID_ARGUMENT;
    return capi::guarded([&] {
        const auto key = ring->lookup()(key_version);
        if (!key) return VL_VAULTFMT_ERR_VHF1_KEY_UNAVAILABLE;
        auto s = std::make_unique<vl_vaultfmt_sealer>();
        vf::vhf1::HeaderParams params;
        params.kind = vf::vhf1::Kind::FileContent;
        params.keyVersion = key_version;
        params.vaultUid = capi::uidOf(vault_uid);
        params.objectUid = capi::uidOf(object_uid);
        params.salt = vf::vhf1::freshSalt();
        s->salt = params.salt;
        s->writer = std::make_unique<vf::vhf1::Writer>(params, *key, capi::adapt(sink, ctx));
        *out = s.release();
        return VL_VAULTFMT_OK;
    });
}

vl_vaultfmt_status vl_vaultfmt_sealer_write(vl_vaultfmt_sealer* sealer, const uint8_t* plaintext, const size_t len) {
    if (!sealer) return VL_VAULTFMT_ERR_INVALID_ARGUMENT;
    if (sealer->broken || sealer->writer->finished()) return VL_VAULTFMT_ERR_UNUSABLE;
    const auto status = capi::guarded([&] {
        sealer->writer->write(capi::bytesOf(plaintext, len));
        return VL_VAULTFMT_OK;
    });
    if (status != VL_VAULTFMT_OK && status != VL_VAULTFMT_ERR_INVALID_ARGUMENT) sealer->broken = true;
    return status;
}

vl_vaultfmt_status vl_vaultfmt_sealer_finish(vl_vaultfmt_sealer* sealer, uint64_t* object_size) {
    if (!sealer) return VL_VAULTFMT_ERR_INVALID_ARGUMENT;
    if (sealer->broken || sealer->writer->finished()) return VL_VAULTFMT_ERR_UNUSABLE;
    const auto status = capi::guarded([&] {
        sealer->writer->finish();
        if (object_size) *object_size = sealer->writer->objectSize();
        return VL_VAULTFMT_OK;
    });
    if (status != VL_VAULTFMT_OK) sealer->broken = true;
    return status;
}

vl_vaultfmt_status vl_vaultfmt_sealer_generation(const vl_vaultfmt_sealer* sealer, uint8_t salt[32]) {
    if (!sealer || !salt) return VL_VAULTFMT_ERR_INVALID_ARGUMENT;
    std::memcpy(salt, sealer->salt.data(), sealer->salt.size());
    return VL_VAULTFMT_OK;
}

void vl_vaultfmt_sealer_free(vl_vaultfmt_sealer* sealer) { delete sealer; }

// ---- VHF1: opening ------------------------------------------------------------------------------------------------

vl_vaultfmt_status vl_vaultfmt_opener_new(const uint8_t* header, const size_t header_len,
                                          const vl_vaultfmt_expectation* expect, const vl_vaultfmt_keyring* ring,
                                          const uint64_t object_size, vl_vaultfmt_opener** out) {
    if (!out) return VL_VAULTFMT_ERR_INVALID_ARGUMENT;
    *out = nullptr;
    if (!expect || !ring || !expect->vault_uid) return VL_VAULTFMT_ERR_INVALID_ARGUMENT;
    if (expect->kind < VL_VAULTFMT_KIND_FILE_CONTENT || expect->kind > VL_VAULTFMT_KIND_MANIFEST_ROOT)
        return VL_VAULTFMT_ERR_INVALID_ARGUMENT;
    return capi::guarded([&] {
        vf::vhf1::Expectation e;
        e.kind = static_cast<vf::vhf1::Kind>(expect->kind);
        e.vaultUid = capi::uidOf(expect->vault_uid);
        if (expect->object_uid) e.objectUid = capi::uidOf(expect->object_uid);
        if (expect->generation) {
            vf::vhf1::Salt salt{};
            std::memcpy(salt.data(), expect->generation, salt.size());
            e.generation = salt;
        }
        auto opened = vf::vhf1::openHeader(capi::bytesOf(header, header_len), e, ring->lookup());
        *out = new vl_vaultfmt_opener{opened, object_size, vf::vhf1::ChunkWalker(opened, object_size),
                                      vf::vhf1::RangeReader(opened, object_size, object_size)};
        return VL_VAULTFMT_OK;
    });
}

vl_vaultfmt_status vl_vaultfmt_opener_info(const vl_vaultfmt_opener* opener, vl_vaultfmt_header_info* out) {
    if (!opener || !out) return VL_VAULTFMT_ERR_INVALID_ARGUMENT;
    const auto& p = opener->header.params();
    vl_vaultfmt_header_info info{};
    info.kind = static_cast<int32_t>(p.kind);
    info.key_version = p.keyVersion;
    std::memcpy(info.vault_uid, p.vaultUid.data(), sizeof info.vault_uid);
    std::memcpy(info.object_uid, p.objectUid.data(), sizeof info.object_uid);
    std::memcpy(info.salt, p.salt.data(), sizeof info.salt);
    info.chunk_log2 = p.chunkLog2;
    info.plaintext_size = opener->walker.layout().plaintextSize;
    info.chunk_count = opener->walker.layout().chunkCount;
    *out = info;
    return VL_VAULTFMT_OK;
}

vl_vaultfmt_status vl_vaultfmt_opener_update(vl_vaultfmt_opener* opener, const uint8_t* sealed, const size_t len,
                                             const vl_vaultfmt_sink_fn sink, void* ctx) {
    if (!opener || !sink) return VL_VAULTFMT_ERR_INVALID_ARGUMENT;
    if (opener->walk_broken || opener->finished) return VL_VAULTFMT_ERR_UNUSABLE;
    const auto status = capi::guarded([&] {
        const auto pass = capi::adapt(sink, ctx);
        opener->walker.update(capi::bytesOf(sealed, len),
                              [&](uint64_t, const std::span<const uint8_t> plaintext) { pass(plaintext); });
        return VL_VAULTFMT_OK;
    });
    if (status == VL_VAULTFMT_ERR_CALLBACK_FAILED) opener->walk_broken = true;
    return status;
}

vl_vaultfmt_status vl_vaultfmt_opener_finish(vl_vaultfmt_opener* opener) {
    if (!opener) return VL_VAULTFMT_ERR_INVALID_ARGUMENT;
    if (opener->walk_broken || opener->finished) return VL_VAULTFMT_ERR_UNUSABLE;
    const auto status = capi::guarded([&] {
        opener->walker.finish();
        return VL_VAULTFMT_OK;
    });
    if (status == VL_VAULTFMT_OK) opener->finished = true;
    return status;
}

vl_vaultfmt_status vl_vaultfmt_range_plan(const vl_vaultfmt_opener* opener, const uint64_t start, const uint64_t end,
                                          uint64_t* offset, uint64_t* length) {
    if (!opener || !offset || !length) return VL_VAULTFMT_ERR_INVALID_ARGUMENT;
    return capi::guarded([&] {
        const auto plan = opener->ranged.plan(start, end);
        *offset = plan.objectRange ? plan.objectRange->begin : 0;
        *length = plan.objectRange ? plan.objectRange->size() : 0;
        return VL_VAULTFMT_OK;
    });
}

vl_vaultfmt_status vl_vaultfmt_range_read(vl_vaultfmt_opener* opener, const uint64_t start, const uint64_t end,
                                          const uint64_t provider_size, const uint8_t* window, const size_t window_len,
                                          const vl_vaultfmt_sink_fn sink, void* ctx) {
    if (!opener || !sink) return VL_VAULTFMT_ERR_INVALID_ARGUMENT;
    if (provider_size != opener->object_size) return VL_VAULTFMT_ERR_VHF1_SIZE_MISMATCH;
    return capi::guarded([&] {
        const auto plaintext = opener->ranged.read(start, end, capi::bytesOf(window, window_len));
        capi::adapt(sink, ctx)(plaintext.span());
        return VL_VAULTFMT_OK;
    });
}

void vl_vaultfmt_opener_free(vl_vaultfmt_opener* opener) { delete opener; }

// ---- manifest: root -----------------------------------------------------------------------------------------------

vl_vaultfmt_status vl_vaultfmt_root_open(const uint8_t* object, const size_t object_len, const uint8_t vault_uid[16],
                                         const vl_vaultfmt_keyring* ring, const vl_vaultfmt_known* known,
                                         vl_vaultfmt_root** out) {
    if (!out) return VL_VAULTFMT_ERR_INVALID_ARGUMENT;
    *out = nullptr;
    if (!ring || !vault_uid) return VL_VAULTFMT_ERR_INVALID_ARGUMENT;
    if (known && (!known->root_sha256 || std::strlen(known->root_sha256) < VL_VAULTFMT_SHA256_HEX_SIZE))
        return VL_VAULTFMT_ERR_INVALID_ARGUMENT;
    return capi::guarded([&] {
        const auto bytes = capi::bytesOf(object, object_len);
        auto r = std::make_unique<vl_vaultfmt_root>();
        r->doc = vf::manifest::openRoot(bytes, capi::uidOf(vault_uid), ring->lookup());
        std::optional<vf::manifest::Known> k;
        if (known) k = vf::manifest::Known{known->epoch, std::string(known->root_sha256, VL_VAULTFMT_SHA256_HEX_SIZE)};
        r->acceptance = vf::manifest::checkChain(r->doc, vf::manifest::sha256Hex(bytes), k);
        for (const auto& s : r->doc.segments)
            r->pins.push_back({s.sid, vf::manifest::segmentKey(s.sid), s.object_sha256, s.size, false, s.range});
        for (const auto& s : r->doc.snapshots)
            r->pins.push_back({s.sid, vf::manifest::segmentKey(s.sid), s.object_sha256, s.size, true, {}});
        *out = r.release();
        return VL_VAULTFMT_OK;
    });
}

vl_vaultfmt_status vl_vaultfmt_root_info_get(const vl_vaultfmt_root* root, vl_vaultfmt_root_info* out) {
    if (!root || !out) return VL_VAULTFMT_ERR_INVALID_ARGUMENT;
    vl_vaultfmt_root_info info{};
    info.epoch = root->acceptance.epoch;
    const auto& sha = root->acceptance.root_sha256;
    std::memcpy(info.root_sha256, sha.data(), std::min(sha.size(), sizeof info.root_sha256 - 1));
    info.gap = root->acceptance.gap ? 1 : 0;
    info.version_log = root->doc.publish == vf::manifest::kPublishVersionLog ? 1 : 0;
    info.files = root->doc.stats.files;
    info.dirs = root->doc.stats.dirs;
    info.bytes = root->doc.stats.bytes;
    *out = info;
    return VL_VAULTFMT_OK;
}

size_t vl_vaultfmt_root_object_count(const vl_vaultfmt_root* root) { return root ? root->pins.size() : 0; }

vl_vaultfmt_status vl_vaultfmt_root_object(const vl_vaultfmt_root* root, const size_t index,
                                           vl_vaultfmt_object_ref* out) {
    if (!root || !out) return VL_VAULTFMT_ERR_INVALID_ARGUMENT;
    if (index >= root->pins.size()) return VL_VAULTFMT_ERR_NOT_FOUND;
    const auto& p = root->pins[index];
    *out = vl_vaultfmt_object_ref{p.sid.c_str(), p.key.c_str(), p.sha256.c_str(), p.size, p.snapshot ? 1 : 0,
                                  p.range.lo, p.range.hi};
    return VL_VAULTFMT_OK;
}

void vl_vaultfmt_root_free(vl_vaultfmt_root* root) { delete root; }

// ---- manifest: tree -----------------------------------------------------------------------------------------------

vl_vaultfmt_status vl_vaultfmt_tree_build(const vl_vaultfmt_root* root, const vl_vaultfmt_object_bytes* objects,
                                          const size_t count, const vl_vaultfmt_keyring* ring, vl_vaultfmt_tree** out) {
    if (!out) return VL_VAULTFMT_ERR_INVALID_ARGUMENT;
    *out = nullptr;
    if (!root || !ring || (!objects && count)) return VL_VAULTFMT_ERR_INVALID_ARGUMENT;
    return capi::guarded([&] {
        std::map<std::string, std::vector<uint8_t>> bySid;
        for (size_t i = 0; i < count; ++i) {
            const auto sid = capi::textOf(objects[i].sid, objects[i].sid ? std::strlen(objects[i].sid) : 0);
            const auto bytes = capi::bytesOf(objects[i].bytes, objects[i].len);
            bySid.emplace(std::string(sid), std::vector<uint8_t>(bytes.begin(), bytes.end()));
        }
        const auto find = [&](const std::string& sid) -> const std::vector<uint8_t>* {
            const auto it = bySid.find(sid);
            return it == bySid.end() ? nullptr : &it->second;
        };
        const auto vault = vf::manifest::parseUid(root->doc.vault_uid, "bad_root", "vault_uid");
        const auto lookup = ring->lookup();
        std::vector<vf::manifest::SegmentDocument> segments;
        std::vector<vf::manifest::SnapshotDocument> snapshots;
        for (const auto& ref : root->doc.segments) {
            const auto* bytes = find(ref.sid);
            vf::manifest::checkSegment(ref, bytes);
            segments.push_back(vf::manifest::openSegment(*bytes, vault, vf::manifest::parseUid(ref.sid, "bad_root", "sid"),
                                                         lookup));
        }
        for (const auto& ref : root->doc.snapshots) {
            const auto* bytes = find(ref.sid);
            vf::manifest::checkSnapshot(ref, bytes);
            snapshots.push_back(vf::manifest::openSnapshot(
                *bytes, vault, vf::manifest::parseUid(ref.sid, "bad_root", "sid"), lookup));
        }
        auto t = std::make_unique<vl_vaultfmt_tree>();
        t->content = vf::manifest::contentOf(root->doc, segments, snapshots);
        *out = t.release();
        return VL_VAULTFMT_OK;
    });
}

size_t vl_vaultfmt_tree_entry_count(const vl_vaultfmt_tree* tree) { return tree ? tree->content.entries.size() : 0; }

vl_vaultfmt_status vl_vaultfmt_tree_entry(const vl_vaultfmt_tree* tree, const size_t index, vl_vaultfmt_entry* out) {
    if (!tree || !out) return VL_VAULTFMT_ERR_INVALID_ARGUMENT;
    if (index >= tree->content.entries.size()) return VL_VAULTFMT_ERR_NOT_FOUND;
    const auto& e = tree->content.entries[index];
    vl_vaultfmt_entry r{};
    r.uid = e.uid.c_str();
    r.kind = static_cast<int32_t>(e.kind);
    r.parent = capi::cstrOr(e.parent);
    r.name = e.name.c_str();
    r.name_len = e.name.size();
    r.trashed = e.trashed ? 1 : 0;
    r.has_size = e.size ? 1 : 0;
    r.size = e.size.value_or(0);
    r.mode = e.mode.value_or(0);
    r.key_version = e.key_version.value_or(0);
    r.mtime = capi::cstrOr(e.mtime);
    r.generation = capi::cstrOr(e.generation);
    r.target = capi::cstrOr(e.target);
    r.has_object = e.object ? 1 : 0;
    r.object_size = e.object ? e.object->size : 0;
    r.version_id = e.object ? capi::cstrOr(e.object->version_id) : nullptr;
    *out = r;
    return VL_VAULTFMT_OK;
}

vl_vaultfmt_status vl_vaultfmt_tree_find(const vl_vaultfmt_tree* tree, const char* uid, const size_t uid_len,
                                         size_t* index) {
    if (!tree || !index) return VL_VAULTFMT_ERR_INVALID_ARGUMENT;
    return capi::guarded([&] {
        const auto want = capi::textOf(uid, uid_len);
        const auto& entries = tree->content.entries;
        const auto it = std::lower_bound(entries.begin(), entries.end(), want,
                                         [](const auto& e, const std::string_view u) { return e.uid < u; });
        if (it == entries.end() || it->uid != want) return VL_VAULTFMT_ERR_NOT_FOUND;
        *index = static_cast<size_t>(it - entries.begin());
        return VL_VAULTFMT_OK;
    });
}

vl_vaultfmt_status vl_vaultfmt_tree_children(const vl_vaultfmt_tree* tree, const char* parent, const size_t parent_len,
                                             size_t* out, size_t* out_len) {
    if (!tree || !out_len) return VL_VAULTFMT_ERR_INVALID_ARGUMENT;
    return capi::guarded([&] {
        const auto want = capi::textOf(parent, parent_len);
        std::vector<size_t> found;
        for (size_t i = 0; i < tree->content.entries.size(); ++i)
            if (const auto& p = tree->content.entries[i].parent; p && *p == want) found.push_back(i);
        if (*out_len < found.size() || (!out && !found.empty())) {
            *out_len = found.size();
            return VL_VAULTFMT_ERR_BUFFER_TOO_SMALL;
        }
        std::copy(found.begin(), found.end(), out);
        *out_len = found.size();
        return VL_VAULTFMT_OK;
    });
}

vl_vaultfmt_status vl_vaultfmt_tree_json(const vl_vaultfmt_tree* tree, char* out, size_t* out_len) {
    if (!tree) return VL_VAULTFMT_ERR_INVALID_ARGUMENT;
    return capi::guarded([&] {
        auto array = nlohmann::json::array();
        for (const auto& e : tree->content.entries) array.push_back(vf::manifest::toJson(e));
        return capi::writeOut(vf::manifest::canonicalJson(array), out, out_len);
    });
}

void vl_vaultfmt_tree_free(vl_vaultfmt_tree* tree) { delete tree; }

}

namespace vl::vaultfmt {

const char* version() noexcept { return VL_VAULTFMT_VERSION; }

}
