# vl-vaultfmt

Vaulthalla's vault format for C++23, in one library shared by Vaulthalla Server, the Desktop-only engine and the
portal's browser reader, so the rules that decide what a bucket holds cannot exist twice:

- **VHF1** (`vl/vaultfmt/vhf1/`): the versioned, self-describing authenticated file format. `Format.hpp` (header codec,
  HKDF key schedule, size math, ordered error codes), `Writer.hpp` (streaming sealing), `Reader.hpp` (whole, streamed
  and authenticated ranged reads), `Key.hpp` (the 256-bit key type, locked and wiped), `Aead.hpp` (AES-256-GCM chunks).
- **Object keys** (`vl/vaultfmt/ObjectKeys.hpp`, `vl::vaultfmt::keys`): the keys of an opaque_v1 bucket (`o/<uid>`,
  `.vaulthalla/...`), the allowlist every request is held to, and the multipart part size.
- **The encrypted manifest** (`vl/vaultfmt/manifest/`): the root, segment and snapshot documents (`Document`), a vault's
  content and the pending-changes merge (`Content`), segment partitioning (`Partition`), sealing and opening
  (`Objects`), the reader's chain rules (`Chain`), the version log of buckets without conditional writes
  (`VersionLog`), loading with every fallback and the blind rebuild (`Reader`), publishing in both modes with GC and the
  root janitor (`Publisher`), the three-way apply plan (`Reconcile`), the decision logic of a writer over a `StateStore`
  (`Session`), and the `ObjectStore` seam a consumer implements over its bucket (`Store`, `WriteCapability`).
- **The database-free engine** (`vl/vaultfmt/engine/`, `docs/engine.md`): one opaque_v1 vault kept in its bucket with
  no server and no database, as Vaulthalla Desktop runs a Desktop-only vault. The working content (the last settled
  content plus a journal of local changes) and the chain position live in one state blob per vault (`StateFile`,
  checksummed and versioned; `FileStateBlob` writes it atomically with `F_FULLFSYNC`); the operations are list, stat,
  changes since an anchor, authenticated ranged reads, streamed writes, mkdir, rename, move, trash, restore, purge,
  key versions with their envelopes PUT first, refresh (another writer's root reconciled in by the server applier's
  rules), publish in the vault's mode, GC and the janitor. It is the server's own `Session`, `publish`, `load` and
  `reconcile` over that state, not a second implementation.
- **Test doubles** (`vl/vaultfmt/testing/`, header-only): an in-memory versioned `ObjectStore` that answers as S3,
  Backblaze B2 and R2 do (and breaks their ordering assumptions on purpose), a hooking wrapper for schedulers, and the
  engine's doubles (an in-memory `BucketStore`, a hooking one, a state blob that crashes and tears).

And for callers that can't use C++: a **C API** (`vl/vaultfmt/vl_vaultfmt.h`, plain C11) with opaque handles (vault
keys live only in a wiped keyring), stable status codes and sinks: streamed VHF1 sealing and opening, ranged reads,
object keys, and a manifest root and its segments opened from bytes into a tree to iterate or export as JSON. Its
reader part (the canonical head over a version listing, KEV1 unwrapping, the tree as JSON, content bound to its entry)
is also built to **WebAssembly** for the portal's browser reader: `wasm/` (see its README).

The engine has its own header (`vl/vaultfmt/vl_vaultfmt_engine.h`): the store, keys and state as callback tables, a vault
handle for every operation above, listings, streamed writes, and statuses with stable names. For Swift,
`scripts/build-xcframework.sh` builds `VLVaultfmt.xcframework` (static arm64, OpenSSL and vl-keykit inside, a module map
for `import VLVaultfmt`); `tests/apple/run.sh` builds it and runs a Swift check against it.

**The engine's guarantees** (each proved by a test, listed in `docs/engine.md`): an operation that returned is durable
and one that threw never happened; nothing is published over a refused root, a head not yet applied, or a root above
the engine's writer revision; a crash between a root's PUT and its record, a PUT that lands late (also where Backblaze
puts it, below roots recorded since), and another writer
building on our unrecorded root each end with every local change kept; a lost Mac loses at most the names of changes
not yet published (finished writes come back under `/Recovered`, keys are never lost); only authenticated chunks reach
a read. **Its limits:** one writer on a version_log bucket (a second Mac's join is refused: Backblaze orders versions
by upload start), no key hand-over between installations, no recovery grants written, no orphan collection while
several writers are named, and a bucket without versions keeps only one generation of a two-sided edit.

**The writer floor.** A root may name `writer_floor`, the lowest writer revision allowed to write over it; a writer
below it reads but neither publishes nor takes the root into its store (`docs/engine.md`, "The writer floor", with what
vaulthalla-server must do; vectors in `vectors/writer_floor.json`).

The code came from vaulthalla-server (`core/{include,src}/crypto/vhf1/`, `sync/manifest/`, `storage/ObjectKeys`, at
fc636330) and is byte-compatible with it. Specifications: vaulthalla-server `design/encryption/` (02 for VHF1, 01 for
object keys, 03 for the manifest, 06 for publishing without preconditions) and `design/sync/manifest-applier.md`;
paths such as `design/...` in the code's comments name that repository. Golden vectors: `vectors/` (see its README).

Dependencies: OpenSSL 3 (libcrypto), nlohmann_json and vl-keykit (uids, `SecretBytes`, wiping, constant-time
comparison, KEV1 object keys); GoogleTest for the tests. Standing alone, vl-keykit comes from the release pinned in
`subprojects/vl-keykit.wrap`, whose tarball is committed under `subprojects/packagecache/` (no network needed).

```bash
meson setup build -Db_sanitize=address,undefined && meson compile -C build && meson test -C build --print-errorlogs
CXX=clang++-18 meson setup build-fuzz -Dfuzz=true -Db_sanitize=address,undefined -Db_lundef=false  # fuzz/fuzz_vhf1
tests/apple/run.sh                                         # macOS: VLVaultfmt.xcframework and its Swift check
```

Consume it as a meson subproject (`dependency('vl-vaultfmt', fallback: ['vl-vaultfmt', 'vl_vaultfmt_dep'])`) or through
pkg-config (`vl-vaultfmt`). The `vectors_dir` variable of `vl_vaultfmt_dep` names `vectors/` for a consumer that
checks its own copy of the vectors against this one.

© 2026 Valkyrian Labs LLC. GNU Affero General Public License, version 3 or later (see `LICENSE` and `NOTICE`).
