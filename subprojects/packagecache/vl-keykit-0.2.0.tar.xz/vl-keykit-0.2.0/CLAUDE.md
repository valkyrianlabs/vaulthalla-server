# vl-keykit

Vaulthalla's key-recovery formats (KEV1 envelopes, recovery seed, recovery kit, uids, locked secrets) for C++23,
extracted from vaulthalla-server `core/{include,src}/crypto/recovery/` and shared by vaulthalla-server and
vaulthalla-cloud. Owner: **Valkyrian Labs LLC**. License: **MIT** (`Copyright (c) 2026 Valkyrian Labs LLC`).
Repository: `valkyrianlabs/vl-keykit` (private).

## Map

| Path | What |
| --- | --- |
| `include/vl/keykit/` | public headers: `secret`, `uid`, `kev1`, `seed`, `kit`; the cloud formats `account_key`, `recovery_policy`, `kak1`, `vault_label`, `storage_credential`; `base64url`; umbrella `keykit.hpp`. Each format's header is its normative text |
| `src/` | implementation; private helpers: `openssl.{hpp,cpp}` (SHA-256, HKDF, CSPRNG, raw public keys, Ed25519), `sealing.{hpp,cpp}` (the ECDH + HKDF + AES-GCM construction KEV1, KAK1, labels and credentials share), `text.{hpp,cpp}` (strict line-format parsing, base64url) |
| `tests/` | GoogleTest suite against `vectors/vectors.json` and `vectors/vhc.json`, plus the `vectors-reference` and `vhc-vectors-reference` Python checks |
| `vectors/` | `vectors.json`: verbatim copy of vaulthalla-server `design/encryption/vectors/`; `vhc.json`: this repository's own vectors for the cloud formats (see its README) |
| `ci/` | `run-ci` (verbatim from vaulthalla-server), `Containerfile` |

## Commands

```bash
meson setup build -Db_sanitize=address,undefined && meson compile -C build && meson test -C build --print-errorlogs
# macOS: PKG_CONFIG_PATH=$(brew --prefix openssl@3)/lib/pkgconfig:/opt/homebrew/lib/pkgconfig:/opt/homebrew/share/pkgconfig meson setup build-mac
CI_CACHE_NAMES=ccache ./ci/run-ci meson test -C build   # the CI container (Podman); run it on `ssh dev`
```

## Rules

- **Licensing.** MIT. Every source file (C++, meson, scripts, workflows) starts with `// SPDX-License-Identifier: MIT`
  (or `#`) and `Copyright (c) 2026 Valkyrian Labs LLC`; `vectors/` is a verbatim copy and keeps the upstream bytes.
  Code may be taken from Vaulthalla (AGPL) only because the LLC owns both; never import third-party code.
- **Scope.** Namespace `vl::keykit` (`vl::keykit::kev1` for envelopes). Dependencies: OpenSSL 3 and nlohmann_json
  only. No libsodium, no Boost, no I/O, no logging. The only global is the test wipe observer.
- **Formats are frozen by the vectors.** Output must stay byte-for-byte equal to `vectors/vectors.json` and
  `vectors/vhc.json`. A KEV1, seed or kit change starts in vaulthalla-server's spec and vectors, then is copied here.
  The cloud formats (`vhc.json`) are defined here: a change edits the format header, `vhc_vectors.py` and the C++
  together. Never edit an expected vector to get green. Reserved KEV1 purposes and recipient classes stay refused until a separately approved design adds one.
- **Secrets.** Every secret the library returns is `SecretBytes`; temporaries are wiped on every path
  (`WipeOnExit`, `wipe`); comparisons of secret-dependent bytes use `equalConstantTime`. Never log or put a secret
  in an exception message.
- **Builds are silent.** Zero warnings on GCC 14 and clang at `warning_level=3`; fix causes, never suppress.
- **Tests with every change**, positive vectors and the negative path; the suite passes under ASan/UBSan.
- **Git.** Changes land on `main` through PRs and CI. Tags and releases (`vX.Y.Z`, the tarball consumers pin) only
  with Cooper's go-ahead. Keep `ci/run-ci` identical to vaulthalla-server's.
