// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Valkyrian Labs LLC
#pragma once

#include "vl/keykit/seed.hpp"

#include <array>
#include <cstddef>
#include <cstdint>
#include <optional>
#include <span>
#include <stdexcept>
#include <string>
#include <string_view>
#include <vector>

// The Vaulthalla Cloud account recovery key (vaulthalla-cloud docs/design/key-manager.md, vaulthalla-server
// design/cloud/key-manager.md). The key is a recovery seed (seed.hpp); servers wrap vault keys to its X25519 key as
// ordinary KEV1 envelopes and verify what it signs with its Ed25519 key. Vectors: vectors/vhc.json `account_key`.
//
// Key statement: one per generation, seven lines joined by '\n', no trailing newline:
//
//   vhc-account-key-v1
//   <account public_id>      canonical UUID text: 36 characters, lower-case hex, 8-4-4-4-12
//   <generation>             decimal, 1 to 2^32 - 1, no leading zero
//   <X25519 public key>      base64url without padding (43 characters); a canonical u < 2^255 - 19, not of low order
//   <Ed25519 public key>     base64url without padding (43 characters)
//   <previous fingerprint>   empty for generation 1; otherwise the fingerprint text of generation - 1
//   <reason>                 generation 1: "initial"; later: "routine" or "compromise"
//
// Fingerprint = SHA-256(the first five lines joined by '\n')[0..16), written as eight groups of four lower-case hex
// digits joined by '-' (39 characters). It names the key of one generation of one account.
//
// Signatures are Ed25519 (RFC 8032) over the statement's exact bytes: `signature` by the statement's own Ed25519 key;
// from generation 2, `previous_signature` by the previous generation's key over the same bytes (a rotation), or none
// when no device could sign for it (a replacement, which a server pins only after a person confirms its fingerprint).
//
// Parsing errors, in the order checked: unsupported_version (a first line "vhc-account-key-v<digits>" other than
// v1), bad_statement (any other first line, or not exactly seven lines), bad_public_id, bad_generation, bad_base64url,
// bad_key (a decoded key of the wrong size, or an X25519 key that is non-canonical or of low order), bad_previous,
// bad_reason.
namespace vl::keykit::account {

inline constexpr std::string_view kStatementMagic = "vhc-account-key-v1";
inline constexpr std::size_t kFingerprintSize = 16;
inline constexpr std::size_t kFingerprintTextSize = 39;
inline constexpr std::size_t kSignatureSize = 64;
inline constexpr std::size_t kPublicKeySize = 32;

using Fingerprint = std::array<uint8_t, kFingerprintSize>;
using Signature = std::array<uint8_t, kSignatureSize>;
using PublicKey = std::array<uint8_t, kPublicKeySize>;
using Digest = std::array<uint8_t, 32>;

// The account key statement's and the recovery policy's errors (recovery_policy.hpp), spelled in the vectors as
// errorCodeName gives them.
enum class ErrorCode : uint8_t {
    // statement
    UnsupportedVersion,
    BadStatement,
    BadPublicId,
    BadGeneration,
    BadBase64Url,
    BadKey,
    BadPrevious,
    BadReason,
    // chain
    AccountMismatch,
    GenerationGap,
    BadSignature,
    PreviousMismatch,
    BadPreviousSignature,
    // following a pin
    Rollback,
    PinMismatch,
    // recovery policy (recovery_policy.hpp)
    BadPolicy,
    BadSequence,
    BadIssuedAt,
    BadRecipient,
    RecipientIdMismatch,
    UnsupportedSuite,
    UnsupportedClass,
    BadLabel,
    UnsupportedScope,
    UnsortedRecipients,
    TooManyRecipients,
    GenerationMismatch,
    AccountKeyListed,
};

[[nodiscard]] std::string_view errorCodeName(ErrorCode code);

// `index()`: the position in the chain of the statement that failed, when a chain was being checked.
class Error : public std::runtime_error {
public:
    explicit Error(ErrorCode code, std::optional<std::size_t> index = std::nullopt);
    [[nodiscard]] ErrorCode code() const noexcept { return code_; }
    [[nodiscard]] std::optional<std::size_t> index() const noexcept { return index_; }

private:
    ErrorCode code_;
    std::optional<std::size_t> index_;
};

enum class Reason : uint8_t { Initial, Routine, Compromise };
[[nodiscard]] std::string_view reasonName(Reason reason);

struct KeyStatement {
    std::string public_id{};  // canonical UUID text
    uint32_t generation{};
    PublicKey x25519_public{};
    PublicKey ed25519_public{};
    std::optional<Fingerprint> previous{};  // nullopt exactly for generation 1
    Reason reason{Reason::Initial};
    [[nodiscard]] bool operator==(const KeyStatement&) const = default;
};

// The statement a device publishes for `seed` (generation 1 with no previous fingerprint and reason Initial; later
// ones name the previous generation's fingerprint). Throws std::invalid_argument for anything encode would refuse.
[[nodiscard]] KeyStatement statementFor(const RecoverySeed& seed, std::string_view publicId, uint32_t generation,
                                        std::optional<Fingerprint> previous, Reason reason);

// The canonical text. Throws std::invalid_argument for a statement parse would refuse.
[[nodiscard]] std::string encode(const KeyStatement& statement);
// Strict: the only accepted text for a statement is encode's. Throws Error.
[[nodiscard]] KeyStatement parseStatement(std::string_view text);

[[nodiscard]] Fingerprint fingerprint(const KeyStatement& statement);
[[nodiscard]] std::string fingerprintText(const Fingerprint& fp);
// The canonical text only (lower case, '-' between groups). With `lenient`, also what a person types: upper case,
// and any of '-', ' ' or nothing between groups. nullopt otherwise.
[[nodiscard]] std::optional<Fingerprint> parseFingerprint(std::string_view text, bool lenient = false);

struct SignedStatement {
    std::string statement{};
    Signature signature{};
    std::optional<Signature> previous_signature{};
};

// Signs encode(statement) with `key` (whose derived public keys must be the statement's) and, for a rotation, with
// `previous` (whose generation - 1 fingerprint must be the statement's previous one). Throws std::invalid_argument when
// a seed doesn't match.
[[nodiscard]] SignedStatement sign(const KeyStatement& statement, const RecoverySeed& key,
                                   const RecoverySeed* previous = nullptr);

// Ed25519 over arbitrary bytes with the account key (the recovery policy uses it). The seed's Ed25519 key signs.
[[nodiscard]] Signature signBytes(std::span<const uint8_t> message, const RecoverySeed& key);
[[nodiscard]] bool verifyBytes(const PublicKey& ed25519Public, std::span<const uint8_t> message,
                               const Signature& signature);

enum class Link : uint8_t { Initial, Rotation, Replacement };
[[nodiscard]] std::string_view linkName(Link link);

struct VerifiedGeneration {
    KeyStatement statement{};
    Fingerprint fingerprint{};
    Link link{Link::Initial};
};

// The whole chain as the cloud serves it, generation 1 first. Each statement must parse; name `publicId`
// (account_mismatch); be generation i + 1 at position i (generation_gap: skipped, repeated or reordered); verify under
// its own key (bad_signature); from generation 2 name the fingerprint of the one before (previous_mismatch); and carry
// either a previous signature that verifies under the previous generation's key (a Rotation; bad_previous_signature
// otherwise, also for one on generation 1) or none (a Replacement). Throws Error with the failing position; an empty
// chain is bad_statement.
[[nodiscard]] std::vector<VerifiedGeneration> verifyChain(std::span<const SignedStatement> chain,
                                                          std::string_view publicId);

// What a server has pinned: a generation whose fingerprint a person confirmed (or reached through rotations).
struct Pin {
    uint32_t generation{};
    Fingerprint fingerprint{};
};

struct FollowResult {
    // The highest generation reached from the pin through signed rotations only (the pin's own when none): the server
    // pins it without asking anyone.
    uint32_t accepted{};
    // The chain's newest generation. When it is above `accepted`, generation accepted + 1 is a replacement and every
    // newer one waits for a person to confirm the newest fingerprint; the server keeps wrapping to `accepted`.
    uint32_t newest{};
    [[nodiscard]] bool needsConfirmation() const noexcept { return newest > accepted; }
};

// Follows a verified chain from a pin. rollback: the chain ends below the pinned generation; pin_mismatch: its
// statement of the pinned generation has another fingerprint (another key under a number already pinned).
[[nodiscard]] FollowResult follow(const Pin& pin, std::span<const VerifiedGeneration> chain);

}
