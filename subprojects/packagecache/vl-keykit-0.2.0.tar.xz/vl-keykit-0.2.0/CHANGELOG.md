# Changelog

All notable changes to vl-keykit are recorded here. The format follows [Keep a Changelog](https://keepachangelog.com/),
and versions follow [Semantic Versioning](https://semver.org/) (before 1.0, a minor version may break the API).

## [Unreleased]

## [0.2.0]

### Added

- The Vaulthalla Cloud account recovery key formats, with their own golden vectors (`vectors/vhc.json`, 146 vectors)
  and an independent Python reference (`vectors/vhc_vectors.py --check`, run by `meson test` as
  `vhc-vectors-reference`):
  - `account_key.hpp`: the `vhc-account-key-v1` key statement (`encode`, strict `parseStatement`, `statementFor`),
    its `fingerprint` and fingerprint text, Ed25519 signing (`sign`, `signBytes`, `verifyBytes`), `verifyChain`
    (rotations signed by both generations, replacements) and `follow` from a server's pin.
  - `recovery_policy.hpp`: the signed `vhc-recovery-policy-v1` document (`encode`, `parsePolicy`, `signPolicy`,
    `verifyPolicy` against a pinned generation), `policyHash`, and the sequence rules (`compareToFloor`,
    `isNextSequence`); the caller stores the floor.
  - `kak1.hpp`: KAK1, the account key wrapped to a holder's X25519 or P-256 key (`wrap`, `unwrap`, `unwrapWith` for a
    key that never leaves its hardware, `inspect`).
  - `vault_label.hpp`: a vault's display name sealed to the account key (`vh.vault-label.v1`), padded to 128 bytes.
  - `storage_credential.hpp`: a managed bucket's key secret sealed to a server's one-time X25519 key
    (`vhc-storage-credential-v1`), bound to the installation, vault and key id.
  - `base64url.hpp`: strict unpadded base64url.

### Changed

- KEV1's ECDH, HKDF and AES-GCM helpers are shared with the new sealed formats (`src/sealing.{hpp,cpp}`), and its
  temporaries (ephemeral secret, shared secret, wrapping key) are held in `SecretBytes`. Every KEV1 vector is
  reproduced unchanged.

## [0.1.0]

### Added

- First release, extracted from vaulthalla-server 1.22.2 (`core/{include,src}/crypto/recovery/`, `crypto/id/ObjectUid`
  and `crypto/SecretBytes`). Byte-compatible with it: every `kev1`, `recovery_seed` and `object_ids` golden vector
  is reproduced.
  - `kev1`: `wrap`, `unwrap`, `inspect`, `recipientId`, `publicKeyOf`, `kid`, `objectKey`, `skippedByRestore`, and
    the reader's ordered `ErrorCode`s.
  - `RecoverySeed`: `generate`, `parse`, `fromBytes`, `text`, and the X25519 and Ed25519 derivations.
  - The recovery kit codec (`parseKit`, `toJson`, `kitVaultFromJson`) and strict standard base64.
  - `Uid`, `newUid`, strict `toBase32` / `fromBase32`.
  - `SecretBytes` (locked, wiped, move-only), `wipe`, `equalConstantTime`, and the test wipe observer.
- `vectors/`: a verbatim copy of vaulthalla-server's golden vectors and their Python reference, checked by
  `meson test` (`vectors-reference`).

### Changed (from the vaulthalla-server code)

- OpenSSL 3 is the only crypto dependency: X25519 and Ed25519 public keys, SHA-256, the CSPRNG
  (`RAND_priv_bytes` for secrets), wiping (`OPENSSL_cleanse`) and constant-time comparison (`CRYPTO_memcmp`) no
  longer come from libsodium. Memory locking uses `mlock`.
- `kev1::wrap` takes the vault key as 32 bytes (`std::span`), and `kev1::Unwrapped::key` is `SecretBytes`, so the
  library has no key type of its own.
