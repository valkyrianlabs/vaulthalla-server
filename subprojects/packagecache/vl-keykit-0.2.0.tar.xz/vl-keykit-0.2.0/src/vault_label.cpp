// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Valkyrian Labs LLC
#include "vl/keykit/vault_label.hpp"

#include "sealing.hpp"
#include "text.hpp"

#include <algorithm>
#include <utility>

namespace vl::keykit::label {

namespace {

constexpr std::array<std::pair<ErrorCode, std::string_view>, 10> kErrorNames{{
    {ErrorCode::BadMagic, "bad_magic"},
    {ErrorCode::UnsupportedVersion, "unsupported_version"},
    {ErrorCode::UnsupportedSuite, "unsupported_suite"},
    {ErrorCode::AccountMismatch, "account_mismatch"},
    {ErrorCode::VaultMismatch, "vault_mismatch"},
    {ErrorCode::KeyMismatch, "key_mismatch"},
    {ErrorCode::BadLength, "bad_length"},
    {ErrorCode::BadEphemeral, "bad_ephemeral"},
    {ErrorCode::AuthFailed, "auth_failed"},
    {ErrorCode::BadLabel, "bad_label"},
}};

constexpr std::string_view kInfo = "vh.vault-label.v1";
constexpr uint16_t kSuite = static_cast<uint16_t>(kev1::Suite::X25519);
constexpr std::size_t kOffVersion = 8, kOffSuite = 10, kOffGeneration = 12, kOffPublicId = 16, kOffVaultUid = 32,
                      kOffFingerprint = 48, kOffEpk = 64;

std::array<uint8_t, 16> publicIdBytes(const account::KeyStatement& statement) {
    const auto id = detail::parseUuid(statement.public_id);
    if (!id) throw std::invalid_argument("the statement's public id is not a canonical UUID");
    return *id;
}

void checkStructure(const std::span<const uint8_t> sealed) {
    if (sealed.size() < kPrefixSize || !std::equal(kMagic.begin(), kMagic.end(), sealed.begin()))
        throw Error(ErrorCode::BadMagic);
    if (detail::be16(sealed.data() + kOffVersion) != kVersion) throw Error(ErrorCode::UnsupportedVersion);
    if (detail::be16(sealed.data() + kOffSuite) != kSuite) throw Error(ErrorCode::UnsupportedSuite);
}

}

std::string_view errorCodeName(const ErrorCode code) {
    for (const auto& [c, name] : kErrorNames)
        if (c == code) return name;
    return "unknown";
}

Error::Error(const ErrorCode code)
    : std::runtime_error("vault label rejected: " + std::string(errorCodeName(code))), code_(code) {}

bool isSealableName(const std::string_view name) { return detail::isLabel(detail::viewBytes(name), kPaddedSize); }

std::vector<uint8_t> seal(const std::string_view name, const account::KeyStatement& pinned, const Uid& vaultUid,
                          const std::span<const uint8_t> ephemeralSecretForTesting) {
    if (!isSealableName(name)) throw std::invalid_argument("a vault label is 1-128 bytes of UTF-8 without controls");
    (void)account::encode(pinned);
    const auto peer = detail::publicKey(kev1::Suite::X25519, pinned.x25519_public);
    const auto esk = detail::ephemeralSecret(kev1::Suite::X25519, ephemeralSecretForTesting);
    const auto mine = detail::secretKey(kev1::Suite::X25519, esk.bytes());
    if (!mine || !peer) throw std::invalid_argument("bad X25519 key");
    const auto epk = kev1::publicKeyOf(kev1::Suite::X25519, esk.bytes());
    const auto z = detail::agree(mine.get(), peer.get());
    if (!z) throw Error(ErrorCode::BadEphemeral);

    std::vector<uint8_t> out(kMagic.begin(), kMagic.end());
    detail::putBe16(out, kVersion);
    detail::putBe16(out, kSuite);
    detail::putBe32(out, pinned.generation);
    detail::append(out, publicIdBytes(pinned));
    detail::append(out, vaultUid);
    detail::append(out, account::fingerprint(pinned));
    detail::append(out, epk);
    std::array<uint8_t, kPaddedSize> padded{};
    std::ranges::copy(detail::viewBytes(name), padded.begin());
    const auto key = detail::deriveKey(z->bytes(), epk, pinned.x25519_public, kInfo, out);
    detail::append(out, detail::aeadSeal(key.bytes(), padded, out));
    return out;
}

std::string open(const std::span<const uint8_t> sealed, const std::span<const uint8_t> accountX25519Secret,
                 const account::KeyStatement& statement, const Uid& vaultUid) {
    if (accountX25519Secret.size() != kev1::kX25519KeySize) throw std::invalid_argument("an X25519 secret is 32 bytes");
    checkStructure(sealed);
    const auto id = publicIdBytes(statement);
    if (!std::equal(id.begin(), id.end(), sealed.begin() + kOffPublicId)) throw Error(ErrorCode::AccountMismatch);
    if (!std::equal(vaultUid.begin(), vaultUid.end(), sealed.begin() + kOffVaultUid))
        throw Error(ErrorCode::VaultMismatch);
    const auto fp = account::fingerprint(statement);
    if (detail::be32(sealed.data() + kOffGeneration) != statement.generation ||
        !std::equal(fp.begin(), fp.end(), sealed.begin() + kOffFingerprint))
        throw Error(ErrorCode::KeyMismatch);
    if (sealed.size() != kSealedSize) throw Error(ErrorCode::BadLength);
    const auto prefix = sealed.first(kPrefixSize);
    const auto epk = sealed.subspan(kOffEpk, kev1::kX25519KeySize);
    const auto mine = detail::secretKey(kev1::Suite::X25519, accountX25519Secret);
    const auto peer = detail::publicKey(kev1::Suite::X25519, epk);
    const auto z = detail::agree(mine.get(), peer.get());
    if (!z) throw Error(ErrorCode::BadEphemeral);
    const auto key = detail::deriveKey(z->bytes(), epk, statement.x25519_public, kInfo, prefix);
    const auto padded = detail::aeadOpen(key.bytes(), sealed.subspan(kPrefixSize), prefix);
    if (!padded) throw Error(ErrorCode::AuthFailed);
    const auto bytes = padded->bytes();
    const auto end = std::ranges::find(bytes, uint8_t{0});
    const auto name = bytes.first(static_cast<std::size_t>(end - bytes.begin()));
    if (!std::all_of(end, bytes.end(), [](const uint8_t b) { return b == 0; }) || !detail::isLabel(name, kPaddedSize))
        throw Error(ErrorCode::BadLabel);
    return {name.begin(), name.end()};
}

uint32_t sealedGeneration(const std::span<const uint8_t> sealed) {
    checkStructure(sealed);
    if (sealed.size() != kSealedSize) throw Error(ErrorCode::BadLength);
    return detail::be32(sealed.data() + kOffGeneration);
}

}
