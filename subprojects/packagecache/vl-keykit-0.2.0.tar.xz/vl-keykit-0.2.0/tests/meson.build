# SPDX-License-Identifier: MIT
# Copyright (c) 2026 Valkyrian Labs LLC
test_sources = files(
  'test_account_key.cpp',
  'test_cloud_sealing.cpp',
  'test_kev1.cpp',
  'test_recovery_policy.cpp',
  'test_seed_kit.cpp',
  'test_uid_secret.cpp',
)

vl_keykit_tests = executable('vl-keykit-tests', test_sources,
  dependencies: [vl_keykit_dep, gtest_dep],
  include_directories: include_directories('../src'),  # white-box tests use the private sealing helpers
  cpp_args: ['-DVL_KEYKIT_VECTORS_DIR="' + meson.project_source_root() / 'vectors' + '"'],
  build_by_default: true,
  install: false,
)

test('vl-keykit', vl_keykit_tests, timeout: 120)

python = find_program('python3', required: false)
if python.found()
  # The same for the Vaulthalla Cloud formats (vectors/vhc.json, written by vhc_vectors.py in this repository).
  test('vhc-vectors-reference', python,
    args: ['-c', '''
import importlib.util, subprocess, sys
if importlib.util.find_spec("cryptography") is None:
    sys.exit(77)
sys.exit(subprocess.call([sys.executable, sys.argv[1], "--check"]))
''', meson.project_source_root() / 'vectors' / 'vhc_vectors.py'],
  )

  # The independent Python reference: regenerates the vectors, compares them with vectors.json byte for byte, and
  # runs its own reader over every vector. Skipped (exit 77) where the `cryptography` package is missing.
  test('vectors-reference', python,
    args: ['-c', '''
import importlib.util, subprocess, sys
if importlib.util.find_spec("cryptography") is None:
    sys.exit(77)
sys.exit(subprocess.call([sys.executable, sys.argv[1], "--check"]))
''', meson.project_source_root() / 'vectors' / 'vh_crypto_vectors.py'],
  )
endif
