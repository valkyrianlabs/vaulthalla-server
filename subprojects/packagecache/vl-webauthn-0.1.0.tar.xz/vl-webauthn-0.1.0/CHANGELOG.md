# Changelog

All notable changes to vl-webauthn are recorded here. The format follows [Keep a Changelog](https://keepachangelog.com/),
and versions follow [Semantic Versioning](https://semver.org/) (before 1.0, a minor version may break the API).

## [Unreleased]

## [0.1.0]

### Added

- First release, extracted from vaulthalla-server (`core/{include,src}/auth/webauthn/`, #355) with its tests, W3C and
  recorded vectors, fuzz targets and seed corpora. Namespace `vl::webauthn`.

### Fixed

- Builds against OpenSSL 4 as well as 3: `X509_get_subject_name` and `X509_get_ext` return const there, and
  `ASN1_STRING_length` is deprecated from 4.1 on.
