# Vectors

Data files, kept byte for byte as vaulthalla-server recorded them (`core/test-assets/webauthn/`, #355):

- `w3c-webauthn-l3-vectors.json`: the test vectors of WebAuthn Level 3, section 16, extracted from the
  specification by `tools/extract_w3c_webauthn_vectors.py`. Replayed by `tests/test_vectors.cpp`.
- `chrome-virtual-authenticator.json`: ceremonies recorded from Chrome's virtual authenticator through the CDP
  WebAuthn domain by `tools/record-webauthn-fixtures.mjs`. Replayed by `tests/test_recorded.cpp`.

Their `source` fields name the tools by their vaulthalla-server paths (`tools/dev/`). Regenerating them here writes
the same content under the paths in `tools/`.
