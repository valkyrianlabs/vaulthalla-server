// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Valkyrian Labs LLC
// libFuzzer: clientDataJSON and the browser's response JSON (RegistrationResponseJSON / AuthenticationResponseJSON).
// Seeds: corpus/client_data/.
#include "vl/webauthn/ClientData.hpp"
#include "vl/webauthn/Wire.hpp"

#include <cstddef>
#include <cstdint>
#include <string_view>

extern "C" int LLVMFuzzerTestOneInput(const std::uint8_t* data, const std::size_t size) {
    namespace wa = vl::webauthn;
    (void)wa::clientdata::parse(wa::ByteView(data, size));
    const std::string_view text(reinterpret_cast<const char*>(data), size);
    (void)wa::wire::parseRegistration(text);
    (void)wa::wire::parseAssertion(text);
    return 0;
}
