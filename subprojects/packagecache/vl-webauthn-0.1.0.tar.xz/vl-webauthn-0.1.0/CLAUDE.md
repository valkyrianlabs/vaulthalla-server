# vl-webauthn

A strict WebAuthn relying-party verifier for C++23: registration (`none` and `packed` attestation) and assertion
ceremonies, ES256 / EdDSA / RS256, a single-use challenge store, and strict CBOR, COSE, authenticatorData and
clientDataJSON parsers. Extracted from vaulthalla-server `core/{include,src}/auth/webauthn/` (#355, the MFA design's
section 4.1) and shared by vaulthalla-server and vaulthalla-cloud. Owner: **Valkyrian Labs LLC**. License: **MIT**
(`Copyright (c) 2026 Valkyrian Labs LLC`). Repository: `valkyrianlabs/vl-webauthn` (private).

## Map

| Path | What |
| --- | --- |
| `include/vl/webauthn/` | public headers; `Verifier.hpp` (the ceremonies) and `Challenge.hpp` (the store) are the entry points |
| `src/` | implementation; `OpenSsl.{hpp,cpp}` are internal helpers |
| `tests/` | GoogleTest suite (parsers, ceremonies, W3C vectors, recorded Chrome ceremonies, corpus replay) and `test_contract.py` |
| `vectors/` | the W3C WebAuthn L3 test vectors and Chrome virtual-authenticator recordings (see its README) |
| `fuzz/` | the three libFuzzer targets and their committed seed corpora (`corpus/<target>/`) |
| `tools/` | `fuzz.sh`, the vector extractor, the Chrome recorder, the seed-corpus writer |
| `ci/` | `run-ci` (verbatim from vaulthalla-server), `Containerfile` |

## Commands

```bash
meson setup build -Db_sanitize=address,undefined && meson compile -C build && meson test -C build --print-errorlogs
# macOS: PKG_CONFIG_PATH=/opt/homebrew/lib/pkgconfig:/opt/homebrew/share/pkgconfig meson setup build-mac -Dtests=enabled
CXX=clang++-18 tools/fuzz.sh --seconds 60     # libFuzzer, ASan/UBSan; --merge folds new coverage into fuzz/corpus
CI_CACHE_NAMES=ccache ./ci/run-ci meson test -C build   # the CI container (Podman); run it on `ssh dev`
```

## Rules

- **Licensing.** MIT. Every source file (C++, meson, scripts, workflows) starts with an SPDX MIT line and
  `Copyright (c) 2026 Valkyrian Labs LLC`. `vectors/` and `fuzz/corpus/` are data and keep their bytes. Code may be
  taken from Vaulthalla (AGPL) only because the LLC owns both; never import third-party code.
- **Scope.** Namespace `vl::webauthn`. Dependencies: libcbor, OpenSSL 3 or 4, libsodium and nlohmann_json only. No
  host concepts: no database, sessions, config or logging. A failure is a `Failure` value the host logs and audits.
  `tests/test_contract.py` pins the include boundary.
- **Strictness is the point.** Every check of the design's table runs, in order; any failure refuses. User
  verification is always required: `UserVerification::Preferred` exists for the W3C vectors only and is never
  selected by the library (hosts pin the same for their code).
- **Fuzzed.** A parser change runs `tools/fuzz.sh`; a reproducer of any fixed crash goes into its target's corpus, which
  the unit tests replay (`WebAuthnFuzzCorpus`).
- **Builds are silent.** Zero warnings on GCC 14 and clang at `warning_level=3`, against OpenSSL 3 and 4; fix causes,
  never suppress.
- **Tests with every change**, positive and negative; the suite passes under ASan/UBSan.
