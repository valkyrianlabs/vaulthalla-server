# SPDX-License-Identifier: MIT
# Copyright (c) 2026 Valkyrian Labs LLC
"""The verifier stays self-contained, strict and fuzzed (Vaulthalla's MFA design section 4.1, decision D5).

- Its sources include only each other, the standard library, libcbor, OpenSSL, libsodium and nlohmann/json.
- UserVerification::Preferred (the spec policy knob the W3C vectors need) is selected only by the tests.
- CI fuzzes every target, and every target has a committed seed corpus.
"""

import re
import unittest
from pathlib import Path

REPO = Path(__file__).resolve().parents[1]
ALLOWED_INCLUDE = re.compile(
    r'^#include (?:"vl/webauthn/[A-Za-z0-9]+\.hpp"|<(?:openssl/[a-z0-9_]+\.h|cbor\.h|sodium\.h|nlohmann/json(?:_fwd)?\.hpp|'
    r"[a-z_]+)>)$"
)


def sources() -> list[Path]:
    return sorted(p for root in (REPO / "include", REPO / "src") for p in root.rglob("*") if p.suffix in {".cpp", ".hpp"})


class BoundaryContract(unittest.TestCase):
    def test_sources_include_only_their_dependencies(self) -> None:
        self.assertGreater(len(sources()), 20)
        offenders = []
        for path in sources():
            for lineno, line in enumerate(path.read_text(encoding="utf-8").splitlines(), 1):
                if line.startswith("#include") and not ALLOWED_INCLUDE.match(line):
                    offenders.append(f"{path.relative_to(REPO)}:{lineno}: {line}")
        self.assertEqual(offenders, [], "\n".join(offenders))

    def test_no_file_scope_using_namespace(self) -> None:
        for path in sources():
            with self.subTest(path=str(path.relative_to(REPO))):
                self.assertNotRegex(path.read_text(encoding="utf-8"), r"(?m)^using namespace")

    def test_user_verification_is_never_relaxed_by_the_library(self) -> None:
        offenders = [str(p.relative_to(REPO)) for p in (REPO / "src").rglob("*.cpp")
                     if "UserVerification::Preferred" in p.read_text(encoding="utf-8")]
        self.assertEqual(offenders, [])


class FuzzContract(unittest.TestCase):
    def test_ci_fuzzes_every_target_with_a_seed_corpus(self) -> None:
        workflow = (REPO / ".github" / "workflows" / "ci.yml").read_text(encoding="utf-8")
        self.assertIn("bash tools/fuzz.sh --seconds 60", workflow)
        script = (REPO / "tools" / "fuzz.sh").read_text(encoding="utf-8")
        self.assertIn("-Dfuzz=true -Db_sanitize=address,undefined", script)
        for target in ("cbor_cose", "authenticator_data", "client_data"):
            with self.subTest(target=target):
                self.assertTrue((REPO / "fuzz" / f"fuzz_{target}.cpp").is_file())
                self.assertIn(target, script)
                corpus = REPO / "fuzz" / "corpus" / target
                self.assertTrue(corpus.is_dir() and any(corpus.iterdir()), f"{corpus} needs a committed seed corpus")


if __name__ == "__main__":
    unittest.main()
