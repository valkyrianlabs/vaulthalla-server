# vl-webauthn

A strict WebAuthn relying-party verifier for C++23, shared by Vaulthalla Server and Vaulthalla Cloud:

- **Ceremonies** (`vl/webauthn/Verifier.hpp`): registration with `none` or `packed` attestation (self and x5c),
  and assertions; ES256, EdDSA (Ed25519) and RS256 only. Every check of the design's table runs, in its order, and any
  failure refuses with a `Failure` value for the host's log.
- **Challenges** (`vl/webauthn/Challenge.hpp`): single-use, short-lived, bound to the session, purpose, user and
  scope that asked; consumed before any signature is checked.
- **Strict parsers**: CBOR (definite lengths, canonical, no duplicate keys or trailing bytes), COSE keys,
  authenticatorData, clientDataJSON, and the relying party's configuration. All three parser groups are fuzzed.
- **Vectors**: the W3C WebAuthn Level 3 test vectors and ceremonies recorded from Chrome's virtual authenticator
  (`vectors/`).

The library knows nothing about its host: credential lookup is an interface, and logging, auditing and storage are
the host's.

Dependencies: libcbor (>= 0.10), OpenSSL 3 or 4, libsodium, nlohmann_json; GoogleTest for the tests, clang 18 for
fuzzing.

```bash
meson setup build -Db_sanitize=address,undefined && meson compile -C build && meson test -C build --print-errorlogs
CXX=clang++-18 tools/fuzz.sh --seconds 60
```

Consume it as a meson subproject (`dependency('vl-webauthn', fallback: ['vl-webauthn', 'vl_webauthn_dep'])`) or
through pkg-config (`vl-webauthn`).

© 2026 Valkyrian Labs LLC. MIT License (see `LICENSE`).
